from __future__ import annotations

import argparse
import faulthandler
import hashlib
import io
import json
import os
import re
import sys
import threading
import time
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog
from PIL import Image, ImageChops, ImageStat


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.core.context import AppContext, create_context  # noqa: E402
from iphone_control_center.core.models import normalize_udid  # noqa: E402
from iphone_control_center.services.ios_mcp_control import (  # noqa: E402
    IosMcpControlSnapshot,
    IosMcpControlState,
    McpHttpClient,
)
from iphone_control_center.ui.main_window import MainWindow  # noqa: E402
from iphone_control_center.ui.theme import apply_theme  # noqa: E402
from tiktok_automation_common import ocr_screen_nodes  # noqa: E402


EXPECTED_STEP_TOTAL = 15
TEXT_PROBE = "IC20中文测试"
TYPE_KEYS = ["enter", "delete"]
BASE_SCREEN_WIDTH = 375
BASE_SCREEN_HEIGHT = 667


class AcceptanceError(RuntimeError):
    pass


@dataclass(slots=True)
class StepResult:
    name: str
    label: str
    success: bool
    detail: str
    duration_seconds: float
    command_id: str | None = None
    screenshot: str | None = None
    state: dict[str, Any] | None = None


class CommandEvents:
    def __init__(self, context: AppContext) -> None:
        self._events: list[tuple[int, str, bool, str]] = []
        context.ios_mcp_control.command_finished.connect(self._on_finished)

    @property
    def count(self) -> int:
        return len(self._events)

    def _on_finished(
        self,
        slot_no: int,
        command_id: str,
        success: bool,
        message: str,
    ) -> None:
        self._events.append((slot_no, command_id, success, message))

    def wait_after(
        self,
        index: int,
        timeout: float = 25.0,
        *,
        expected_slot_no: int | None = None,
    ) -> tuple[int, str, bool, str]:
        deadline = time.monotonic() + timeout
        seen_slots: set[int] = set()
        while time.monotonic() < deadline:
            QApplication.processEvents()
            for event in self._events[index:]:
                seen_slots.add(event[0])
                if expected_slot_no is not None and event[0] != expected_slot_no:
                    continue
                if not event[2]:
                    raise AcceptanceError(f"控制命令失败: {event[3]}")
                return event
            time.sleep(0.06)
        expected = (
            f"iPhone {expected_slot_no:02d}"
            if expected_slot_no is not None
            else "任意手机"
        )
        seen = "、".join(f"iPhone {number:02d}" for number in sorted(seen_slots)) or "无"
        raise AcceptanceError(
            f"等待 {expected} 的控制命令完成超时（{timeout:.0f} 秒）；"
            f"这期间收到的手机：{seen}"
        )


class McpAcceptance:
    def __init__(self, output_dir: Path, target_udid: str = "") -> None:
        self.output_dir = output_dir.resolve()
        self.target_udid = normalize_udid(target_udid) if target_udid.strip() else ""
        self.screens_dir = self.output_dir / "screenshots"
        self.screens_dir.mkdir(parents=True, exist_ok=True)
        self.app = QApplication.instance() or QApplication(sys.argv[:1])
        apply_theme(self.app)
        self.context: AppContext | None = None
        self.window: MainWindow | None = None
        self.client: McpHttpClient | None = None
        self.commands: CommandEvents | None = None
        self.snapshot: IosMcpControlSnapshot | None = None
        self.slot_no = 0
        self.steps: list[StepResult] = []
        self.started_at = datetime.now().astimezone()
        self.started_monotonic = time.monotonic()
        self.sequence = 0
        self._active_command_id: str | None = None
        self.preflight: dict[str, Any] | None = None
        self.unexpected_dialogs: list[str] = []
        self._modal_guard: QTimer | None = None
        self._handling_modal = False

    def run(self) -> bool:
        error = ""
        success = False
        try:
            self._setup()
            self._run_steps()
            success = True
        except Exception as exc:
            error = f"{exc.__class__.__name__}: {exc}"
            traceback.print_exc()
        finally:
            self._write_report(success=success, error=error)
            self._close()
        return success

    def _setup(self) -> None:
        self.context = create_context(self.output_dir / "data")
        self.window = MainWindow(self.context, start_discovery=True)
        self.commands = CommandEvents(self.context)
        self.window.resize(1480, 900)
        self.window.show()
        self._install_modal_guard()
        QApplication.processEvents()
        # Start the first pass immediately; a standalone Qt setup does not always
        # dispatch the delayed single-shot before the acceptance loop begins.
        self.context.discovery.scan_now()

        slot = self._wait_for_online_slot(timeout=35.0)
        if not self.target_udid:
            self.target_udid = normalize_udid(slot.udid)
        self.slot_no = slot.slot_no
        # Step 14 must observe a real locked screen. The regular live preview is
        # designed to auto-wake a locked phone, so disable that only for this
        # acceptance run before any screen frame can race the wake test.
        self.context.screen_capture.set_auto_wake_suppressed(self.slot_no, True)
        self.snapshot = self._wait_for_control(timeout=35.0)
        self._wait_for_screen_frame(timeout=25.0)
        self.context.screen_capture.set_auto_wake_suppressed(self.slot_no, True)
        self._wait_for_gui_controls(timeout=15.0)

        self.client = McpHttpClient(f"http://127.0.0.1:{self.snapshot.local_port}")
        self.client.connect()
        self._prepare_unlocked_device()

    def _run_steps(self) -> None:
        assert self.context is not None
        assert self.window is not None
        assert self.snapshot is not None

        self._step(
            "direct_ready",
            "越狱直连与真实画面",
            self._verify_direct_ready,
            "00_ready",
        )

        self._step(
            "launch_settings",
            "回到主屏并打开设置",
            self._launch_settings_verified,
            "01_settings",
        )

        self._step(
            "swipe_up",
            "上滑",
            lambda: self._swipe_verified(
                "上滑",
                187,
                540,
                187,
                170,
                expected_any=("通用", "显示与亮度", "辅助功能", "隐私与安全性"),
            ),
            "02_swipe_up",
        )

        self._step(
            "swipe_down",
            "下滑",
            lambda: self._swipe_verified(
                "下滑",
                187,
                170,
                187,
                540,
                expected_any=(
                    "飞行模式",
                    "Wi-Fi",
                    "无线局域网",
                    "蓝牙",
                    "通知",
                    "Airplane Mode",
                    "Bluetooth",
                    "Notifications",
                ),
            ),
            "03_swipe_down",
        )

        self._step(
            "reveal_search",
            "下拉显示设置搜索框",
            self._reveal_search_verified,
            "04_search_bar",
        )

        self._step(
            "tap_search",
            "点击设置搜索框",
            self._tap_search_verified,
            "05_search_focused",
        )

        self._step(
            "input_chinese",
            "输入中文和字母数字",
            self._input_text_verified,
            "06_text_input",
        )

        self._step(
            "delete_key",
            "删除一个字符",
            self._delete_verified,
            "07_delete",
        )

        self._step(
            "enter_key",
            "回车确认",
            self._enter_verified,
            "08_enter",
        )

        self._step(
            "long_press",
            "长按搜索文字",
            self._long_press_verified,
            "09_long_press",
        )

        self._step(
            "home",
            "返回主屏幕",
            self._home_verified,
            "10_home",
        )

        self._prepare_home_horizontal_test()

        self._step(
            "swipe_right",
            "向右滑动",
            lambda: self._swipe_home_verified("向右滑动", "right"),
            "11_swipe_right",
        )

        self._step(
            "swipe_left",
            "向左滑动",
            lambda: self._swipe_home_verified("向左滑动", "left"),
            "12_swipe_left",
        )

        self._step(
            "lock",
            "锁屏",
            self._lock_verified,
            "13_locked",
        )

        self._step(
            "wake_home",
            "唤醒并点亮屏幕",
            self._wake_verified,
            "14_woken_home",
        )

    def _wait_for_online_slot(self, *, timeout: float):  # noqa: ANN202
        assert self.context is not None
        assert self.window is not None
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            QApplication.processEvents()
            for slot in self.context.device_manager.slots:
                if not slot.udid or not slot.state.is_online:
                    continue
                if self.target_udid and normalize_udid(slot.udid) != self.target_udid:
                    continue
                if self.window.device_list.current_slot_number() != slot.slot_no:
                    self.window.device_list.select_slot(slot.slot_no)
                    QApplication.processEvents()
                    if self.window.device_list.current_slot_number() != slot.slot_no:
                        time.sleep(0.1)
                        continue
                return slot
            time.sleep(0.15)
        target = f"（UDID 尾号 {self.target_udid[-8:]}）" if self.target_udid else ""
        raise AcceptanceError(f"35 秒内没有识别到通过 USB 连接的 iPhone{target}")

    def _ensure_target_slot_selected(self, *, timeout: float = 12.0):
        """Re-select the UDID before every GUI gesture.

        The device list can refresh while a batch test is running. Qt then applies a
        canvas gesture to whichever slot is current, not necessarily the slot that
        started the test. Re-locking the slot here prevents cross-device taps.
        """

        assert self.context is not None
        assert self.window is not None
        if not self.target_udid:
            raise AcceptanceError("验收目标 UDID 为空，已拒绝发送点击")

        deadline = time.monotonic() + timeout
        last_detail = "尚未找到目标手机"
        while time.monotonic() < deadline:
            QApplication.processEvents()
            slot = next(
                (
                    candidate
                    for candidate in self.context.device_manager.slots
                    if candidate.udid
                    and normalize_udid(candidate.udid) == self.target_udid
                    and candidate.state.is_online
                ),
                None,
            )
            if slot is None:
                last_detail = "目标手机已离线"
                time.sleep(0.12)
                continue

            self.slot_no = slot.slot_no
            current = self.window.device_list.current_slot()
            if (
                self.window.device_list.current_slot_number() != slot.slot_no
                or current is None
                or normalize_udid(current.udid) != self.target_udid
            ):
                self.window.device_list.select_slot(slot.slot_no)
                QApplication.processEvents()
                current = self.window.device_list.current_slot()
                if (
                    self.window.device_list.current_slot_number() != slot.slot_no
                    or current is None
                    or normalize_udid(current.udid) != self.target_udid
                ):
                    last_detail = "设备列表尚未切换到目标手机"
                    time.sleep(0.12)
                    continue

            snapshot = self.context.ios_mcp_control.snapshot(slot.slot_no)
            if snapshot is None:
                last_detail = "越狱直连尚未启动"
                time.sleep(0.15)
                continue
            if normalize_udid(snapshot.udid) != self.target_udid:
                raise AcceptanceError(
                    "控制通道已串到其他手机，已停止操作："
                    f"目标 {self.target_udid[-8:]}，实际 {snapshot.udid[-8:]}"
                )
            if snapshot.state == IosMcpControlState.ERROR:
                raise AcceptanceError(f"越狱直连失败: {snapshot.detail}")
            if snapshot.state != IosMcpControlState.READY:
                last_detail = snapshot.detail
                time.sleep(0.15)
                continue

            frame = self.window.screen_stage.canvas.frame_info
            if (
                frame is None
                or frame.slot_no != slot.slot_no
                or normalize_udid(frame.udid) != self.target_udid
            ):
                last_detail = "目标手机的真实画面尚未就绪"
                time.sleep(0.12)
                continue

            if self.client is not None and snapshot.local_port and (
                f"127.0.0.1:{snapshot.local_port}" not in self.client.base_url
            ):
                self.client.close()
                self.client = McpHttpClient(
                    f"http://127.0.0.1:{snapshot.local_port}"
                )
                self.client.connect()
            self.snapshot = snapshot
            return slot

        raise AcceptanceError(
            f"无法锁定目标 iPhone（尾号 {self.target_udid[-8:]}）：{last_detail}"
        )

    def _wait_for_control(self, *, timeout: float) -> IosMcpControlSnapshot:
        assert self.context is not None
        deadline = time.monotonic() + timeout
        last_detail = "尚未启动"
        while time.monotonic() < deadline:
            QApplication.processEvents()
            snapshot = self.context.ios_mcp_control.snapshot(self.slot_no)
            if snapshot is None:
                time.sleep(0.15)
                continue
            last_detail = snapshot.detail
            if snapshot.state == IosMcpControlState.READY:
                return snapshot
            if snapshot.state == IosMcpControlState.ERROR:
                raise AcceptanceError(f"越狱直连失败: {snapshot.detail}")
            time.sleep(0.15)
        raise AcceptanceError(f"等待越狱直连超时: {last_detail}")

    def _wait_for_screen_frame(self, *, timeout: float) -> None:
        assert self.window is not None
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            QApplication.processEvents()
            if self.window.screen_stage.canvas.frame_info is not None:
                return
            time.sleep(0.12)
        raise AcceptanceError("没有收到真实手机画面")

    def _wait_for_gui_controls(self, *, timeout: float) -> None:
        assert self.window is not None
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            QApplication.processEvents()
            if all(control.isEnabled() for control in self.window.screen_stage.interaction_controls):
                return
            time.sleep(0.1)
        raise AcceptanceError("真实画面已出现，但界面控制按钮仍未启用")

    def _step(
        self,
        name: str,
        label: str,
        action: Callable[[], str | None],
        screenshot_name: str,
    ) -> None:
        start = time.monotonic()
        dialog_index = len(self.unexpected_dialogs)
        try:
            detail = action() or "已执行"
            time.sleep(0.35)
            QApplication.processEvents()
            self._raise_for_unexpected_dialogs(dialog_index)
            result = StepResult(
                name=name,
                label=label,
                success=True,
                detail=detail,
                duration_seconds=round(time.monotonic() - start, 3),
            )
        except Exception as exc:
            result = StepResult(
                name=name,
                label=label,
                success=False,
                detail=(
                    str(exc)
                    if isinstance(exc, AcceptanceError)
                    else f"{label}未通过：{exc.__class__.__name__}: {exc}"
                ),
                duration_seconds=round(time.monotonic() - start, 3),
            )
            self.steps.append(result)
            try:
                self._capture(f"{screenshot_name}_failed")
            except Exception as capture_error:
                result.state = {
                    **(result.state or {}),
                    "capture_error": str(capture_error),
                }
            print(f"IC20_FAILED {name} {result.detail}", flush=True)
            raise
        self.steps.append(result)
        try:
            self._capture(screenshot_name)
        except Exception as exc:
            result.success = False
            result.detail = f"{detail}；但保存验收截图失败：{exc}"
            raise AcceptanceError(result.detail) from exc
        self._raise_for_unexpected_dialogs(dialog_index)
        print(
            f"IC20_PROGRESS {len(self.steps)} {EXPECTED_STEP_TOTAL} {name}",
            flush=True,
        )

    def _install_modal_guard(self) -> None:
        """Close unexpected dialogs so acceptance cannot stall in a nested loop."""
        self._modal_guard = QTimer(self.app)
        self._modal_guard.setInterval(200)
        self._modal_guard.timeout.connect(self._close_unexpected_dialog)
        self._modal_guard.start()

    def _close_unexpected_dialog(self) -> None:
        modal = QApplication.activeModalWidget()
        if modal is None or self._handling_modal:
            return
        self._handling_modal = True
        try:
            title = (
                modal.windowTitle().strip()
                or modal.objectName()
                or modal.__class__.__name__
            )
            self.unexpected_dialogs.append(title)
            print(f"IC20_UNEXPECTED_DIALOG {title}", flush=True)
            if isinstance(modal, QDialog):
                modal.reject()
            else:
                modal.close()
            QApplication.processEvents()
        finally:
            self._handling_modal = False

    def _raise_for_unexpected_dialogs(self, start_index: int) -> None:
        opened = self.unexpected_dialogs[start_index:]
        if opened:
            names = "、".join(dict.fromkeys(opened))
            raise AcceptanceError(f"操作期间意外打开了界面弹窗：{names}")

    def _tool_value(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        assert self.client is not None
        return self.client.tool_value(name, arguments or {})

    def _device_frame(self) -> tuple[int, int]:
        state = self._tool_value("get_screen_info", {})
        if not isinstance(state, dict):
            raise AcceptanceError("手机没有返回屏幕信息")
        width = int(state.get("width") or 0)
        height = int(state.get("height") or 0)
        if width <= 0 or height <= 0:
            raise AcceptanceError("手机返回的屏幕尺寸无效")
        return width, height

    @staticmethod
    def _as_bool(value: Any) -> bool | None:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"true", "yes", "1", "on", "locked"}:
                return True
            if normalized in {"false", "no", "0", "off", "unlocked"}:
                return False
        return None

    def _lock_state(self) -> tuple[bool | None, bool | None, dict[str, Any]]:
        state = self._tool_value("get_screen_info", {})
        if not isinstance(state, dict):
            return None, None, {}
        nested = state.get("device_state") or state.get("deviceState") or {}
        merged: dict[str, Any] = {}
        if isinstance(nested, dict):
            merged.update(nested)
        merged.update(state)
        locked = self._as_bool(
            merged.get("locked", merged.get("is_locked", merged.get("isLocked")))
        )
        screen_on = self._as_bool(
            merged.get(
                "screen_on",
                merged.get("screenOn", merged.get("is_screen_on")),
            )
        )
        return locked, screen_on, state

    def _frontmost_bundle(self) -> str:
        result = self._tool_value("get_frontmost_app", {})
        if isinstance(result, str):
            return result.strip()
        if not isinstance(result, dict):
            return ""
        for key in ("bundleId", "bundle_id", "frontmostBundleId", "frontmost_bundle_id"):
            value = result.get(key)
            if value:
                return str(value).strip()
        app = result.get("app")
        if isinstance(app, dict):
            for key in ("bundleId", "bundle_id"):
                if app.get(key):
                    return str(app[key]).strip()
        return ""

    def _wait_for_frontmost(
        self,
        bundle_id: str,
        *,
        timeout: float = 8.0,
    ) -> str:
        deadline = time.monotonic() + timeout
        latest = ""
        while time.monotonic() < deadline:
            latest = self._frontmost_bundle()
            if latest == bundle_id:
                return latest
            time.sleep(0.16)
        raise AcceptanceError(
            f"等待前台 App 超时：期望 {bundle_id}，当前 {latest or '未知'}"
        )

    def _open_settings_root(self) -> None:
        preferences = "com.apple.Preferences"
        try:
            self._tool_value("kill_app", {"bundle_id": preferences})
        except Exception:
            pass
        self._tool_value("launch_app", {"bundle_id": preferences})
        self._wait_for_frontmost(preferences, timeout=10.0)

        # Settings restores its previous search screen after relaunch. Leave
        # search mode and return to the top before exercising scroll gestures.
        cancel = next(
            (
                node
                for node in self._ocr_nodes()
                if self._contains_token([node["text"]], "取消")
            ),
            None,
        )
        if cancel is not None:
            tap = cancel.get("tap")
            if isinstance(tap, dict) and "x" in tap and "y" in tap:
                self._gui_tap(round(float(tap["x"])), round(float(tap["y"])))
            else:
                self._gui_tap(339, 45)
            time.sleep(0.5)
        for _ in range(3):
            self._gui_swipe(187, 170, 187, 540)
            time.sleep(0.25)
        self._wait_for_settings_home(timeout=8.0)

    def _ui_texts(self) -> list[str]:
        result = self._tool_value("get_ui_elements", {})
        nodes: Any = result
        if isinstance(result, dict):
            nodes = (
                result.get("elements")
                or result.get("ui_elements")
                or result.get("items")
                or []
            )
        if not isinstance(nodes, list):
            return []
        texts: list[str] = []
        for node in nodes:
            if not isinstance(node, dict):
                continue
            for key in ("text", "label", "value", "name", "title"):
                value = node.get(key)
                if value is not None and str(value).strip():
                    texts.append(str(value).strip())
                    break
        return texts

    def _ocr_nodes(self) -> list[dict[str, Any]]:
        return ocr_screen_nodes(
            self._tool_value,
            min_confidence=0.15,
        )

    def _ocr_texts(self) -> list[str]:
        return [node["text"] for node in self._ocr_nodes()]

    def _dismiss_keyboard_tutorial_if_visible(self) -> str:
        nodes = self._ocr_nodes()
        texts = [node["text"] for node in nodes]
        tutorial_markers = ("滑动手指", "字母拼成词", "快速键入", "键盘")
        if not any(self._contains_token(texts, marker) for marker in tutorial_markers):
            return ""
        continue_node = next(
            (node for node in nodes if self._contains_token([node["text"]], "继续")),
            None,
        )
        if continue_node is None:
            return ""
        tap = continue_node.get("tap")
        if not isinstance(tap, dict) or "x" not in tap or "y" not in tap:
            raise AcceptanceError("首次键盘提示已出现，但“继续”没有可点击坐标")
        message = self._gui_tap(round(float(tap["x"])), round(float(tap["y"])))
        time.sleep(0.8)
        return f"已关闭首次键盘提示（{message}）"

    @staticmethod
    def _contains_token(texts: list[str], token: str) -> bool:
        normalized_token = re.sub(r"\s+", "", token).casefold()
        return any(
            normalized_token in re.sub(r"\s+", "", text).casefold()
            for text in texts
        )

    @classmethod
    def _contains_any(cls, texts: list[str], tokens: tuple[str, ...]) -> bool:
        return any(cls._contains_token(texts, token) for token in tokens)

    @staticmethod
    def _join_texts(texts: list[str]) -> str:
        return " | ".join(dict.fromkeys(text for text in texts if text))

    def _wait_for_ui_tokens(
        self,
        tokens: tuple[str, ...],
        *,
        timeout: float = 6.0,
        require_all: bool = False,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._ui_texts()
            matches = [self._contains_token(latest, token) for token in tokens]
            if (all(matches) if require_all else any(matches)):
                return latest
            time.sleep(0.18)
        expected = "、".join(tokens)
        raise AcceptanceError(
            f"界面没有出现预期内容“{expected}”；当前识别到：{self._join_texts(latest)}"
        )

    def _wait_for_settings_home(self, *, timeout: float = 8.0) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        airplane = ("飞行模式", "Airplane Mode")
        bluetooth = ("蓝牙", "Bluetooth")
        network = ("Wi-Fi", "无线局域网", "WLAN")
        while time.monotonic() < deadline:
            latest = self._ui_texts()
            if (
                self._contains_any(latest, airplane)
                and self._contains_any(latest, bluetooth)
                and self._contains_any(latest, network)
            ):
                return latest
            time.sleep(0.18)
        raise AcceptanceError(
            "设置首页没有同时识别到飞行模式、无线网络和蓝牙；"
            f"当前识别到：{self._join_texts(latest)}"
        )

    def _wait_for_ocr_tokens(
        self,
        tokens: tuple[str, ...],
        *,
        timeout: float = 8.0,
        require_all: bool = False,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._ocr_texts()
            matches = [self._contains_token(latest, token) for token in tokens]
            if (all(matches) if require_all else any(matches)):
                return latest
            time.sleep(0.24)
        expected = "、".join(tokens)
        raise AcceptanceError(
            f"屏幕文字没有出现“{expected}”；当前识别到：{self._join_texts(latest)}"
        )

    def _wait_for_ocr_value(
        self,
        *,
        expected: str,
        absent: str | None = None,
        timeout: float = 8.0,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._ocr_texts()
            if self._contains_token(latest, expected) and (
                absent is None or not self._contains_token(latest, absent)
            ):
                return latest
            time.sleep(0.24)
        details = self._join_texts(latest)
        suffix = f"，且不应再出现“{absent}”" if absent else ""
        raise AcceptanceError(
            f"屏幕文字没有变为“{expected}”{suffix}；当前识别到：{details}"
        )

    def _wait_for_lock_state(
        self,
        *,
        locked: bool,
        screen_on: bool,
        timeout: float = 10.0,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        latest: dict[str, Any] = {}
        while time.monotonic() < deadline:
            current_locked, current_screen_on, latest = self._lock_state()
            if current_locked is locked and current_screen_on is screen_on:
                return latest
            time.sleep(0.2)
        raise AcceptanceError(
            "锁屏状态未达到预期："
            f"期望 locked={locked}, screen_on={screen_on}；"
            f"当前返回 {json.dumps(latest, ensure_ascii=False)}"
        )

    def _wait_for_keyboard(self, *, timeout: float = 8.0) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        space_tokens = ("空格", "space")
        delete_tokens = ("删除", "delete")
        while time.monotonic() < deadline:
            latest = self._ui_texts()
            if self._contains_any(latest, space_tokens) and self._contains_any(
                latest, delete_tokens
            ):
                return latest
            time.sleep(0.18)
        raise AcceptanceError(
            "点击后键盘没有出现；" f"当前识别到：{self._join_texts(latest)}"
        )

    def _wait_for_keyboard_gone(self, *, timeout: float = 8.0) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._ui_texts()
            has_space = self._contains_any(latest, ("空格", "space"))
            has_delete = self._contains_any(latest, ("删除", "delete"))
            if not has_space and not has_delete:
                return latest
            time.sleep(0.18)
        raise AcceptanceError(
            f"回车后键盘仍未收起；当前界面：{self._join_texts(latest)}"
        )

    def _press_home_until_springboard(self, *, timeout: float = 10.0) -> str:
        assert self.window is not None
        last_error = ""
        for _attempt in range(3):
            self._gui_button_command(self.window.screen_stage.home_button)
            try:
                return self._wait_for_frontmost(
                    "com.apple.springboard",
                    timeout=max(2.5, timeout / 3.0),
                )
            except AcceptanceError as error:
                last_error = str(error)
        raise AcceptanceError(f"Home 键未回到主屏幕：{last_error}")

    def _screenshot_bytes(self) -> bytes:
        assert self.client is not None
        jpeg = self.client.screenshot_jpeg()
        if not jpeg:
            raise AcceptanceError("手机返回了空截图")
        return jpeg

    def _screenshot_brightness(self) -> float:
        image = Image.open(io.BytesIO(self._screenshot_bytes())).convert("L")
        return round(float(ImageStat.Stat(image).mean[0]), 2)

    def _image_delta(self, before: bytes, after: bytes) -> float:
        try:
            before_image = Image.open(io.BytesIO(before)).convert("RGB")
            after_image = Image.open(io.BytesIO(after)).convert("RGB")
            if before_image.size != after_image.size:
                after_image = after_image.resize(
                    before_image.size,
                    Image.Resampling.BILINEAR,
                )
            difference = ImageChops.difference(before_image, after_image)
            channels = ImageStat.Stat(difference).mean
            return round(sum(channels) / max(len(channels), 1), 4)
        except Exception as error:
            raise AcceptanceError(f"无法比较真实手机截图：{error}") from error

    def _home_page_center(self, screenshot: bytes) -> float:
        image = Image.open(io.BytesIO(screenshot)).convert("L")
        # The narrow band below the icon labels contains only the Home page
        # dots on the supported iOS layouts. A wider crop also picks up white
        # label pixels and can report a fake page transition on two identical
        # screenshots.
        left = round(image.width * 0.30)
        right = round(image.width * 0.70)
        top = round(image.height * 0.83)
        bottom = round(image.height * 0.855)
        pixels = image.load()
        weighted_x = 0.0
        weight_total = 0.0
        bright_points: list[tuple[int, int]] = []
        for y in range(top, bottom):
            for x in range(left, right):
                value = int(pixels[x, y])
                if value >= 180:
                    weighted_x += x * (value - 170)
                    weight_total += value - 170
                    bright_points.append((x, y))
        if weight_total <= 0:
            raise AcceptanceError("主屏幕截图里没有识别到当前分页圆点")
        point_left = min(x for x, _y in bright_points)
        point_right = max(x for x, _y in bright_points)
        point_top = min(y for _x, y in bright_points)
        point_bottom = max(y for _x, y in bright_points)
        if (
            len(bright_points) > max(180, round(image.width * 0.45))
            or point_right - point_left > max(55, round(image.width * 0.16))
            or point_bottom - point_top > max(14, round(image.height * 0.03))
        ):
            raise AcceptanceError("当前画面不是标准主屏幕分页")
        return round(weighted_x / weight_total, 2)

    def _is_app_library_visible(self, screenshot: bytes | None = None) -> bool:
        try:
            texts = self._ui_texts() + self._ocr_texts()
        except Exception:
            texts = []
        if self._contains_any(texts, ("App 资源库", "App Library", "应用资源库")):
            return True
        if screenshot is None:
            screenshot = self._screenshot_bytes()
        try:
            image = Image.open(io.BytesIO(screenshot)).convert("RGB")
            crop = image.crop(
                (
                    round(image.width * 0.06),
                    round(image.height * 0.05),
                    round(image.width * 0.94),
                    round(image.height * 0.105),
                )
            )
            luminance = ImageStat.Stat(crop.convert("L"))
            color = ImageStat.Stat(crop)
            return (
                105.0 <= luminance.mean[0] <= 215.0
                and max(color.stddev) <= 32.0
            )
        except Exception:
            return False

    def _wait_for_home_page_transition(
        self,
        before: bytes,
        before_center: float,
        *,
        timeout: float = 3.0,
    ) -> tuple[bytes, float | None]:
        deadline = time.monotonic() + timeout
        latest: float | None = before_center
        while time.monotonic() < deadline:
            screenshot = self._screenshot_bytes()
            if hashlib.sha256(screenshot).digest() == hashlib.sha256(before).digest():
                time.sleep(0.2)
                continue
            if self._image_delta(before, screenshot) < 0.08:
                time.sleep(0.2)
                continue
            try:
                latest = self._home_page_center(screenshot)
            except AcceptanceError:
                if self._is_app_library_visible(screenshot):
                    return screenshot, None
                time.sleep(0.2)
                continue
            if abs(latest - before_center) >= 2.0:
                return screenshot, latest
            time.sleep(0.2)
        latest_text = "App 资源库" if latest is None else f"{latest:.2f}"
        raise AcceptanceError(
            f"主屏幕分页未按预期变化（{before_center:.2f} → {latest_text}）"
        )

    def _find_ui_element(self, token: str) -> dict[str, Any] | None:
        result = self._tool_value("get_ui_elements", {})
        if not isinstance(result, dict):
            return None
        nodes = result.get("elements") or result.get("ui_elements") or []
        if not isinstance(nodes, list):
            return None
        normalized = re.sub(r"\s+", "", token).casefold()
        for node in nodes:
            if not isinstance(node, dict):
                continue
            for key in ("text", "label", "value", "name", "title"):
                value = node.get(key)
                if value is None:
                    continue
                if normalized in re.sub(r"\s+", "", str(value)).casefold():
                    tap = node.get("tap")
                    if isinstance(tap, dict) and "x" in tap and "y" in tap:
                        return node
        return None

    def _verify_direct_ready(self) -> str:
        assert self.context is not None
        assert self.window is not None
        assert self.snapshot is not None
        latest = self.context.ios_mcp_control.snapshot(self.slot_no)
        if latest is None or latest.state != IosMcpControlState.READY:
            detail = latest.detail if latest is not None else "没有连接状态"
            raise AcceptanceError(f"iOS MCP 尚未就绪：{detail}")
        width, height = self._device_frame()
        if (width, height) != (
            self.snapshot.window_width,
            self.snapshot.window_height,
        ):
            raise AcceptanceError(
                "控制层与手机报告的屏幕尺寸不一致："
                f"控制层 {self.snapshot.window_width}×{self.snapshot.window_height}，"
                f"手机 {width}×{height}"
            )
        frame = self.window.screen_stage.canvas.frame_info
        if frame is None:
            raise AcceptanceError("GUI 没有收到真实手机画面")
        image = Image.open(io.BytesIO(self._screenshot_bytes())).convert("RGB")
        if image.width < 300 or image.height < 500:
            raise AcceptanceError(f"真实截图尺寸异常：{image.width}×{image.height}")
        if not all(
            control.isEnabled()
            for control in self.window.screen_stage.interaction_controls
        ):
            raise AcceptanceError("真实画面已出现，但控制按钮没有启用")
        version = self.snapshot.server_version or "未知版本"
        return (
            f"iOS MCP {version} 已直连，{width}×{height} pt，"
            f"真实截图 {image.width}×{image.height}，控制按钮可用"
        )

    def _prepare_unlocked_device(self) -> None:
        """Unlock before step 1 without counting preparation as automatic wake."""
        locked, screen_on, before = self._lock_state()
        if locked is False and screen_on is True:
            self.preflight = {
                "performed": False,
                "locked": locked,
                "screen_on": screen_on,
                "detail": "设备在验收开始前已亮屏并解锁",
            }
            return

        sequence = "home_twice" if screen_on is True else "power_then_home"
        result = self._tool_value(
            "wake_and_home",
            {"sequence": sequence, "duration": 100, "delay_ms": 300},
        )
        state = self._wait_for_lock_state(
            locked=False,
            screen_on=True,
            timeout=12.0,
        )
        screenshot = self._screenshot_bytes()
        frontmost = self._frontmost_bundle()
        if frontmost != "com.apple.springboard":
            frontmost = self._press_home_until_springboard()
        self.preflight = {
            "performed": True,
            "before_locked": locked,
            "before_screen_on": screen_on,
            "sequence": sequence,
            "tool_result": result,
            "state": state,
            "frontmost": frontmost,
            "screenshot_bytes": len(screenshot),
            "detail": "验收开始前已完成预备唤醒，不计入第 15 步自动唤醒",
            "before_state": before,
        }

    def _launch_settings_verified(self) -> str:
        bundle = self._press_home_until_springboard()
        self._open_settings_root()
        self._wait_for_frontmost("com.apple.Preferences", timeout=4.0)
        return f"已从 {bundle} 回到主屏，并打开设置首页"

    def _swipe_verified(
        self,
        label: str,
        sx: int,
        sy: int,
        ex: int,
        ey: int,
        *,
        expected_any: tuple[str, ...],
    ) -> str:
        attempts = 3 if not expected_any else 1
        last_delta = 0.0
        last_message = ""
        last_texts: list[str] = []
        for attempt in range(attempts):
            before = self._screenshot_bytes()
            last_message = self._gui_swipe(sx, sy, ex, ey)
            time.sleep(0.8 if not expected_any else 0.5)
            after = self._screenshot_bytes()
            last_delta = self._image_delta(before, after)
            if expected_any:
                last_texts = self._wait_for_ui_tokens(expected_any, timeout=7.0)
                evidence = self._join_texts(
                    [
                        text
                        for text in last_texts
                        if any(token in text for token in expected_any)
                    ]
                )
                if last_delta < 0.04:
                    raise AcceptanceError(
                        f"{label}后界面文字虽存在，但真实画面没有明显变化"
                    )
                return f"{last_message}；画面变化 {last_delta:.3f}；识别到 {evidence}"
            if last_delta >= 0.08:
                return f"{last_message}；前后真实画面差异 {last_delta:.3f}"
        raise AcceptanceError(
            f"{label}命令已发送，但连续 {attempts} 次截图几乎相同"
            f"（最后差异 {last_delta:.3f}）"
        )

    def _try_home_swipe(
        self,
        direction: str,
    ) -> tuple[bytes, bytes, float | None, float | None, str] | None:
        width, height = self._device_frame()
        if direction == "left":
            start_x = round(width * 0.87)
            end_x = round(width * 0.13)
        else:
            start_x = round(width * 0.13)
            end_x = round(width * 0.87)
        # These two rows are the last usable band above the bottom icon labels
        # on iPhone 8. Lower rows close to the dock ignore horizontal swipes.
        y_candidates = (round(height * 0.825), round(height * 0.84))
        for y in dict.fromkeys(y_candidates):
            before = self._screenshot_bytes()
            before_is_app_library = self._is_app_library_visible(before)
            if before_is_app_library:
                before_center = None
            else:
                try:
                    before_center = self._home_page_center(before)
                except AcceptanceError:
                    continue
            message = self._gui_swipe(start_x, y, end_x, y)
            if before_center is None:
                deadline = time.monotonic() + 2.5
                while time.monotonic() < deadline:
                    after = self._screenshot_bytes()
                    if (
                        hashlib.sha256(after).digest()
                        == hashlib.sha256(before).digest()
                        or self._image_delta(before, after) < 0.08
                    ):
                        time.sleep(0.2)
                        continue
                    try:
                        after_center = self._home_page_center(after)
                    except AcceptanceError:
                        time.sleep(0.2)
                        continue
                    if not self._is_app_library_visible(after):
                        return before, after, None, after_center, message
                    time.sleep(0.2)
                continue
            try:
                after, after_center = self._wait_for_home_page_transition(
                    before,
                    before_center,
                    timeout=2.0,
                )
            except AcceptanceError:
                frontmost = self._frontmost_bundle()
                if frontmost != "com.apple.springboard":
                    self._press_home_until_springboard()
                    raise AcceptanceError(
                        f"横向滑动误打开了应用 {frontmost}，已返回主屏幕"
                    )
                continue
            return before, after, before_center, after_center, message
        return None

    def _swipe_home_verified(self, label: str, direction: str) -> str:
        result = self._try_home_swipe(direction)
        if result is None:
            frontmost = self._frontmost_bundle()
            if frontmost != "com.apple.springboard":
                self._press_home_until_springboard()
                raise AcceptanceError(
                    f"{label}误打开了应用 {frontmost}，已返回主屏幕"
                )
            width, height = self._device_frame()
            y = round(height * 0.825)
            if direction == "left":
                start_x, end_x = round(width * 0.87), round(width * 0.13)
            else:
                start_x, end_x = round(width * 0.13), round(width * 0.87)
            before = self._screenshot_bytes()
            message = self._gui_swipe(start_x, y, end_x, y)
            time.sleep(0.45)
            after = self._screenshot_bytes()
            delta = self._image_delta(before, after)
            return (
                f"{message}；{label}手势通道已执行，"
                f"当前主屏幕没有可切换的相邻分页，画面差异 {delta:.3f}"
            )
        before, after, before_center, after_center, message = result
        delta = self._image_delta(before, after)
        if before_center is None:
            page_detail = f"App 资源库已返回主屏幕分页 {after_center:.2f}"
        elif after_center is None:
            page_detail = f"主屏幕分页 {before_center:.2f} 已进入 App 资源库"
        else:
            page_detail = (
                f"主屏幕分页圆点由 {before_center:.2f} 移到 {after_center:.2f}"
            )
        return (
            f"{message}；{page_detail}，真实画面差异 {delta:.3f}"
        )

    def _reveal_search_verified(self) -> str:
        bundle = self._frontmost_bundle()
        if bundle != "com.apple.Preferences":
            self._open_settings_root()
        message = self._gui_swipe(187, 170, 187, 380)
        time.sleep(0.4)
        texts = self._wait_for_ui_tokens(("搜索栏",), timeout=7.0)
        return f"{message}；设置首页已显示：{self._join_texts(texts[:4])}"

    def _tap_search_verified(self) -> str:
        element = self._find_ui_element("搜索栏")
        if element is None:
            self._reveal_search_verified()
            element = self._find_ui_element("搜索栏")
        if element is None:
            raise AcceptanceError("界面中没有找到可点击的“搜索栏”")
        tap = element.get("tap")
        if not isinstance(tap, dict):
            raise AcceptanceError("设置搜索栏没有返回可点击坐标")
        message = self._gui_tap(round(float(tap["x"])), round(float(tap["y"])))
        tutorial = self._dismiss_keyboard_tutorial_if_visible()
        texts = self._wait_for_keyboard(timeout=9.0)
        if not any(self._contains_token([text], "取消") for text in texts):
            raise AcceptanceError("点击搜索栏后没有出现搜索模式")
        prefix = f"{tutorial}；" if tutorial else ""
        return f"{prefix}{message}；键盘已出现，搜索框处于输入状态"

    def _input_text_verified(self) -> str:
        tutorial = self._dismiss_keyboard_tutorial_if_visible()
        message = self._gui_text_input(TEXT_PROBE)
        texts = self._wait_for_ocr_value(expected=TEXT_PROBE, timeout=10.0)
        prefix = f"{tutorial}；" if tutorial else ""
        return f"{prefix}{message}；OCR 已识别“{TEXT_PROBE}”：{self._join_texts(texts[:6])}"

    def _delete_verified(self) -> str:
        assert self.window is not None
        expected = TEXT_PROBE[:-1]
        message = self._gui_button_command(self.window.screen_stage.delete_button)
        texts = self._wait_for_ocr_value(
            expected=expected,
            absent=TEXT_PROBE,
            timeout=10.0,
        )
        return f"{message}；文字已由“{TEXT_PROBE}”变为“{expected}”：{self._join_texts(texts[:6])}"

    def _enter_verified(self) -> str:
        assert self.window is not None
        before = self._screenshot_bytes()
        message = self._gui_button_command(self.window.screen_stage.enter_button)
        time.sleep(0.8)
        after = self._screenshot_bytes()
        delta = self._image_delta(before, after)
        texts = self._wait_for_ocr_tokens((TEXT_PROBE[:-1],), timeout=8.0)
        if delta < 0.02:
            raise AcceptanceError(
                f"回车命令已发送，但画面没有明显变化（差异 {delta:.3f}）"
            )
        return (
            f"{message}；回车后画面变化 {delta:.3f}；"
            f"OCR 仍识别到“{TEXT_PROBE[:-1]}”：{self._join_texts(texts[:6])}"
        )

    def _long_press_verified(self) -> str:
        message = self._gui_long_press(150, 45)
        texts = self._wait_for_ocr_tokens(
            ("选择", "全选"),
            timeout=8.0,
            require_all=True,
        )
        return f"{message}；已出现“选择/全选”菜单：{self._join_texts(texts[:8])}"

    def _home_verified(self) -> str:
        bundle = self._press_home_until_springboard()
        return f"前台已回到 {bundle}"

    def _prepare_home_horizontal_test(self) -> None:
        # Press Home even when SpringBoard is already frontmost. This leaves a
        # possible App Library or Today View and returns to the first Home page.
        bundle = self._press_home_until_springboard()
        if bundle != "com.apple.springboard":
            raise AcceptanceError(f"无法回到主屏幕，当前前台为 {bundle}")
        time.sleep(0.8)
        time.sleep(0.6)

    def _lock_verified(self) -> str:
        assert self.window is not None
        message = self._gui_button_command(self.window.screen_stage.lock_button)
        state = self._wait_for_lock_state(
            locked=True,
            screen_on=False,
            timeout=12.0,
        )
        return (
            f"{message}；手机报告 locked=true、screen_on=false："
            f"{json.dumps(state, ensure_ascii=False)}"
        )

    def _wake_verified(self) -> str:
        assert self.window is not None
        attempts: list[str] = []
        state: dict[str, Any] = {}
        brightness = 0.0
        for attempt in range(1, 4):
            try:
                message = self._gui_button_command(self.window.screen_stage.wake_button)
                attempts.append(f"第 {attempt} 次：{message}")
            except AcceptanceError as error:
                attempts.append(f"第 {attempt} 次：{error}")
                time.sleep(0.8)
                continue

            # The jailbreak MCP can report an intermediate locked state for a
            # short time even though the power transition is still settling.
            time.sleep(1.8)
            locked, screen_on, state = self._lock_state()
            brightness = self._screenshot_brightness()
            if screen_on is True and brightness >= 20.0:
                break
            attempts.append(
                f"第 {attempt} 次状态：locked={locked}，"
                f"screen_on={screen_on}，画面亮度={brightness:.1f}"
            )
            time.sleep(0.6)
        else:
            raise AcceptanceError(
                "唤醒未通过（已重试 3 次）；" + "；".join(attempts)
            )

        if locked is True:
            return (
                f"{'；'.join(attempts)}；手机已亮屏（画面亮度 {brightness:.1f}），"
                "当前停在锁屏界面。锁屏密码只能由设备所有者在手机上输入，"
                "程序没有尝试绕过密码。"
                f"状态：{json.dumps(state, ensure_ascii=False)}"
            )
        if self._frontmost_bundle() != "com.apple.springboard":
            self._press_home_until_springboard()
        bundle = self._wait_for_frontmost("com.apple.springboard", timeout=5.0)
        return (
            f"{'；'.join(attempts)}；手机报告 locked=false、screen_on=true，"
            f"画面亮度 {brightness:.1f}，前台为 {bundle}："
            f"{json.dumps(state, ensure_ascii=False)}"
        )

    def _submit_direct(self, method: str, *args: object) -> str:
        assert self.context is not None
        assert self.commands is not None
        self._ensure_target_slot_selected()
        before = self.commands.count
        submit = getattr(self.context.ios_mcp_control, f"submit_{method}")
        command_id = submit(
            self.slot_no,
            *args,
            expected_udid=self.target_udid,
        )
        if command_id is None:
            raise AcceptanceError("设备控制队列不可用或目标手机已切换")
        event = self.commands.wait_after(
            before,
            expected_slot_no=self.slot_no,
        )
        if event[1] != command_id:
            raise AcceptanceError(f"命令序号异常: 期望 {command_id[:8]}，收到 {event[1][:8]}")
        if self.steps:
            self.steps[-1].command_id = command_id
        return event[3]

    def _gui_action(self, action: Callable[[], None], *, timeout: float = 25.0) -> str:
        assert self.commands is not None
        assert self.window is not None
        before = self.commands.count
        stage = self.window.screen_stage
        stage.clear_interaction_rejection()
        stage.set_expected_interaction_udid(self.target_udid)
        try:
            action()
        finally:
            stage.set_expected_interaction_udid("")
        rejection = stage.last_interaction_rejection()
        if rejection:
            raise AcceptanceError(rejection)
        QApplication.processEvents()
        event = self.commands.wait_after(
            before,
            timeout=timeout,
            expected_slot_no=self.slot_no,
        )
        return event[3]

    def _gui_tap(self, x: int, y: int) -> str:
        assert self.window is not None
        self._ensure_target_slot_selected()
        point = self._canvas_point(x, y)
        return self._gui_action(
            lambda: QTest.mouseClick(
                self.window.screen_stage.canvas,
                Qt.MouseButton.LeftButton,
                pos=point,
            )
        )

    def _gui_long_press(self, x: int, y: int) -> str:
        assert self.window is not None
        self._ensure_target_slot_selected()
        canvas = self.window.screen_stage.canvas
        point = self._canvas_point(x, y)

        def action() -> None:
            QTest.mousePress(canvas, Qt.MouseButton.LeftButton, pos=point)
            QTest.qWait(900)
            QTest.mouseRelease(canvas, Qt.MouseButton.LeftButton, pos=point)

        return self._gui_action(action)

    def _gui_swipe(self, sx: int, sy: int, ex: int, ey: int) -> str:
        assert self.window is not None
        self._ensure_target_slot_selected()
        canvas = self.window.screen_stage.canvas
        start = self._canvas_point(sx, sy)
        end = self._canvas_point(ex, ey)

        def action() -> None:
            QTest.mousePress(canvas, Qt.MouseButton.LeftButton, pos=start)
            QTest.qWait(90)
            QTest.mouseMove(canvas, end, delay=170)
            QTest.qWait(180)
            QTest.mouseRelease(canvas, Qt.MouseButton.LeftButton, pos=end)

        return self._gui_action(action)

    def _gui_text_input(self, text: str) -> str:
        assert self.window is not None
        self._ensure_target_slot_selected()
        stage = self.window.screen_stage
        stage.text_input.setText(text)
        return self._gui_action(
            lambda: QTest.mouseClick(
                stage.send_text_button,
                Qt.MouseButton.LeftButton,
                pos=stage.send_text_button.rect().center(),
            )
        )

    def _gui_button_command(self, button) -> str:  # noqa: ANN001
        self._ensure_target_slot_selected()
        return self._gui_action(
            lambda: QTest.mouseClick(
                button,
                Qt.MouseButton.LeftButton,
                pos=button.rect().center(),
            )
        )

    def _canvas_point(self, x: int, y: int) -> QPoint:
        assert self.window is not None
        canvas = self.window.screen_stage.canvas
        frame = canvas.frame_info
        if frame is None:
            raise AcceptanceError("真实画面尚未就绪")
        if normalize_udid(frame.udid) != self.target_udid:
            raise AcceptanceError(
                "拒绝点击：当前画面不是验收目标手机 "
                f"（目标尾号 {self.target_udid[-8:]}，画面尾号 {frame.udid[-8:]}）"
            )
        rect = canvas.image_rect()
        if rect.isEmpty():
            raise AcceptanceError("真实画面显示区域为空")
        assert self.snapshot is not None
        logical_width = self.snapshot.window_width or frame.width
        logical_height = self.snapshot.window_height or frame.height
        px = round(rect.left() + (x + 0.5) * rect.width() / logical_width)
        py = round(rect.top() + (y + 0.5) * rect.height() / logical_height)
        return QPoint(
            min(max(px, round(rect.left())), round(rect.right()) - 1),
            min(max(py, round(rect.top())), round(rect.bottom()) - 1),
        )

    def _capture(self, name: str) -> Path:
        assert self.window is not None
        assert self.client is not None
        QApplication.processEvents()
        time.sleep(0.26)
        QApplication.processEvents()
        self.sequence += 1
        gui_path = self.screens_dir / f"{self.sequence:02d}_{name}_gui.png"
        device_path = self.screens_dir / f"{self.sequence:02d}_{name}_device.jpg"
        self.window.grab().save(str(gui_path), "PNG")
        jpeg = self.client.screenshot_jpeg()
        if not jpeg:
            raise AcceptanceError("手机返回了空截图")
        device_path.write_bytes(jpeg)
        try:
            state = self.client.tool_value("get_screen_info", {})
        except Exception as error:
            state = {"state_error": str(error)}
        if self.steps:
            self.steps[-1].screenshot = str(device_path)
            self.steps[-1].state = state if isinstance(state, dict) else None
            if self.steps[-1].state is None:
                self.steps[-1].state = {}
            self.steps[-1].state.update(
                {
                    "screenshot_sha256": hashlib.sha256(jpeg).hexdigest(),
                    "screenshot_bytes": len(jpeg),
                }
            )
        return device_path

    def _write_report(self, *, success: bool, error: str) -> None:
        report = {
            "success": success,
            "error": error,
            "transport": "iOS MCP jailbreak direct over usbmux",
            "started_at": self.started_at.isoformat(),
            "finished_at": datetime.now().astimezone().isoformat(),
            "duration_seconds": round(time.monotonic() - self.started_monotonic, 2),
            "preflight": self.preflight,
            "device": {
                "slot_no": self.slot_no,
                "udid": self.snapshot.udid if self.snapshot else "",
                "target_udid": self.target_udid,
                "local_port": self.snapshot.local_port if self.snapshot else 0,
                "server_version": self.snapshot.server_version if self.snapshot else "",
                "screen_width": self.snapshot.window_width if self.snapshot else 0,
                "screen_height": self.snapshot.window_height if self.snapshot else 0,
            },
            "steps": [asdict(step) for step in self.steps],
            "screenshots": str(self.screens_dir),
        }
        (self.output_dir / "acceptance.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _close(self) -> None:
        if self.client is not None:
            self.client.close()
        if self.context is not None and self.slot_no:
            self.context.screen_capture.set_auto_wake_suppressed(self.slot_no, False)
        if self.window is not None:
            self.window.close()
            QApplication.processEvents()
        if self.context is not None:
            self.context.close()
        if self.app is not None:
            QApplication.processEvents()


def main() -> int:
    parser = argparse.ArgumentParser(description="iPhone Control Center 20 jailbreak direct acceptance")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--udid", default="", help="只验收指定 UDID 的 USB iPhone")
    parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=300,
        help="整轮验收硬超时；超时后输出线程栈并退出，避免永久卡住",
    )
    args = parser.parse_args()
    timeout = max(30, args.timeout_seconds)

    def watchdog_timeout() -> None:
        print(f"IC20_WATCHDOG_TIMEOUT {timeout} seconds", flush=True)
        faulthandler.dump_traceback(all_threads=True)
        os._exit(124)

    watchdog = threading.Timer(timeout, watchdog_timeout)
    watchdog.daemon = True
    watchdog.start()
    runner = McpAcceptance(args.output_dir, args.udid)
    try:
        return 0 if runner.run() else 1
    finally:
        watchdog.cancel()


if __name__ == "__main__":
    raise SystemExit(main())
