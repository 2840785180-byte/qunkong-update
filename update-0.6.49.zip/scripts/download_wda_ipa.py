#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
import plistlib
import shutil
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from collections.abc import Callable, Sequence
from pathlib import Path, PurePosixPath


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from iphone_control_center.services.wda_catalog import (  # noqa: E402
    LEGACY_WDA_PROFILE,
    MODERN_WDA_PROFILE,
    ConnectedIPhone,
    WDAProfile,
    WDAProfileError,
    discover_connected_iphones,
    profiles_for_ios_range,
    profile_by_key,
    profile_path,
    select_wda_profile,
    wda_compatibility_rows,
)


WDA_DIR = PROJECT_ROOT / "wda"
TESTED_IPA = WDA_DIR / LEGACY_WDA_PROFILE.filename
DEFAULT_IPA = WDA_DIR / "WebDriverAgentRunner-goios-1.3.2-official.ipa"
MODERN_IPA = WDA_DIR / MODERN_WDA_PROFILE.filename
IOS_14_TO_17_MANIFEST_NAME = "iOS14-17安装包对照表.txt"

# Backward-compatible names used by the existing downloader tests.
SOURCE_URL = LEGACY_WDA_PROFILE.source_url
SOURCE_MEMBER = LEGACY_WDA_PROFILE.source_member or ""
EXPECTED_SOURCE_SHA256 = LEGACY_WDA_PROFILE.source_sha256
EXPECTED_SOURCE_SIZE = LEGACY_WDA_PROFILE.source_size
EXPECTED_IPA_SHA256 = "EEA1A2DAE4725E9C786661AD6B77FBEFBB5911622FA8F54346F44409093BD1AF"
EXPECTED_IPA_SIZE = 5_102_334
TESTED_IPA_SHA256 = "41EEF4B998806F01D9B151BB01DECD25C9F7C20D017961B7F0D82EE4B7C67E49"
TESTED_IPA_SIZE = 4_642_367
CHUNK_SIZE = 1024 * 1024

APPIUM_RUNNER_ROOT = "Payload/WebDriverAgentRunner-Runner.app/"
APPIUM_XCTEST_ROOT = APPIUM_RUNNER_ROOT + "PlugIns/WebDriverAgentRunner.xctest/"
APPIUM_REQUIRED_FILES = (
    APPIUM_RUNNER_ROOT + "Info.plist",
    APPIUM_RUNNER_ROOT + "WebDriverAgentRunner-Runner",
    APPIUM_XCTEST_ROOT + "Info.plist",
    APPIUM_XCTEST_ROOT + "WebDriverAgentRunner",
    APPIUM_XCTEST_ROOT + "Frameworks/WebDriverAgentLib.framework/Info.plist",
)


class DownloadError(RuntimeError):
    pass


def _configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


def _human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{size} B"
        value /= 1024
    return f"{size} B"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _file_matches(path: Path, expected_size: int, expected_sha256: str) -> bool:
    if not path.is_file() or path.stat().st_size != expected_size:
        return False
    return _sha256(path) == expected_sha256


def _verify_ipa(
    path: Path,
    expected_size: int = EXPECTED_IPA_SIZE,
    expected_sha256: str = EXPECTED_IPA_SHA256,
) -> bool:
    return _file_matches(path, expected_size, expected_sha256)


def _is_safe_archive_name(name: str) -> bool:
    normalized = name.replace("\\", "/")
    member = PurePosixPath(normalized)
    return bool(normalized) and not member.is_absolute() and ".." not in member.parts


def _verify_appium_ipa(path: Path) -> bool:
    if not path.is_file():
        return False
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            if not all(name.startswith("Payload/") and _is_safe_archive_name(name) for name in names):
                return False
            if not all(required in names for required in APPIUM_REQUIRED_FILES):
                return False
            runner_info = plistlib.loads(archive.read(APPIUM_RUNNER_ROOT + "Info.plist"))
            xctest_info = plistlib.loads(archive.read(APPIUM_XCTEST_ROOT + "Info.plist"))
            library_info = plistlib.loads(
                archive.read(
                    APPIUM_XCTEST_ROOT + "Frameworks/WebDriverAgentLib.framework/Info.plist"
                )
            )
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, plistlib.InvalidFileException):
        return False

    runner_identifier = str(runner_info.get("CFBundleIdentifier") or "")
    xctest_identifier = str(xctest_info.get("CFBundleIdentifier") or "")
    library_identifier = str(library_info.get("CFBundleIdentifier") or "")
    runner_minimum_os = str(runner_info.get("MinimumOSVersion") or "")
    xctest_minimum_os = str(xctest_info.get("MinimumOSVersion") or "")
    library_minimum_os = str(library_info.get("MinimumOSVersion") or "")
    sdk_name = str(runner_info.get("DTSDKName") or "")
    return (
        runner_identifier == "com.facebook.WebDriverAgentRunner.xctrunner"
        and xctest_identifier == "com.facebook.WebDriverAgentRunner"
        and library_identifier == "com.facebook.WebDriverAgentLib"
        and runner_minimum_os.startswith(("13.", "14.", "15.", "16.", "17.", "18."))
        and xctest_minimum_os.startswith("15.")
        and library_minimum_os.startswith("15.")
        and "iphoneos18." in sdk_name.lower()
    )


def _verify_profile_ipa(profile: WDAProfile, path: Path) -> bool:
    if profile.source_kind == "appium_runner_zip":
        return _verify_appium_ipa(path)
    if path.resolve() == TESTED_IPA.resolve():
        return _verify_ipa(path, TESTED_IPA_SIZE, TESTED_IPA_SHA256)
    return _verify_ipa(path)


def _download(source_url: str, destination: Path, fallback_size: int) -> None:
    request = urllib.request.Request(
        source_url,
        headers={
            "User-Agent": "iPhone-Control-Center-20-WDA-Downloader/2.0",
            "Accept": "application/zip,application/octet-stream,*/*",
        },
    )
    print("正在连接官方下载地址...")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            content_length = response.headers.get("Content-Length")
            total = int(content_length) if content_length else fallback_size
            received = 0
            next_report = 10
            with destination.open("wb") as output:
                while True:
                    chunk = response.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    output.write(chunk)
                    received += len(chunk)
                    if total > 0:
                        percent = min(100, received * 100 // total)
                        if percent >= next_report:
                            print(f"下载进度：{percent}%  ({_human_size(received)})")
                            next_report = min(100, ((percent // 10) + 1) * 10)
    except urllib.error.HTTPError as exc:
        raise DownloadError(f"下载服务器返回 HTTP {exc.code}，请稍后重试。") from exc
    except urllib.error.URLError as exc:
        raise DownloadError(f"无法连接下载服务器：{exc.reason}") from exc
    except OSError as exc:
        raise DownloadError(f"保存下载文件失败：{exc}") from exc


def _verify_source_archive(path: Path, profile: WDAProfile) -> None:
    size = path.stat().st_size
    if size != profile.source_size:
        raise DownloadError(
            f"官方源码包大小不正确：应为 {profile.source_size} 字节，实际为 {size} 字节。"
        )
    actual = _sha256(path)
    if actual != profile.source_sha256:
        raise DownloadError(
            "官方源码包校验失败，已停止处理。\n"
            f"应为：{profile.source_sha256}\n"
            f"实际：{actual}"
        )


def _extract_legacy_ipa(archive: Path, destination: Path, profile: WDAProfile) -> None:
    member_name = profile.source_member or ""
    try:
        with zipfile.ZipFile(archive) as source_zip:
            try:
                member = source_zip.getinfo(member_name)
            except KeyError as exc:
                raise DownloadError(f"官方源码包中缺少预期文件：{member_name}") from exc
            if member.file_size != EXPECTED_IPA_SIZE:
                raise DownloadError(
                    "官方源码包中的 IPA 大小不正确："
                    f"应为 {EXPECTED_IPA_SIZE} 字节，实际为 {member.file_size} 字节。"
                )
            with source_zip.open(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output, CHUNK_SIZE)
    except zipfile.BadZipFile as exc:
        raise DownloadError("下载到的文件不是有效 ZIP，可能下载不完整。") from exc
    except OSError as exc:
        raise DownloadError(f"解压 IPA 失败：{exc}") from exc


def _package_appium_runner(archive: Path, destination: Path) -> None:
    try:
        with zipfile.ZipFile(archive) as source_zip, zipfile.ZipFile(
            destination,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as output_zip:
            for source_info in source_zip.infolist():
                name = source_info.filename
                if not _is_safe_archive_name(name):
                    raise DownloadError(f"新版 WDA 包包含不安全路径：{name!r}")
                target = zipfile.ZipInfo("Payload/" + name, source_info.date_time)
                target.compress_type = zipfile.ZIP_DEFLATED
                target.external_attr = source_info.external_attr
                target.create_system = source_info.create_system
                data = b"" if source_info.is_dir() else source_zip.read(source_info)
                output_zip.writestr(target, data)
    except zipfile.BadZipFile as exc:
        raise DownloadError("新版 WDA 官方包不是有效 ZIP，可能下载不完整。") from exc
    except OSError as exc:
        raise DownloadError(f"生成新版 IPA 失败：{exc}") from exc
    if not _verify_appium_ipa(destination):
        raise DownloadError("生成的新版 IPA 结构校验失败，已停止写入正式文件。")


def _report_existing(path: Path, profile: WDAProfile) -> None:
    print(f"已找到匹配的 WDA 安装包：{profile.label}")
    print(f"文件：{path}")
    print(f"大小：{_human_size(path.stat().st_size)}")
    print(f"SHA-256：{_sha256(path)}")
    if profile.max_ios_major is None:
        print(f"兼容范围：iOS {profile.min_ios_major}+")
    else:
        print(f"兼容范围：iOS {profile.min_ios_major}-{profile.max_ios_major}")
    print(f"验证状态：{profile.verification_label}")


def download_profile_ipa(
    profile: WDAProfile,
    wda_dir: Path = WDA_DIR,
    *,
    force: bool = False,
    source_url: str | None = None,
    output: Path | None = None,
) -> Path:
    destination = (output or profile_path(profile, wda_dir)).resolve()
    if not force and _verify_profile_ipa(profile, destination):
        _report_existing(destination, profile)
        return destination

    if destination.is_file():
        print("发现同名安装包，但与当前手机类型不匹配或校验不一致；成功后才会替换。")

    destination.parent.mkdir(parents=True, exist_ok=True)
    url = source_url or profile.source_url
    print(f"手机匹配结果：{profile.label}")
    print(f"下载地址：{url}")

    archive_temp: Path | None = None
    ipa_temp: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=".wda-download-", suffix=".zip", dir=destination.parent, delete=False
        ) as handle:
            archive_temp = Path(handle.name)
        with tempfile.NamedTemporaryFile(
            prefix=".wda-extract-", suffix=".ipa", dir=destination.parent, delete=False
        ) as handle:
            ipa_temp = Path(handle.name)

        _download(url, archive_temp, profile.source_size)
        print("正在校验官方文件...")
        _verify_source_archive(archive_temp, profile)

        if profile.source_kind == "goios_archive":
            print("正在提取旧版 WDA 安装包...")
            _extract_legacy_ipa(archive_temp, ipa_temp, profile)
            if not _verify_ipa(ipa_temp):
                raise DownloadError(
                    "提取出的 IPA 校验失败，已停止安装包写入。\n"
                    f"应为：{EXPECTED_IPA_SHA256}"
                )
        else:
            print("正在把官方新版 Runner 封装为 IPA...")
            _package_appium_runner(archive_temp, ipa_temp)

        if not _verify_profile_ipa(profile, ipa_temp):
            raise DownloadError("最终 IPA 校验失败，已停止安装包写入。")
        os.replace(ipa_temp, destination)
        ipa_temp = None
    finally:
        for temporary in (archive_temp, ipa_temp):
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    _report_existing(destination, profile)
    return destination


def download_wda_ipa(output: Path, force: bool = False, source_url: str = SOURCE_URL) -> Path:
    """Backward-compatible entry point for the original iOS 14 package."""
    if not force and output.resolve() == DEFAULT_IPA.resolve() and TESTED_IPA.is_file():
        if _verify_ipa(TESTED_IPA, TESTED_IPA_SIZE, TESTED_IPA_SHA256):
            _report_existing(TESTED_IPA, LEGACY_WDA_PROFILE)
            return TESTED_IPA
    return download_profile_ipa(
        LEGACY_WDA_PROFILE,
        output=output,
        force=force,
        source_url=source_url,
    )


def _print_ios_range_matrix(start_major: int = 14, end_major: int = 17) -> None:
    print(
        "当前正式支持：iOS 16.7.16 / 20H392、16.7.15 / 20H380、"
        "16.7.12 / 20H364、16.7.11 / 20H360"
    )
    print(f"历史候选范围：iOS {start_major}.x - {end_major}.x（小版本统一按大版本匹配）")
    for row in wda_compatibility_rows(start_major, end_major):
        print(f"  {row.ios_label:<9} -> {row.profile.filename}")


def _write_ios_range_manifest(
    wda_dir: Path,
    profiles: Sequence[WDAProfile],
    start_major: int = 14,
    end_major: int = 17,
) -> Path:
    manifest = wda_dir / IOS_14_TO_17_MANIFEST_NAME
    lines = [
        "iPhone Control Center 20 - WDA 历史安装包对照表",
        "当前配置：iOS 16.7.16 / 20H392、16.7.15 / 20H380、"
        "16.7.12 / 20H364、16.7.11 / 20H360",
        "注意：这是历史候选资料，不是当前正式支持承诺。",
        f"历史候选范围：iOS {start_major}.x 到 iOS {end_major}.x",
        "",
        "手机系统 -> 要安装的文件",
    ]
    for row in wda_compatibility_rows(start_major, end_major):
        lines.append(f"iOS {row.ios_major}.x -> {row.profile.filename}")
    lines.extend(
        [
            "",
            "说明：",
            "1. 同一个安装包可覆盖该范围内多个 iOS 小版本，不需要每个 14.0/14.1/14.2 各一份。",
            "2. iOS 14.x 使用旧实测包；iOS 15.x-17.x 使用 Appium 16.15.3 官方候选包。",
            "3. 安装仍须本人登录 Apple ID、完成双重认证、点 Start 并在 iPhone 上信任开发者 App。",
            "4. iOS 15.x-17.x 的候选包尚未在当前电脑逐台完成签名安装和控制验收，不能把“有包”当成“必成功”。",
            "5. 当前主控制流程使用 USB + 越狱手机端直连组件，不依赖 WDA。",
            "",
            "文件校验：",
        ]
    )
    for profile in profiles:
        path = profile_path(profile, wda_dir)
        if path.is_file():
            lines.extend(
                [
                    f"{profile.filename}",
                    f"  大小：{path.stat().st_size} 字节",
                    f"  SHA-256：{_sha256(path)}",
                    f"  验证状态：{profile.verification_label}",
                ]
            )
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return manifest


def download_supported_ios_range(
    wda_dir: Path = WDA_DIR,
    *,
    start_major: int = 14,
    end_major: int = 17,
    force: bool = False,
) -> tuple[Path, ...]:
    profiles = profiles_for_ios_range(start_major, end_major)
    _print_ios_range_matrix(start_major, end_major)
    print(f"共需 {len(profiles)} 个不同的官方安装包（兼容范围复用，不重复造包）。")
    print()

    destinations: list[Path] = []
    for profile in profiles:
        destination = profile_path(profile, wda_dir)
        range_start = max(profile.min_ios_major, start_major)
        range_end = min(profile.max_ios_major or end_major, end_major)
        print(f"正在准备：{profile.label}")
        print(f"本次使用：iOS {range_start}-{range_end}")
        destinations.append(download_profile_ipa(profile, wda_dir, force=force))
        print()

    manifest = _write_ios_range_manifest(wda_dir, profiles, start_major, end_major)
    print(f"已生成对照表：{manifest}")
    return tuple(destinations)


def _device_line(device: ConnectedIPhone) -> str:
    parts = [
        device.product_type or "iPhone",
        f"iOS {device.ios_version or '未知'}",
        f"Build {device.build_version or '未知'}",
        device.udid,
    ]
    return " / ".join(parts)


def _select_device(
    devices: Sequence[ConnectedIPhone],
    *,
    udid: str | None = None,
    input_func: Callable[[str], str] = input,
) -> ConnectedIPhone:
    if not devices:
        raise DownloadError(
            "没有识别到通过 USB 连接的 iPhone。请连接并解锁手机、点“信任此电脑”后重试。"
        )
    if udid:
        needle = udid.strip().lower()
        matches = [device for device in devices if device.udid.lower().startswith(needle)]
        if not matches:
            raise DownloadError(f"没有找到 UDID 以 {udid!r} 开头的已连接手机。")
        if len(matches) > 1:
            raise DownloadError(f"UDID 前缀 {udid!r} 匹配到多台手机，请提供更长的 UDID。")
        return matches[0]
    if len(devices) == 1:
        return devices[0]

    print("检测到多台手机，请选择这次要安装 WDA 的手机：")
    for index, device in enumerate(devices, start=1):
        print(f"  {index}. {_device_line(device)}")
    for _attempt in range(3):
        try:
            raw = input_func(f"请输入序号 1-{len(devices)}：").strip()
        except EOFError as exc:
            raise DownloadError("无法读取选择；请在命令行中使用 --udid 指定手机。") from exc
        if raw.isdigit() and 1 <= int(raw) <= len(devices):
            return devices[int(raw) - 1]
        print("序号无效，请重新输入。")
    raise DownloadError("没有选择有效手机；请重新运行，或使用 --udid 指定手机。")


def _resolve_profile(
    args: argparse.Namespace,
    devices: Sequence[ConnectedIPhone],
    *,
    input_func: Callable[[str], str] = input,
) -> tuple[ConnectedIPhone | None, WDAProfile]:
    device: ConnectedIPhone | None = None
    if args.udid and devices:
        device = _select_device(devices, udid=args.udid)

    if args.profile != "auto":
        profile = profile_by_key(args.profile)
    elif args.ios_version:
        profile = select_wda_profile(args.ios_version)
    else:
        if not devices:
            raise DownloadError(
                "没有识别到通过 USB 连接的 iPhone，无法自动选择 WDA。"
                "请连接手机后重试，或用 --ios-version 手动指定。"
            )
        device = device or _select_device(devices, udid=args.udid, input_func=input_func)
        profile = select_wda_profile(device.ios_version)

    if device is not None and not profile.supports_ios(device.ios_version or ""):
        raise DownloadError(
            f"选中的 {profile.label} 不适用于 {_device_line(device)}，已拒绝下载。"
        )
    return device, profile


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="读取当前 USB iPhone，自动选择、下载并校验匹配的 WDA IPA。"
    )
    parser.add_argument("--udid", help="多台手机同时连接时，用 UDID 或唯一前缀指定手机。")
    parser.add_argument(
        "--ios-version",
        help="没有连接手机时，可手动指定 iOS 版本用于准备安装包。",
    )
    parser.add_argument(
        "--profile",
        choices=["auto", LEGACY_WDA_PROFILE.key, MODERN_WDA_PROFILE.key],
        default="auto",
        help="默认 auto；通常无需手动指定安装包类型。",
    )
    parser.add_argument("--wda-dir", type=Path, default=WDA_DIR, help="IPA 保存目录。")
    parser.add_argument("--output", type=Path, help="覆盖默认 IPA 输出路径。")
    parser.add_argument("--force", action="store_true", help="即使已有可用包也重新下载。")
    parser.add_argument("--source-url", help="官方下载地址的受控镜像（故障排查用）。")
    parser.add_argument(
        "--prepare-ios14-17",
        "--all-supported",
        dest="prepare_ios14_17",
        action="store_true",
        help="历史资料模式：备齐 iOS 14.x-17.x 所需的候选 WDA 包，不代表这些小版本已全部验证。",
    )
    parser.add_argument("--dry-run", action="store_true", help="只显示匹配结果，不下载。")
    parser.add_argument("--list-devices", action="store_true", help="只列出当前 USB 手机。")
    return parser


def _print_profile(device: ConnectedIPhone | None, profile: WDAProfile, ipa: Path) -> None:
    if device is not None:
        print(f"当前手机：{_device_line(device)}")
    print(f"自动选择：{profile.label}")
    print(f"选择原因：iOS {profile.min_ios_major}-{profile.max_ios_major or '最新'} 使用该包")
    print(f"验证状态：{profile.verification_label}")
    print(f"目标文件：{ipa}")
    if profile.note:
        print(f"说明：{profile.note}")


def main(argv: list[str] | None = None) -> int:
    _configure_console()
    args = _build_parser().parse_args(argv)
    print("iPhone Control Center 20 - 自动匹配 WDA 安装包")
    print("=" * 52)
    try:
        if args.prepare_ios14_17:
            required = profiles_for_ios_range()
            if args.dry_run:
                _print_ios_range_matrix()
                print(f"共需 {len(required)} 个不同的官方安装包；不会为每个小版本重复下载。")
                print("仅检查范围，没有下载文件。")
                return 0
            if args.source_url:
                raise DownloadError("批量准备不支持自定义镜像；请改用单台手机自动匹配。")
            download_supported_ios_range(args.wda_dir, force=args.force)
            print("iOS 14.x-17.x 的历史候选 WDA 安装包已经准备好；不等同于这些系统都已支持。")
            return 0

        try:
            devices = discover_connected_iphones()
        except Exception as exc:
            if args.ios_version or args.profile != "auto":
                devices = ()
                print(f"读取 USB 手机失败，但已手动指定版本，将继续准备：{exc}")
            else:
                raise DownloadError(f"无法读取 USB 手机：{exc}") from exc
        if args.list_devices:
            if not devices:
                print("当前没有通过 USB 连接的 iPhone。")
            for index, device in enumerate(devices, start=1):
                print(f"{index}. {_device_line(device)}")
            return 0

        device, profile = _resolve_profile(args, devices)
        destination = (args.output or profile_path(profile, args.wda_dir)).resolve()
        _print_profile(device, profile, destination)
        if args.dry_run:
            print("仅检查匹配结果，没有下载文件。")
            return 0

        download_profile_ipa(
            profile,
            args.wda_dir,
            force=args.force,
            source_url=args.source_url,
            output=destination,
        )
        print("安装包准备完成。现在可以回到“连接器”，点击第 2 步打开签名安装。")
    except WDAProfileError as exc:
        print(f"\n无法选择 WDA：{exc}", file=sys.stderr)
        return 2
    except DownloadError as exc:
        print(f"\n下载没有完成：{exc}", file=sys.stderr)
        print("\n请检查 USB、手机解锁状态和网络后重试；原有安装包不会被删除。", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n已取消下载，原有安装包不会被删除。", file=sys.stderr)
        return 130
    except OSError as exc:
        print(f"\n文件操作失败：{exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
