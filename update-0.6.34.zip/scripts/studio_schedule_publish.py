from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Sequence


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(SCRIPT_ROOT))

from tiktok_automation_common import (  # noqa: E402
    AutomationError,
    LOGIN_REQUIRED_MARKERS,
    RATE_LIMIT_MARKERS,
    SECURITY_MARKERS,
    UiAutomation,
    clean,
    node_point,
    node_rect,
    node_text,
    normalize,
    run_shell,
    text_matches,
)


STUDIO_BUNDLE_ID = "com.ss.iphone.tt.creator"

LOGIN_MARKERS = (
    "登录 TikTok Studio",
    "使用手机号码/电子邮箱/用户名登录",
    "Log in to TikTok Studio",
    "Use phone/email/username",
)
CREATE_TAB_MARKERS = (
    "创作",
    "制作",
    "发布",
    "Create",
    "Create post",
    "Produce",
)
CREATE_ENTRY_MARKERS = (
    "发布视频",
    "上传视频",
    "创建视频",
    "新建视频",
    "Post video",
    "Upload video",
    "Create video",
    "New video",
)
RECENT_MARKERS = (
    "最近项目",
    "最近",
    "所有照片",
    "Recents",
    "Recent",
    "All photos",
    "Photos",
    "相册",
)
VIDEO_FILTER_MARKERS = ("视频", "Videos", "Video")
NEXT_MARKERS = ("下一步", "继续", "Next", "Continue", "添加", "Add")
CAPTION_MARKERS = (
    "添加描述",
    "添加文案",
    "聊聊你的视频",
    "说说这个视频",
    "Write a caption",
    "Add a caption",
    "Caption",
    "Description",
    "描述",
    "文案",
)
MORE_MARKERS = ("更多选项", "更多", "More options", "More")
SCHEDULE_MARKERS = (
    "定时发布",
    "预约发布",
    "定时",
    "排定",
    "Schedule post",
    "Schedule",
)
DATE_MARKERS = ("日期", "选择日期", "Date", "Select date")
TIME_MARKERS = ("时间", "选择时间", "Time", "Select time")
DONE_MARKERS = ("完成", "确定", "应用", "Done", "Set", "Apply")
CONFIRM_SCHEDULE_MARKERS = (
    "定时发布",
    "预约发布",
    "已选择时间",
    "Scheduled time",
    "Schedule post",
)
SUBMIT_MARKERS = ("预约", "排定", "定时发布", "Schedule", "Schedule post")
SUCCESS_MARKERS = (
    "已排定",
    "预约成功",
    "已预约",
    "Scheduled",
    "Your post has been scheduled",
    "帖子已排定",
)
IMMEDIATE_PUBLISH_MARKERS = ("立即发布", "Post now", "Publish now")

DATE_PATTERN = re.compile(r"(20\d{2})\s*[年/-]\s*(\d{1,2})\s*[月/-]\s*(\d{1,2})")
TIME_PATTERN = re.compile(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)")


def emit_progress(stage: str, message: str) -> None:
    print(f"STUDIO_SCHEDULE_PROGRESS|{stage}|{clean(message, 500)}", flush=True)


def emit_result(value: dict[str, Any]) -> None:
    print(
        "STUDIO_SCHEDULE_RESULT|"
        + json.dumps(value, ensure_ascii=False, separators=(",", ":")),
        flush=True,
    )


def read_payload() -> dict[str, Any]:
    raw = sys.stdin.buffer.read() if sys.stdin is not None else b""
    if not raw.strip():
        raise ValueError("TikTok Studio 预约任务没有收到数据。")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("TikTok Studio 预约任务数据格式不正确。") from error
    if not isinstance(payload, dict):
        raise ValueError("TikTok Studio 预约任务格式不正确。")
    device = payload.get("device")
    items = payload.get("items")
    if (
        not isinstance(device, dict)
        or not isinstance(items, list)
        or not items
        or any(not isinstance(item, dict) for item in items)
    ):
        raise ValueError("TikTok Studio 预约任务缺少手机或视频信息。")
    return payload


def schedule_instant(item: dict[str, Any]) -> datetime:
    raw = str(item.get("publish_at_utc") or "").strip()
    try:
        instant = datetime.fromisoformat(raw)
    except ValueError as error:
        raise AutomationError("task", f"预约时间格式不正确：{raw}") from error
    if instant.tzinfo is None:
        instant = instant.replace(tzinfo=timezone.utc)
    return instant.astimezone(timezone.utc)


def parse_phone_offset_minutes(value: Any) -> int | None:
    text = str(value or "").strip()
    match = re.search(r"([+-])(\d{2})(\d{2})", text)
    if match is None:
        return None
    minutes = int(match.group(2)) * 60 + int(match.group(3))
    return minutes if match.group(1) == "+" else -minutes


def local_schedule_time(item: dict[str, Any], offset_minutes: int) -> datetime:
    return schedule_instant(item).astimezone(
        timezone(timedelta(minutes=int(offset_minutes)), name="PhoneLocal")
    )


def contains_text(texts: Sequence[str], markers: Sequence[str], *, exact: bool = False) -> bool:
    return any(
        text_matches(text, marker, exact=exact)
        for text in texts
        for marker in markers
    )


def blocking_page_error(texts: Sequence[str]) -> tuple[str, str] | None:
    if contains_text(texts, RATE_LIMIT_MARKERS):
        return (
            "rate_limit",
            "TikTok 提示操作太频繁，已停止本机预约，避免账号风险。",
        )
    if contains_text(texts, SECURITY_MARKERS):
        return (
            "security",
            "检测到 TikTok 安全验证，请在手机上手动完成后重新执行。",
        )
    if contains_text(texts, LOGIN_MARKERS + LOGIN_REQUIRED_MARKERS):
        return "login_required", "TikTok Studio 尚未登录或登录已失效。"
    return None


def find_exact_node(
    nodes: Sequence[dict[str, Any]],
    value: str,
    *,
    min_y: float = 0,
    max_y: float = 10000,
) -> dict[str, Any] | None:
    normalized = normalize(value)
    for node in nodes:
        point = node_point(node)
        if point is None or not (min_y <= point[1] <= max_y):
            continue
        if normalize(node_text(node)) == normalized:
            return node
    return None


def node_is_selected(node: dict[str, Any]) -> bool | None:
    false_values = {"0", "false", "no", "off", "unchecked", "未选", "未选中"}
    true_values = {"1", "true", "yes", "on", "selected", "checked", "已选", "已选中"}
    for key in ("selected", "checked", "isSelected", "is_selected", "state", "value"):
        raw = node.get(key)
        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return bool(raw)
        text = normalize(raw)
        if text in true_values:
            return True
        if text in false_values:
            return False
    return None


def immediate_publish_is_active(nodes: Sequence[dict[str, Any]]) -> bool:
    return any(
        text_matches(node_text(node), marker, exact=True)
        and node_is_selected(node) is True
        for node in nodes
        for marker in IMMEDIATE_PUBLISH_MARKERS
    )


class StudioScheduleRunner:
    def __init__(self, port: int, payload: dict[str, Any]) -> None:
        self.payload = payload
        self.device = payload["device"]
        self.items = [item for item in payload["items"] if isinstance(item, dict)]
        self.output_dir = Path(
            str(payload.get("output_dir") or PROJECT_ROOT / "work" / "Studio自动预约")
        ).expanduser().resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.ui = UiAutomation(port, STUDIO_BUNDLE_ID, timeout=90.0)
        self.offset_minutes = 0
        self.scheduled_count = 0
        self.failed_count = 0
        self.records: list[dict[str, Any]] = []

    def run(self) -> int:
        try:
            self.ui.connect()
            self._open_studio()
            self.offset_minutes = self._read_phone_timezone()
            emit_progress(
                "timezone",
                f"手机本地时区偏移 {self.offset_minutes // 60:+d} 小时",
            )
            for index, item in enumerate(self.items, 1):
                label = str(item.get("filename") or f"第 {index} 条视频")
                try:
                    emit_progress("prepare", f"{index}/{len(self.items)} · {label}")
                    self._assert_not_blocked()
                    local_time = local_schedule_time(item, self.offset_minutes)
                    if schedule_instant(item) <= datetime.now(timezone.utc) + timedelta(
                        minutes=1
                    ):
                        raise AutomationError(
                            "schedule_time",
                            f"预约时间 {local_time:%Y-%m-%d %H:%M} 已过或不足 1 分钟，"
                            "已停止本机后续预约。",
                        )
                    self._open_create_page()
                    self._select_video(
                        int(item.get("album_index") or 0),
                        index,
                        label,
                    )
                    self._fill_caption(str(item.get("caption") or ""), item.get("hashtags"))
                    self._configure_schedule(local_time)
                    self._submit_schedule(local_time)
                    self.scheduled_count += 1
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "publish_at_phone": local_time.isoformat(timespec="minutes"),
                            "status": "scheduled",
                            "detail": "已在 TikTok Studio 完成定时发布",
                        }
                    )
                except AutomationError as error:
                    self.failed_count += len(self.items) - index + 1
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "status": "failed",
                            "stage": error.stage,
                            "detail": clean(error.detail, 1200),
                        }
                    )
                    # Stop this phone on the first failure so a broken page cannot
                    # cause duplicate submissions or an accidental immediate post.
                    break

            creator_visible, screenshot = self._open_creator_for_review()
            success = self.scheduled_count == len(self.items)
            result = {
                "success": success,
                "stage": "complete" if success else "scheduled_with_failures",
                "detail": (
                    f"已完成 {self.scheduled_count}/{len(self.items)} 条预约，"
                    "并打开创作页面供复核。"
                    if success
                    else f"只完成 {self.scheduled_count}/{len(self.items)} 条预约。"
                ),
                "total_count": len(self.items),
                "scheduled_count": self.scheduled_count,
                "failed_count": self.failed_count,
                "items": self.records,
                "creator_visible": creator_visible,
                "creator_screenshot": screenshot,
                "phone_timezone": f"{self.offset_minutes // 60:+d}",
            }
            emit_result(result)
            return 0 if success else 1
        except AutomationError as error:
            result = self._failure_result(error.stage, error.detail)
            emit_result(result)
            return 1
        except Exception as error:
            result = self._failure_result(
                "unexpected",
                f"{error.__class__.__name__}: {clean(error, 1000)}",
            )
            emit_result(result)
            return 1
        finally:
            self.ui.close()

    def _failure_result(self, stage: str, detail: str) -> dict[str, Any]:
        remaining = max(0, len(self.items) - self.scheduled_count)
        if remaining and (not self.records or self.records[-1].get("status") != "failed"):
            self.failed_count += remaining
        return {
            "success": False,
            "stage": stage,
            "detail": clean(detail, 1500) or "TikTok Studio 预约失败",
            "total_count": len(self.items),
            "scheduled_count": self.scheduled_count,
            "failed_count": max(self.failed_count, len(self.items) - self.scheduled_count),
            "items": self.records,
            "creator_visible": False,
            "creator_screenshot": "",
            "phone_timezone": f"{self.offset_minutes // 60:+d}",
        }

    def _open_studio(self) -> None:
        emit_progress("studio_home", "正在清理后台并打开 TikTok Studio")
        self.ui.restart_app_clean(STUDIO_BUNDLE_ID)
        deadline = time.monotonic() + 12.0
        while time.monotonic() < deadline:
            texts = self.ui.texts(include_ocr=True)
            blocker = blocking_page_error(texts)
            if blocker is not None:
                raise AutomationError(*blocker)
            if contains_text(texts, CREATE_TAB_MARKERS):
                return
            time.sleep(0.4)
        raise AutomationError("studio_home", "没有打开 TikTok Studio 首页或创作入口。")

    def _assert_not_blocked(self) -> None:
        blocker = blocking_page_error(self.ui.texts(include_ocr=True))
        if blocker is not None:
            raise AutomationError(*blocker)

    def _read_phone_timezone(self) -> int:
        try:
            value = run_shell(self.ui.client, "date +%z", timeout=8)
            if int(value.get("exitCode") or 0) == 0:
                offset = parse_phone_offset_minutes(value.get("output"))
                if offset is not None:
                    return offset
        except Exception:
            pass
        raise AutomationError("timezone", "无法读取手机本地时区，为避免错时预约已停止。")

    def _open_create_page(self) -> None:
        _width, height = self.ui.screen_size()
        tapped = False
        for marker in CREATE_TAB_MARKERS:
            node = self.ui.find_node(
                (marker,),
                exact=True,
                min_y=height * 0.70,
            )
            if node is not None and self.ui.tap_node(node):
                tapped = True
                break
        if not tapped:
            self.ui.tap_marker(CREATE_TAB_MARKERS, exact=False, min_y=height * 0.70)
        time.sleep(0.8)
        texts = self.ui.texts(include_ocr=True)
        blocker = blocking_page_error(texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if contains_text(texts, CREATE_ENTRY_MARKERS):
            return
        # Some Studio versions open the composer directly from the create tab.
        if contains_text(texts, CAPTION_MARKERS) or contains_text(texts, RECENT_MARKERS):
            return
        raise AutomationError("create_page", "没有找到 TikTok Studio 的发布视频入口。")

    def _select_video(
        self,
        album_index: int,
        item_number: int,
        filename: str,
    ) -> None:
        if not self.ui.tap_marker(CREATE_ENTRY_MARKERS, exact=False):
            raise AutomationError("video_entry", "创作页面没有“发布视频 / 上传视频”入口。")
        self.ui.wait_for(
            RECENT_MARKERS,
            timeout=16.0,
            stage="photo_picker",
            detail="TikTok Studio 没有打开相册选择页。",
        )
        # Prefer the video filter when the picker opens on all media.
        self.ui.tap_marker(VIDEO_FILTER_MARKERS, exact=True, max_y=180)
        time.sleep(0.6)
        tile = self._find_media_tile(album_index, filename)
        if tile is None:
            raise AutomationError(
                "photo_picker",
                f"相册中没有找到 {filename}（备用序号 {album_index + 1}）。",
            )
        if not self.ui.tap_node(tile):
            raise AutomationError("photo_picker", "相册视频没有可点击坐标。")
        time.sleep(0.8)
        if self.ui.tap_marker(NEXT_MARKERS, exact=True, min_y=40):
            self.ui.wait_for(
                CAPTION_MARKERS + ("视频", "Video", "发布", "Post"),
                timeout=18.0,
                stage="editor",
                detail=f"第 {item_number} 条视频没有进入发布编辑页。",
            )

    @staticmethod
    def _media_tile_matches_filename(text: str, filename: str) -> bool:
        value = str(text or "").strip()
        name = Path(filename).name
        if not value or not name:
            return False
        for candidate in (name, Path(name).stem):
            if candidate and re.search(
                rf"(?<![\w]){re.escape(candidate)}(?![\w])",
                value,
                flags=re.IGNORECASE,
            ):
                return True
        return False

    def _visible_media_tiles(self) -> list[dict[str, Any]]:
        width, height = self.ui.screen_size()
        controls = {
            normalize(item)
            for item in (
                *CREATE_TAB_MARKERS,
                *RECENT_MARKERS,
                *VIDEO_FILTER_MARKERS,
                *NEXT_MARKERS,
                *DONE_MARKERS,
                "返回",
                "取消",
                "关闭",
                "Back",
                "Cancel",
                "Close",
            )
        }
        tiles: list[tuple[float, float, dict[str, Any]]] = []
        seen: set[tuple[int, int, int, int]] = set()
        for node in self.ui.nodes(include_ocr=False):
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, tile_width, tile_height = rect
            if tile_width < 68 or tile_height < 68:
                continue
            if x < 0 or y < 65 or y + tile_height > height - 45:
                continue
            if tile_width > width * 0.92 or tile_height > height * 0.45:
                continue
            if node_text(node) and normalize(node_text(node)) in controls:
                continue
            key = (round(x), round(y), round(tile_width), round(tile_height))
            if key in seen:
                continue
            seen.add(key)
            tiles.append((y, x, node))
        tiles.sort(key=lambda item: (item[0], item[1]))
        return [item[2] for item in tiles]

    @staticmethod
    def _tile_signature(
        tiles: Sequence[dict[str, Any]],
    ) -> tuple[tuple[tuple[int, int, int, int], str], ...]:
        signature = []
        for node in tiles:
            rect = node_rect(node)
            if rect is not None:
                signature.append(
                    (tuple(round(value) for value in rect), node_text(node))
                )
        return tuple(signature)

    def _find_media_tile(
        self,
        index: int,
        filename: str = "",
    ) -> dict[str, Any] | None:
        if index < 0:
            return None
        remaining = index
        tiles = self._visible_media_tiles()
        for _attempt in range(60):
            if filename:
                named_tile = next(
                    (
                        node
                        for node in tiles
                        if self._media_tile_matches_filename(node_text(node), filename)
                    ),
                    None,
                )
                if named_tile is not None:
                    return named_tile
            if remaining < len(tiles):
                return tiles[remaining]
            if not tiles:
                return None
            previous_signature = self._tile_signature(tiles)
            self.ui.swipe_up()
            refreshed = self._visible_media_tiles()
            if not refreshed or self._tile_signature(refreshed) == previous_signature:
                return None
            remaining = max(0, remaining - len(tiles))
            tiles = refreshed
        return None

    def _fill_caption(self, caption: str, hashtags: object) -> None:
        tag_text = " ".join(
            str(value).strip()
            for value in (hashtags if isinstance(hashtags, (list, tuple)) else [])
            if str(value).strip()
        )
        complete = " ".join(part for part in (caption.strip(), tag_text) if part)
        if not complete:
            raise AutomationError("caption", "这条视频没有可填写的文案。")
        node = self.ui.find_node(CAPTION_MARKERS, exact=False)
        if node is None:
            node = self._largest_editable_node()
        if node is None or not self.ui.tap_node(node):
            raise AutomationError("caption", "没有找到发布文案输入框。")
        time.sleep(0.5)
        self.ui.clear_focused_field(anchor=node_point(node))
        self.ui.input_text(complete)
        time.sleep(0.8)
        texts = self.ui.texts(include_ocr=True)
        wanted = normalize(complete[:40])
        if not any(wanted in normalize(text) for text in texts if text):
            # A second focus/type pass handles keyboards that dismiss during
            # animation, while preserving a clear hard failure otherwise.
            if self.ui.tap_node(node):
                self.ui.input_text(complete)
                time.sleep(0.8)
                texts = self.ui.texts(include_ocr=True)
        if not any(wanted in normalize(text) for text in texts if text):
            raise AutomationError("caption", "发布文案输入后无法复核，已停止以免发错内容。")

    def _largest_editable_node(self) -> dict[str, Any] | None:
        width, height = self.ui.screen_size()
        candidates: list[tuple[float, dict[str, Any]]] = []
        for node in self.ui.nodes(include_ocr=False):
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, w, h = rect
            if w < width * 0.55 or h < 38 or y < 90 or y > height * 0.82:
                continue
            marker = str(node.get("type") or node.get("role") or "").casefold()
            if bool(node.get("editable")) or "text" in marker or "field" in marker:
                candidates.append((w * h, node))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]

    def _configure_schedule(self, local_time: datetime) -> None:
        if not self.ui.tap_marker(SCHEDULE_MARKERS, exact=False):
            if self.ui.tap_marker(MORE_MARKERS, exact=False):
                time.sleep(0.5)
            if not self.ui.tap_marker(SCHEDULE_MARKERS, exact=False):
                raise AutomationError("schedule", "发布页没有找到“定时发布 / Schedule”。")
        time.sleep(0.8)
        self._set_schedule_datetime(local_time)
        texts = self.ui.texts(include_ocr=True)
        if not self._schedule_time_is_visible(texts, local_time):
            raise AutomationError(
                "schedule_time",
                f"无法确认预约时间 {local_time:%Y-%m-%d %H:%M}，已停止，未提交发布。",
            )

    def _set_schedule_datetime(self, local_time: datetime) -> None:
        # Some builds expose editable date and time fields. Fill those first.
        if self._fill_datetime_fields(local_time):
            if self.ui.tap_marker(DONE_MARKERS, exact=True):
                time.sleep(0.7)
            return
        # Otherwise use the visible calendar day and clock values.
        if self._select_calendar_day(local_time):
            self._select_clock_time(local_time)
            if self.ui.tap_marker(DONE_MARKERS, exact=True):
                time.sleep(0.7)
            return
        raise AutomationError(
            "schedule_time",
            "当前 TikTok Studio 日期选择器没有可识别的输入框或日期网格。",
        )

    def _fill_datetime_fields(self, local_time: datetime) -> bool:
        nodes = self.ui.nodes(include_ocr=True)
        date_node = None
        time_node = None
        for node in nodes:
            text = node_text(node)
            if date_node is None and any(text_matches(text, marker) for marker in DATE_MARKERS):
                date_node = node
            if time_node is None and any(text_matches(text, marker) for marker in TIME_MARKERS):
                time_node = node
        if date_node is None or time_node is None:
            return False
        if not self.ui.tap_node(date_node):
            return False
        self.ui.clear_focused_field(anchor=node_point(date_node))
        self.ui.input_text(local_time.strftime("%Y-%m-%d"))
        if not self.ui.tap_node(time_node):
            return False
        self.ui.clear_focused_field(anchor=node_point(time_node))
        self.ui.input_text(local_time.strftime("%H:%M"))
        return True

    def _select_calendar_day(self, local_time: datetime) -> bool:
        deadline = time.monotonic() + 8.0
        while time.monotonic() < deadline:
            nodes = self.ui.nodes(include_ocr=True)
            month_text = "\n".join(node_text(node) for node in nodes if node_text(node))
            match = re.search(r"(20\d{2})\s*[年/-]\s*(\d{1,2})\s*月?", month_text)
            if match is not None:
                current_year, current_month = int(match.group(1)), int(match.group(2))
            else:
                current_year, current_month = local_time.year, local_time.month
            if (current_year, current_month) == (local_time.year, local_time.month):
                day_node = find_exact_node(nodes, str(local_time.day))
                if day_node is not None and self.ui.tap_node(day_node):
                    time.sleep(0.6)
                    return True
            if (current_year, current_month) > (local_time.year, local_time.month):
                break
            if not self.ui.tap_marker(("›", ">", "下一个", "Next"), exact=True):
                break
            time.sleep(0.5)
        return False

    def _select_clock_time(self, local_time: datetime) -> bool:
        nodes = self.ui.nodes(include_ocr=True)
        time_text = local_time.strftime("%H:%M")
        exact = find_exact_node(nodes, time_text)
        if exact is not None and self.ui.tap_node(exact):
            return True
        # If the wheel shows hour and minute separately, tapping both exact
        # values is safe only when both nodes are present.
        hour_node = find_exact_node(nodes, local_time.strftime("%H"))
        minute_node = find_exact_node(nodes, local_time.strftime("%M"))
        if hour_node is not None and minute_node is not None:
            if self.ui.tap_node(hour_node):
                time.sleep(0.3)
                return self.ui.tap_node(minute_node)
        return False

    @staticmethod
    def _schedule_time_is_visible(texts: Sequence[str], local_time: datetime) -> bool:
        joined = normalize("\n".join(texts))
        date_candidates = {
            f"{local_time.year}-{local_time.month:02d}-{local_time.day:02d}",
            f"{local_time.year}/{local_time.month}/{local_time.day}",
            f"{local_time.year}年{local_time.month}月{local_time.day}日",
            f"{local_time.month}月{local_time.day}日",
            local_time.strftime("%b %d, %Y"),
            local_time.strftime("%B %d, %Y"),
        }
        twelve_hour = local_time.strftime("%I:%M %p")
        time_candidates = {
            f"{local_time.hour:02d}:{local_time.minute:02d}",
            twelve_hour,
            twelve_hour.lstrip("0"),
        }
        return any(normalize(value) in joined for value in date_candidates) and any(
            normalize(value) in joined for value in time_candidates
        )

    def _submit_schedule(self, local_time: datetime) -> None:
        self._assert_not_blocked()
        nodes = self.ui.nodes(include_ocr=True)
        texts = [node_text(node) for node in nodes if node_text(node)]
        if immediate_publish_is_active(nodes):
            raise AutomationError("submit", "页面仍处于立即发布模式，已停止预约。")
        if not contains_text(texts, CONFIRM_SCHEDULE_MARKERS, exact=False):
            raise AutomationError("submit", "没有检测到定时发布状态，已停止提交。")
        if not self._schedule_time_is_visible(texts, local_time):
            raise AutomationError("submit", "提交前预约时间复核失败，已停止提交。")
        if not self.ui.tap_marker(SUBMIT_MARKERS, exact=False):
            raise AutomationError("submit", "没有找到预约发布按钮。")
        try:
            self.ui.wait_for(
                SUCCESS_MARKERS,
                timeout=25.0,
                stage="submit",
                detail="提交后没有检测到预约成功提示。",
            )
        except AutomationError:
            # Some versions return directly to Studio home without a toast.
            if not contains_text(self.ui.texts(include_ocr=True), CREATE_TAB_MARKERS):
                raise

    def _open_creator_for_review(self) -> tuple[bool, str]:
        try:
            self._open_create_page()
            screenshot = self.ui.client.screenshot_jpeg()
            path = self.output_dir / "创作页面复核.jpg"
            path.write_bytes(screenshot)
            emit_progress("creator_review", f"已打开创作页面供复核：{path}")
            return True, str(path)
        except Exception as error:
            emit_progress("creator_review", f"创作页面复核失败：{clean(error, 300)}")
            return False, ""


def diagnose(output_dir: Path, port: int) -> int:
    output_dir.mkdir(parents=True, exist_ok=True)
    ui = UiAutomation(port, STUDIO_BUNDLE_ID, timeout=90.0)
    try:
        ui.connect()
        ui.launch_app(STUDIO_BUNDLE_ID)
        ui.dismiss_overlays()
        nodes = ui.nodes(include_ocr=False)
        ocr_nodes = ui.ocr_nodes()
        (output_dir / "studio_nodes.json").write_text(
            json.dumps(nodes, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (output_dir / "studio_ocr_nodes.json").write_text(
            json.dumps(ocr_nodes, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (output_dir / "studio_current.jpg").write_bytes(ui.client.screenshot_jpeg())
        print(f"Studio diagnostic saved to {output_dir}", flush=True)
        return 0
    finally:
        ui.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="在 TikTok Studio 逐条设置定时发布")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--diagnose-dir", type=Path)
    args = parser.parse_args()
    if args.diagnose_dir is not None:
        return diagnose(args.diagnose_dir.resolve(), args.port)
    try:
        payload = read_payload()
    except Exception as error:
        emit_result(
            {
                "success": False,
                "stage": "task",
                "detail": clean(error),
                "total_count": 0,
                "scheduled_count": 0,
                "failed_count": 0,
                "items": [],
                "creator_visible": False,
                "creator_screenshot": "",
                "phone_timezone": "",
            }
        )
        return 2
    return StudioScheduleRunner(args.port, payload).run()


if __name__ == "__main__":
    raise SystemExit(main())
