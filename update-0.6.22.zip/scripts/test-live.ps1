﻿[CmdletBinding()]
param(
    [string]$OutputDirectory = "",
    [string]$Udid = "",
    [switch]$OpenReport
)

$ErrorActionPreference = "Stop"
try {
    $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $Utf8NoBom
    [Console]::InputEncoding = $Utf8NoBom
    $OutputEncoding = $Utf8NoBom
}
catch {
}

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptRoot
$PortablePython = Join-Path $ProjectRoot "runtime\python.exe"
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$Python = if (Test-Path -LiteralPath $PortablePython) { $PortablePython } else { $VenvPython }
$AcceptanceScript = Join-Path $ScriptRoot "live_acceptance_mcp.py"

if (-not (Test-Path -LiteralPath $Python)) {
    throw "没有找到内置运行环境。请重新打开「群控小助手」，不要单独移动 runtime 文件夹。"
}
if (-not (Test-Path -LiteralPath $AcceptanceScript)) {
    throw "没有找到真机验收脚本：$AcceptanceScript"
}

if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $OutputDirectory = Join-Path $ProjectRoot "work\mcp_live_test_$stamp"
}
elseif (-not [System.IO.Path]::IsPathRooted($OutputDirectory)) {
    $OutputDirectory = Join-Path $ProjectRoot $OutputDirectory
}

$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$ConsoleLog = Join-Path $OutputDirectory "console.log"
$ErrorLog = Join-Path $OutputDirectory "stderr.log"

Write-Host "iPhone Control Center 20 - 15 步真机验收" -ForegroundColor Green
Write-Host "连接方式：USB + 越狱手机端直连组件"
Write-Host "结果目录：$OutputDirectory"
Write-Host "测试会自行锁屏并自动唤醒；请保持 USB 连接，不要拔线。"

Push-Location $ProjectRoot
$exitCode = 1
try {
    $oldPath = $env:PYTHONPATH
    $oldUtf8 = $env:PYTHONUTF8
    $oldIoEncoding = $env:PYTHONIOENCODING
    try {
        $env:PYTHONPATH = Join-Path $ProjectRoot "src"
        $env:PYTHONUTF8 = "1"
        $env:PYTHONIOENCODING = "utf-8"
        $AcceptanceArguments = @(
            $AcceptanceScript,
            "--output-dir",
            $OutputDirectory
        )
        if (-not [string]::IsNullOrWhiteSpace($Udid)) {
            $AcceptanceArguments += @("--udid", $Udid.Trim())
        }
        & $Python @AcceptanceArguments 2> $ErrorLog | Tee-Object -FilePath $ConsoleLog
        $exitCode = $LASTEXITCODE
    }
    finally {
        $env:PYTHONPATH = $oldPath
        $env:PYTHONUTF8 = $oldUtf8
        $env:PYTHONIOENCODING = $oldIoEncoding
    }
}
finally {
    Pop-Location
}

$ReportPath = Join-Path $OutputDirectory "acceptance.json"
if (Test-Path -LiteralPath $ReportPath) {
    $report = Get-Content -LiteralPath $ReportPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Host ""
    if ($report.success) {
        $passed = @($report.steps | Where-Object { $_.success }).Count
        Write-Host "真机验收通过：$passed/15，用时 $($report.duration_seconds) 秒。" -ForegroundColor Green
    }
    else {
        Write-Host "真机验收未通过。" -ForegroundColor Red
        Write-Host "原因：$($report.error)"
    }
}
else {
    Write-Host "没有生成验收报告。请查看：$ErrorLog" -ForegroundColor Red
}

if ($OpenReport) {
    Start-Process explorer.exe -ArgumentList $OutputDirectory
}

if ($exitCode -ne 0) {
    exit $exitCode
}
exit 0
