from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.services.ios_mcp_control import (  # noqa: E402
    McpHttpClient,
    McpProtocolError,
)
from iphone_control_center.services.tiktok_accounts import (  # noqa: E402
    TikTokLoginAccount,
    TikTokTemplateError,
)


TIKTOK_STUDIO_BUNDLE_ID = "com.ss.iphone.tt.creator"
TIKTOK_BUNDLE_ID = "com.zhiliaoapp.musically"
DEFAULT_BUNDLE_ID = TIKTOK_STUDIO_BUNDLE_ID
SAFARI_BUNDLE_ID = "com.apple.mobilesafari"
RESULT_PREFIX = "TIKTOK_LOGIN_RESULT|"
PROGRESS_PREFIX = "TIKTOK_LOGIN_PROGRESS|"
VERIFICATION_HTTP_TIMEOUT = 15.0
VERIFICATION_HTTP_MAX_BYTES = 1024 * 1024
INPUT_RETRY_DELAY_SECONDS = 2.0
WRONG_CODE_LINK_REFRESH_DELAY_SECONDS = 6.0
VERIFICATION_HTTP_USER_AGENT = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 "
    "Mobile/15E148 Safari/604.1"
)

LOGIN_ENTRY_MARKERS = (
    "使用手机号码/电子邮箱/用户名登录",
    "使用手机号码/电子邮件/用户名登录",
    "Use phone/email/username",
)
STUDIO_LOGIN_TITLE_MARKERS = (
    "登录 TikTok Studio",
    "Log in to TikTok Studio",
    "Log into TikTok Studio",
)
STUDIO_MANAGE_TAB_MARKERS = ("管理", "manage", "Manage")
STUDIO_LOGGED_IN_MARKERS = (
    "账号概览",
    "账号数据",
    "作品数据",
    "作品",
    "评论",
    "粉丝",
    "Account overview",
    "Analytics",
    "Posts",
    "Comments",
    "Followers",
)
EMAIL_TAB_MARKERS = ("邮箱/用户名", "电子邮件或用户名", "Email/username")
EMAIL_FIELD_MARKERS = ("电子邮件或用户名", "邮箱/用户名", "Email or username")
CONTINUE_MARKERS = (
    "继续",
    "下一步",
    "登录",
    "Next",
    "Continue",
    "Log in",
    "Login",
    "Sign in",
)
PASSWORD_MARKERS = ("密码", "Password")
SECURE_CONTENT_MARKERS = ("•", "●", "*", "·")
VERIFICATION_MARKERS = (
    "验证码",
    "确认代码",
    "安全代码",
    "输入代码",
    "输入 6 位代码",
    "6 位代码",
    "verification code",
    "security code",
    "enter the code",
    "enter code",
    "6-digit code",
    "one-time code",
)
CODE_ERROR_MARKERS = (
    "验证码已过期",
    "验证码过期",
    "验证码无效",
    "验证码错误",
    "验证码不正确",
    "代码已过期",
    "代码无效",
    "链接已过期",
    "code has expired",
    "code expired",
    "code is invalid",
    "invalid code",
    "incorrect code",
    "verification code is incorrect",
    "code is no longer valid",
)
RESEND_CODE_MARKERS = (
    "重新发送验证码",
    "重新发送",
    "发送验证码",
    "获取新验证码",
    "Resend code",
    "Send code",
    "Get new code",
    "Resend",
)
PASTE_MARKERS = ("粘贴", "Paste")
SECURITY_CHOICE_MARKERS = (
    "核实确实是你本人",
    "确认是你本人",
    "选择一种方式进行身份验证",
    "确保确实是你本人登录",
    "Verify it's you",
    "Verify it’s you",
    "Confirm it's you",
    "Confirm it’s you",
    "Choose a way to verify",
    "Choose a verification method",
    "Select a verification method",
    "Verify your identity",
)
EMAIL_OPTION_MARKERS = (
    "电子邮件",
    "邮箱",
    "Email",
    "E-mail",
    "Email address",
    "Send code to email",
)
AUTHENTICATOR_OPTION_MARKERS = (
    "身份验证器",
    "验证器",
    "动态密码",
    "动态码",
    "Authenticator",
    "Authenticator app",
    "Authentication app",
    "Two-factor authentication",
    "2FA",
)
CAPTCHA_MARKERS = (
    "拖动滑块",
    "完成安全验证",
    "请完成下列验证",
    "验证你是真人",
    "选择所有符合",
    "captcha",
    "安全验证",
)
CONSENT_PROMPT_MARKERS = (
    "点击【同意并继续】",
    "点击“同意并继续”",
    "点击\"同意并继续\"",
    "点击同意并继续",
    "By tapping Agree and continue",
    "By clicking Agree and continue",
    "By continuing, you agree to our Terms of Service",
    "By continuing, you agree to our Privacy Policy",
)
CONSENT_ACCEPT_MARKERS = (
    "同意并继续",
    "同意並繼續",
    "Agree and continue",
    "Agree & continue",
    "Accept and continue",
    "Accept & continue",
    "I agree",
)
SYSTEM_PERMISSION_PROMPT_MARKERS = (
    "想给你发送通知",
    "想要给你发送通知",
    "想访问你的相机",
    "想访问你的麦克风",
    "想访问你的照片",
    "想使用你的相机",
    "想使用你的麦克风",
    "想使用你的照片",
    "Would Like to Send You Notifications",
    "Would Like to Access Your Camera",
    "Would Like to Access the Microphone",
    "Would Like to Access Your Photos",
    "Would Like to Use Your Camera",
    "Would Like to Use the Microphone",
)
SYSTEM_PERMISSION_ALLOW_MARKERS = (
    "允许完全访问",
    "允许访问所有照片",
    "允许所有照片",
    "Allow Full Access",
    "Allow Access to All Photos",
    "允许",
    "Allow",
)
ACCOUNT_ERROR_MARKERS = (
    "用户不存在",
    "找不到该账号",
    "账号或密码错误",
    "密码错误",
    "登录失败",
    "incorrect password",
    "couldn't find your account",
)
ACCOUNT_MISSING_MARKERS = (
    "用户不存在",
    "用户已注销",
    "用户已删除",
    "该用户不存在",
    "找不到该账号",
    "找不到该用户",
    "无法找到该账号",
    "该账号不存在",
    "此账号不存在",
    "该账号已被删除",
    "账号已注销",
    "account not found",
    "user not found",
    "couldn't find your account",
    "couldn’t find your account",
    "couldn't find this account",
    "couldn’t find this account",
    "this account doesn't exist",
    "this account doesn’t exist",
)
RATE_LIMIT_MARKERS = (
    "访问太频繁",
    "操作太频繁",
    "尝试次数过多",
    "请稍后再试",
    "too many attempts",
    "too many requests",
    "try again later",
    "rate limit",
)
HOME_MARKERS = ("推荐", "关注", "社区", "For You", "Following", "Profile", "主页")


class LoginFlowError(RuntimeError):
    def __init__(self, stage: str, detail: str) -> None:
        super().__init__(detail)
        self.stage = stage
        self.detail = detail


def emit_progress(stage: str, message: str) -> None:
    print(f"{PROGRESS_PREFIX}{stage}|{message}", flush=True)


def emit_result(
    success: bool,
    stage: str,
    detail: str,
    account: TikTokLoginAccount | None,
) -> None:
    print(
        RESULT_PREFIX
        + json.dumps(
            {
                "success": success,
                "stage": stage,
                "detail": detail,
                "account_masked": account.masked_account if account is not None else "",
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        flush=True,
    )


def normalize(value: str) -> str:
    return re.sub(r"\s+", "", value or "").casefold()


def contains_any(texts: list[str], markers: tuple[str, ...]) -> bool:
    haystack = [normalize(text) for text in texts]
    return any(normalize(marker) in text for marker in markers for text in haystack)


class TikTokEmailLoginFlow:
    def __init__(
        self,
        port: int,
        account: TikTokLoginAccount,
        *,
        bundle_id: str = DEFAULT_BUNDLE_ID,
    ) -> None:
        self.client = McpHttpClient(f"http://127.0.0.1:{port}")
        self.account = account
        self.bundle_id = bundle_id
        self.is_studio = bundle_id == TIKTOK_STUDIO_BUNDLE_ID
        self._verification_attempts = 0
        self._last_verification_code = ""

    @property
    def app_name(self) -> str:
        return "TikTok Studio" if self.is_studio else "TikTok"

    def run(self) -> None:
        self.client.connect()
        emit_progress("connect", "已连接手机控制服务")
        if self._resume_login_flow_if_present():
            self._wait_for_login_success()
            return
        self._open_clean_login_page()
        self._submit_account()
        self._submit_password_or_verification()
        self._wait_for_login_success()

    def close(self) -> None:
        self.client.close()

    def _tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def _nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "get_ui_elements",
                {"visible_only": True, "clickable_only": False},
            )
        except McpProtocolError:
            return []
        if isinstance(value, dict):
            for key in ("elements", "ui_elements", "items"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    return [node for node in nodes if isinstance(node, dict)]
        return []

    def _ocr_nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "ocr_screen",
                {"engine": "paddleocr", "min_confidence": 0.35},
            )
        except McpProtocolError:
            return []
        roots: list[Any] = []
        if isinstance(value, list):
            roots = value
        elif isinstance(value, dict):
            for key in ("results", "items", "texts", "elements"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    roots.extend(nodes)
        result: list[dict[str, Any]] = []
        for node in roots:
            if isinstance(node, str) and node.strip():
                result.append({"text": node.strip()})
            elif isinstance(node, dict) and str(node.get("text") or "").strip():
                result.append(node)
        return result

    def _texts(self, *, include_ocr: bool = False) -> list[str]:
        nodes = self._nodes()
        if include_ocr:
            nodes.extend(self._ocr_nodes())
        texts: list[str] = []
        for node in nodes:
            for key in ("text", "label", "value", "name", "title"):
                value = node.get(key)
                if value is not None and str(value).strip():
                    texts.append(str(value).strip())
                    break
        return texts

    def _frontmost_bundle(self) -> str:
        try:
            value = self._tool("get_frontmost_app", {})
        except McpProtocolError:
            return ""
        if isinstance(value, dict):
            return str(value.get("bundleId") or value.get("bundle_id") or "")
        return ""

    def _screen_size(self) -> tuple[int, int]:
        value = self._tool("get_screen_info", {})
        if not isinstance(value, dict):
            return (375, 667)
        try:
            return (int(value.get("width") or 375), int(value.get("height") or 667))
        except (TypeError, ValueError):
            return (375, 667)

    def _tap_xy(self, x: float, y: float) -> None:
        self._tool("tap_screen", {"x": round(x), "y": round(y)})

    def _tap_text(self, marker: str, *, exact: bool = True, index: int = 0) -> bool:
        try:
            value = self._tool(
                "tap_element",
                {
                    "text": marker,
                    "match": "exact" if exact else "contains",
                    "role": "control",
                    "index": index,
                },
            )
        except McpProtocolError:
            return False
        return isinstance(value, dict) and bool(value.get("tapped"))

    def _tap_markers(self, markers: tuple[str, ...]) -> bool:
        for _attempt in range(2):
            for marker in markers:
                if self._tap_text(marker, exact=True):
                    return True
            for marker in markers:
                if self._tap_text(marker, exact=False):
                    return True
            time.sleep(0.25)
        return False

    def _has_exact_text(self, markers: tuple[str, ...]) -> bool:
        expected = {normalize(marker) for marker in markers}
        return any(normalize(self._node_text(node)) in expected for node in self._nodes())

    def _node_text(self, node: dict[str, Any]) -> str:
        for key in ("text", "label", "value", "name", "title"):
            value = node.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""

    def _find_node(
        self,
        markers: tuple[str, ...],
        *,
        exact: bool = False,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, Any] | None:
        for node in self._nodes():
            text = normalize(self._node_text(node))
            if not text:
                continue
            matched = any(
                (text == normalize(marker)) if exact else (normalize(marker) in text)
                for marker in markers
            )
            if not matched:
                continue
            tap = node.get("tap")
            if not isinstance(tap, dict) or "x" not in tap or "y" not in tap:
                continue
            y = float(tap["y"])
            if min_y is not None and y < min_y:
                continue
            if max_y is not None and y > max_y:
                continue
            return node
        return None

    def _tap_node(self, node: dict[str, Any]) -> None:
        tap = node.get("tap")
        if not isinstance(tap, dict) or "x" not in tap or "y" not in tap:
            raise LoginFlowError("tap", "界面控件没有可点击坐标")
        self._tap_xy(float(tap["x"]), float(tap["y"]))

    def _assert_no_captcha(self, texts: list[str]) -> None:
        if not contains_any(texts, CAPTCHA_MARKERS):
            return
        emit_progress(
            "security",
            "检测到安全验证，请在手机上手动完成；完成后软件会自动继续登录。",
        )
        deadline = time.monotonic() + 180.0
        while time.monotonic() < deadline:
            current = self._texts()
            if not contains_any(current, CAPTCHA_MARKERS):
                emit_progress("security", "安全验证已完成，正在继续登录")
                time.sleep(0.6)
                return
            time.sleep(1.0)
        raise LoginFlowError(
            "security",
            "安全验证等待超时，请在手机上完成滑块或拼图后重新执行。",
        )

    def _accept_consent_if_present(self, texts: list[str]) -> bool:
        if not contains_any(texts, CONSENT_PROMPT_MARKERS):
            return False
        if not self._has_exact_text(CONSENT_ACCEPT_MARKERS):
            return False
        emit_progress(
            "consent",
            f"检测到 {self.app_name} 登录提示，正在自动点击“同意并继续”",
        )
        if not self._tap_markers(CONSENT_ACCEPT_MARKERS):
            raise LoginFlowError(
                "consent",
                "检测到 TikTok 同意弹窗，但没有找到可点击的“同意并继续”按钮。",
            )
        deadline = time.monotonic() + 8.0
        while time.monotonic() < deadline:
            if not self._has_exact_text(CONSENT_ACCEPT_MARKERS):
                emit_progress(
                    "consent",
                    f"已同意 {self.app_name} 登录提示，正在继续登录",
                )
                time.sleep(0.7)
                return True
            time.sleep(0.35)
        raise LoginFlowError(
            "consent",
            "已点击“同意并继续”，但 TikTok 提示窗口没有关闭，请手动检查。",
        )

    def _accept_system_permission_if_present(self, texts: list[str]) -> bool:
        if not contains_any(texts, SYSTEM_PERMISSION_PROMPT_MARKERS):
            return False
        emit_progress(
            "permission",
            "检测到 iPhone 系统权限弹窗，正在自动选择“允许”",
        )
        if not self._tap_markers(SYSTEM_PERMISSION_ALLOW_MARKERS):
            raise LoginFlowError(
                "permission",
                "检测到 iPhone 系统权限弹窗，但没有找到“允许”按钮。",
            )
        time.sleep(0.8)
        return True

    def _wait_for(
        self,
        predicate: Callable[[list[str]], bool],
        *,
        timeout: float,
        stage: str,
        timeout_detail: str,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._texts()
            self._assert_no_captcha(latest)
            self._raise_rate_limit_if_present(latest)
            if self._accept_system_permission_if_present(latest):
                continue
            if predicate(latest):
                return latest
            time.sleep(0.35)
        raise LoginFlowError(stage, timeout_detail)

    def _wait_tiktok_foreground(self, *, timeout: float = 15.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._frontmost_bundle() == self.bundle_id:
                return
            time.sleep(0.25)
        app_name = "TikTok Studio" if self.is_studio else "TikTok"
        raise LoginFlowError(
            "launch",
            f"{app_name} 没有在前台打开，请确认 App 仍已安装且手机已解锁。",
        )

    def _launch_login_app(self) -> None:
        last_error = ""
        for attempt in range(1, 4):
            try:
                self._tool("launch_app", {"bundle_id": self.bundle_id})
            except Exception as error:
                last_error = " ".join(str(error).split())[:220]
            try:
                self._wait_tiktok_foreground(timeout=7.0)
                return
            except LoginFlowError:
                try:
                    self._tool("wake_and_home", {"sequence": "auto"})
                except Exception:
                    pass
                if attempt < 3:
                    emit_progress(
                        "launch",
                        f"{self.app_name} 首次没有打开，正在自动重试（{attempt + 1}/3）",
                    )
                    time.sleep(1.2 * attempt)
        suffix = f"：{last_error}" if last_error else ""
        raise LoginFlowError(
            "launch",
            f"{self.app_name} 连续 3 次没有打开，请确认 App 仍已安装且手机已解锁{suffix}",
        )

    def _resume_login_flow_if_present(self) -> bool:
        """Continue an interrupted login instead of reopening the Studio tab."""
        if self._frontmost_bundle() != self.bundle_id:
            return False
        texts = self._texts(include_ocr=True)
        self._raise_rate_limit_if_present(texts)
        self._raise_account_missing_if_present(texts)
        if contains_any(texts, PASSWORD_MARKERS):
            emit_progress("resume", "检测到空密码页，正在返回账号页重新核对并填写")
            if not self._tap_markers(("返回", "Back")):
                node = self._find_node(("返回", "Back"), min_y=0, max_y=100)
                if node is None:
                    raise LoginFlowError(
                        "resume",
                        "检测到密码页，但没有找到返回账号页的按钮。",
                    )
                self._tap_node(node)
            texts = self._wait_for(
                lambda current: contains_any(current, EMAIL_FIELD_MARKERS),
                timeout=8.0,
                stage="resume",
                timeout_detail="从密码页返回后，没有找到邮箱/用户名输入框。",
            )
        if contains_any(texts, EMAIL_FIELD_MARKERS):
            emit_progress("resume", "检测到账号登录页，正在按 Word 账号续接登录")
            self._submit_account()
            return True
        if self._is_verification_step(texts):
            emit_progress("resume", "检测到验证码页，正在续接验证流程")
            return True
        return False

    def _open_clean_login_page(self) -> None:
        app_name = "TikTok Studio" if self.is_studio else "TikTok"
        emit_progress("launch", f"正在唤醒手机并启动 {app_name}")
        try:
            self._tool("wake_and_home", {"sequence": "auto"})
        except Exception:
            pass
        if self._frontmost_bundle() != self.bundle_id:
            self._launch_login_app()
        time.sleep(2.0)

        if self.is_studio:
            self._open_studio_manage_page()

        started_at = time.monotonic()
        deadline = started_at + 20.0
        home_seen_at: float | None = None
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._texts(include_ocr=True)
            self._assert_no_captcha(latest)
            self._raise_rate_limit_if_present(latest)
            if self._accept_system_permission_if_present(latest):
                continue
            if self._accept_consent_if_present(latest):
                continue
            if contains_any(latest, EMAIL_FIELD_MARKERS):
                break
            if contains_any(latest, LOGIN_ENTRY_MARKERS):
                emit_progress("email_tab", "正在进入邮箱/用户名登录")
                self._tap_markers(LOGIN_ENTRY_MARKERS)
                time.sleep(0.8)
                continue
            if contains_any(latest, EMAIL_TAB_MARKERS):
                break
            if self._is_home(latest):
                now = time.monotonic()
                if home_seen_at is None:
                    home_seen_at = now
                if now - home_seen_at >= 5.0:
                    raise LoginFlowError(
                        "already_logged_in",
                        "TikTok 当前已经登录账号，请先在手机里退出当前账号再执行。",
                    )
            else:
                home_seen_at = None
            time.sleep(0.35)
        else:
            if self._is_home(self._texts()):
                raise LoginFlowError(
                    "already_logged_in",
                    f"{app_name} 当前已经登录账号，请先在手机里退出当前账号再执行。",
                )
            raise LoginFlowError(
                "open_login",
                f"没有找到 {app_name} 登录入口，请确认 App 页面正常。",
            )

        if not self._tap_markers(EMAIL_TAB_MARKERS):
            node = self._find_node(EMAIL_TAB_MARKERS, min_y=55, max_y=130)
            if node is None:
                raise LoginFlowError("email_tab", "没有找到“邮箱/用户名”页签。")
            self._tap_node(node)
        self._wait_for(
            lambda texts: contains_any(texts, EMAIL_FIELD_MARKERS),
            timeout=10.0,
            stage="email_field",
            timeout_detail="邮箱/用户名输入框没有出现。",
        )
        if not self._tap_text("清除文本", exact=True):
            self._tap_text("清除文本", exact=False)
        time.sleep(0.25)
        emit_progress("email_tab", "已进入邮箱/用户名登录页")

    def _open_studio_manage_page(self) -> None:
        """Reach the signed-out Studio management page before starting login."""
        deadline = time.monotonic() + 25.0
        last_manage_tap = 0.0
        last_login_tap = 0.0
        while time.monotonic() < deadline:
            texts = self._texts(include_ocr=True)
            self._assert_no_captcha(texts)
            self._raise_rate_limit_if_present(texts)
            if self._accept_system_permission_if_present(texts):
                continue
            if contains_any(texts, LOGIN_ENTRY_MARKERS):
                return
            if contains_any(texts, EMAIL_FIELD_MARKERS):
                return

            if contains_any(texts, STUDIO_LOGIN_TITLE_MARKERS):
                now = time.monotonic()
                if now - last_login_tap > 1.5:
                    node = self._find_node(("登录", "Log in", "Sign in"), min_y=420, max_y=610)
                    if node is not None:
                        emit_progress("studio_login", "正在打开 TikTok Studio 登录页")
                        self._tap_node(node)
                    else:
                        width, height = self._screen_size()
                        self._tap_xy(width * 0.5, height * 0.78)
                    last_login_tap = now
                time.sleep(0.45)
                continue

            now = time.monotonic()
            if now - last_manage_tap > 1.5:
                if not self._tap_markers(STUDIO_MANAGE_TAB_MARKERS):
                    width, height = self._screen_size()
                    self._tap_xy(width * 0.9, height * 0.96)
                last_manage_tap = now
            time.sleep(0.45)
        raise LoginFlowError(
            "studio_login",
            "没有找到 TikTok Studio 的“管理 > 登录”入口，请确认 Studio 页面正常。",
        )

    def _focus_field(
        self,
        markers: tuple[str, ...],
        *,
        min_y: float = 105,
        max_y: float = 330,
    ) -> None:
        for marker in markers:
            if self._tap_text(marker, exact=True):
                return
        node = self._find_node(markers, min_y=min_y, max_y=max_y)
        if node is None:
            raise LoginFlowError("field", "没有找到要填写的输入框。")
        self._tap_node(node)

    def _input_text(
        self, value: str, *, secure: bool = False, force_type: bool = False
    ) -> None:
        if secure or force_type:
            try:
                self._tool("type_text", {"text": value, "delay_ms": 45})
                time.sleep(0.75)
                return
            except Exception:
                pass
        try:
            self._tool("input_text", {"text": value})
        except Exception:
            self._tool("type_text", {"text": value, "delay_ms": 35})
        time.sleep(0.55)

    @staticmethod
    def _node_y(node: dict[str, Any]) -> float | None:
        tap = node.get("tap")
        if isinstance(tap, dict) and tap.get("y") is not None:
            try:
                return float(tap["y"])
            except (TypeError, ValueError):
                pass
        rect = node.get("rect") or node.get("visible_rect")
        if isinstance(rect, dict) and rect.get("y") is not None:
            try:
                return float(rect["y"]) + float(rect.get("height") or 0) / 2
            except (TypeError, ValueError):
                pass
        return None

    def _field_has_content(
        self,
        center_y: float,
        markers: tuple[str, ...],
        *,
        expected: str | None,
        include_ocr: bool = False,
    ) -> bool:
        expected_normalized = normalize(expected or "")
        nodes = self._nodes()
        self._raise_rate_limit_if_present([self._node_text(node) for node in nodes])
        for node in nodes:
            y = self._node_y(node)
            # The secure text field reports its placeholder and masked value as
            # separate accessibility nodes with different vertical coordinates.
            if y is None or abs(y - center_y) > 120:
                continue
            text = self._node_text(node)
            normalized = normalize(text)
            if not normalized:
                continue
            if expected_normalized:
                if normalized == expected_normalized or (
                    len(normalized) >= 6 and normalized in expected_normalized
                ):
                    return True
                continue
            if any(normalize(marker) in normalized for marker in markers):
                continue
            if any(marker in text for marker in SECURE_CONTENT_MARKERS):
                return True
            if re.fullmatch(r"\d{4,8}", text):
                return True
        if not include_ocr:
            return False
        ocr_nodes = self._ocr_nodes()
        self._raise_rate_limit_if_present(
            [self._node_text(node) for node in ocr_nodes]
        )
        for node in ocr_nodes:
            y = self._node_y(node)
            if y is None or abs(y - center_y) > 130:
                continue
            text = self._node_text(node)
            normalized = normalize(text)
            if expected_normalized and (
                normalized == expected_normalized
                or (len(normalized) >= 6 and normalized in expected_normalized)
            ):
                return True
            if any(marker in text for marker in SECURE_CONTENT_MARKERS):
                return True
            if re.fullmatch(r"\d{4,8}", text):
                return True
        return False

    def _clear_field(self, *, min_y: float, max_y: float) -> None:
        if self._tap_text("清除文本", exact=True):
            return
        if self._tap_text("Clear text", exact=True):
            return
        if self._tap_text("清除文本", exact=False):
            return
        node = self._find_node(
            ("关闭", "清除", "Clear", "Close"),
            exact=True,
            min_y=min_y,
            max_y=max_y,
        )
        if node is not None:
            self._tap_node(node)

    def _clear_clipboard(self) -> None:
        try:
            self._tool("set_clipboard", {"text": ""})
        except Exception:
            pass

    def _paste_field_value(
        self,
        value: str,
        *,
        center_y: float,
        markers: tuple[str, ...],
        expected: str | None,
        min_y: float,
        max_y: float,
    ) -> bool:
        try:
            self._tool("set_clipboard", {"text": value})
            anchor = self._find_node(
                ("关闭", "清除文本", "Clear text"),
                exact=True,
                min_y=min_y,
                max_y=max_y,
            )
            width, height = self._screen_size()
            if anchor is not None:
                anchor_y = self._node_y(anchor)
                paste_y = anchor_y if anchor_y is not None else center_y
                paste_x = width * 0.45
            else:
                paste_x = width * 0.5
                paste_y = center_y
            self._tool(
                "long_press",
                {"x": round(paste_x), "y": round(paste_y), "duration": 900},
            )
            time.sleep(0.45)
            if not self._tap_markers(PASTE_MARKERS):
                self._clear_clipboard()
                return False
            pasted = self._wait_for_field_content(
                center_y, markers, expected=expected, timeout=2.0
            )
            self._clear_clipboard()
            return pasted
        except Exception:
            self._clear_clipboard()
            return False

    def _wait_for_field_content(
        self,
        center_y: float,
        markers: tuple[str, ...],
        *,
        expected: str | None,
        timeout: float = 2.0,
    ) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._field_has_content(center_y, markers, expected=expected):
                return True
            time.sleep(0.2)
        return self._field_has_content(
            center_y, markers, expected=expected, include_ocr=True
        )

    def _input_with_retry(
        self,
        value: str,
        *,
        field_name: str,
        markers: tuple[str, ...],
        secure: bool,
        expected: str | None,
        min_y: float = 105,
        max_y: float = 340,
    ) -> None:
        node = self._find_node(markers, min_y=min_y, max_y=max_y)
        center_y = self._node_y(node) if node is not None else (min_y + max_y) / 2
        tap = node.get("tap") if node is not None else None
        for attempt in range(1, 4):
            if attempt == 1:
                self._focus_field(markers, min_y=min_y, max_y=max_y)
            elif isinstance(tap, dict) and "x" in tap and "y" in tap:
                self._tap_xy(float(tap["x"]), float(tap["y"]))
            else:
                self._focus_field(markers, min_y=min_y, max_y=max_y)
            self._clear_field(min_y=min_y, max_y=max_y)
            if self._paste_field_value(
                value,
                center_y=center_y,
                markers=markers,
                expected=expected,
                min_y=min_y,
                max_y=max_y,
            ):
                emit_progress("input", f"{field_name}已通过粘贴写入")
                return
            emit_progress("input", f"{field_name}粘贴未成功，改用键盘输入")
            self._input_text(value, secure=secure, force_type=attempt > 1)
            if self._wait_for_field_content(
                center_y, markers, expected=expected, timeout=2.0
            ):
                return
            self._raise_rate_limit_if_present(self._texts())
            if attempt < 3:
                emit_progress(
                    "input_retry",
                    f"检测到{field_name}没有输入，2 秒后自动重新输入"
                    f"（第 {attempt + 1}/3 次）",
                )
                time.sleep(INPUT_RETRY_DELAY_SECONDS)
        raise LoginFlowError(
            "input",
            f"{field_name}连续 3 次没有输入成功，请确认输入框和键盘正常。",
        )

    def _tap_continue(self) -> None:
        if self._tap_markers(CONTINUE_MARKERS):
            return
        node = self._find_node(CONTINUE_MARKERS, min_y=250, max_y=620)
        if node is None:
            raise LoginFlowError("continue", "没有找到“继续”按钮。")
        self._tap_node(node)

    def _has_account_error(self, texts: list[str]) -> bool:
        return contains_any(texts, ACCOUNT_ERROR_MARKERS)

    def _has_account_missing(self, texts: list[str]) -> bool:
        return contains_any(texts, ACCOUNT_MISSING_MARKERS)

    def _raise_account_missing_if_present(self, texts: list[str]) -> None:
        if not self._has_account_missing(texts):
            return
        raise LoginFlowError(
            "account_missing",
            f"{self.app_name} 明确提示该账号不存在，正在清理旧登录记录。",
        )

    def _has_rate_limit(self, texts: list[str]) -> bool:
        return contains_any(texts, RATE_LIMIT_MARKERS)

    def _raise_rate_limit_if_present(self, texts: list[str]) -> None:
        if not self._has_rate_limit(texts):
            return
        raise LoginFlowError(
            "rate_limit",
            "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
        )

    @staticmethod
    def _is_verification_step(texts: list[str]) -> bool:
        return contains_any(texts, VERIFICATION_MARKERS + SECURITY_CHOICE_MARKERS)

    def _is_studio_logged_in(self, texts: list[str]) -> bool:
        if contains_any(
            texts,
            STUDIO_LOGIN_TITLE_MARKERS
            + LOGIN_ENTRY_MARKERS
            + EMAIL_FIELD_MARKERS
            + EMAIL_TAB_MARKERS
            + VERIFICATION_MARKERS
            + SECURITY_CHOICE_MARKERS,
        ):
            return False
        return contains_any(texts, STUDIO_LOGGED_IN_MARKERS)

    def _is_home(self, texts: list[str]) -> bool:
        if self.is_studio:
            return self._is_studio_logged_in(texts)
        if not contains_any(texts, HOME_MARKERS):
            return False
        if contains_any(
            texts,
            EMAIL_FIELD_MARKERS
            + EMAIL_TAB_MARKERS
            + LOGIN_ENTRY_MARKERS
            + CONSENT_PROMPT_MARKERS
            + CONSENT_ACCEPT_MARKERS
            + VERIFICATION_MARKERS
            + SECURITY_CHOICE_MARKERS
            + ("保存登录信息", "新建账号", "登录"),
        ):
            return False
        return True

    def _submit_account(self) -> None:
        emit_progress("account", "正在填写账号")
        self._input_with_retry(
            self.account.account,
            field_name="账号",
            markers=EMAIL_FIELD_MARKERS,
            secure=False,
            expected=self.account.account,
            min_y=105,
            max_y=250,
        )
        self._tap_continue()
        texts = self._wait_for(
            lambda current: self._has_account_error(current)
            or self._has_rate_limit(current)
            or contains_any(current, PASSWORD_MARKERS)
            or self._is_verification_step(current)
            or self._is_home(current),
            timeout=22.0,
            stage="account",
            timeout_detail="提交账号后页面没有进入密码或验证步骤。",
        )
        if self._has_rate_limit(texts):
            raise LoginFlowError(
                "rate_limit",
                "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
            )
        self._raise_account_missing_if_present(texts)
        if self._has_account_error(texts):
            raise LoginFlowError("account", "TikTok 未识别这个账号，请检查 Word 里的账号是否正确。")
        if self._is_home(texts):
            return
        if contains_any(texts, PASSWORD_MARKERS):
            emit_progress("password", "账号已识别，正在填写密码")
            self._input_with_retry(
                self.account.password,
                field_name="密码",
                markers=PASSWORD_MARKERS,
                secure=True,
                expected=None,
                min_y=105,
                max_y=380,
            )
            self._tap_continue()
            return
        emit_progress("verification", "TikTok 要求先完成验证码验证")

    def _submit_password_or_verification(self) -> None:
        texts = self._wait_for(
            lambda current: self._has_account_error(current)
            or self._has_rate_limit(current)
            or self._is_home(current)
            or self._is_verification_step(current),
            timeout=28.0,
            stage="password",
            timeout_detail="提交密码后没有进入 TikTok 首页或验证页面。",
        )
        if self._has_rate_limit(texts):
            raise LoginFlowError(
                "rate_limit",
                "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
            )
        self._raise_account_missing_if_present(texts)
        if self._has_account_error(texts):
            raise LoginFlowError("password", "TikTok 提示账号或密码不正确，请检查 Word 内容。")
        if self._is_home(texts):
            return
        if self._is_verification_step(texts):
            self._complete_verification()

    @staticmethod
    def _normalize_code_candidate(value: Any) -> str:
        compact = re.sub(r"[\s-]+", "", str(value or "")).upper()
        if (
            re.fullmatch(r"[A-Z0-9]{4,8}", compact)
            and re.search(r"\d", compact)
        ):
            return compact
        return ""

    @classmethod
    def _extract_code(cls, values: list[str]) -> str:
        joined = "\n".join(values)
        compact = re.sub(r"\s+", "", joined)
        structured_patterns = (
            r'(?i)["\']?(?:data|code|otp|verification_code|security_code|auth_code)'
            r'["\']?\s*:\s*["\']?([A-Z0-9]{4,8})',
        )
        for pattern in structured_patterns:
            for candidate in re.findall(pattern, joined) + re.findall(pattern, compact):
                code = cls._normalize_code_candidate(candidate)
                if code:
                    return code
        natural_patterns = (
            r"(?i)\b(?:tiktok\s*)?([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})"
            r"\s+is\s+your\s+"
            r"(?:verification|security|confirmation|authentication|sign[\s-]?in|"
            r"login|one[\s-]?time|2fa|two[\s-]?factor)\s+code\b",
            r"(?i)\b(?:verification|security|confirmation|authentication|sign[\s-]?in|"
            r"login|one[\s-]?time)\s+code(?:\s+(?:is|was))?\s*[:=,-]?\s*"
            r"([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})\b",
            r"(?i)\b(?:otp|totp|2fa|two[\s-]?factor|authenticator)"
            r"(?:\s+(?:code|token|passcode))?(?:\s+(?:is|was))?\s*[:=,-]?\s*"
            r"([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})\b",
        )
        for pattern in natural_patterns:
            for candidate in re.findall(pattern, joined):
                code = cls._normalize_code_candidate(candidate)
                if code:
                    return code
        labelled = re.findall(
            r"(?i)(?:验证码|确认码|安全代码|verification\s*code|security\s*code|otp)"
            r"[^A-Z0-9]{0,24}([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})",
            joined,
        )
        candidates = labelled or re.findall(r"(?<!\d)(\d{4,8})(?!\d)", compact)
        for candidate in candidates:
            code = cls._normalize_code_candidate(candidate)
            if code:
                return code
        return ""

    def _clipboard_code(self) -> str:
        try:
            value = self._tool("get_clipboard", {})
        except Exception:
            return ""
        text = ""
        if isinstance(value, dict):
            text = str(value.get("text") or "")
        elif value is not None:
            text = str(value)
        return self._extract_code([text])

    def _close_safari(self) -> None:
        try:
            self._tool("kill_app", {"bundle_id": SAFARI_BUNDLE_ID})
        except Exception:
            pass
        time.sleep(0.9)

    def _reset_verification_link_page(self) -> None:
        """Remove the stale link page and wait before requesting a fresh code."""
        emit_progress(
            "verification",
            "验证码错误，正在清除浏览器旧链接并等待 6 秒后重新读取",
        )
        self._close_safari()
        self._clear_clipboard()
        try:
            self._tool("open_url", {"url": "about:blank"})
        except Exception:
            pass
        time.sleep(WRONG_CODE_LINK_REFRESH_DELAY_SECONDS)
        emit_progress("verification", "旧链接已清除，正在重新打开验证链接")

    @classmethod
    def _verification_code_from_json(cls, value: Any, *, depth: int = 0) -> str:
        if depth > 8:
            return ""
        if isinstance(value, dict):
            for key in (
                "data",
                "code",
                "otp",
                "verification_code",
                "verificationCode",
                "security_code",
                "securityCode",
                "auth_code",
                "authCode",
                "pin",
            ):
                candidate = value.get(key)
                if isinstance(candidate, (str, int)):
                    code = cls._normalize_code_candidate(candidate)
                    if code:
                        return code
            for nested in value.values():
                code = cls._verification_code_from_json(nested, depth=depth + 1)
                if code:
                    return code
        elif isinstance(value, list):
            for nested in value:
                code = cls._verification_code_from_json(nested, depth=depth + 1)
                if code:
                    return code
        return ""

    def _extract_code_from_http_text(self, text: str) -> str:
        cleaned = text.strip()
        if not cleaned:
            return ""
        json_text = cleaned
        if not json_text.startswith(("{", "[")):
            start = cleaned.find("{")
            end = cleaned.rfind("}")
            if start >= 0 and end > start:
                json_text = cleaned[start : end + 1]
        try:
            payload = json.loads(json_text)
        except (TypeError, ValueError, json.JSONDecodeError):
            payload = None
        if payload is not None:
            code = self._verification_code_from_json(payload)
            if code:
                return code
        if any(
            marker in cleaned.casefold()
            for marker in (
                "验证码",
                "确认码",
                "安全代码",
                "verification code",
                "security code",
                "otp",
                "2fa",
            )
        ):
            code = self._extract_code([cleaned])
            if code:
                return code
        code = self._normalize_code_candidate(cleaned)
        if code:
            return code
        return ""

    def _code_from_verification_url_http(self) -> str:
        """Read the code without depending on Safari OCR or screen text."""
        url = self.account.verification_url.strip()
        if not url:
            return ""
        try:
            parsed_url = urlsplit(url)
        except ValueError:
            return ""
        if parsed_url.scheme.casefold() not in {"http", "https"} or not parsed_url.netloc:
            return ""
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json,text/plain,text/html;q=0.9,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "User-Agent": VERIFICATION_HTTP_USER_AGENT,
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request,
                timeout=VERIFICATION_HTTP_TIMEOUT,
            ) as response:
                body = response.read(VERIFICATION_HTTP_MAX_BYTES + 1)
                charset = response.headers.get_content_charset() or "utf-8"
        except (
            urllib.error.HTTPError,
            urllib.error.URLError,
            TimeoutError,
            OSError,
            ValueError,
        ):
            return ""
        if not body or len(body) > VERIFICATION_HTTP_MAX_BYTES:
            return ""
        try:
            text = body.decode(charset, "replace")
        except LookupError:
            text = body.decode("utf-8", "replace")
        return self._extract_code_from_http_text(text)

    def _code_from_verification_link(self, *, force_fresh: bool = False) -> str:
        if not self.account.verification_url:
            return ""
        http_attempts = 18 if force_fresh else 8
        for http_attempt in range(http_attempts):
            code = self._code_from_verification_url_http()
            if code and not (
                force_fresh and code == self._last_verification_code
            ):
                self._last_verification_code = code
                emit_progress(
                    "verification_link",
                    "已直接从邮箱验证链接取得验证码",
                )
                return code
            if http_attempt == 2:
                emit_progress(
                    "verification_link",
                    "邮箱链接暂未返回新验证码，正在继续等待",
                )
            if http_attempt + 1 < http_attempts:
                time.sleep(1.8)

        copy_markers = (
            "查看验证码",
            "显示验证码",
            "复制验证码",
            "获取验证码",
            "查看",
            "复制",
            "Show code",
            "Copy code",
        )
        for fetch_attempt in range(3):
            if force_fresh or fetch_attempt > 0:
                emit_progress(
                    "verification_link",
                    "验证码页面可能是旧内容，正在关闭 Safari 并重新打开",
                )
                self._close_safari()
            emit_progress("verification_link", "正在打开验证链接")
            self._tool("open_url", {"url": self.account.verification_url})
            time.sleep(2.2)
            nodes = self._ocr_nodes()
            texts = [self._node_text(node) for node in nodes]
            self._assert_no_captcha(texts)
            if self._tap_markers(("复制验证码", "复制", "Copy code", "Copy")):
                time.sleep(0.7)
                code = self._clipboard_code()
                if code:
                    self._close_safari()
                    self._return_to_tiktok()
                    return code
            elif self._tap_markers(copy_markers):
                time.sleep(0.7)
            code = self._extract_code([self._node_text(node) for node in nodes])
            if not code:
                code = self._extract_code(self._texts())
            if code:
                if force_fresh and code == self._last_verification_code:
                    continue
                self._last_verification_code = code
                self._close_safari()
                self._return_to_tiktok()
                return code
            if fetch_attempt + 1 < 3:
                continue
        raise LoginFlowError(
            "verification_link",
            "电脑直接读取和 Safari 备用读取都没有拿到新验证码；"
            "请确认验证链接有效，稍后重试。",
        )

    def _return_to_tiktok(self) -> None:
        self._tool("launch_app", {"bundle_id": self.bundle_id})
        self._wait_tiktok_foreground()
        time.sleep(0.7)

    def _verification_code(
        self, page_texts: list[str], *, force_fresh_link: bool = False
    ) -> str:
        if self.account.has_2fa:
            lowered = " ".join(page_texts).casefold()
            authenticator = any(
                marker in lowered
                for marker in ("authenticator", "身份验证器", "动态密码", "动态码")
            )
            if authenticator or not self.account.has_verification_link:
                return self.account.current_two_factor_code()
        if self.account.has_verification_link:
            return self._code_from_verification_link(force_fresh=force_fresh_link)
        if self.account.has_2fa:
            return self.account.current_two_factor_code()
        return ""

    def _focus_verification_field(self) -> None:
        markers = (
            "输入验证码",
            "输入 6 位代码",
            "6 位代码",
            "验证码",
            "Enter code",
            "Code",
        )
        try:
            self._focus_field(markers, min_y=90, max_y=430)
            return
        except LoginFlowError:
            width, height = self._screen_size()
            self._tap_xy(width * 0.5, height * 0.24)

    def _input_verification_code(self, code: str) -> None:
        self._focus_verification_field()
        self._input_with_retry(
            code,
            field_name="验证码",
            markers=VERIFICATION_MARKERS,
            secure=True,
            expected=code,
            min_y=90,
            max_y=430,
        )

    def _resend_verification_code(self) -> None:
        emit_progress("verification", "验证码已过期或无效，正在重新发送验证码")
        deadline = time.monotonic() + 32.0
        while time.monotonic() < deadline:
            texts = self._texts()
            if contains_any(texts, RESEND_CODE_MARKERS) and self._tap_markers(
                RESEND_CODE_MARKERS
            ):
                time.sleep(1.2)
                emit_progress("verification", "已重新发送验证码，正在重新读取")
                return
            time.sleep(0.8)
        raise LoginFlowError(
            "verification",
            "没有找到可用的“重新发送验证码”按钮，请在手机上手动重发。",
        )

    def _has_code_error(self, texts: list[str]) -> bool:
        return contains_any(texts, CODE_ERROR_MARKERS)

    def _wait_for_code_result(self, *, timeout: float = 22.0) -> bool | None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            texts = self._texts()
            self._assert_no_captcha(texts)
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError("login", "TikTok 提示账号、密码或验证信息不正确。")
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._is_home(texts):
                emit_progress("success", "已进入 TikTok 首页")
                return True
            if self._has_code_error(texts):
                return False
            time.sleep(0.5)
        return None

    def _tap_verify_action(self) -> None:
        markers = (
            "继续",
            "验证",
            "确认",
            "登录",
            "Verify",
            "Continue",
            "Next",
            "Submit",
            "Confirm",
            "Log in",
            "Done",
        )
        if self._tap_markers(markers):
            return
        node = self._find_node(markers, min_y=240, max_y=640)
        if node is not None:
            self._tap_node(node)

    def _choose_verification_method(self, texts: list[str]) -> list[str]:
        if not contains_any(texts, SECURITY_CHOICE_MARKERS):
            return texts
        tapped = False
        if self.account.has_2fa:
            emit_progress("verification_method", "正在按 Word 内容选择身份验证器")
            tapped = self._tap_markers(AUTHENTICATOR_OPTION_MARKERS)
        if not tapped and self.account.has_verification_link:
            emit_progress("verification_method", "正在按 Word 内容选择电子邮件验证")
            tapped = self._tap_markers(EMAIL_OPTION_MARKERS)
        if not tapped and self.account.has_2fa:
            tapped = self._tap_markers(AUTHENTICATOR_OPTION_MARKERS)
        if not tapped:
            raise LoginFlowError(
                "verification_method",
                "TikTok 要求身份验证，但没有找到与 Word 匹配的验证方式。",
            )
        return self._wait_for(
            lambda current: contains_any(current, VERIFICATION_MARKERS)
            or self._is_home(current),
            timeout=14.0,
            stage="verification_method",
            timeout_detail="选择身份验证方式后，没有出现验证码输入页面。",
        )

    def _complete_verification(self) -> None:
        self._verification_attempts += 1
        page_texts = self._texts(include_ocr=True)
        page_texts = self._choose_verification_method(page_texts)
        if self._is_home(page_texts):
            return
        reset_link_before_refresh = False
        for attempt in range(1, 4):
            if attempt > 1:
                self._resend_verification_code()
                page_texts = self._wait_for(
                    lambda current: self._is_verification_step(current)
                    or self._is_home(current),
                    timeout=18.0,
                    stage="verification",
                    timeout_detail="重新发送验证码后，没有回到验证码页面。",
                )
                page_texts = self._choose_verification_method(page_texts)
                if self._is_home(page_texts):
                    return
                if reset_link_before_refresh:
                    self._reset_verification_link_page()
                    reset_link_before_refresh = False
            code = self._verification_code(
                page_texts,
                force_fresh_link=attempt > 1,
            )
            if not code:
                raise LoginFlowError(
                    "verification",
                    "TikTok 要求验证码，但 Word 里没有可用的 2FA 或验证链接。",
                )
            emit_progress(
                "verification",
                f"已取得验证码，正在返回 {self.app_name} 并填写（第 {attempt}/3 次）",
            )
            # Always return to the login app before typing. This also covers
            # the direct HTTP path, where Safari may never have been opened.
            self._return_to_tiktok()
            self._input_verification_code(code)
            self._tap_verify_action()
            result = self._wait_for_code_result()
            if result is True:
                return
            if result is False:
                reset_link_before_refresh = True
            if attempt >= 3:
                break
            emit_progress(
                "verification",
                "本次验证码未通过，正在重新发送并重试",
            )
            time.sleep(1.8)
        raise LoginFlowError(
            "verification",
            "验证码连续 3 次未通过，请检查验证链接或 2FA 内容后重试。",
        )

    def _wait_for_login_success(self) -> None:
        if self.is_studio:
            self._wait_for_studio_login_success()
            return
        deadline = time.monotonic() + 45.0
        while time.monotonic() < deadline:
            texts = self._texts()
            self._assert_no_captcha(texts)
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError("login", "TikTok 提示账号、密码或验证信息不正确。")
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._is_home(texts):
                emit_progress("success", "已进入 TikTok 首页")
                return
            if self._is_verification_step(texts) and self._verification_attempts == 0:
                self._complete_verification()
                continue
            time.sleep(0.45)
        raise LoginFlowError(
            "login",
            "等待 TikTok 登录成功超时，请查看手机当前页面。",
        )

    def _wait_for_studio_login_success(self) -> None:
        deadline = time.monotonic() + 55.0
        last_manage_tap = 0.0
        while time.monotonic() < deadline:
            texts = self._texts(include_ocr=True)
            self._assert_no_captcha(texts)
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError(
                    "login",
                    "TikTok Studio 提示账号、密码或验证信息不正确。",
                )
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok Studio 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._is_verification_step(texts) and self._verification_attempts == 0:
                self._complete_verification()
                continue
            if self._is_studio_logged_in(texts):
                emit_progress("success", "已登录 TikTok Studio")
                return

            now = time.monotonic()
            if now - last_manage_tap > 4.0:
                if not self._tap_markers(STUDIO_MANAGE_TAB_MARKERS):
                    width, height = self._screen_size()
                    self._tap_xy(width * 0.9, height * 0.96)
                last_manage_tap = now
            time.sleep(0.45)
        raise LoginFlowError(
            "login",
            "等待 TikTok Studio 登录成功超时，请查看手机当前页面。",
        )


def read_private_task() -> TikTokLoginAccount:
    if sys.stdin is None:
        raise TikTokTemplateError("无法读取内存中的登录账号。")
    raw = sys.stdin.buffer.read()
    if not raw:
        raise TikTokTemplateError("登录任务没有收到账号数据。")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise TikTokTemplateError("登录任务数据格式不正确。") from error
    if not isinstance(payload, dict) or not isinstance(payload.get("account"), dict):
        raise TikTokTemplateError("登录任务缺少账号数据。")
    return TikTokLoginAccount.from_private_payload(payload["account"])


def safe_error_detail(
    error: BaseException,
    app_name: str = "TikTok",
) -> tuple[str, str]:
    if isinstance(error, LoginFlowError):
        return error.stage, error.detail
    if isinstance(error, TikTokTemplateError):
        return "task", str(error)
    detail = " ".join(str(error or error.__class__.__name__).split())
    return "login", detail[:500] or f"{app_name} 登录失败"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="使用内存账号任务登录 TikTok 或 TikTok Studio 邮箱/用户名页"
    )
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument(
        "--bundle-id",
        choices=(TIKTOK_STUDIO_BUNDLE_ID, TIKTOK_BUNDLE_ID),
        default=DEFAULT_BUNDLE_ID,
    )
    args = parser.parse_args()
    account: TikTokLoginAccount | None = None
    flow: TikTokEmailLoginFlow | None = None
    try:
        account = read_private_task()
        flow = TikTokEmailLoginFlow(
            args.port,
            account,
            bundle_id=args.bundle_id,
        )
        flow.run()
        emit_progress("success", f"{flow.app_name} 登录成功")
        emit_result(True, "success", f"已登录 {flow.app_name}。", account)
        return 0
    except BaseException as error:
        app_name = "TikTok Studio" if args.bundle_id == TIKTOK_STUDIO_BUNDLE_ID else "TikTok"
        stage, detail = safe_error_detail(error, app_name)
        emit_result(False, stage, detail, account)
        return 1
    finally:
        if flow is not None:
            flow.close()


if __name__ == "__main__":
    raise SystemExit(main())
