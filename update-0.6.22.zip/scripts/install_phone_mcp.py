from __future__ import annotations

import argparse
import asyncio
import getpass
import hashlib
import json
import os
import re
import shlex
import sys
import time
import urllib.error
import urllib.request
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.services.device_support import (  # noqa: E402
    IOSInstallPlan,
    select_ios_install_plan,
)
from iphone_control_center.services.usb_discovery import PymobiledeviceUSBProbe  # noqa: E402


SSH_REMOTE_PORT = 22
MCP_REMOTE_PORT = 8090
FORWARD_READY_TIMEOUT_SECONDS = 12.0
HEALTH_READY_TIMEOUT_SECONDS = 35.0
PROBE_READY_TIMEOUT_SECONDS = 14.0
DEVICE_DISCOVERY_ATTEMPTS = 6
DEVICE_DISCOVERY_RETRY_SECONDS = 1.0
MCP_LOCAL_PACKAGE_PATH = (
    PROJECT_ROOT
    / "resources"
    / "phone_packages"
    / "com.witchan.ios-mcp_1.2.7_iphoneos-arm64.deb"
)
MCP_LOCAL_PACKAGE_SHA256 = (
    "08A50AC1340B6FC05612140D94CD9A477CDBD5C54DC23BEEB5A2A8930639B51B"
)
MCP_LOCAL_PACKAGE_VERSION = "1.2.7"
MCP_BASE_DEPENDENCIES = (
    ("ellekit", "ElleKit"),
    ("preferenceloader", "PreferenceLoader"),
)
_SHA256_PATTERN = re.compile(r"\b[0-9a-fA-F]{64}\b")


class PhoneInstallError(RuntimeError):
    pass


class UnsupportedPhoneError(PhoneInstallError):
    pass


@dataclass(frozen=True, slots=True)
class PhoneTarget:
    udid: str
    label: str
    ios_version: str
    build_version: str
    install_plan: IOSInstallPlan


@dataclass(frozen=True, slots=True)
class CommandResult:
    exit_code: int
    output: str
    error: str

    @property
    def combined(self) -> str:
        return "\n".join(part for part in (self.output.strip(), self.error.strip()) if part)


@dataclass(slots=True)
class PortForward:
    forwarder: Any
    task: asyncio.Task[Any]
    local_port: int

    async def close(self) -> None:
        self.forwarder.stop()
        with suppress(Exception):
            await asyncio.wait_for(self.task, timeout=5.0)


class SshSession:
    """Paramiko session whose password stays in memory and is never logged."""

    def __init__(self, local_port: int, username: str, password: str) -> None:
        self.local_port = local_port
        self.username = username
        self._password = password
        self._client: Any = None
        self.shell_path = "/var/jb/usr/bin/sh"

    def connect(self) -> None:
        import paramiko

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(
                hostname="127.0.0.1",
                port=self.local_port,
                username=self.username,
                password=self._password,
                timeout=12.0,
                banner_timeout=12.0,
                auth_timeout=12.0,
                look_for_keys=False,
                allow_agent=False,
            )
        except paramiko.AuthenticationException as error:
            client.close()
            raise PhoneInstallError(
                "手机 SSH 账号或密码不正确。请先试账号 mobile，再试 root；"
                "账号不是登录密码，密码在下一个输入框填写。"
            ) from error
        except Exception as error:
            client.close()
            raise PhoneInstallError(f"无法连接手机 SSH：{_compact(error)}") from error
        self._client = client
        shell = self.run("test -x /var/jb/usr/bin/sh && echo /var/jb/usr/bin/sh || echo /bin/sh")
        shell_path = shell.output.strip().splitlines()[-1:] or ["/bin/sh"]
        if shell.exit_code == 0 and shell_path[0].startswith("/"):
            self.shell_path = shell_path[0]

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def run(
        self,
        command: str,
        *,
        timeout: float = 35.0,
        input_text: str | None = None,
    ) -> CommandResult:
        if self._client is None:
            raise PhoneInstallError("手机 SSH 会话尚未建立")
        stdin, stdout, stderr = self._client.exec_command(command, timeout=timeout)
        if input_text:
            stdin.write(input_text)
            stdin.flush()
        output = stdout.read().decode("utf-8", "replace")
        error = stderr.read().decode("utf-8", "replace")
        exit_code = int(stdout.channel.recv_exit_status())
        return CommandResult(exit_code=exit_code, output=output, error=error)

    def run_privileged(self, command: str, *, timeout: float = 120.0) -> CommandResult:
        probe = self.run("id -u")
        if probe.exit_code == 0 and probe.output.strip() == "0":
            return self.run(command, timeout=timeout)
        sudo_command = (
            "sudo -S -p '' "
            + shlex.quote(self.shell_path)
            + " -c "
            + shlex.quote(command)
        )
        result = self.run(
            sudo_command,
            timeout=timeout,
            input_text=f"{self._password}\n",
        )
        if result.exit_code != 0 and "password is required" in result.error.lower():
            raise PhoneInstallError(
                "手机账号没有可用的 sudo 权限。请使用越狱环境的管理员账号。"
            )
        return result

    def resolve_binary(self, name: str, fallback: str) -> str:
        result = self.run(f"command -v {shlex.quote(name)} 2>/dev/null || true")
        candidate = result.output.strip().splitlines()[-1:] or [fallback]
        return candidate[0] if candidate[0].startswith("/") else fallback

    def upload(self, source: Path, remote_path: str) -> None:
        if self._client is None:
            raise PhoneInstallError("手机 SSH 会话尚未建立")
        sftp = self._client.open_sftp()
        try:
            sftp.put(str(source), remote_path)
        except Exception as error:
            raise PhoneInstallError(
                "无法把手机控制组件上传到手机：" + _compact(error)
            ) from error
        finally:
            sftp.close()


def _compact(error: BaseException | str, limit: int = 500) -> str:
    text = " ".join(str(error).split())
    return text[:limit]


def _stage(message: str) -> None:
    print(f"==> {message}", flush=True)


def _device_match_line(target: PhoneTarget) -> str:
    payload = target.install_plan.machine_payload()
    payload["udidSuffix"] = target.udid[-8:]
    marker = "IC20_DEVICE_MATCH" if target.install_plan.matched else "IC20_DEVICE_UNSUPPORTED"
    return marker + " " + json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _print_device_match(target: PhoneTarget) -> None:
    print(_device_match_line(target), flush=True)
    print(f"自动匹配：{target.install_plan.message}", flush=True)


def _require_supported_install_plan(target: PhoneTarget) -> None:
    if not target.install_plan.matched:
        raise UnsupportedPhoneError(target.install_plan.message)


def _discover_target(udid: str | None) -> PhoneTarget:
    devices: list[Any] = []
    last_error = ""
    for attempt in range(DEVICE_DISCOVERY_ATTEMPTS):
        try:
            snapshot = PymobiledeviceUSBProbe().scan()
        except Exception as error:
            last_error = _compact(error)
            snapshot = None
        if snapshot is not None:
            candidates = list(snapshot.devices)
            if udid:
                wanted = udid.strip().lower()
                candidates = [
                    device for device in candidates if device.udid.lower() == wanted
                ]
            if candidates:
                devices = candidates
                complete = [
                    device
                    for device in candidates
                    if str(device.ios_version or "").strip()
                    and str(device.build_version or "").strip()
                ]
                if complete:
                    devices = complete
                    break
        if attempt + 1 < DEVICE_DISCOVERY_ATTEMPTS:
            time.sleep(DEVICE_DISCOVERY_RETRY_SECONDS)
    if not devices:
        detail = f" USB 读取详情：{last_error}" if last_error else ""
        raise PhoneInstallError(
            "没有识别到 USB 连接的越狱 iPhone。请保持解锁，点“信任此电脑”，"
            f"重新插拔数据线后再试。{detail}"
        )
    device = next(
        (candidate for candidate in devices if candidate.is_paired is True),
        devices[0],
    )
    ios_version = str(device.ios_version or "").strip()
    build_version = str(device.build_version or "").strip()
    if not ios_version or not build_version:
        raise PhoneInstallError(
            "已经检测到 USB 手机，但系统版本和 Build 暂时没有读全。"
            "请保持手机解锁并点“信任此电脑”，稍后重新点击第 2 步；"
            "本次没有判定为系统版本未配置。"
        )
    install_plan = select_ios_install_plan(ios_version, build_version)
    label = " · ".join(
        part
        for part in (
            device.product_type or device.device_name or "iPhone",
            f"iOS {ios_version}" if ios_version else "",
            f"Build {build_version}" if build_version else "",
            device.udid[-8:],
        )
        if part
    )
    return PhoneTarget(
        udid=device.udid,
        label=label,
        ios_version=ios_version,
        build_version=build_version,
        install_plan=install_plan,
    )


async def _start_forward(udid: str, remote_port: int) -> PortForward:
    from pymobiledevice3.tcp_forwarder import UsbmuxTcpForwarder

    listening = asyncio.Event()
    forwarder = UsbmuxTcpForwarder(
        udid,
        remote_port,
        src_port=0,
        listening_event=listening,
        usbmux_connection_type="USB",
    )
    task = asyncio.create_task(
        forwarder.start(address="127.0.0.1"),
        name=f"ic20-phone-install-forward-{remote_port}",
    )
    try:
        await asyncio.wait_for(listening.wait(), timeout=FORWARD_READY_TIMEOUT_SECONDS)
    except Exception:
        forwarder.stop()
        with suppress(Exception):
            await asyncio.wait_for(task, timeout=3.0)
        raise PhoneInstallError("无法建立手机 USB 转发端口")
    local_port = int(forwarder.listening_port or 0)
    if local_port <= 0:
        forwarder.stop()
        with suppress(Exception):
            await asyncio.wait_for(task, timeout=3.0)
        raise PhoneInstallError("Windows 没有分配到可用的手机转发端口")
    return PortForward(forwarder=forwarder, task=task, local_port=local_port)


def _package_status(session: SshSession, dpkg: str, package_id: str) -> tuple[bool, str]:
    result = session.run_privileged(
        f"{shlex.quote(dpkg)} -s {shlex.quote(package_id)}"
    )
    text = result.combined
    installed = result.exit_code == 0 and "Status: install ok installed" in text
    version = ""
    for line in text.splitlines():
        if line.lower().startswith("version:"):
            version = line.split(":", 1)[1].strip()
            break
    return installed, version


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as package_file:
        for chunk in iter(lambda: package_file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _validate_local_phone_package(
    path: Path | None = None,
    expected_sha256: str | None = None,
) -> str:
    package_path = Path(path) if path is not None else MCP_LOCAL_PACKAGE_PATH
    expected = (
        expected_sha256
        if expected_sha256 is not None
        else MCP_LOCAL_PACKAGE_SHA256
    ).strip().upper()
    if not package_path.is_file():
        raise PhoneInstallError(
            "安装包内缺少手机控制组件："
            f"{package_path.name}。请重新解压完整安装包后再试。"
        )
    actual = _sha256_file(package_path)
    if actual != expected:
        raise PhoneInstallError(
            "手机控制组件校验失败，安装包可能不完整。"
            f"应为 {expected}，实际为 {actual}。请重新解压完整安装包。"
        )
    return actual


def _package_version_matches(version: str, expected: str) -> bool:
    return version.strip() == expected.strip()


def _missing_phone_dependencies(
    session: SshSession,
    dpkg: str,
) -> list[tuple[str, str]]:
    missing: list[tuple[str, str]] = []
    for package_id, label in MCP_BASE_DEPENDENCIES:
        installed, _version = _package_status(session, dpkg, package_id)
        if not installed:
            missing.append((package_id, label))
    return missing


def _remote_file_sha256(session: SshSession, remote_path: str) -> str:
    details: list[str] = []
    candidates = (
        ("sha256sum", "/var/jb/usr/bin/sha256sum", ""),
        ("shasum", "/var/jb/usr/bin/shasum", "-a 256"),
    )
    for name, fallback, arguments in candidates:
        binary = session.resolve_binary(name, fallback)
        command = f"{shlex.quote(binary)}"
        if arguments:
            command += f" {arguments}"
        command += f" {shlex.quote(remote_path)}"
        result = session.run(command)
        match = _SHA256_PATTERN.search(result.output)
        if result.exit_code == 0 and match is not None:
            return match.group(0).upper()
        details.append(_compact(result.combined or f"{name} 不可用"))
    raise PhoneInstallError(
        "手机没有可用的 SHA256 校验工具，无法安全校验安装包。"
        "请先在手机上安装 coreutils 后重试。详情：" + "；".join(details)
    )


async def _install_apt_packages(
    session: SshSession,
    apt_get: str,
    packages: list[tuple[str, str]],
) -> None:
    package_ids = [package_id for package_id, _label in packages]
    quoted_packages = " ".join(shlex.quote(package_id) for package_id in package_ids)
    install_command = (
        "export DEBIAN_FRONTEND=noninteractive; "
        f"{shlex.quote(apt_get)} -y --allow-unauthenticated install "
        f"{quoted_packages}"
    )
    first = await asyncio.to_thread(
        session.run_privileged,
        install_command,
        timeout=300.0,
    )
    if first.exit_code == 0:
        return

    _stage("正在更新手机软件源")
    update = await asyncio.to_thread(
        session.run_privileged,
        "export DEBIAN_FRONTEND=noninteractive; "
        f"{shlex.quote(apt_get)} -y --allow-unauthenticated update",
        timeout=180.0,
    )
    if update.exit_code != 0:
        print(
            "手机软件源更新没有完全成功，可能有单个旧源失效；"
            "继续使用现有安全索引重试基础依赖。",
            flush=True,
        )

    retry = await asyncio.to_thread(
        session.run_privileged,
        install_command,
        timeout=300.0,
    )
    if retry.exit_code != 0:
        detail = retry.combined or update.combined or first.combined
        raise PhoneInstallError(
            f"手机基础依赖安装失败（{'、'.join(label for _, label in packages)}）："
            f"{_compact(detail)}"
        )


async def _ensure_phone_dependencies(
    session: SshSession,
    dpkg: str,
    apt_get: str,
) -> None:
    missing = await asyncio.to_thread(_missing_phone_dependencies, session, dpkg)
    if not missing:
        return
    labels = "、".join(label for _package_id, label in missing)
    _stage(f"正在安装手机基础依赖：{labels}")
    await _install_apt_packages(session, apt_get, missing)
    still_missing = await asyncio.to_thread(
        _missing_phone_dependencies,
        session,
        dpkg,
    )
    if still_missing:
        raise PhoneInstallError(
            "手机基础依赖安装命令结束，但仍缺少："
            + "、".join(label for _package_id, label in still_missing)
        )
    print(f"手机基础依赖已就绪：{labels}", flush=True)


def _health_once(local_port: int) -> dict[str, Any] | None:
    request = urllib.request.Request(
        f"http://127.0.0.1:{local_port}/health",
        headers={"Accept": "application/json"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=3.0) as response:
            payload = json.loads(response.read().decode("utf-8", "replace"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    if str(payload.get("status") or "").lower() != "ok":
        return None
    if str(payload.get("server") or "") != "ios-mcp":
        return None
    return payload


async def _wait_for_health(udid: str, timeout: float = HEALTH_READY_TIMEOUT_SECONDS) -> dict[str, Any] | None:
    forward = await _start_forward(udid, MCP_REMOTE_PORT)
    try:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            payload = await asyncio.to_thread(_health_once, forward.local_port)
            if payload is not None:
                return payload
            await asyncio.sleep(0.75)
        return None
    finally:
        await forward.close()


async def _install_with_ssh(
    *,
    target: PhoneTarget,
    username: str,
    password: str,
    check_only: bool,
) -> tuple[bool, dict[str, Any] | None]:
    package = target.install_plan.install_package
    if package is None or package.install_method not in {
        "jailbreak_deb",
        "jailbreak_apt",
    }:
        raise UnsupportedPhoneError(
            "当前系统没有配置可执行的越狱组件安装包，已停止安装。"
        )
    _stage("正在建立手机 USB 调试连接")
    ssh_forward = await _start_forward(target.udid, SSH_REMOTE_PORT)
    session = SshSession(ssh_forward.local_port, username, password)
    newly_installed = False
    try:
        _stage("正在登录手机")
        await asyncio.to_thread(session.connect)
        dpkg = await asyncio.to_thread(session.resolve_binary, "dpkg", "/var/jb/usr/bin/dpkg")
        apt_get = await asyncio.to_thread(
            session.resolve_binary,
            "apt-get",
            "/var/jb/usr/bin/apt-get",
        )

        _stage("正在检查手机控制组件")
        installed, version = await asyncio.to_thread(
            _package_status,
            session,
            dpkg,
            package.package_id,
        )
        version_matches = installed and _package_version_matches(
            version,
            MCP_LOCAL_PACKAGE_VERSION,
        )
        if version_matches:
            print(
                f"手机端 {package.package_id} 已安装"
                + (f"（版本 {version}）" if version else ""),
                flush=True,
            )
        elif check_only:
            if installed:
                raise PhoneInstallError(
                    f"手机组件版本是 {version or '未知'}，需要 {MCP_LOCAL_PACKAGE_VERSION}。"
                    "请点击第 2 步的一键安装完成更新。"
                )
            raise PhoneInstallError("手机还没有安装 iOS MCP，请点击第 2 步的一键安装。")

        if not version_matches:
            local_package_sha256 = await asyncio.to_thread(
                _validate_local_phone_package,
            )
            await _ensure_phone_dependencies(session, dpkg, apt_get)
            _stage(f"正在安装{package.label}")
            remote_package_path = (
                f"/tmp/ic20-{package.package_id.replace('.', '-')}-"
                f"{target.udid[-8:]}-{int(time.time())}.deb"
            )
            try:
                await asyncio.to_thread(
                    session.upload,
                    MCP_LOCAL_PACKAGE_PATH,
                    remote_package_path,
                )
                remote_package_sha256 = await asyncio.to_thread(
                    _remote_file_sha256,
                    session,
                    remote_package_path,
                )
                if remote_package_sha256 != local_package_sha256:
                    raise PhoneInstallError(
                        "手机控制组件上传后校验不一致，已停止安装。"
                        f"电脑端 {local_package_sha256}，手机端 {remote_package_sha256}。"
                    )
                install = await asyncio.to_thread(
                    session.run_privileged,
                    f"{shlex.quote(dpkg)} -i {shlex.quote(remote_package_path)}",
                    timeout=300.0,
                )
                if install.exit_code != 0:
                    raise PhoneInstallError(
                        "手机组件本地安装失败：" + _compact(install.combined)
                    )
            finally:
                with suppress(Exception):
                    await asyncio.to_thread(
                        session.run,
                        f"rm -f {shlex.quote(remote_package_path)}",
                        timeout=20.0,
                    )
            newly_installed = True
            installed, version = await asyncio.to_thread(
                _package_status,
                session,
                dpkg,
                package.package_id,
            )
            if not installed:
                raise PhoneInstallError("安装命令结束，但手机仍报告组件未安装。")
            if not _package_version_matches(version, MCP_LOCAL_PACKAGE_VERSION):
                raise PhoneInstallError(
                    f"手机报告组件版本为 {version or '未知'}，"
                    f"没有达到要求的 {MCP_LOCAL_PACKAGE_VERSION}。"
                )
            print(
                f"手机端 {package.package_id} 安装完成"
                + (f"（版本 {version}）" if version else ""),
                flush=True,
            )

        if newly_installed:
            _stage("正在重启手机桌面服务")
            sbreload = await asyncio.to_thread(
                session.resolve_binary,
                "sbreload",
                "/var/jb/usr/bin/sbreload",
            )
            restart = await asyncio.to_thread(
                session.run_privileged,
                f"{shlex.quote(sbreload)} >/dev/null 2>&1 || true",
                timeout=45.0,
            )
            if restart.exit_code != 0:
                print("桌面服务重启返回异常，将继续检查直连服务。", flush=True)
            await asyncio.sleep(4.0)

        _stage("正在验证手机控制服务")
        health = await _wait_for_health(target.udid)
        if health is None and not check_only:
            _stage("控制服务尚未响应，正在刷新手机用户空间服务")
            launchctl = await asyncio.to_thread(
                session.resolve_binary,
                "launchctl",
                "/var/jb/usr/bin/launchctl",
            )
            with suppress(Exception):
                await asyncio.to_thread(
                    session.run_privileged,
                    f"{shlex.quote(launchctl)} reboot userspace "
                    ">/dev/null 2>&1 || true",
                    timeout=20.0,
                )
            print("用户空间刷新会短暂断开手机连接，正在等待恢复。", flush=True)
            await asyncio.sleep(16.0)
            health = await _wait_for_health(target.udid, timeout=55.0)
        if health is None:
            raise PhoneInstallError(
                "手机端组件已安装，但 8090 控制服务没有响应。请重启手机后再次检查。"
            )
        return True, health
    finally:
        await asyncio.to_thread(session.close)
        await ssh_forward.close()


async def run(options: argparse.Namespace) -> int:
    if options.probe_only:
        target = await asyncio.to_thread(_discover_target, options.udid)
        print(f"目标手机：{target.label}", flush=True)
        _print_device_match(target)
        _require_supported_install_plan(target)
        _stage("正在检查手机控制服务")
        health = await _wait_for_health(
            target.udid,
            timeout=PROBE_READY_TIMEOUT_SECONDS,
        )
        if health is None:
            print("PHONE_MCP_NOT_READY", flush=True)
            print("手机控制组件尚未就绪，需要安装后再检查。", flush=True)
            return 2
        version = str(health.get("version") or "未知")
        print("手机越狱控制组件已就绪。", flush=True)
        print(f"iOS MCP 版本：{version}", flush=True)
        print("PHONE_MCP_READY", flush=True)
        return 0

    target = await asyncio.to_thread(_discover_target, options.udid)
    print(f"目标手机：{target.label}", flush=True)
    _print_device_match(target)
    _require_supported_install_plan(target)
    password = os.environ.get("IC20_SSH_PASSWORD")
    if password is None:
        if not sys.stdin.isatty():
            raise PhoneInstallError("没有收到手机 SSH 密码，请回到连接器重新点击第 2 步。")
        password = getpass.getpass("手机 SSH 密码（不会保存）：")
    if not password:
        raise PhoneInstallError("手机 SSH 密码不能为空。")

    success, health = await _install_with_ssh(
        target=target,
        username=options.username,
        password=password,
        check_only=bool(options.check_only),
    )
    if not success or health is None:
        return 1
    version = str(health.get("version") or "未知")
    print("", flush=True)
    print("手机越狱控制组件已就绪。", flush=True)
    print(f"iOS MCP 版本：{version}", flush=True)
    print("PHONE_MCP_READY", flush=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="安装并验证 iPhone 越狱 MCP 直连组件")
    parser.add_argument("--udid", default="", help="只处理指定 UDID 的 USB iPhone")
    parser.add_argument(
        "--username",
        default=os.environ.get("IC20_SSH_USERNAME", "mobile"),
        help="越狱手机 SSH 账号",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="只检查组件和 8090 服务，不安装或重启",
    )
    parser.add_argument(
        "--probe-only",
        action="store_true",
        help="只检查 8090 服务，不需要 SSH 账号或密码",
    )
    options = parser.parse_args()
    try:
        return asyncio.run(run(options))
    except UnsupportedPhoneError as error:
        print("", flush=True)
        print(f"手机系统与安装包没有匹配：{_compact(error)}", flush=True)
        return 3
    except PhoneInstallError as error:
        print("", flush=True)
        print(f"手机组件操作失败：{_compact(error)}", flush=True)
        return 1
    except KeyboardInterrupt:
        print("操作已取消。", flush=True)
        return 130
    except Exception as error:
        print("", flush=True)
        print(f"手机组件操作异常：{_compact(error)}", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
