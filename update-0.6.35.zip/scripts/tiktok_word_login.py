from __future__ import annotations

import argparse
import io
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit

from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from iphone_control_center.services.ios_mcp_control import (  # noqa: E402
    McpHttpClient,
    McpProtocolError,
)
from iphone_control_center.services.tiktok_accounts import (  # noqa: E402
    TikTokLoginAccount,
    TikTokTemplateError,
)
from tiktok_automation_common import clean_background_apps  # noqa: E402


TIKTOK_STUDIO_BUNDLE_ID = "com.ss.iphone.tt.creator"
TIKTOK_BUNDLE_ID = "com.zhiliaoapp.musically"
DEFAULT_BUNDLE_ID = TIKTOK_STUDIO_BUNDLE_ID
SAFARI_BUNDLE_ID = "com.apple.mobilesafari"
RESULT_PREFIX = "TIKTOK_LOGIN_RESULT|"
PROGRESS_PREFIX = "TIKTOK_LOGIN_PROGRESS|"
VERIFICATION_HTTP_TIMEOUT = 15.0
VERIFICATION_HTTP_MAX_BYTES = 1024 * 1024
VERIFICATION_HTTP_FAST_POLL_ATTEMPTS = 5
VERIFICATION_HTTP_FAST_POLL_INTERVAL_SECONDS = 0.35
VERIFICATION_HTTP_SLOW_POLL_INTERVAL_SECONDS = 0.75
FAST_FIELD_VERIFY_TIMEOUT_SECONDS = 1.1
PAGE_WAIT_INTERVAL_SECONDS = 0.18
STATUS_OCR_INTERVAL_SECONDS = 0.9
TAP_RETRY_DELAY_SECONDS = 0.18
INPUT_RETRY_DELAY_SECONDS = 2.0
WRONG_CODE_LINK_REFRESH_DELAY_SECONDS = 6.0
VERIFICATION_LINK_PREFLIGHT_TIMEOUT_SECONDS = 14.0
VERIFICATION_LINK_PREFLIGHT_FAST_TIMEOUT_SECONDS = 4.0
VERIFICATION_CODE_VISIBLE_TIMEOUT_SECONDS = 2.5
VERIFICATION_SEND_SETTLE_SECONDS = 1.2
VERIFICATION_CODE_INPUT_X_RATIO = 0.16
VERIFICATION_CODE_INPUT_Y_RATIO = 0.306
VERIFICATION_CODE_OCR_MIN_Y = 170.0
VERIFICATION_CODE_OCR_MAX_Y = 260.0
VERIFICATION_HTTP_USER_AGENT = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 "
    "Mobile/15E148 Safari/604.1"
)

LOGIN_ENTRY_MARKERS = (
    "使用手机号码/电子邮箱/用户名登录",
    "使用手机号码/电子邮件/用户名登录",
    "Use phone/email/username",
)
STUDIO_LOGIN_TITLE_MARKERS = (
    "登录 TikTok Studio",
    "Log in to TikTok Studio",
    "Log into TikTok Studio",
)
STUDIO_OTHER_LOGIN_MARKERS = (
    "使用其它方式登录",
    "使用其他方式登录",
    "Use another way to log in",
    "Use another way to sign in",
    "Other ways to log in",
    "Other ways to sign in",
    "Other login options",
    "Sign in another way",
)
STUDIO_MANAGE_TAB_MARKERS = ("管理", "manage", "Manage")
STUDIO_SETTINGS_MARKERS = (
    "设置与隐私",
    "Settings and privacy",
    "Settings & privacy",
)
STUDIO_SWITCH_ACCOUNT_MARKERS = (
    "切换账号",
    "Switch account",
    "Switch Account",
)
STUDIO_ADD_ACCOUNT_MARKERS = (
    "添加账号",
    "Add account",
    "Add Account",
)
STUDIO_LOGGED_IN_STRONG_MARKERS = (
    "账号概览",
    "账号数据",
    "作品数据",
    "Account overview",
    "Post details",
)
STUDIO_LOGGED_IN_SUPPORT_MARKERS = (
    "作品",
    "评论",
    "粉丝",
    "Analytics",
    "Posts",
    "Comments",
    "Followers",
)
EMAIL_TAB_MARKERS = ("邮箱/用户名", "电子邮件/用户名", "Email/username")
EMAIL_FIELD_MARKERS = ("电子邮件或用户名", "邮箱或用户名", "Email or username")
CONTINUE_MARKERS = (
    "继续",
    "下一步",
    "登录",
    "Next",
    "Continue",
    "Log in",
    "Login",
    "Sign in",
)
PASSWORD_MARKERS = ("密码", "Password")
SECURE_CONTENT_MARKERS = ("•", "●", "*", "·")
VERIFICATION_MARKERS = (
    "验证码",
    "确认代码",
    "安全代码",
    "输入代码",
    "输入 6 位代码",
    "6 位代码",
    "verification code",
    "security code",
    "enter the code",
    "enter code",
    "6-digit code",
    "one-time code",
)
CODE_ERROR_MARKERS = (
    "验证码已过期",
    "验证码过期",
    "验证码无效",
    "验证码错误",
    "验证码不正确",
    "代码已过期",
    "代码无效",
    "链接已过期",
    "code has expired",
    "code expired",
    "code is invalid",
    "invalid code",
    "incorrect code",
    "verification code is incorrect",
    "code is no longer valid",
)
RESEND_CODE_MARKERS = (
    "重新发送验证码",
    "重新发送",
    "发送验证码",
    "获取新验证码",
    "Resend code",
    "Send code",
    "Get new code",
    "Resend",
)
PASTE_MARKERS = ("粘贴", "Paste")
SECURITY_CHOICE_MARKERS = (
    "核实确实是你本人",
    "确认是你本人",
    "选择一种方式进行身份验证",
    "确保确实是你本人登录",
    "Verify it's you",
    "Verify it’s you",
    "Confirm it's you",
    "Confirm it’s you",
    "Choose a way to verify",
    "Choose a verification method",
    "Select a verification method",
    "Verify your identity",
)
EMAIL_OPTION_MARKERS = (
    "电子邮件",
    "邮箱",
    "Email",
    "E-mail",
    "Email address",
    "Send code to email",
)
VERIFICATION_METHOD_CONTINUE_MARKERS = ("下一步", "Next", "Continue")
AUTHENTICATOR_OPTION_MARKERS = (
    "身份验证器",
    "验证器",
    "动态密码",
    "动态码",
    "Authenticator",
    "Authenticator app",
    "Authentication app",
    "Two-factor authentication",
    "2FA",
)
CAPTCHA_MARKERS = (
    "拖动滑块",
    "完成安全验证",
    "请完成下列验证",
    "验证你是真人",
    "选择所有符合",
    "captcha",
    "安全验证",
)
CONSENT_PROMPT_MARKERS = (
    "点击【同意并继续】",
    "点击“同意并继续”",
    "点击\"同意并继续\"",
    "点击同意并继续",
    "By tapping Agree and continue",
    "By clicking Agree and continue",
    "By continuing, you agree to our Terms of Service",
    "By continuing, you agree to our Privacy Policy",
)
CONSENT_ACCEPT_MARKERS = (
    "同意并继续",
    "同意並繼續",
    "Agree and continue",
    "Agree & continue",
    "Accept and continue",
    "Accept & continue",
    "I agree",
)
SYSTEM_PERMISSION_PROMPT_MARKERS = (
    "想给你发送通知",
    "想要给你发送通知",
    "想访问你的相机",
    "想访问你的麦克风",
    "想访问你的照片",
    "想使用你的相机",
    "想使用你的麦克风",
    "想使用你的照片",
    "Would Like to Send You Notifications",
    "Would Like to Access Your Camera",
    "Would Like to Access the Microphone",
    "Would Like to Access Your Photos",
    "Would Like to Use Your Camera",
    "Would Like to Use the Microphone",
)
TRACKING_PROMPT_MARKERS = (
    "跟踪你在其他公司的 App 和网站上的活动",
    "跟踪您在其他公司的 App 和网站上的活动",
    "允许“TikTok Studio”跟踪",
    "允许 TikTok Studio 跟踪",
    "track your activity across other companies",
    "track your activity across other companies’ apps and websites",
    "track your activity across other companies' apps and websites",
)
TRACKING_DENY_MARKERS = (
    "要求 App 不跟踪",
    "要求App不跟踪",
    "要求应用不跟踪",
    "Ask App Not to Track",
)
SYSTEM_PERMISSION_ALLOW_MARKERS = (
    "允许完全访问",
    "允许访问所有照片",
    "允许所有照片",
    "Allow Full Access",
    "Allow Access to All Photos",
    "允许",
    "Allow",
)
ACCOUNT_ERROR_MARKERS = (
    "用户不存在",
    "找不到该账号",
    "账号或密码错误",
    "密码错误",
    "登录失败",
    "incorrect password",
    "couldn't find your account",
)
ACCOUNT_MISSING_MARKERS = (
    "用户不存在",
    "用户已注销",
    "用户已删除",
    "该用户不存在",
    "找不到该账号",
    "找不到该用户",
    "无法找到该账号",
    "该账号不存在",
    "此账号不存在",
    "该账号已被删除",
    "账号已注销",
    "account not found",
    "user not found",
    "couldn't find your account",
    "couldn’t find your account",
    "couldn't find this account",
    "couldn’t find this account",
    "this account doesn't exist",
    "this account doesn’t exist",
)
ACCOUNT_STATUS_PROMPT_MARKERS = (
    "账号状态",
    "你的账号已退出登录",
    "你的账号已被退出登录",
    "请尝试重新登录",
    "Account status",
    "You have been logged out",
    "You’ve been logged out",
    "Try logging in again",
)
ACCOUNT_STATUS_ACK_MARKERS = (
    "确定",
    "知道了",
    "好",
    "OK",
    "Okay",
    "Got it",
)
RATE_LIMIT_MARKERS = (
    "访问太频繁",
    "操作太频繁",
    "尝试次数过多",
    "请稍后再试",
    "too many attempts",
    "too many requests",
    "try again later",
    "rate limit",
)
HOME_MARKERS = ("推荐", "关注", "社区", "For You", "Following", "Profile", "主页")
HOME_CONFIRMATION_SAMPLES = 4
HOME_CONFIRMATION_INTERVAL_SECONDS = 0.35


class LoginFlowError(RuntimeError):
    def __init__(self, stage: str, detail: str) -> None:
        super().__init__(detail)
        self.stage = stage
        self.detail = detail


def emit_progress(stage: str, message: str) -> None:
    print(f"{PROGRESS_PREFIX}{stage}|{message}", flush=True)


def emit_result(
    success: bool,
    stage: str,
    detail: str,
    account: TikTokLoginAccount | None,
) -> None:
    print(
        RESULT_PREFIX
        + json.dumps(
            {
                "success": success,
                "stage": stage,
                "detail": detail,
                "account_masked": account.masked_account if account is not None else "",
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        flush=True,
    )


def normalize(value: str) -> str:
    return re.sub(r"\s+", "", value or "").casefold()


def contains_any(texts: list[str], markers: tuple[str, ...]) -> bool:
    haystack = [normalize(text) for text in texts]
    return any(normalize(marker) in text for marker in markers for text in haystack)


def contains_exact(texts: list[str], markers: tuple[str, ...]) -> bool:
    expected = {normalize(marker) for marker in markers}
    return any(normalize(text) in expected for text in texts)


class TikTokEmailLoginFlow:
    def __init__(
        self,
        port: int,
        account: TikTokLoginAccount,
        *,
        bundle_id: str = DEFAULT_BUNDLE_ID,
    ) -> None:
        self.client = McpHttpClient(f"http://127.0.0.1:{port}")
        self.account = account
        self.bundle_id = bundle_id
        self.is_studio = bundle_id == TIKTOK_STUDIO_BUNDLE_ID
        self._verification_attempts = 0
        self._last_verification_code = ""
        self._verification_method = ""
        self._verification_method_confirmed = False
        self._verification_link_preflight_done = False
        self._verification_code_sent = False

    @property
    def app_name(self) -> str:
        return "TikTok Studio" if self.is_studio else "TikTok"

    def run(self) -> None:
        self.client.connect()
        emit_progress("connect", "已连接手机控制服务")
        if self._resume_login_flow_if_present():
            self._wait_for_login_success()
            return
        self._open_clean_login_page()
        self._submit_account()
        self._submit_password_or_verification()
        self._wait_for_login_success()

    def close(self) -> None:
        self.client.close()

    def _tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def _nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "get_ui_elements",
                {"visible_only": True, "clickable_only": False},
            )
        except McpProtocolError:
            return []
        if isinstance(value, dict):
            for key in ("elements", "ui_elements", "items"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    return [node for node in nodes if isinstance(node, dict)]
        return []

    def _ocr_nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "ocr_screen",
                {"engine": "paddleocr", "min_confidence": 0.35},
            )
        except McpProtocolError:
            return []
        roots: list[Any] = []
        if isinstance(value, list):
            roots = value
        elif isinstance(value, dict):
            for key in ("results", "items", "texts", "elements"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    roots.extend(nodes)
        result: list[dict[str, Any]] = []
        for node in roots:
            if isinstance(node, str) and node.strip():
                result.append({"text": node.strip()})
            elif isinstance(node, dict) and str(node.get("text") or "").strip():
                result.append(node)
        return result

    @staticmethod
    def _texts_from_nodes(nodes: list[dict[str, Any]]) -> list[str]:
        texts: list[str] = []
        for node in nodes:
            for key in ("text", "label", "value", "name", "title"):
                value = node.get(key)
                if value is not None and str(value).strip():
                    texts.append(str(value).strip())
                    break
        return texts

    def _ocr_texts(self) -> list[str]:
        return self._texts_from_nodes(self._ocr_nodes())

    def _texts(self, *, include_ocr: bool = False) -> list[str]:
        nodes = self._nodes()
        if include_ocr:
            nodes.extend(self._ocr_nodes())
        return self._texts_from_nodes(nodes)

    def _frontmost_bundle(self) -> str:
        try:
            value = self._tool("get_frontmost_app", {})
        except McpProtocolError:
            return ""
        if isinstance(value, dict):
            return str(value.get("bundleId") or value.get("bundle_id") or "")
        return ""

    def _screen_size(self) -> tuple[int, int]:
        value = self._tool("get_screen_info", {})
        if not isinstance(value, dict):
            return (375, 667)
        try:
            return (int(value.get("width") or 375), int(value.get("height") or 667))
        except (TypeError, ValueError):
            return (375, 667)

    def _tap_xy(self, x: float, y: float) -> None:
        self._tool("tap_screen", {"x": round(x), "y": round(y)})

    def _tap_text(self, marker: str, *, exact: bool = True, index: int = 0) -> bool:
        try:
            value = self._tool(
                "tap_element",
                {
                    "text": marker,
                    "match": "exact" if exact else "contains",
                    "role": "control",
                    "index": index,
                },
            )
        except McpProtocolError:
            return False
        return isinstance(value, dict) and bool(value.get("tapped"))

    def _tap_markers(self, markers: tuple[str, ...]) -> bool:
        for _attempt in range(2):
            for marker in markers:
                if self._tap_text(marker, exact=True):
                    return True
            for marker in markers:
                if self._tap_text(marker, exact=False):
                    return True
            # System alerts often live above the app accessibility tree. OCR
            # still sees their buttons, so fall back to their tap coordinates.
            nodes = self._nodes()
            nodes.extend(self._ocr_nodes())
            for exact in (True, False):
                node = self._find_node_in_nodes(
                    nodes,
                    markers,
                    exact=exact,
                )
                if node is not None:
                    self._tap_node(node)
                    return True
            time.sleep(TAP_RETRY_DELAY_SECONDS)
        return False

    def _has_exact_text(self, markers: tuple[str, ...]) -> bool:
        expected = {normalize(marker) for marker in markers}
        return any(normalize(self._node_text(node)) in expected for node in self._nodes())

    def _node_text(self, node: dict[str, Any]) -> str:
        for key in ("text", "label", "value", "name", "title"):
            value = node.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""

    def _find_node(
        self,
        markers: tuple[str, ...],
        *,
        exact: bool = False,
        min_y: float | None = None,
        max_y: float | None = None,
        include_ocr: bool = False,
    ) -> dict[str, Any] | None:
        nodes = self._nodes()
        if include_ocr:
            nodes.extend(self._ocr_nodes())
        return self._find_node_in_nodes(
            nodes,
            markers,
            exact=exact,
            min_y=min_y,
            max_y=max_y,
        )

    def _find_node_in_nodes(
        self,
        nodes: list[dict[str, Any]],
        markers: tuple[str, ...],
        *,
        exact: bool = False,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, Any] | None:
        for node in nodes:
            text = normalize(self._node_text(node))
            if not text:
                continue
            matched = any(
                (text == normalize(marker)) if exact else (normalize(marker) in text)
                for marker in markers
            )
            if not matched:
                continue
            tap = node.get("tap")
            if not isinstance(tap, dict) or "x" not in tap or "y" not in tap:
                continue
            y = float(tap["y"])
            if min_y is not None and y < min_y:
                continue
            if max_y is not None and y > max_y:
                continue
            return node
        return None

    def _tap_node(self, node: dict[str, Any]) -> None:
        tap = node.get("tap")
        if not isinstance(tap, dict) or "x" not in tap or "y" not in tap:
            raise LoginFlowError("tap", "界面控件没有可点击坐标")
        self._tap_xy(float(tap["x"]), float(tap["y"]))

    def _verification_radio_selected(self, x: float, y: float) -> bool:
        try:
            image = Image.open(io.BytesIO(self.client.screenshot_jpeg())).convert("RGB")
        except Exception:
            return False
        red_samples = 0
        for offset_x in (-4, -2, 0, 2, 4):
            for offset_y in (-4, -2, 0, 2, 4):
                point_x = min(max(round(x + offset_x), 0), image.width - 1)
                point_y = min(max(round(y + offset_y), 0), image.height - 1)
                red, green, blue = image.getpixel((point_x, point_y))
                if red > 150 and red - green > 70 and red - blue > 60:
                    red_samples += 1
        return red_samples >= 3

    def _select_masked_email_verification_option(self) -> bool:
        nodes = self._nodes()
        nodes.extend(self._ocr_nodes())
        for node in nodes:
            text = self._node_text(node)
            tap = node.get("tap")
            if "@" not in text or not isinstance(tap, dict):
                continue
            if "x" not in tap or "y" not in tap:
                continue
            y = float(tap["y"])
            if not 150 <= y <= 380:
                continue
            width, _height = self._screen_size()
            circle_x = width * 0.837
            if not self._verification_radio_selected(circle_x, y):
                self._tap_xy(circle_x, y)
                time.sleep(0.25)
                if not self._verification_radio_selected(circle_x, y):
                    self._tap_xy(float(tap["x"]), y)
                    time.sleep(0.2)
            return True
        return False

    def _confirm_verification_method(self) -> bool:
        time.sleep(0.2)
        nodes = self._nodes()
        nodes.extend(self._ocr_nodes())
        current = self._texts_from_nodes(nodes)
        if not contains_any(current, SECURITY_CHOICE_MARKERS):
            return False
        node = self._find_node_in_nodes(
            nodes,
            VERIFICATION_METHOD_CONTINUE_MARKERS,
            exact=True,
            min_y=500,
            max_y=650,
        )
        if node is None:
            node = self._find_node_in_nodes(
                nodes,
                VERIFICATION_METHOD_CONTINUE_MARKERS,
                exact=False,
                min_y=500,
                max_y=650,
            )
        if node is not None:
            self._tap_node(node)
            time.sleep(0.2)
            return True
        return False

    @staticmethod
    def _verification_countdown_active(texts: list[str]) -> bool:
        joined = normalize(" ".join(texts))
        return bool(
            re.search(
                r"(?:发送验证码|重新发送验证码|resend|sendcode)\d+s",
                joined,
                re.IGNORECASE,
            )
        )

    def _assert_no_captcha(self, texts: list[str]) -> None:
        if not contains_any(texts, CAPTCHA_MARKERS):
            return
        emit_progress(
            "security",
            "检测到安全验证，请在手机上手动完成；完成后软件会自动继续登录。",
        )
        deadline = time.monotonic() + 180.0
        while time.monotonic() < deadline:
            current = self._texts()
            if not contains_any(current, CAPTCHA_MARKERS):
                emit_progress("security", "安全验证已完成，正在继续登录")
                time.sleep(0.6)
                return
            time.sleep(1.0)
        raise LoginFlowError(
            "security",
            "安全验证等待超时，请在手机上完成滑块或拼图后重新执行。",
        )

    def _accept_consent_if_present(self, texts: list[str]) -> bool:
        if not contains_any(texts, CONSENT_PROMPT_MARKERS):
            return False
        if not self._has_exact_text(CONSENT_ACCEPT_MARKERS):
            return False
        emit_progress(
            "consent",
            f"检测到 {self.app_name} 登录提示，正在自动点击“同意并继续”",
        )
        if not self._tap_markers(CONSENT_ACCEPT_MARKERS):
            raise LoginFlowError(
                "consent",
                "检测到 TikTok 同意弹窗，但没有找到可点击的“同意并继续”按钮。",
            )
        deadline = time.monotonic() + 8.0
        while time.monotonic() < deadline:
            if not self._has_exact_text(CONSENT_ACCEPT_MARKERS):
                emit_progress(
                    "consent",
                    f"已同意 {self.app_name} 登录提示，正在继续登录",
                )
                time.sleep(0.2)
                return True
            time.sleep(0.25)
        raise LoginFlowError(
            "consent",
            "已点击“同意并继续”，但 TikTok 提示窗口没有关闭，请手动检查。",
        )

    def _accept_system_permission_if_present(self, texts: list[str]) -> bool:
        if not contains_any(texts, SYSTEM_PERMISSION_PROMPT_MARKERS):
            return False
        emit_progress(
            "permission",
            "检测到 iPhone 系统权限弹窗，正在自动选择“允许”",
        )
        if not self._tap_markers(SYSTEM_PERMISSION_ALLOW_MARKERS):
            raise LoginFlowError(
                "permission",
                "检测到 iPhone 系统权限弹窗，但没有找到“允许”按钮。",
            )
        time.sleep(0.3)
        return True

    def _decline_tracking_if_present(self, texts: list[str]) -> bool:
        if not contains_any(texts, TRACKING_PROMPT_MARKERS):
            return False
        emit_progress(
            "permission",
            "检测到跨 App 跟踪弹窗，正在选择“要求 App 不跟踪”",
        )
        if not self._tap_markers(TRACKING_DENY_MARKERS):
            raise LoginFlowError(
                "permission",
                "检测到跨 App 跟踪弹窗，但没有找到“要求 App 不跟踪”按钮。",
            )
        time.sleep(0.3)
        return True

    def _dismiss_account_status_prompt_if_present(
        self, texts: list[str]
    ) -> bool:
        if not contains_any(texts, ACCOUNT_STATUS_PROMPT_MARKERS):
            return False
        emit_progress(
            "account_status",
            f"检测到 {self.app_name} 账号状态弹窗，正在点击“确定”后继续",
        )
        if not self._tap_markers(ACCOUNT_STATUS_ACK_MARKERS):
            raise LoginFlowError(
                "account_status",
                "检测到账号状态弹窗，但没有找到“确定”按钮。",
            )
        time.sleep(0.3)
        return True

    def _wait_for(
        self,
        predicate: Callable[[list[str]], bool],
        *,
        timeout: float,
        stage: str,
        timeout_detail: str,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._texts()
            self._assert_no_captcha(latest)
            self._raise_rate_limit_if_present(latest)
            if self._dismiss_account_status_prompt_if_present(latest):
                continue
            if self._decline_tracking_if_present(latest):
                continue
            if self._accept_system_permission_if_present(latest):
                continue
            if predicate(latest):
                return latest
            time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
        raise LoginFlowError(stage, timeout_detail)

    def _wait_tiktok_foreground(self, *, timeout: float = 15.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            frontmost = self._frontmost_bundle()
            latest = self._texts()
            if self._decline_tracking_if_present(latest):
                continue
            if self._accept_system_permission_if_present(latest):
                continue
            if self._dismiss_account_status_prompt_if_present(latest):
                continue
            if frontmost == self.bundle_id:
                return
            time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
        app_name = "TikTok Studio" if self.is_studio else "TikTok"
        raise LoginFlowError(
            "launch",
            f"{app_name} 没有在前台打开，请确认 App 仍已安装且手机已解锁。",
        )

    def _launch_login_app(self) -> None:
        try:
            self._tool("list_running_apps", {})
            clean_background_apps(self._tool)
        except Exception:
            pass
        last_error = ""
        for attempt in range(1, 4):
            try:
                self._tool("launch_app", {"bundle_id": self.bundle_id})
            except Exception as error:
                last_error = " ".join(str(error).split())[:220]
            try:
                self._wait_tiktok_foreground(timeout=7.0)
                return
            except LoginFlowError:
                try:
                    self._tool("wake_and_home", {"sequence": "auto"})
                except Exception:
                    pass
                if attempt < 3:
                    emit_progress(
                        "launch",
                        f"{self.app_name} 首次没有打开，正在自动重试（{attempt + 1}/3）",
                    )
                    time.sleep(1.2 * attempt)
        suffix = f"：{last_error}" if last_error else ""
        raise LoginFlowError(
            "launch",
            f"{self.app_name} 连续 3 次没有打开，请确认 App 仍已安装且手机已解锁{suffix}",
        )

    def _activate_email_tab(self) -> list[str]:
        """Select the email tab and wait for its actual text field."""
        texts = self._texts(include_ocr=True)
        if contains_any(texts, EMAIL_FIELD_MARKERS) or self._has_email_account_field():
            return texts
        if not contains_exact(texts, EMAIL_TAB_MARKERS):
            raise LoginFlowError("email_tab", "没有找到“邮箱/用户名”页签。")

        emit_progress("email_tab", "正在切换到邮箱/用户名登录")
        if not self._tap_markers(EMAIL_TAB_MARKERS):
            node = self._find_node(EMAIL_TAB_MARKERS, min_y=55, max_y=130)
            if node is None:
                raise LoginFlowError("email_tab", "没有找到“邮箱/用户名”页签。")
            self._tap_node(node)
        return self._wait_for(
            lambda current: contains_any(current, EMAIL_FIELD_MARKERS)
            or self._has_email_account_field(),
            timeout=10.0,
            stage="email_field",
            timeout_detail="已点击“邮箱/用户名”，但邮箱输入框没有出现。",
        )

    def _has_email_account_field(self) -> bool:
        expected = normalize(self.account.account)
        for node in self._nodes():
            y = self._node_y(node)
            if y is None or not 115 <= y <= 200:
                continue
            text = self._node_text(node)
            normalized = normalize(text)
            if expected and (normalized == expected or expected in normalized):
                return True
            if "@" in text and not contains_any((text,), EMAIL_TAB_MARKERS):
                return True
        return False

    def _resume_login_flow_if_present(self) -> bool:
        """Continue an interrupted login instead of reopening the Studio tab."""
        if self._frontmost_bundle() != self.bundle_id:
            return False
        texts = self._texts(include_ocr=True)
        self._raise_rate_limit_if_present(texts)
        self._raise_account_missing_if_present(texts)
        if self._dismiss_account_status_prompt_if_present(texts):
            texts = self._texts(include_ocr=True)
        if self._decline_tracking_if_present(texts):
            texts = self._texts(include_ocr=True)
        if self.is_studio and contains_any(
            texts,
            LOGIN_ENTRY_MARKERS + STUDIO_OTHER_LOGIN_MARKERS,
        ):
            emit_progress(
                "resume",
                "检测到 Studio 登录方式页，正在直接续接到邮箱/用户名登录",
            )
            self._open_studio_manage_page()
            texts = self._texts(include_ocr=True)
        if contains_any(texts, PASSWORD_MARKERS):
            emit_progress("resume", "检测到空密码页，正在返回账号页重新核对并填写")
            if not self._tap_markers(("返回", "Back")):
                node = self._find_node(("返回", "Back"), min_y=0, max_y=100)
                if node is None:
                    raise LoginFlowError(
                        "resume",
                        "检测到密码页，但没有找到返回账号页的按钮。",
                    )
                self._tap_node(node)
            texts = self._wait_for(
                lambda current: contains_any(
                    current, EMAIL_TAB_MARKERS + EMAIL_FIELD_MARKERS
                ),
                timeout=8.0,
                stage="resume",
                timeout_detail="从密码页返回后，没有找到邮箱/用户名登录页。",
            )
        if contains_any(texts, EMAIL_TAB_MARKERS + EMAIL_FIELD_MARKERS):
            emit_progress("resume", "检测到账号登录页，正在按 Word 账号续接登录")
            self._activate_email_tab()
            self._submit_account()
            return True
        if self._is_verification_step(texts):
            emit_progress("resume", "检测到验证码页，正在续接验证流程")
            return True
        return False

    def _open_clean_login_page(self) -> None:
        app_name = "TikTok Studio" if self.is_studio else "TikTok"
        emit_progress("launch", f"正在清理后台、唤醒手机并启动 {app_name}")
        try:
            self._tool("wake_and_home", {"sequence": "auto"})
        except Exception:
            pass
        self._launch_login_app()
        time.sleep(0.2)

        if self.is_studio:
            self._open_studio_manage_page()

        started_at = time.monotonic()
        deadline = started_at + 20.0
        home_seen_at: float | None = None
        latest: list[str] = []
        next_ocr_at = 0.0
        while time.monotonic() < deadline:
            now = time.monotonic()
            latest = self._texts()
            if now >= next_ocr_at:
                latest.extend(self._ocr_texts())
                next_ocr_at = now + STATUS_OCR_INTERVAL_SECONDS
            self._assert_no_captcha(latest)
            self._raise_rate_limit_if_present(latest)
            if self._dismiss_account_status_prompt_if_present(latest):
                continue
            if self._decline_tracking_if_present(latest):
                continue
            if self._accept_system_permission_if_present(latest):
                continue
            if self._accept_consent_if_present(latest):
                continue
            if contains_any(latest, EMAIL_FIELD_MARKERS):
                break
            if contains_any(latest, LOGIN_ENTRY_MARKERS):
                emit_progress("email_tab", "正在进入邮箱/用户名登录")
                self._tap_markers(LOGIN_ENTRY_MARKERS)
                time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
                continue
            if self.is_studio and contains_any(latest, STUDIO_OTHER_LOGIN_MARKERS):
                emit_progress(
                    "studio_login",
                    "检测到快捷账号入口，正在改走“使用其它方式登录”",
                )
                self._tap_markers(STUDIO_OTHER_LOGIN_MARKERS)
                time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
                continue
            if contains_exact(latest, EMAIL_TAB_MARKERS):
                break
            if self._is_home(latest):
                now = time.monotonic()
                if home_seen_at is None:
                    home_seen_at = now
                if now - home_seen_at >= 5.0:
                    raise LoginFlowError(
                        "already_logged_in",
                        "TikTok 当前已经登录账号，请先在手机里退出当前账号再执行。",
                    )
            else:
                home_seen_at = None
            time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
        else:
            if self._is_home(self._texts()):
                raise LoginFlowError(
                    "already_logged_in",
                    f"{app_name} 当前已经登录账号，请先在手机里退出当前账号再执行。",
                )
            raise LoginFlowError(
                "open_login",
                f"没有找到 {app_name} 登录入口，请确认 App 页面正常。",
            )

        self._activate_email_tab()
        if not self._tap_text("清除文本", exact=True):
            self._tap_text("清除文本", exact=False)
        time.sleep(0.15)
        emit_progress("email_tab", "已进入邮箱/用户名登录页")

    def _open_studio_manage_page(self) -> None:
        """Reach the signed-out Studio management page before starting login."""
        deadline = time.monotonic() + 45.0
        last_manage_tap = 0.0
        last_login_tap = 0.0
        last_profile_tap = 0.0
        last_scroll_tap = 0.0
        next_ocr_at = 0.0
        while time.monotonic() < deadline:
            now = time.monotonic()
            texts = self._texts()
            if now >= next_ocr_at:
                texts.extend(self._ocr_texts())
                next_ocr_at = now + STATUS_OCR_INTERVAL_SECONDS
            self._assert_no_captcha(texts)
            self._raise_rate_limit_if_present(texts)
            if self._dismiss_account_status_prompt_if_present(texts):
                continue
            if self._decline_tracking_if_present(texts):
                continue
            if self._accept_system_permission_if_present(texts):
                continue
            if contains_any(texts, EMAIL_FIELD_MARKERS):
                return
            # TikTok Studio keeps the previous login-method screen in the
            # accessibility tree during/after navigation. The visible email
            # tab is the stronger signal and must win over that stale text.
            if contains_exact(texts, EMAIL_TAB_MARKERS):
                return

            if contains_any(texts, LOGIN_ENTRY_MARKERS):
                if now - last_login_tap > 1.0:
                    emit_progress(
                        "studio_login",
                        "正在选择“手机号码/电子邮箱/用户名登录”",
                    )
                    if not self._tap_markers(LOGIN_ENTRY_MARKERS):
                        raise LoginFlowError(
                            "studio_login",
                            "已找到 Studio 登录方式页，但无法点击邮箱/用户名入口。",
                        )
                    last_login_tap = now
                time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
                continue

            if contains_any(texts, STUDIO_OTHER_LOGIN_MARKERS):
                now = time.monotonic()
                if now - last_login_tap > 1.5:
                    emit_progress(
                        "studio_login",
                        "检测到快捷账号入口，正在改走“使用其它方式登录”",
                    )
                    if not self._tap_markers(STUDIO_OTHER_LOGIN_MARKERS):
                        raise LoginFlowError(
                            "studio_login",
                            "检测到 Studio 快捷账号入口，但无法点击“使用其它方式登录”。",
                        )
                    last_login_tap = now
                time.sleep(0.25)
                continue

            if contains_any(texts, STUDIO_ADD_ACCOUNT_MARKERS):
                emit_progress(
                    "studio_account",
                    "检测到账号切换列表，正在添加新账号",
                )
                if self._tap_markers(STUDIO_ADD_ACCOUNT_MARKERS):
                    time.sleep(0.55)
                    continue

            if contains_any(texts, STUDIO_SWITCH_ACCOUNT_MARKERS):
                emit_progress(
                    "studio_account",
                    "检测到 Studio 已登录旧账号，正在打开账号切换",
                )
                if self._tap_markers(STUDIO_SWITCH_ACCOUNT_MARKERS):
                    time.sleep(0.35)
                    continue

            if contains_any(texts, STUDIO_LOGIN_TITLE_MARKERS):
                if now - last_login_tap > 1.0:
                    node = self._find_node(("登录", "Log in", "Sign in"), min_y=420, max_y=610)
                    if node is not None:
                        emit_progress("studio_login", "正在打开 TikTok Studio 登录页")
                        self._tap_node(node)
                    else:
                        width, height = self._screen_size()
                        self._tap_xy(width * 0.5, height * 0.78)
                    last_login_tap = now
                time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
                continue

            if contains_any(texts, STUDIO_SETTINGS_MARKERS):
                if now - last_scroll_tap > 0.6:
                    width, height = self._screen_size()
                    self._tool(
                        "swipe_screen",
                        {
                            "fromX": round(width * 0.5),
                            "fromY": round(height * 0.84),
                            "toX": round(width * 0.5),
                            "toY": round(height * 0.38),
                            "duration": 550,
                        },
                    )
                    last_scroll_tap = now
                time.sleep(0.25)
                continue

            if self._is_studio_logged_in(texts):
                if now - last_profile_tap > 1.5:
                    self._tap_markers(STUDIO_MANAGE_TAB_MARKERS)
                    width, height = self._screen_size()
                    emit_progress(
                        "studio_account",
                        "检测到 Studio 已登录账号，正在打开账号菜单",
                    )
                    self._tap_xy(width * 0.91, height * 0.069)
                    last_profile_tap = now
                time.sleep(0.3)
                continue

            if now - last_manage_tap > 1.0:
                if not self._tap_markers(STUDIO_MANAGE_TAB_MARKERS):
                    width, height = self._screen_size()
                    self._tap_xy(width * 0.9, height * 0.96)
                last_manage_tap = now
            time.sleep(0.25)
        latest = self._texts(include_ocr=True)
        if self._is_studio_logged_in(latest):
            raise LoginFlowError(
                "already_logged_in",
                "检测到 TikTok Studio 现有登录账号，但未能打开“切换账号 > 添加账号”。"
                "请先确认网络正常，再重新执行登录。",
            )
        raise LoginFlowError(
            "studio_login",
            "没有找到 TikTok Studio 的登录入口，请确认 Studio 页面正常。",
        )

    def _focus_field(
        self,
        markers: tuple[str, ...],
        *,
        min_y: float = 105,
        max_y: float = 330,
    ) -> None:
        for marker in markers:
            if self._tap_text(marker, exact=True):
                return
        node = self._find_node(markers, min_y=min_y, max_y=max_y)
        if node is None:
            raise LoginFlowError("field", "没有找到要填写的输入框。")
        self._tap_node(node)

    def _input_text(
        self, value: str, *, secure: bool = False, force_type: bool = False
    ) -> None:
        if secure or force_type:
            try:
                self._tool("type_text", {"text": value, "delay_ms": 25})
                time.sleep(0.25)
                return
            except Exception:
                pass
        try:
            self._tool("input_text", {"text": value})
        except Exception:
            self._tool("type_text", {"text": value, "delay_ms": 25})
        time.sleep(0.25)

    @staticmethod
    def _node_y(node: dict[str, Any]) -> float | None:
        tap = node.get("tap")
        if isinstance(tap, dict) and tap.get("y") is not None:
            try:
                return float(tap["y"])
            except (TypeError, ValueError):
                pass
        rect = node.get("rect") or node.get("visible_rect")
        if isinstance(rect, dict) and rect.get("y") is not None:
            try:
                return float(rect["y"]) + float(rect.get("height") or 0) / 2
            except (TypeError, ValueError):
                pass
        return None

    def _field_has_content(
        self,
        center_y: float,
        markers: tuple[str, ...],
        *,
        expected: str | None,
        include_ocr: bool = False,
    ) -> bool:
        expected_normalized = normalize(expected or "")
        nodes = self._nodes()
        self._raise_rate_limit_if_present([self._node_text(node) for node in nodes])
        for node in nodes:
            y = self._node_y(node)
            # The secure text field reports its placeholder and masked value as
            # separate accessibility nodes with different vertical coordinates.
            if y is None or abs(y - center_y) > 120:
                continue
            text = self._node_text(node)
            normalized = normalize(text)
            if not normalized:
                continue
            if expected_normalized:
                if normalized == expected_normalized or (
                    len(normalized) >= 6 and normalized in expected_normalized
                ):
                    return True
                continue
            if any(normalize(marker) in normalized for marker in markers):
                continue
            if any(marker in text for marker in SECURE_CONTENT_MARKERS):
                return True
            if re.fullmatch(r"\d{4,8}", text):
                return True
        if not include_ocr:
            return False
        ocr_nodes = self._ocr_nodes()
        self._raise_rate_limit_if_present(
            [self._node_text(node) for node in ocr_nodes]
        )
        for node in ocr_nodes:
            y = self._node_y(node)
            if y is None or abs(y - center_y) > 130:
                continue
            text = self._node_text(node)
            normalized = normalize(text)
            if expected_normalized and (
                normalized == expected_normalized
                or (len(normalized) >= 6 and normalized in expected_normalized)
            ):
                return True
            if any(marker in text for marker in SECURE_CONTENT_MARKERS):
                return True
            if re.fullmatch(r"\d{4,8}", text):
                return True
        return False

    def _clear_field(self, *, min_y: float, max_y: float) -> None:
        if self._tap_text("清除文本", exact=True):
            return
        if self._tap_text("Clear text", exact=True):
            return
        if self._tap_text("清除文本", exact=False):
            return
        node = self._find_node(
            ("关闭", "清除", "Clear", "Close"),
            exact=True,
            min_y=min_y,
            max_y=max_y,
        )
        if node is not None:
            self._tap_node(node)

    def _clear_clipboard(self) -> None:
        try:
            self._tool("set_clipboard", {"text": ""})
        except Exception:
            pass

    def _paste_field_value(
        self,
        value: str,
        *,
        center_y: float,
        markers: tuple[str, ...],
        expected: str | None,
        min_y: float,
        max_y: float,
    ) -> bool:
        try:
            self._tool("set_clipboard", {"text": value})
            anchor = self._find_node(
                ("关闭", "清除文本", "Clear text"),
                exact=True,
                min_y=min_y,
                max_y=max_y,
            )
            width, height = self._screen_size()
            if anchor is not None:
                anchor_y = self._node_y(anchor)
                paste_y = anchor_y if anchor_y is not None else center_y
                paste_x = width * 0.45
            else:
                paste_x = width * 0.5
                paste_y = center_y
            self._tool(
                "long_press",
                {"x": round(paste_x), "y": round(paste_y), "duration": 520},
            )
            time.sleep(0.2)
            if not self._tap_markers(PASTE_MARKERS):
                self._clear_clipboard()
                return False
            pasted = self._wait_for_field_content(
                center_y, markers, expected=expected, timeout=1.1
            )
            self._clear_clipboard()
            return pasted
        except Exception:
            self._clear_clipboard()
            return False

    def _wait_for_field_content(
        self,
        center_y: float,
        markers: tuple[str, ...],
        *,
        expected: str | None,
        timeout: float = 2.0,
    ) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._field_has_content(center_y, markers, expected=expected):
                return True
            time.sleep(0.12)
        return self._field_has_content(
            center_y, markers, expected=expected, include_ocr=True
        )

    def _input_with_retry(
        self,
        value: str,
        *,
        field_name: str,
        markers: tuple[str, ...],
        secure: bool,
        expected: str | None,
        min_y: float = 105,
        max_y: float = 340,
    ) -> None:
        node = self._find_node(markers, min_y=min_y, max_y=max_y)
        if node is None and expected:
            # When a resumed form is already populated, iOS may stop exposing
            # the placeholder text and expose only the current value node.
            node = self._find_node(
                (expected,),
                exact=True,
                min_y=min_y,
                max_y=max_y,
            )
        center_y = self._node_y(node) if node is not None else (min_y + max_y) / 2
        tap = node.get("tap") if node is not None else None
        initial_text = self._node_text(node) if node is not None else ""
        initial_normalized = normalize(initial_text)
        expected_normalized = normalize(expected or "")
        if expected_normalized and initial_normalized == expected_normalized:
            emit_progress("input", f"{field_name}已是目标内容，无需重复输入")
            return
        placeholder_visible = bool(
            initial_normalized
            and any(
                normalize(marker) in initial_normalized for marker in markers
            )
        )
        for attempt in range(1, 4):
            self._raise_rate_limit_if_present(self._texts())
            if attempt == 1:
                if node is not None:
                    self._tap_node(node)
                else:
                    self._focus_field(markers, min_y=min_y, max_y=max_y)
            elif isinstance(tap, dict) and "x" in tap and "y" in tap:
                self._tap_xy(float(tap["x"]), float(tap["y"]))
            else:
                self._focus_field(markers, min_y=min_y, max_y=max_y)
            if not (attempt == 1 and placeholder_visible):
                self._clear_field(min_y=min_y, max_y=max_y)
            self._input_text(
                value,
                secure=secure,
                force_type=secure or attempt > 1,
            )
            if self._wait_for_field_content(
                center_y,
                markers,
                expected=expected,
                timeout=FAST_FIELD_VERIFY_TIMEOUT_SECONDS,
            ):
                emit_progress("input", f"{field_name}已快速输入")
                return
            self._clear_field(min_y=min_y, max_y=max_y)
            if self._paste_field_value(
                value,
                center_y=center_y,
                markers=markers,
                expected=expected,
                min_y=min_y,
                max_y=max_y,
            ):
                emit_progress("input", f"{field_name}已通过粘贴写入")
                return
            self._raise_rate_limit_if_present(self._texts())
            emit_progress("input", f"{field_name}快速输入和粘贴均未确认，准备重试")
            if attempt < 3:
                emit_progress(
                    "input_retry",
                    f"检测到{field_name}没有输入，2 秒后自动重新输入"
                    f"（第 {attempt + 1}/3 次）",
                )
                time.sleep(INPUT_RETRY_DELAY_SECONDS)
        raise LoginFlowError(
            "input",
            f"{field_name}连续 3 次没有输入成功，请确认输入框和键盘正常。",
        )

    def _tap_continue(self) -> None:
        # The password screen contains "需要登录帮助？". A contains-based
        # fallback for the "登录" marker would tap that help link and leave the
        # login flow. Continue buttons must match exactly and stay in the form.
        for marker in CONTINUE_MARKERS:
            if self._tap_text(marker, exact=True):
                return
        node = self._find_node(
            CONTINUE_MARKERS,
            exact=True,
            min_y=250,
            max_y=650,
        )
        if node is None:
            raise LoginFlowError("continue", "没有找到“继续”按钮。")
        self._tap_node(node)

    def _fill_password(self) -> None:
        emit_progress("password", "账号已识别，正在填写密码")
        self._input_with_retry(
            self.account.password,
            field_name="密码",
            markers=PASSWORD_MARKERS,
            secure=True,
            expected=None,
            min_y=145,
            max_y=250,
        )
        self._tap_continue()

    def _has_account_error(self, texts: list[str]) -> bool:
        return contains_any(texts, ACCOUNT_ERROR_MARKERS)

    def _has_account_missing(self, texts: list[str]) -> bool:
        return contains_any(texts, ACCOUNT_MISSING_MARKERS)

    def _raise_account_missing_if_present(self, texts: list[str]) -> None:
        if not self._has_account_missing(texts):
            return
        raise LoginFlowError(
            "account_missing",
            f"{self.app_name} 明确提示该账号不存在，正在清理旧登录记录。",
        )

    def _has_rate_limit(self, texts: list[str]) -> bool:
        return contains_any(texts, RATE_LIMIT_MARKERS)

    def _raise_rate_limit_if_present(self, texts: list[str]) -> None:
        if not self._has_rate_limit(texts):
            return
        raise LoginFlowError(
            "rate_limit",
            "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
        )

    @staticmethod
    def _is_verification_step(texts: list[str]) -> bool:
        return contains_any(texts, VERIFICATION_MARKERS + SECURITY_CHOICE_MARKERS)

    def _is_studio_logged_in(self, texts: list[str]) -> bool:
        if contains_any(
            texts,
            STUDIO_LOGIN_TITLE_MARKERS
            + LOGIN_ENTRY_MARKERS
            + EMAIL_FIELD_MARKERS
            + EMAIL_TAB_MARKERS
            + VERIFICATION_MARKERS
            + SECURITY_CHOICE_MARKERS,
        ):
            return False
        if contains_any(texts, STUDIO_LOGGED_IN_STRONG_MARKERS):
            return True
        support_count = sum(
            1
            for marker in STUDIO_LOGGED_IN_SUPPORT_MARKERS
            if contains_any(texts, (marker,))
        )
        return support_count >= 2

    def _is_home(self, texts: list[str]) -> bool:
        if self.is_studio:
            return self._is_studio_logged_in(texts)
        if not contains_any(texts, HOME_MARKERS):
            return False
        if contains_any(
            texts,
            EMAIL_FIELD_MARKERS
            + EMAIL_TAB_MARKERS
            + LOGIN_ENTRY_MARKERS
            + CONSENT_PROMPT_MARKERS
            + CONSENT_ACCEPT_MARKERS
            + VERIFICATION_MARKERS
            + SECURITY_CHOICE_MARKERS
            + ("保存登录信息", "新建账号", "登录"),
        ):
            return False
        return True

    def _submit_account(self) -> None:
        emit_progress("account", "正在填写账号")
        self._input_with_retry(
            self.account.account,
            field_name="账号",
            markers=EMAIL_FIELD_MARKERS,
            secure=False,
            expected=self.account.account,
            min_y=105,
            max_y=250,
        )
        self._tap_continue()
        texts = self._wait_for(
            lambda current: self._has_account_error(current)
            or self._has_rate_limit(current)
            or contains_any(current, PASSWORD_MARKERS)
            or self._is_verification_step(current)
            or self._is_home(current),
            timeout=22.0,
            stage="account",
            timeout_detail="提交账号后页面没有进入密码或验证步骤。",
        )
        if self._has_rate_limit(texts):
            raise LoginFlowError(
                "rate_limit",
                "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
            )
        self._raise_account_missing_if_present(texts)
        if self._has_account_error(texts):
            raise LoginFlowError("account", "TikTok 未识别这个账号，请检查 Word 里的账号是否正确。")
        if self._is_home(texts):
            return
        if contains_any(texts, PASSWORD_MARKERS):
            self._fill_password()
            return
        emit_progress("verification", "TikTok 要求先完成验证码验证")

    def _submit_password_or_verification(self) -> None:
        texts = self._wait_for(
            lambda current: self._has_account_error(current)
            or self._has_rate_limit(current)
            or self._is_home(current)
            or self._is_verification_step(current),
            timeout=28.0,
            stage="password",
            timeout_detail="提交密码后没有进入 TikTok 首页或验证页面。",
        )
        if self._has_rate_limit(texts):
            raise LoginFlowError(
                "rate_limit",
                "TikTok 提示访问太频繁，请等待一段时间后再试，不要连续切换账号。",
            )
        self._raise_account_missing_if_present(texts)
        if self._has_account_error(texts):
            raise LoginFlowError("password", "TikTok 提示账号或密码不正确，请检查 Word 内容。")
        if self._is_home(texts):
            return
        if self._is_verification_step(texts):
            self._complete_verification()

    @staticmethod
    def _normalize_code_candidate(value: Any) -> str:
        compact = re.sub(r"[\s-]+", "", str(value or "")).upper()
        if (
            re.fullmatch(r"[A-Z0-9]{4,8}", compact)
            and re.search(r"\d", compact)
        ):
            return compact
        return ""

    @classmethod
    def _extract_code(cls, values: list[str]) -> str:
        joined = "\n".join(values)
        compact = re.sub(r"\s+", "", joined)
        structured_patterns = (
            r'(?i)["\']?(?:data|code|otp|verification_code|security_code|auth_code)'
            r'["\']?\s*:\s*["\']?([A-Z0-9]{4,8})',
        )
        for pattern in structured_patterns:
            for candidate in re.findall(pattern, joined) + re.findall(pattern, compact):
                code = cls._normalize_code_candidate(candidate)
                if code:
                    return code
        natural_patterns = (
            r"(?i)\b(?:tiktok\s*)?([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})"
            r"\s+is\s+your\s+"
            r"(?:verification|security|confirmation|authentication|sign[\s-]?in|"
            r"login|one[\s-]?time|2fa|two[\s-]?factor)\s+code\b",
            r"(?i)\b(?:verification|security|confirmation|authentication|sign[\s-]?in|"
            r"login|one[\s-]?time)\s+code(?:\s+(?:is|was))?\s*[:=,-]?\s*"
            r"([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})\b",
            r"(?i)\b(?:otp|totp|2fa|two[\s-]?factor|authenticator)"
            r"(?:\s+(?:code|token|passcode))?(?:\s+(?:is|was))?\s*[:=,-]?\s*"
            r"([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})\b",
        )
        for pattern in natural_patterns:
            for candidate in re.findall(pattern, joined):
                code = cls._normalize_code_candidate(candidate)
                if code:
                    return code
        labelled = re.findall(
            r"(?i)(?:验证码|确认码|安全代码|verification\s*code|security\s*code|otp)"
            r"[^A-Z0-9]{0,24}([A-Z0-9]{4,8}|[A-Z0-9]{3}[\s-][A-Z0-9]{3})",
            joined,
        )
        candidates = labelled or re.findall(r"(?<!\d)(\d{4,8})(?!\d)", compact)
        for candidate in candidates:
            code = cls._normalize_code_candidate(candidate)
            if code:
                return code
        return ""

    def _clipboard_code(self) -> str:
        try:
            value = self._tool("get_clipboard", {})
        except Exception:
            return ""
        text = ""
        if isinstance(value, dict):
            text = str(value.get("text") or "")
        elif value is not None:
            text = str(value)
        return self._extract_code([text])

    def _close_safari(self) -> None:
        try:
            self._tool("kill_app", {"bundle_id": SAFARI_BUNDLE_ID})
        except Exception:
            pass
        time.sleep(0.2)

    def _preflight_verification_link(self) -> str:
        """Verify Safari can open the mailbox link and record the old code."""
        if self._verification_link_preflight_done:
            return self._last_verification_code
        url = self.account.verification_url.strip()
        if not url:
            return ""

        emit_progress(
            "verification_link_preflight",
            "先检查能否离开 TikTok 并打开邮箱链接；这一步不会发送验证码",
        )
        baseline_code = self._code_from_verification_url_http()
        if baseline_code:
            self._last_verification_code = baseline_code

        self._close_safari()
        try:
            self._tool("open_url", {"url": url})
        except Exception as error:
            raise LoginFlowError(
                "verification_link_preflight",
                "无法打开邮箱验证链接，因此没有发送验证码。请检查 Safari 和网络。",
            ) from error

        preflight_timeout = (
            VERIFICATION_LINK_PREFLIGHT_FAST_TIMEOUT_SECONDS
            if baseline_code
            else VERIFICATION_LINK_PREFLIGHT_TIMEOUT_SECONDS
        )
        deadline = time.monotonic() + preflight_timeout
        safari_seen = False
        page_seen = False
        page_error = False
        while time.monotonic() < deadline:
            if self._frontmost_bundle() == SAFARI_BUNDLE_ID:
                safari_seen = True
            if baseline_code and safari_seen:
                # The direct mailbox read already proved the link is fresh.
                # Only verify Safari can receive it; skip the slow OCR pass.
                page_seen = True
                break
            texts = [self._node_text(node) for node in self._ocr_nodes()]
            if texts and safari_seen:
                page_seen = True
            code = self._extract_code(texts)
            if code and safari_seen:
                baseline_code = code
                page_seen = True
            if contains_any(
                texts,
                (
                    "链接已过期",
                    "链接无效",
                    "not found",
                    "link expired",
                    "invalid link",
                ),
            ):
                page_error = True
            if page_seen or page_error:
                break
            time.sleep(0.25)

        if not safari_seen:
            raise LoginFlowError(
                "verification_link_preflight",
                "TikTok 无法切换到 Safari，因此没有发送验证码。",
            )
        if page_error:
            raise LoginFlowError(
                "verification_link_preflight",
                "邮箱验证链接已失效，因此没有发送验证码。请更新 Word 里的链接。",
            )
        if not page_seen and not baseline_code:
            raise LoginFlowError(
                "verification_link_preflight",
                "Safari 已打开，但邮箱验证页面没有正常显示，因此没有发送验证码。",
            )

        if baseline_code:
            self._last_verification_code = baseline_code
        self._verification_link_preflight_done = True
        emit_progress(
            "verification_link_preflight",
            "已记录发送前的验证码基线；返回 TikTok 后由“下一步”发送一次新验证码",
        )
        self._return_to_tiktok()
        return self._last_verification_code

    def _reset_verification_link_page(self) -> None:
        """Remove the stale link page and wait before requesting a fresh code."""
        emit_progress(
            "verification",
            "验证码错误，正在清除浏览器旧链接并等待 6 秒后重新读取",
        )
        self._close_safari()
        self._clear_clipboard()
        try:
            self._tool("open_url", {"url": "about:blank"})
        except Exception:
            pass
        time.sleep(WRONG_CODE_LINK_REFRESH_DELAY_SECONDS)
        emit_progress("verification", "旧链接已清除，正在重新打开验证链接")

    @classmethod
    def _verification_code_from_json(cls, value: Any, *, depth: int = 0) -> str:
        if depth > 8:
            return ""
        if isinstance(value, dict):
            for key in (
                "data",
                "code",
                "otp",
                "verification_code",
                "verificationCode",
                "security_code",
                "securityCode",
                "auth_code",
                "authCode",
                "pin",
            ):
                candidate = value.get(key)
                if isinstance(candidate, (str, int)):
                    code = cls._normalize_code_candidate(candidate)
                    if code:
                        return code
            for nested in value.values():
                code = cls._verification_code_from_json(nested, depth=depth + 1)
                if code:
                    return code
        elif isinstance(value, list):
            for nested in value:
                code = cls._verification_code_from_json(nested, depth=depth + 1)
                if code:
                    return code
        return ""

    def _extract_code_from_http_text(self, text: str) -> str:
        cleaned = text.strip()
        if not cleaned:
            return ""
        json_text = cleaned
        if not json_text.startswith(("{", "[")):
            start = cleaned.find("{")
            end = cleaned.rfind("}")
            if start >= 0 and end > start:
                json_text = cleaned[start : end + 1]
        try:
            payload = json.loads(json_text)
        except (TypeError, ValueError, json.JSONDecodeError):
            payload = None
        if payload is not None:
            code = self._verification_code_from_json(payload)
            if code:
                return code
        if any(
            marker in cleaned.casefold()
            for marker in (
                "验证码",
                "确认码",
                "安全代码",
                "verification code",
                "security code",
                "otp",
                "2fa",
            )
        ):
            code = self._extract_code([cleaned])
            if code:
                return code
        code = self._normalize_code_candidate(cleaned)
        if code:
            return code
        return ""

    def _code_from_verification_url_http(self) -> str:
        """Read the code without depending on Safari OCR or screen text."""
        url = self.account.verification_url.strip()
        if not url:
            return ""
        try:
            parsed_url = urlsplit(url)
        except ValueError:
            return ""
        if parsed_url.scheme.casefold() not in {"http", "https"} or not parsed_url.netloc:
            return ""
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json,text/plain,text/html;q=0.9,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.7",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "User-Agent": VERIFICATION_HTTP_USER_AGENT,
            },
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request,
                timeout=VERIFICATION_HTTP_TIMEOUT,
            ) as response:
                body = response.read(VERIFICATION_HTTP_MAX_BYTES + 1)
                charset = response.headers.get_content_charset() or "utf-8"
        except (
            urllib.error.HTTPError,
            urllib.error.URLError,
            TimeoutError,
            OSError,
            ValueError,
        ):
            return ""
        if not body or len(body) > VERIFICATION_HTTP_MAX_BYTES:
            return ""
        try:
            text = body.decode(charset, "replace")
        except LookupError:
            text = body.decode("utf-8", "replace")
        return self._extract_code_from_http_text(text)

    def _code_from_verification_link(self, *, force_fresh: bool = False) -> str:
        if not self.account.verification_url:
            return ""
        http_attempts = 18 if force_fresh else 8
        for http_attempt in range(http_attempts):
            code = self._code_from_verification_url_http()
            if code and not (
                force_fresh and code == self._last_verification_code
            ):
                self._last_verification_code = code
                emit_progress(
                    "verification_link",
                    "已直接从邮箱验证链接取得验证码",
                )
                return code
            if http_attempt == 2:
                emit_progress(
                    "verification_link",
                    "邮箱链接暂未返回新验证码，正在继续等待",
                )
            if http_attempt + 1 < http_attempts:
                interval = (
                    VERIFICATION_HTTP_FAST_POLL_INTERVAL_SECONDS
                    if http_attempt < VERIFICATION_HTTP_FAST_POLL_ATTEMPTS
                    else VERIFICATION_HTTP_SLOW_POLL_INTERVAL_SECONDS
                )
                time.sleep(interval)

        copy_markers = (
            "查看验证码",
            "显示验证码",
            "复制验证码",
            "获取验证码",
            "查看",
            "复制",
            "Show code",
            "Copy code",
        )
        for fetch_attempt in range(3):
            if fetch_attempt > 0:
                emit_progress(
                    "verification_link",
                    "验证码页面可能是旧内容，正在关闭 Safari 并重新打开",
                )
                self._close_safari()
            emit_progress("verification_link", "正在打开验证链接")
            self._tool("open_url", {"url": self.account.verification_url})
            time.sleep(0.65)
            nodes = self._ocr_nodes()
            texts = [self._node_text(node) for node in nodes]
            self._assert_no_captcha(texts)
            if self._tap_markers(("复制验证码", "复制", "Copy code", "Copy")):
                time.sleep(0.15)
                code = self._clipboard_code()
                if code and not (
                    force_fresh and code == self._last_verification_code
                ):
                    self._last_verification_code = code
                    return code
            elif self._tap_markers(copy_markers):
                time.sleep(0.15)
            code = self._extract_code([self._node_text(node) for node in nodes])
            if not code:
                code = self._extract_code(self._texts())
            if code:
                if force_fresh and code == self._last_verification_code:
                    continue
                self._last_verification_code = code
                return code
            if fetch_attempt + 1 < 3:
                continue
        if force_fresh:
            raise LoginFlowError(
                "verification_link",
                "邮箱尚未收到与发送前不同的新验证码。为避免填写旧验证码，"
                "流程已停止，也不会自动重发。",
            )
        raise LoginFlowError(
            "verification_link",
            "电脑直接读取和 Safari 备用读取都没有拿到验证码；"
            "请确认验证链接有效，稍后重试。",
        )

    def _return_to_tiktok(self) -> None:
        if self._frontmost_bundle() == self.bundle_id:
            return
        self._tool("launch_app", {"bundle_id": self.bundle_id})
        self._wait_tiktok_foreground()
        time.sleep(0.15)

    def _verification_code(
        self, page_texts: list[str], *, force_fresh_link: bool = False
    ) -> str:
        if self.account.has_2fa:
            lowered = " ".join(page_texts).casefold()
            authenticator = any(
                marker in lowered
                for marker in ("authenticator", "身份验证器", "动态密码", "动态码")
            )
            if authenticator or not self.account.has_verification_link:
                return self.account.current_two_factor_code()
        if self.account.has_verification_link:
            return self._code_from_verification_link(force_fresh=force_fresh_link)
        if self.account.has_2fa:
            return self.account.current_two_factor_code()
        return ""

    def _focus_verification_field(self) -> None:
        width, height = self._screen_size()
        self._tap_xy(
            width * VERIFICATION_CODE_INPUT_X_RATIO,
            height * VERIFICATION_CODE_INPUT_Y_RATIO,
        )

    def _verification_ocr_snapshot(self) -> tuple[str, bool]:
        ocr_nodes = self._ocr_nodes()
        ocr_texts = [self._node_text(node) for node in ocr_nodes]
        ui_texts = self._texts()
        page_visible = contains_any(
            ocr_texts + ui_texts,
            (
                "验证身份",
                "输入 6 位验证码",
                "输入6位验证码",
                "发送验证码",
                "重新发送验证码",
                "Enter the 6-digit code",
            ),
        )
        digit_nodes: list[tuple[float, str]] = []
        for node in ocr_nodes:
            y = self._node_y(node)
            if y is None or not (
                VERIFICATION_CODE_OCR_MIN_Y <= y <= VERIFICATION_CODE_OCR_MAX_Y
            ):
                continue
            digits = "".join(re.findall(r"\d", self._node_text(node)))
            if not digits:
                continue
            tap = node.get("tap")
            rect = node.get("rect") or node.get("visible_rect") or {}
            try:
                x = float(tap["x"]) if isinstance(tap, dict) and "x" in tap else float(rect["x"])
            except (KeyError, TypeError, ValueError):
                x = 0.0
            digit_nodes.append((x, digits))
        digit_nodes.sort(key=lambda item: item[0])
        visible_code = "".join(digits for _x, digits in digit_nodes)
        return visible_code, page_visible

    def _verification_code_visible(self, code: str) -> bool:
        expected = normalize(code)
        if not expected:
            return False
        visible_code, _page_visible = self._verification_ocr_snapshot()
        return expected in visible_code

    def _verification_page_visible(self) -> bool:
        _visible_code, page_visible = self._verification_ocr_snapshot()
        return page_visible

    def _wait_for_verification_code_visible(
        self,
        code: str,
        *,
        timeout: float = VERIFICATION_CODE_VISIBLE_TIMEOUT_SECONDS,
    ) -> bool:
        expected = normalize(code)
        deadline = time.monotonic() + timeout
        saw_verification_page = False
        while time.monotonic() < deadline:
            visible_code, page_visible = self._verification_ocr_snapshot()
            saw_verification_page = saw_verification_page or page_visible
            if expected and expected in visible_code:
                return True
            if saw_verification_page and not page_visible:
                return True
            time.sleep(0.18)
        visible_code, _page_visible = self._verification_ocr_snapshot()
        return bool(expected and expected in visible_code)

    def _clear_verification_code(self) -> None:
        visible_code, _page_visible = self._verification_ocr_snapshot()
        if not visible_code:
            return
        for _attempt in range(min(max(len(visible_code) + 2, 6), 10)):
            try:
                self._tool("press_key", {"key": "backspace"})
            except Exception:
                return
            time.sleep(0.05)
        time.sleep(0.18)

    def _input_verification_code(self, code: str) -> None:
        for attempt in range(1, 3):
            if not self._verification_page_visible():
                return
            self._focus_verification_field()
            self._clear_verification_code()
            self._input_text(code, secure=True, force_type=True)
            if self._wait_for_verification_code_visible(code):
                emit_progress("input", "验证码已确认显示在 6 个输入格中")
                return
            if not self._verification_page_visible():
                return
            if attempt == 1:
                emit_progress(
                    "input_retry",
                    "验证码没有完整显示，2 秒后重新填写一次",
                )
                time.sleep(INPUT_RETRY_DELAY_SECONDS)
        raise LoginFlowError(
            "input",
            "验证码没有完整显示在 6 个输入格中，已停止提交。",
        )

    def _resend_verification_code(self) -> None:
        if self.account.has_verification_link and not self._verification_link_preflight_done:
            self._preflight_verification_link()
        if self._verification_code_sent:
            raise LoginFlowError(
                "rate_limit",
                "本次登录已经发送过验证码，为避免频繁登录，已停止再次发送。",
            )
        emit_progress(
            "verification",
            "邮箱链接检查完成，正在发送一次新的验证码",
        )
        deadline = time.monotonic() + 18.0
        while time.monotonic() < deadline:
            texts = self._texts(include_ocr=True)
            self._raise_rate_limit_if_present(texts)
            if contains_any(texts, RESEND_CODE_MARKERS) and self._tap_markers(
                RESEND_CODE_MARKERS
            ):
                self._verification_code_sent = True
                time.sleep(VERIFICATION_SEND_SETTLE_SECONDS)
                emit_progress(
                    "verification",
                    "已发送一次新验证码，正在读取邮件链接",
                )
                return
            time.sleep(0.8)
        raise LoginFlowError(
            "verification",
            "没有成功发送验证码，软件不会自动连续重试。请查看手机页面后再试。",
        )

    def _has_code_error(self, texts: list[str]) -> bool:
        return contains_any(texts, CODE_ERROR_MARKERS)

    def _wait_for_code_result(self, *, timeout: float = 22.0) -> bool | None:
        deadline = time.monotonic() + timeout
        home_samples = 0
        while time.monotonic() < deadline:
            texts = self._texts()
            self._assert_no_captcha(texts)
            if self._dismiss_account_status_prompt_if_present(texts):
                continue
            if self._decline_tracking_if_present(texts):
                continue
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError("login", "TikTok 提示账号、密码或验证信息不正确。")
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._has_code_error(texts):
                return False
            if self._is_home(texts):
                home_samples += 1
                if home_samples >= HOME_CONFIRMATION_SAMPLES:
                    emit_progress("success", "已确认进入 TikTok 首页")
                    return True
            else:
                home_samples = 0
            time.sleep(HOME_CONFIRMATION_INTERVAL_SECONDS)
        return None

    def _tap_verify_action(self) -> None:
        markers = (
            "继续",
            "验证",
            "确认",
            "登录",
            "Verify",
            "Continue",
            "Next",
            "Submit",
            "Confirm",
            "Log in",
            "Done",
        )
        if self._tap_markers(markers):
            return
        node = self._find_node(markers, min_y=240, max_y=640)
        if node is not None:
            self._tap_node(node)

    def _choose_verification_method(self, texts: list[str]) -> list[str]:
        if not contains_any(texts, SECURITY_CHOICE_MARKERS):
            if not self._verification_method:
                if self.account.has_verification_link:
                    self._verification_method = "email_link"
                elif self.account.has_2fa:
                    self._verification_method = "authenticator"
            return texts
        tapped = False
        if self.account.has_2fa:
            emit_progress("verification_method", "正在按 Word 内容选择身份验证器")
            tapped = self._tap_markers(AUTHENTICATOR_OPTION_MARKERS)
            if tapped:
                self._verification_method = "authenticator"
        if not tapped and self.account.has_verification_link:
            emit_progress("verification_method", "正在按 Word 内容选择电子邮件验证")
            tapped = self._tap_markers(EMAIL_OPTION_MARKERS)
            if not tapped:
                tapped = self._select_masked_email_verification_option()
            if tapped:
                self._verification_method = "email_link"
        if not tapped and self.account.has_2fa:
            tapped = self._tap_markers(AUTHENTICATOR_OPTION_MARKERS)
            if tapped:
                self._verification_method = "authenticator"
        if not tapped:
            raise LoginFlowError(
                "verification_method",
                "TikTok 要求身份验证，但没有找到与 Word 匹配的验证方式。",
            )
        if (
            self._verification_method == "email_link"
            and self.account.has_verification_link
            and not self._verification_link_preflight_done
        ):
            self._preflight_verification_link()
        if self._confirm_verification_method():
            self._verification_method_confirmed = True
        return self._wait_for(
            lambda current: contains_any(current, VERIFICATION_MARKERS),
            timeout=14.0,
            stage="verification_method",
            timeout_detail="选择身份验证方式后，没有出现验证码输入页面。",
        )

    def _complete_verification(self) -> None:
        self._verification_attempts += 1
        page_texts = self._texts(include_ocr=True)
        page_texts = self._choose_verification_method(page_texts)
        use_email_link = bool(
            self.account.has_verification_link
            and self._verification_method != "authenticator"
        )
        code = self._verification_code(
            page_texts,
            # Only selecting the method and tapping "Next" asks TikTok for a new
            # code. When resuming an existing code page, keep the code already
            # sent so that a countdown is never turned into another request.
            force_fresh_link=use_email_link and self._verification_method_confirmed,
        )

        if not code:
            raise LoginFlowError(
                "verification",
                "TikTok 要求验证码，但 Word 里没有可用的 2FA 或验证链接。",
            )
        emit_progress("verification", "已取得可用验证码，正在返回登录页面填写")
        # Always return to the login app before typing. This also covers the
        # direct HTTP path, where Safari may never have been opened.
        self._return_to_tiktok()
        self._input_verification_code(code)
        time.sleep(0.2)
        if self._is_verification_step(self._texts()):
            self._tap_verify_action()
        result = self._wait_for_code_result()
        if result is True:
            return
        if result is False:
            self._reset_verification_link_page()
            raise LoginFlowError(
                "verification",
                "这次新验证码未通过。为避免频繁登录，软件已停止自动重发；"
                "请稍后再执行一次登录。",
            )
        raise LoginFlowError(
            "verification",
            "验证码已填写，但 TikTok 没有确认登录成功；"
            "为避免频繁登录，软件已停止自动重发。",
        )

    def _wait_for_login_success(self) -> None:
        if self.is_studio:
            self._wait_for_studio_login_success()
            return
        deadline = time.monotonic() + 45.0
        home_samples = 0
        while time.monotonic() < deadline:
            texts = self._texts()
            self._assert_no_captcha(texts)
            if self._dismiss_account_status_prompt_if_present(texts):
                continue
            if self._decline_tracking_if_present(texts):
                continue
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError("login", "TikTok 提示账号、密码或验证信息不正确。")
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._is_home(texts):
                home_samples += 1
                if home_samples >= HOME_CONFIRMATION_SAMPLES:
                    emit_progress("success", "已确认进入 TikTok 首页")
                    return
            else:
                home_samples = 0
            if self._is_verification_step(texts) and self._verification_attempts == 0:
                self._complete_verification()
                continue
            time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
        raise LoginFlowError(
            "login",
            "等待 TikTok 登录成功超时，请查看手机当前页面。",
        )

    def _wait_for_studio_login_success(self) -> None:
        deadline = time.monotonic() + 55.0
        last_manage_tap = 0.0
        next_ocr_at = 0.0
        while time.monotonic() < deadline:
            now = time.monotonic()
            texts = self._texts()
            if now >= next_ocr_at:
                texts.extend(self._ocr_texts())
                next_ocr_at = now + STATUS_OCR_INTERVAL_SECONDS
            self._assert_no_captcha(texts)
            if self._dismiss_account_status_prompt_if_present(texts):
                continue
            if self._decline_tracking_if_present(texts):
                continue
            if self._accept_system_permission_if_present(texts):
                continue
            self._raise_account_missing_if_present(texts)
            if self._has_account_error(texts):
                raise LoginFlowError(
                    "login",
                    "TikTok Studio 提示账号、密码或验证信息不正确。",
                )
            if self._has_rate_limit(texts):
                raise LoginFlowError(
                    "rate_limit",
                    "TikTok Studio 提示访问太频繁，请等待一段时间后再试。",
                )
            if self._is_verification_step(texts) and self._verification_attempts == 0:
                self._complete_verification()
                continue
            if self._is_studio_logged_in(texts):
                emit_progress("success", "已登录 TikTok Studio")
                return

            if now - last_manage_tap > 4.0:
                if not self._tap_markers(STUDIO_MANAGE_TAB_MARKERS):
                    width, height = self._screen_size()
                    self._tap_xy(width * 0.9, height * 0.96)
                last_manage_tap = now
            time.sleep(PAGE_WAIT_INTERVAL_SECONDS)
        raise LoginFlowError(
            "login",
            "等待 TikTok Studio 登录成功超时，请查看手机当前页面。",
        )


def read_private_task() -> TikTokLoginAccount:
    if sys.stdin is None:
        raise TikTokTemplateError("无法读取内存中的登录账号。")
    raw = sys.stdin.buffer.read()
    if not raw:
        raise TikTokTemplateError("登录任务没有收到账号数据。")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise TikTokTemplateError("登录任务数据格式不正确。") from error
    if not isinstance(payload, dict) or not isinstance(payload.get("account"), dict):
        raise TikTokTemplateError("登录任务缺少账号数据。")
    return TikTokLoginAccount.from_private_payload(payload["account"])


def safe_error_detail(
    error: BaseException,
    app_name: str = "TikTok",
) -> tuple[str, str]:
    if isinstance(error, LoginFlowError):
        return error.stage, error.detail
    if isinstance(error, TikTokTemplateError):
        return "task", str(error)
    detail = " ".join(str(error or error.__class__.__name__).split())
    return "login", detail[:500] or f"{app_name} 登录失败"


def main() -> int:
    parser = argparse.ArgumentParser(
        description="使用内存账号任务登录 TikTok 或 TikTok Studio 邮箱/用户名页"
    )
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument(
        "--bundle-id",
        choices=(TIKTOK_STUDIO_BUNDLE_ID, TIKTOK_BUNDLE_ID),
        default=DEFAULT_BUNDLE_ID,
    )
    args = parser.parse_args()
    account: TikTokLoginAccount | None = None
    flow: TikTokEmailLoginFlow | None = None
    try:
        account = read_private_task()
        flow = TikTokEmailLoginFlow(
            args.port,
            account,
            bundle_id=args.bundle_id,
        )
        flow.run()
        emit_progress("success", f"{flow.app_name} 登录成功")
        emit_result(True, "success", f"已登录 {flow.app_name}。", account)
        return 0
    except BaseException as error:
        app_name = "TikTok Studio" if args.bundle_id == TIKTOK_STUDIO_BUNDLE_ID else "TikTok"
        stage, detail = safe_error_detail(error, app_name)
        emit_result(False, stage, detail, account)
        return 1
    finally:
        if flow is not None:
            flow.close()


if __name__ == "__main__":
    raise SystemExit(main())
