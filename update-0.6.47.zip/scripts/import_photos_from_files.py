from __future__ import annotations

import argparse
import json
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

from extract_wanyilianbo_videos import McpClient, atomic_write_json, clean, now_text


FILES_BUNDLE_ID = "com.apple.DocumentsApp"
PHOTOS_BUNDLE_ID = "com.apple.mobileslideshow"
IC20_FOLDER_NAME = "IC20视频"

SAVE_VIDEO_MARKERS = (
    "存储视频",
    "保存视频",
    "存储视频片段",
    "Save Video",
    "Save Video to Photos",
)
DONE_MARKERS = ("完成", "Done")
SHARE_MARKERS = ("共享", "Share")
BROWSE_MARKERS = ("浏览", "Browse")
ROOT_MARKERS = ("我的iPhone", "On My iPhone")
PHOTO_EMPTY_MARKERS = ("无照片或视频", "No Photos or Videos")
PERMISSION_ALLOW_MARKERS = ("允许", "Allow", "允许访问所有照片", "Allow Access to All Photos")
WIRELESS_DATA_PROMPT_MARKERS = (
    "使用无线数据",
    "Wireless Data",
    "Cellular Data",
)
WIRELESS_DATA_WIFI_MARKERS = (
    "仅限无线局域网",
    "WLAN Only",
    "Wi-Fi Only",
    "Wireless LAN Only",
)
_FILE_METADATA_SUFFIX_RE = re.compile(
    r"[,，]\s*(?:视频|video|音频|audio|图片|image|文件夹|folder|文稿|document|压缩包|archive).*$",
    re.IGNORECASE,
)


class PhotoImportError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class PhotoImportResult:
    filename: str
    success: bool
    detail: str


def normalize_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\u00a0", " ").split())


def ui_nodes(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, dict):
        return []
    nodes: list[dict[str, Any]] = []
    for key in ("elements", "texts"):
        raw = value.get(key)
        if isinstance(raw, list):
            nodes.extend(item for item in raw if isinstance(item, dict))
    return nodes


def node_text(node: dict[str, Any]) -> str:
    return normalize_text(node.get("text") or node.get("label") or node.get("value"))


def node_tap(node: dict[str, Any]) -> tuple[float, float] | None:
    tap = node.get("tap")
    if isinstance(tap, dict):
        try:
            return float(tap["x"]), float(tap["y"])
        except (KeyError, TypeError, ValueError):
            pass
    rect = node.get("rect") or node.get("visible_rect")
    if isinstance(rect, dict):
        try:
            return (
                float(rect["x"]) + float(rect.get("width") or 0) / 2,
                float(rect["y"]) + float(rect.get("height") or 0) / 2,
            )
        except (KeyError, TypeError, ValueError):
            pass
    return None


def node_rect(node: dict[str, Any]) -> tuple[float, float, float, float] | None:
    rect = node.get("rect") or node.get("visible_rect")
    if not isinstance(rect, dict):
        return None
    try:
        return (
            float(rect["x"]),
            float(rect["y"]),
            float(rect.get("width") or 0),
            float(rect.get("height") or 0),
        )
    except (KeyError, TypeError, ValueError):
        return None


def text_matches(text: str, marker: str, *, exact: bool = False) -> bool:
    normalized_text = normalize_text(text).casefold()
    normalized_marker = normalize_text(marker).casefold()
    if exact:
        return normalized_text == normalized_marker
    return normalized_marker in normalized_text


def find_text_node(
    nodes: Iterable[dict[str, Any]],
    markers: Sequence[str],
    *,
    exact: bool = False,
    min_y: float | None = None,
    max_y: float | None = None,
) -> dict[str, Any] | None:
    for node in nodes:
        text = node_text(node)
        if not text:
            continue
        if not any(text_matches(text, marker, exact=exact) for marker in markers):
            continue
        point = node_tap(node)
        if point is None:
            continue
        if min_y is not None and point[1] < min_y:
            continue
        if max_y is not None and point[1] > max_y:
            continue
        return node
    return None


def find_file_node(nodes: Iterable[dict[str, Any]], filename: str) -> dict[str, Any] | None:
    wanted = normalize_text(filename).casefold()
    wanted_stem = normalize_text(Path(filename).stem).casefold()
    for node in nodes:
        text = node_text(node).casefold()
        if not text:
            continue
        label = _FILE_METADATA_SUFFIX_RE.sub("", text).strip()
        if label == wanted or (wanted_stem and label == wanted_stem):
            return node
    return None


def looks_like_grid_tile(node: dict[str, Any], screen_height: float = 667.0) -> bool:
    rect = node_rect(node)
    if rect is None:
        return False
    _x, y, width, height = rect
    return (
        width >= 56.0
        and height >= 72.0
        and 90.0 <= y < screen_height * 0.86
    )


def find_ic20_folder_tile(
    nodes: Iterable[dict[str, Any]], screen_height: float = 667.0
) -> dict[str, Any] | None:
    for node in nodes:
        text = node_text(node)
        if IC20_FOLDER_NAME not in text or "操作菜单" in text or "Action Menu" in text:
            continue
        if not looks_like_grid_tile(node, screen_height):
            continue
        if node_tap(node) is not None:
            return node
    return None


def is_ic20_folder_open(nodes: Iterable[dict[str, Any]]) -> bool:
    for node in nodes:
        text = node_text(node).casefold()
        if not text.startswith(IC20_FOLDER_NAME.casefold()):
            continue
        if "操作菜单" in text or "action menu" in text:
            return True
    return False


class FilesPhotoImporter:
    def __init__(self, client: McpClient) -> None:
        self.client = client
        self._screen_width = 375.0
        self._screen_height = 667.0

    def _tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def _nodes(self, *, include_ocr: bool = False) -> list[dict[str, Any]]:
        ax_error: Exception | None = None
        try:
            nodes = ui_nodes(self._tool("get_ui_elements", {}))
        except Exception as error:
            ax_error = error
            nodes = []
        if nodes:
            return nodes
        try:
            ocr_nodes = ui_nodes(self._tool("ocr_screen", {}))
        except Exception:
            if ax_error is not None:
                raise PhotoImportError(
                    f"文件 App 界面读取失败：{clean(ax_error)}"
                ) from ax_error
            if include_ocr:
                raise
            return nodes
        if ocr_nodes or include_ocr or ax_error is not None:
            return ocr_nodes
        return nodes

    def _screen(self) -> tuple[float, float]:
        value = self._tool("get_screen_info", {})
        if isinstance(value, dict):
            try:
                self._screen_width = float(value.get("width") or self._screen_width)
                self._screen_height = float(value.get("height") or self._screen_height)
            except (TypeError, ValueError):
                pass
        return self._screen_width, self._screen_height

    def _swipe_file_list(self, *, to_top: bool = False) -> None:
        width, height = self._screen()
        if to_top:
            from_y, to_y = height * 0.34, height * 0.80
        else:
            from_y, to_y = height * 0.80, height * 0.34
        self._tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.50),
                "fromY": round(from_y),
                "toX": round(width * 0.50),
                "toY": round(to_y),
                "duration": 420,
            },
        )
        time.sleep(0.35)

    def _find_file_with_scroll(
        self,
        filenames: Sequence[str],
        *,
        timeout: float = 14.0,
    ) -> dict[str, Any] | None:
        deadline = time.monotonic() + timeout
        last_swipe_at = 0.0
        while time.monotonic() < deadline:
            nodes = self._nodes()
            for filename in filenames:
                node = find_file_node(nodes, filename)
                if node is not None:
                    return node
            now = time.monotonic()
            if now - last_swipe_at >= 0.75:
                self._swipe_file_list()
                last_swipe_at = now
            else:
                time.sleep(0.22)
        nodes = self._nodes(include_ocr=True)
        for filename in filenames:
            node = find_file_node(nodes, filename)
            if node is not None:
                return node
        return None

    def _reset_file_list_to_top(self) -> None:
        for _ in range(6):
            self._swipe_file_list(to_top=True)

    def _locate_file_node(self, filename: str) -> dict[str, Any] | None:
        node = self._find_file_with_scroll((filename,), timeout=14.0)
        if node is not None:
            return node
        self._reset_file_list_to_top()
        return self._find_file_with_scroll((filename,), timeout=14.0)

    def _tap_node(self, node: dict[str, Any]) -> None:
        point = node_tap(node)
        if point is None:
            raise PhotoImportError("界面元素没有可点击坐标。")
        self._tool("tap_screen", {"x": point[0], "y": point[1]})

    def _tap_cell_icon(self, node: dict[str, Any]) -> None:
        rect = node_rect(node)
        if rect is None:
            self._tap_node(node)
            return
        x, y, width, height = rect
        self._tool(
            "tap_screen",
            {
                "x": x + width / 2,
                "y": y + min(64.0, max(28.0, height * 0.24)),
            },
        )

    def _tap_marker(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        node = find_text_node(
            self._nodes(include_ocr=True),
            markers,
            exact=exact,
            min_y=min_y,
            max_y=max_y,
        )
        if node is None:
            return False
        self._tap_node(node)
        return True

    def _wait_for_markers(
        self,
        markers: Sequence[str],
        *,
        timeout: float,
        exact: bool = False,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            node = find_text_node(self._nodes(), markers, exact=exact)
            if node is not None:
                return node
            time.sleep(0.18)
        node = find_text_node(self._nodes(include_ocr=True), markers, exact=exact)
        if node is not None:
            return node
        raise PhotoImportError(f"等待界面元素超时：{' / '.join(markers)}")

    def _wait_until_gone(self, markers: Sequence[str], *, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if find_text_node(self._nodes(), markers) is None:
                return
            time.sleep(0.18)
        raise PhotoImportError(f"界面元素未消失：{' / '.join(markers)}")

    def _accept_permission_if_present(self) -> bool:
        node = find_text_node(
            self._nodes(),
            PERMISSION_ALLOW_MARKERS,
            exact=True,
            min_y=self._screen_height * 0.25,
            max_y=self._screen_height * 0.90,
        )
        if node is None:
            return False
        self._tap_node(node)
        time.sleep(0.5)
        return True

    def _accept_file_network_permission_if_present(self) -> bool:
        nodes = self._nodes(include_ocr=True)
        if find_text_node(nodes, WIRELESS_DATA_PROMPT_MARKERS) is None:
            return False
        node = find_text_node(nodes, WIRELESS_DATA_WIFI_MARKERS, exact=True)
        if node is None:
            node = find_text_node(nodes, WIRELESS_DATA_WIFI_MARKERS)
        if node is None:
            return False
        self._tap_node(node)
        time.sleep(0.8)
        return True

    def _frontmost_bundle(self) -> str:
        value = self._tool("get_frontmost_app", {})
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, dict):
            for key in ("bundleId", "bundle_id", "frontmostBundleId"):
                bundle = str(value.get(key) or "").strip()
                if bundle:
                    return bundle
        return ""

    def _navigate_to_folder(self, filenames: Sequence[str], timeout: float = 22.0) -> None:
        self._screen()
        last_launch_error: Exception | None = None
        for _attempt in range(3):
            try:
                self._tool("launch_app", {"bundle_id": FILES_BUNDLE_ID})
            except Exception as error:
                last_launch_error = error
            try:
                frontmost = self._frontmost_bundle()
            except Exception:
                frontmost = ""
            if frontmost == FILES_BUNDLE_ID:
                break
            if self._accept_file_network_permission_if_present():
                continue
            time.sleep(0.8)
        else:
            detail = clean(last_launch_error) if last_launch_error is not None else "未能进入前台"
            raise PhotoImportError(f"无法打开“文件”App：{detail}")
        deadline = time.monotonic() + timeout
        browsed_after_open = False
        done_node = find_text_node(self._nodes(), DONE_MARKERS, exact=True)
        if done_node is not None:
            self._tap_node(done_node)
            time.sleep(0.8)
        keyboard_done = find_text_node(
            self._nodes(),
            DONE_MARKERS,
            exact=True,
            min_y=self._screen_height * 0.78,
        )
        if keyboard_done is not None:
            self._tap_node(keyboard_done)
            time.sleep(0.6)
        while time.monotonic() < deadline:
            nodes = self._nodes()
            if any(find_file_node(nodes, filename) is not None for filename in filenames):
                return
            if is_ic20_folder_open(nodes):
                return

            folder_node = find_ic20_folder_tile(nodes, self._screen_height)
            if folder_node is not None:
                self._tap_cell_icon(folder_node)
                time.sleep(0.9)
                continue

            if not browsed_after_open:
                browse_node = find_text_node(nodes, BROWSE_MARKERS, exact=True)
                if browse_node is not None:
                    self._tap_node(browse_node)
                    browsed_after_open = True
                    time.sleep(0.7)
                    continue

            root_node = find_text_node(nodes, ROOT_MARKERS)
            if root_node is not None:
                self._tap_node(root_node)
                time.sleep(0.7)
                continue
            time.sleep(0.35)

        nodes = self._nodes(include_ocr=True)
        if any(find_file_node(nodes, filename) is not None for filename in filenames):
            return
        if is_ic20_folder_open(nodes):
            return
        if find_ic20_folder_tile(nodes, self._screen_height) is not None:
            raise PhotoImportError("已找到 IC20视频 文件夹，但没有找到本次要导入的视频。")
        raise PhotoImportError("没有在“文件”App 中打开 IC20视频 文件夹。")

    def _open_video(self, filename: str) -> None:
        node = self._locate_file_node(filename)
        if node is None:
            raise PhotoImportError(f"没有找到视频：{filename}")
        rect = node_rect(node)
        if rect is None:
            self._tap_node(node)
        else:
            # Tapping the thumbnail opens Quick Look; tapping the label can rename it.
            self._tap_cell_icon(node)
        try:
            self._wait_for_markers(DONE_MARKERS, timeout=8.0, exact=True)
        except PhotoImportError:
            node = find_file_node(self._nodes(), filename)
            if node is not None:
                point = node_tap(node)
                if point is not None:
                    self._tool("double_tap", {"x": point[0], "y": point[1]})
            self._wait_for_markers(DONE_MARKERS, timeout=8.0, exact=True)

    def _store_open_video(self) -> None:
        width, height = self._screen()
        share_node = find_text_node(self._nodes(), SHARE_MARKERS, exact=True)
        if share_node is not None:
            self._tap_node(share_node)
        else:
            self._tool("tap_screen", {"x": width * 0.064, "y": height - 26.0})
        try:
            save_node = self._wait_for_markers(SAVE_VIDEO_MARKERS, timeout=6.0)
        except PhotoImportError:
            self._tool("tap_screen", {"x": width * 0.064, "y": height - 26.0})
            save_node = self._wait_for_markers(SAVE_VIDEO_MARKERS, timeout=6.0)
        self._tap_node(save_node)
        time.sleep(0.6)
        self._accept_permission_if_present()
        self._wait_until_gone(SAVE_VIDEO_MARKERS, timeout=12.0)
        time.sleep(0.7)

    def _close_quick_look(self) -> None:
        done = find_text_node(self._nodes(), DONE_MARKERS, exact=True)
        if done is not None:
            self._tap_node(done)
            time.sleep(0.65)
            return
        width, _height = self._screen()
        self._tool("tap_screen", {"x": width * 0.91, "y": 42.0})
        time.sleep(0.5)

    def import_one(self, filename: str) -> PhotoImportResult:
        try:
            self._navigate_to_folder((filename,))
            self._open_video(filename)
            self._store_open_video()
            self._close_quick_look()
            return PhotoImportResult(filename, True, "已通过“存储视频”保存到照片")
        except Exception as error:
            return PhotoImportResult(filename, False, clean(error, 1200))

    def import_many(self, filenames: Sequence[str]) -> list[PhotoImportResult]:
        requested = tuple(dict.fromkeys(normalize_text(item) for item in filenames if normalize_text(item)))
        if not requested:
            return []
        self._navigate_to_folder(requested)
        results: list[PhotoImportResult] = []
        for filename in requested:
            try:
                self._open_video(filename)
                self._store_open_video()
                self._close_quick_look()
                results.append(PhotoImportResult(filename, True, "已通过“存储视频”保存到照片"))
            except Exception as error:
                results.append(PhotoImportResult(filename, False, clean(error, 1200)))
                try:
                    self._close_quick_look()
                except Exception:
                    pass
        return results

    def verify_photos(self) -> dict[str, Any]:
        self._tool("launch_app", {"bundle_id": PHOTOS_BUNDLE_ID})
        time.sleep(1.0)
        nodes = self._nodes(include_ocr=True)
        empty = find_text_node(nodes, PHOTO_EMPTY_MARKERS, exact=False) is not None
        video_tiles = sum(1 for node in nodes if node_text(node).casefold() == "视频")
        return {
            "opened": True,
            "empty": empty,
            "visible_video_tiles": video_tiles,
        }


def load_task(path: Path) -> list[str]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise PhotoImportError("相册导入任务文件格式不正确。")
    raw_files = value.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise PhotoImportError("相册导入任务没有文件名。")
    result = [normalize_text(item) for item in raw_files if normalize_text(item)]
    if not result:
        raise PhotoImportError("相册导入任务没有有效文件名。")
    return result


def run(args: argparse.Namespace) -> int:
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "photo_import_report.json"
    client = McpClient(f"http://127.0.0.1:{args.port}", timeout=60)
    results: list[PhotoImportResult] = []
    started_at = now_text()
    try:
        filenames = load_task(Path(args.task_file).expanduser().resolve(strict=True))
        client.connect()
        importer = FilesPhotoImporter(client)
        results = importer.import_many(filenames)
        try:
            verification = importer.verify_photos()
        except Exception as error:
            verification = {"opened": False, "error": clean(error)}
        success_count = sum(1 for item in results if item.success)
        report = {
            "success": success_count == len(results) and bool(results),
            "started_at": started_at,
            "completed_at": now_text(),
            "method": "file_quick_look_save_video",
            "folder": IC20_FOLDER_NAME,
            "file_count": len(results),
            "success_count": success_count,
            "failed_count": len(results) - success_count,
            "results": [
                {"filename": item.filename, "success": item.success, "detail": item.detail}
                for item in results
            ],
            "verification": verification,
        }
        atomic_write_json(report_path, report)
        print(
            f"PHOTO_IMPORT_RESULT|success={report['success']}|"
            f"saved={success_count}/{len(results)}|report={report_path}",
            flush=True,
        )
        return 0 if report["success"] else 2
    except Exception as error:
        report = {
            "success": False,
            "completed_at": now_text(),
            "method": "file_quick_look_save_video",
            "error": clean(error, 2000),
            "results": [
                {"filename": item.filename, "success": item.success, "detail": item.detail}
                for item in results
            ],
        }
        atomic_write_json(report_path, report)
        print(f"PHOTO_IMPORT_ERROR|{clean(error)}", flush=True)
        return 1
    finally:
        client.close()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="通过 iOS 文件 App 的“存储视频”入口把 IC20视频 导入照片"
    )
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--task-file", required=True)
    parser.add_argument("--output-dir", required=True)
    return run(parser.parse_args())


if __name__ == "__main__":
    sys.exit(main())
