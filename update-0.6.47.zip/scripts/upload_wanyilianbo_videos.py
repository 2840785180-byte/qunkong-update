from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import posixpath
import shlex
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from extract_wanyilianbo_videos import (
    VIDEO_EXTENSIONS,
    ExtractionError,
    McpClient,
    atomic_write_json,
    clean,
    get_app_roots,
    list_entries,
    now_text,
    run_shell,
    to_int,
)


DEFAULT_BUNDLE_ID = "com.apple.DocumentsApp"
FILE_PROVIDER_GROUP_ID = "group.com.apple.FileProvider.LocalStorage"
FILE_PROVIDER_STORAGE_NAME = "File Provider Storage"
FILE_PROVIDER_FOLDER_NAME = "IC20视频"


def emit(message: str) -> None:
    print(f"{datetime.now():%H:%M:%S} {clean(message, 1200)}", flush=True)


def resolve_upload_directory(
    client: McpClient,
    bundle_id: str,
) -> tuple[str, dict[str, Any], str]:
    info = client.tool_value("get_app_info", {"bundle_id": bundle_id})
    if not isinstance(info, dict) or not info:
        raise ExtractionError(f"无法读取应用信息：{bundle_id}")
    if bundle_id == DEFAULT_BUNDLE_ID:
        groups = info.get("group_containers")
        group_root = (
            str(groups.get(FILE_PROVIDER_GROUP_ID) or "").strip()
            if isinstance(groups, dict)
            else ""
        )
        if not group_root.startswith("/"):
            raise ExtractionError("没有读取到“文件”App 的本机共享目录")
        target = posixpath.join(
            posixpath.normpath(group_root),
            FILE_PROVIDER_STORAGE_NAME,
            FILE_PROVIDER_FOLDER_NAME,
        )
        target_label = f"文件 App · {FILE_PROVIDER_FOLDER_NAME}"
    else:
        data_root = str(info.get("data_container") or "").strip()
        if not data_root:
            roots = get_app_roots(client, bundle_id)
            data_root = roots[0] if roots else ""
        if not data_root.startswith("/"):
            raise ExtractionError("没有读取到应用的数据目录")
        target = posixpath.join(posixpath.normpath(data_root), "Documents")
        target_label = str(info.get("name") or bundle_id)
    shell = run_shell(client, f"mkdir -p -- {shlex.quote(target)}", timeout=10)
    if to_int(shell.get("exitCode"), -1) != 0:
        raise ExtractionError(f"无法创建手机目标目录：{clean(shell.get('output'))}")
    return target, info, target_label


def load_task(path: Path) -> tuple[str, list[Path]]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ExtractionError("上传任务文件格式不正确")
    bundle_id = str(value.get("bundle_id") or DEFAULT_BUNDLE_ID).strip()
    raw_files = value.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise ExtractionError("没有选择要上传的视频")
    files: list[Path] = []
    for raw in raw_files:
        local = Path(str(raw)).expanduser().resolve(strict=True)
        if not local.is_file():
            raise ExtractionError(f"不是有效的视频文件：{local}")
        files.append(local)
    return bundle_id, files


def validate_files(files: list[Path]) -> list[tuple[Path, str, int]]:
    result: list[tuple[Path, str, int]] = []
    names: set[str] = set()
    for local in files:
        name = local.name
        size = local.stat().st_size
        if local.suffix.casefold() not in VIDEO_EXTENSIONS:
            raise ExtractionError(f"不支持的视频格式：{name}")
        if size <= 0:
            raise ExtractionError(f"视频文件是空的：{name}")
        if len(name.encode("utf-8")) > 255:
            raise ExtractionError(f"文件名过长，手机无法保存：{name}")
        if name in names:
            raise ExtractionError(f"所选视频里有重名文件，无法同时保留原名：{name}")
        names.add(name)
        result.append((local, name, size))
    return result


def remote_destination(directory: str, filename: str) -> str:
    """Keep the exact computer filename; never sanitize or generate a new one."""
    if not filename or posixpath.basename(filename) != filename:
        raise ExtractionError(f"文件名无法原样保存到手机：{filename}")
    return posixpath.join(directory, filename)


def upload_stream(
    port: int,
    index: int,
    total: int,
    local: Path,
    size: int,
    name: str,
) -> tuple[dict[str, Any], str]:
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3600)
    digest = hashlib.sha256()
    sent = 0
    last_percent = -1
    try:
        connection.putrequest("POST", "/upload_file")
        connection.putheader("Content-Type", "application/octet-stream")
        connection.putheader("Content-Length", str(size))
        connection.endheaders()
        with local.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                connection.send(chunk)
                digest.update(chunk)
                sent += len(chunk)
                percent = min(100, int(sent * 100 / size))
                if percent >= last_percent + 5 or sent == size:
                    last_percent = percent
                    emit(f"UPLOAD_PROGRESS|{index}|{total}|{percent}|{name}")
        response = connection.getresponse()
        body = response.read()
        text = body.decode("utf-8", "replace")
        if response.status < 200 or response.status >= 300:
            raise ExtractionError(f"上传失败 HTTP {response.status}: {clean(text)}")
        try:
            value = json.loads(text)
        except json.JSONDecodeError as error:
            raise ExtractionError("手机上传接口没有返回有效结果") from error
        if not isinstance(value, dict) or not str(value.get("path") or "").startswith("/"):
            raise ExtractionError("手机上传接口没有返回临时文件路径")
        if sent != size or to_int(value.get("size"), -1) != size:
            raise ExtractionError(
                f"上传大小不一致：电脑 {size}，手机 {to_int(value.get('size'), -1)}"
            )
        return value, digest.hexdigest()
    finally:
        connection.close()


def move_to_documents(client: McpClient, temporary: str, destination: str) -> None:
    command = (
        f"if mv -f -- {shlex.quote(temporary)} {shlex.quote(destination)}; then "
        f"chown mobile:mobile {shlex.quote(destination)} 2>/dev/null || true; "
        f"chmod 0644 {shlex.quote(destination)} 2>/dev/null || true; "
        "echo IC20_MOVE_OK; else echo IC20_MOVE_FAILED; exit 9; fi"
    )
    result = run_shell(client, command, timeout=30)
    if to_int(result.get("exitCode"), -1) != 0 or "IC20_MOVE_OK" not in str(result.get("output")):
        raise ExtractionError(f"移动到手机目标目录失败：{clean(result.get('output'))}")


def remote_entry(client: McpClient, directory: str, name: str) -> dict[str, Any] | None:
    for entry in list_entries(client, directory):
        if str(entry.get("name") or "") == name:
            return entry
    return None


def relaunch_app(client: McpClient, bundle_id: str) -> str | None:
    try:
        client.tool_value("kill_app", {"bundle_id": bundle_id})
    except Exception:
        pass
    time.sleep(0.8)
    try:
        client.tool_value("launch_app", {"bundle_id": bundle_id})
        return None
    except Exception as error:
        return clean(error)


def run(args: argparse.Namespace) -> int:
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "report.json"
    task_path = Path(args.task_file).expanduser().resolve(strict=True)
    bundle_id, files = load_task(task_path)
    validated = validate_files(files)
    records: list[dict[str, Any]] = []
    failures = 0
    uploaded = 0
    already_present = 0
    remote_dir = ""
    client: McpClient | None = None
    started_at = now_text()
    try:
        emit(f"连接 iOS MCP：http://127.0.0.1:{args.port}")
        client = McpClient(f"http://127.0.0.1:{args.port}", timeout=60)
        client.connect()
        emit(f"iOS MCP {client.server_version or '未知版本'} 已连接")
        remote_dir, app_info, target_label = resolve_upload_directory(client, bundle_id)
        emit(f"{target_label} 目录：{remote_dir}")
        existing = {
            str(entry.get("name") or ""): entry
            for entry in list_entries(client, remote_dir)
        }

        total = len(validated)
        for index, (local, name, size) in enumerate(validated, 1):
            destination = remote_destination(remote_dir, name)
            record: dict[str, Any] = {
                "local_path": str(local),
                "remote_path": destination,
                "filename": name,
                "size": size,
            }
            previous = existing.get(name)
            if previous is not None:
                previous_size = to_int(previous.get("size"), -1)
                if previous_size == size:
                    record.update({"status": "already_present", "detail": "手机已有同名同大小文件"})
                    records.append(record)
                    already_present += 1
                    emit(f"{index}/{total} 已存在，跳过：{name}")
                    continue
                record.update(
                    {
                        "status": "failed",
                        "detail": f"手机已有同名文件但大小不同（{previous_size}），未覆盖",
                    }
                )
                records.append(record)
                failures += 1
                emit(f"{index}/{total} 未上传：{name} 已存在且大小不同")
                continue

            emit(f"{index}/{total} 开始上传：{name} ({size} 字节)")
            try:
                response, sha256 = upload_stream(args.port, index, total, local, size, name)
                temporary = str(response.get("path") or "")
                move_to_documents(client, temporary, destination)
                entry = remote_entry(client, remote_dir, name)
                if entry is None:
                    raise ExtractionError(f"移动后没有在{target_label}目录中找到文件")
                remote_size = to_int(entry.get("size"), -1)
                if remote_size != size:
                    try:
                        client.tool_value(
                            "run_command",
                            {"command": f"rm -f -- {shlex.quote(destination)}", "timeout": 10},
                        )
                    except Exception:
                        pass
                    raise ExtractionError(f"手机文件大小不一致：电脑 {size}，手机 {remote_size}")
                record.update(
                    {
                        "status": "uploaded",
                        "sha256": sha256,
                        "verified": True,
                        "name_preserved": True,
                        "detail": "原名上传并核对大小成功",
                    }
                )
                records.append(record)
                existing[name] = entry
                uploaded += 1
                emit(f"{index}/{total} 上传成功：{name}")
            except Exception as error:
                record.update({"status": "failed", "detail": clean(error)})
                records.append(record)
                failures += 1
                emit(f"{index}/{total} 上传失败：{name} · {clean(error)}")

        refresh_warning = None
        if uploaded or already_present:
            emit(f"正在重新打开{target_label}并刷新列表")
            refresh_warning = relaunch_app(client, bundle_id)
            if refresh_warning:
                emit(f"应用刷新失败，可手动打开万能联播：{refresh_warning}")

        photo_import = None
        photo_success = True
        if args.import_photos:
            if bundle_id != DEFAULT_BUNDLE_ID:
                raise ExtractionError("自动导入相册目前只支持“文件”App / IC20视频。")
            from import_photos_from_files import FilesPhotoImporter

            imported_names = [
                str(record.get("filename") or "")
                for record in records
                if record.get("status") in {"uploaded", "already_present"}
            ]
            emit(f"开始把 {len(imported_names)} 条视频自动存储到苹果相册")
            importer = FilesPhotoImporter(client)
            photo_results = importer.import_many(imported_names)
            photo_success = bool(photo_results) and all(item.success for item in photo_results)
            try:
                verification = importer.verify_photos()
            except Exception as error:
                verification = {"opened": False, "error": clean(error)}
            photo_import = {
                "success": photo_success,
                "success_count": sum(1 for item in photo_results if item.success),
                "failed_count": sum(1 for item in photo_results if not item.success),
                "results": [
                    {
                        "filename": item.filename,
                        "success": item.success,
                        "detail": item.detail,
                    }
                    for item in photo_results
                ],
                "verification": verification,
            }
            emit(
                f"相册导入完成：{photo_import['success_count']}/{len(photo_results)}"
            )

        report = {
            "success": failures == 0 and photo_success,
            "app_name": target_label,
            "bundle_id": bundle_id,
            "app_version": str(app_info.get("version") or ""),
            "started_at": started_at,
            "finished_at": now_text(),
            "remote_dir": remote_dir,
            "file_count": len(validated),
            "uploaded_count": uploaded,
            "already_present_count": already_present,
            "failed_count": failures,
            "refresh_warning": refresh_warning,
            "photo_import": photo_import,
            "records": records,
        }
        atomic_write_json(report_path, report)
        emit(
            f"完成：选择 {len(validated)}，上传 {uploaded}，已存在 {already_present}，失败 {failures}"
        )
        return 0 if report["success"] else 1
    except Exception as error:
        report = {
            "success": False,
            "app_name": "文件 App · IC20视频",
            "bundle_id": bundle_id,
            "started_at": started_at,
            "finished_at": now_text(),
            "remote_dir": remote_dir,
            "file_count": len(validated),
            "uploaded_count": uploaded,
            "already_present_count": already_present,
            "failed_count": max(1, failures),
            "error": clean(error),
            "records": records,
        }
        atomic_write_json(report_path, report)
        emit(f"上传任务失败：{clean(error)}")
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(description="通过 iOS MCP 将视频原名上传到手机文件 App")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--task-file", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bundle-id", default=DEFAULT_BUNDLE_ID)
    parser.add_argument("--import-photos", action="store_true")
    return run(parser.parse_args())


if __name__ == "__main__":
    sys.exit(main())
