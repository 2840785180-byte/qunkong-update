from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from iphone_control_center.services.tiktok_profile import (
    TIKTOK_BUNDLE_ID,
    TikTokProfileConfig,
    TikTokProfileError,
)
from tiktok_automation_common import (
    CANCEL_MARKERS,
    CHANGE_PHOTO_MARKERS,
    CHOOSE_FILE_MARKERS,
    CHOOSE_LIBRARY_MARKERS,
    DONE_MARKERS,
    NEXT_MARKERS,
    PROFILE_FILES_FOLDER,
    SAVE_MARKERS,
    AutomationError,
    UiAutomation,
    allow_photo_library_access_if_prompted,
    choose_picker_file,
    clean,
    emit_progress,
    emit_result,
    import_image_to_photos,
    marker_visible,
    node_point,
    node_rect,
)


NICKNAME_MARKERS = ("昵称", "Nickname", "Name", "名字")
BIO_MARKERS = ("简介", "Bio", "Biography")
WEBSITE_MARKERS = ("网站", "Website", "Link", "URL")
PHOTO_READY_MARKERS = ("最近项目", "Recents", "照片", "Photos", "Photo")
EDITOR_PAGE_MARKERS = (
    "编辑主页", "编辑资料", "编辑个人资料", "Edit profile", "Edit Profile",
)
AVATAR_STORY_MARKERS = (
    "发布此照片到限时动态",
    "Post this photo to your Story",
)
AVATAR_POST_BUTTON_MARKERS = (
    "保存并发布",
    "Save and post",
    "Share to Story",
)
FIELD_COOLDOWN_MARKERS = (
    "昵称只能每 7 天更改一次",
    "名称只能每 7 天更改一次",
    "You can change your nickname again",
    "You can only change your nickname once every 7 days",
)
KEYBOARD_MARKERS = (
    "空格", "删除", "听写", "下一个键盘", "数字",
    "Space", "Delete", "Dictation", "Next keyboard", "Numbers",
)


@dataclass(slots=True)
class FieldTarget:
    label: str
    label_node: dict[str, Any]
    tap_point: tuple[float, float]


class ProfileFlowError(AutomationError):
    pass


class TikTokProfileRunner:
    def __init__(self, port: int, config: TikTokProfileConfig) -> None:
        self.port = port
        self.config = config
        self.ui = UiAutomation(port, TIKTOK_BUNDLE_ID)
        self.fields_changed: list[str] = []
        self.warnings: list[str] = []

    def close(self) -> None:
        self.ui.close()

    def run(self) -> dict[str, Any]:
        self.ui.connect()
        if self.config.avatar_path.strip():
            emit_progress("avatar_import", "正在把头像导入手机相册")
            import_image_to_photos(
                self.ui,
                self.port,
                Path(self.config.avatar_path),
            )
        self.ui.restart_app_clean()
        self.ui.open_profile(relaunch=False)
        self.ui.open_edit_profile()
        targets = self._preflight_fields()
        if targets.get("nickname") is not None:
            self._assert_field_not_cooling_down(
                targets["nickname"],
                NICKNAME_MARKERS,
                "昵称",
            )
        if self.config.avatar_path.strip():
            self._change_avatar()
        if self.config.nickname.strip():
            self._replace_text_field(
                targets["nickname"],
                self.config.nickname.strip(),
                "昵称",
                NICKNAME_MARKERS,
            )
        if self.config.bio.strip():
            target = self._find_field(BIO_MARKERS, scroll=True)
            if target is None:
                raise ProfileFlowError("bio", "没有找到简介输入框。")
            self._replace_text_field(
                target,
                self.config.bio.strip(),
                "简介",
                BIO_MARKERS,
            )
        if self.config.website.strip():
            target = targets.get("website")
            if target is None:
                raise ProfileFlowError(
                    "website_unavailable",
                    "当前账号没有“网站 / URL”输入框。该字段通常只对已认证的"
                    "商业或企业账号开放，软件不会绕过 TikTok 权限。",
                )
            self._replace_text_field(
                target,
                self.config.website.strip(),
                "URL",
                WEBSITE_MARKERS,
            )
        self._save_profile()
        self._verify_saved_fields()
        return {
            "success": True,
            "stage": "success",
            "detail": "资料已提交保存"
            + (f"：{'、'.join(self.fields_changed)}" if self.fields_changed else ""),
            "fields_changed": self.fields_changed,
            "warnings": self.warnings,
        }

    def _preflight_fields(self) -> dict[str, FieldTarget | None]:
        targets: dict[str, FieldTarget | None] = {
            "nickname": None,
            "biography": None,
            "website": None,
        }
        if self.config.nickname.strip():
            targets["nickname"] = self._find_field(NICKNAME_MARKERS, scroll=False)
            if targets["nickname"] is None:
                raise ProfileFlowError("nickname", "没有找到昵称输入框。")
        if self.config.bio.strip():
            targets["biography"] = self._find_field(BIO_MARKERS, scroll=True)
            if targets["biography"] is None:
                raise ProfileFlowError("bio", "没有找到简介输入框。")
        if self.config.website.strip():
            targets["website"] = self._find_field(WEBSITE_MARKERS, scroll=True)
        return targets

    def _find_field(
        self,
        markers: Sequence[str],
        *,
        scroll: bool,
    ) -> FieldTarget | None:
        for _attempt in range(4 if scroll else 1):
            node = self.ui.find_node(markers, exact=False)
            if node is not None:
                point = node_point(node)
                if point is not None:
                    return FieldTarget(
                        label=markers[0],
                        label_node=node,
                        tap_point=point,
                    )
            if scroll:
                self.ui.swipe_up()
            else:
                break
        return None

    def _replace_text_field(
        self,
        target: FieldTarget,
        value: str,
        display_name: str,
        field_markers: Sequence[str],
    ) -> None:
        self.ui.assert_healthy()
        detail_editor = False
        entered = False
        for _attempt in range(3):
            self.ui.tap_xy(*target.tap_point)
            time.sleep(0.55)
            try:
                self.ui.wait_for(
                    SAVE_MARKERS + CANCEL_MARKERS,
                    timeout=4.0,
                    stage="field_editor",
                )
                detail_editor = True
            except AutomationError:
                detail_editor = False
            if detail_editor:
                self._raise_if_field_is_read_only(display_name)
            text_area = self._find_editor_text_area()
            self.ui.tap_xy(*text_area)
            time.sleep(0.35)
            self.ui.clear_focused_field(anchor=text_area)
            self.ui.input_text(value)
            time.sleep(0.65)
            if self._value_visible(value, field_markers):
                entered = True
                break
        if not entered:
            raise ProfileFlowError(
                "field",
                f"{display_name}连续 3 次填写后仍未在手机界面识别到目标文本。",
            )
        if detail_editor:
            self._save_field_editor()
        self.fields_changed.append(display_name)
        emit_progress("field", f"已填写{display_name}")

    def _find_editor_text_area(self) -> tuple[float, float]:
        width, height = self.ui.screen_size()
        candidates: list[tuple[float, tuple[float, float]]] = []
        for node in self.ui.nodes():
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, node_width, node_height = rect
            if (
                node_width >= width * 0.70
                and node_width <= width * 0.99
                and node_height >= 36
                and node_height <= height * 0.55
                and y >= height * 0.10
                and y <= height * 0.62
            ):
                candidates.append(
                    (
                        node_width * node_height,
                        (x + node_width / 2, y + node_height / 2),
                    )
                )
        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            return candidates[0][1]
        return width * 0.5, height * 0.386

    def _value_visible(
        self,
        value: str,
        field_markers: Sequence[str] = (),
    ) -> bool:
        wanted = clean(value).casefold().replace(" ", "")
        if not wanted:
            return False
        for text in self.ui.texts(include_ocr=True):
            candidate = clean(text).casefold().replace(" ", "")
            if candidate == wanted:
                return True
            for marker in field_markers:
                label = clean(marker).casefold().replace(" ", "")
                for separator in (",", "，"):
                    prefix = label + separator
                    if (
                        candidate.startswith(prefix)
                        and candidate[len(prefix):] == wanted
                    ):
                        return True
        return False

    def _raise_if_field_is_read_only(self, display_name: str) -> None:
        texts = self.ui.texts(include_ocr=True)
        if not marker_visible(texts, FIELD_COOLDOWN_MARKERS):
            return
        if marker_visible(texts, KEYBOARD_MARKERS):
            return
        cooldown_detail = next(
            (
                text
                for text in texts
                if marker_visible([text], FIELD_COOLDOWN_MARKERS)
            ),
            "当前处于修改冷却期",
        )
        self.ui.tap_marker(CANCEL_MARKERS, exact=True)
        time.sleep(0.5)
        raise ProfileFlowError(
            "field_unavailable",
            f"{display_name}当前不能修改：{clean(cooldown_detail, 240)}",
        )

    def _assert_field_not_cooling_down(
        self,
        target: FieldTarget,
        field_markers: Sequence[str],
        display_name: str,
    ) -> None:
        """Check nickname cooldown before changing other supplied fields."""
        self.ui.tap_xy(*target.tap_point)
        time.sleep(0.55)
        try:
            self.ui.wait_for(
                SAVE_MARKERS + CANCEL_MARKERS,
                timeout=4.0,
                stage="field_preflight",
            )
        except AutomationError:
            return
        texts = self.ui.texts(include_ocr=True)
        if marker_visible(texts, FIELD_COOLDOWN_MARKERS):
            text_area = self._find_editor_text_area()
            self.ui.tap_xy(*text_area)
            time.sleep(0.45)
            texts = self.ui.texts(include_ocr=True)
            if not marker_visible(texts, KEYBOARD_MARKERS):
                cooldown_detail = next(
                    (
                        text
                        for text in texts
                        if marker_visible([text], FIELD_COOLDOWN_MARKERS)
                    ),
                    "当前处于修改冷却期",
                )
                self.ui.tap_marker(CANCEL_MARKERS, exact=True)
                time.sleep(0.5)
                raise ProfileFlowError(
                    "field_unavailable",
                    f"{display_name}当前不能修改：{clean(cooldown_detail, 240)}",
                )
        self.ui.tap_marker(CANCEL_MARKERS, exact=True)
        time.sleep(0.5)

    def _save_field_editor(self) -> None:
        if not self.ui.tap_marker(SAVE_MARKERS, exact=True):
            width, _height = self.ui.screen_size()
            self.ui.tap_xy(width * 0.91, 42)
        time.sleep(1.2)

    def _change_avatar(self) -> None:
        self.ui.assert_healthy()
        tapped = self.ui.tap_marker(CHANGE_PHOTO_MARKERS, exact=False)
        if not tapped:
            width, height = self.ui.screen_size()
            self.ui.tap_xy(width * 0.5, height * 0.21)
        texts = self.ui.wait_for(
            CHOOSE_LIBRARY_MARKERS + CHOOSE_FILE_MARKERS + ("照片", "Photos"),
            timeout=10.0,
            stage="avatar",
            detail="没有打开头像选择菜单。",
        )
        joined = "\n".join(texts).casefold()
        filename = Path(self.config.avatar_path).name
        if any(marker.casefold() in joined for marker in CHOOSE_FILE_MARKERS):
            self.ui.tap_marker(CHOOSE_FILE_MARKERS, exact=False)
            time.sleep(0.8)
            try:
                choose_picker_file(
                    self.ui,
                    PROFILE_FILES_FOLDER,
                    filename,
                )
            except AutomationError as error:
                self.warnings.append(
                    f"文件选择失败，改从相册选择：{clean(error.detail)}"
                )
                self._choose_latest_photo_from_library()
        else:
            self.ui.tap_marker(CHOOSE_LIBRARY_MARKERS, exact=False)
            time.sleep(0.8)
            allow_photo_library_access_if_prompted(self.ui)
            self._choose_latest_photo_from_library()
        self._confirm_photo_choice()
        self.fields_changed.append("头像")
        emit_progress("avatar", "头像已更新")

    def _choose_latest_photo_from_library(self) -> None:
        self.ui.wait_for(
            PHOTO_READY_MARKERS,
            timeout=12.0,
            stage="avatar",
            detail="头像相册没有打开。",
        )
        self.ui.swipe_up()
        time.sleep(0.5)
        width, height = self.ui.screen_size()
        cells: list[tuple[float, dict[str, Any]]] = []
        for node in self.ui.nodes():
            rect = node_rect(node)
            if rect is None:
                continue
            _x, y, cell_width, cell_height = rect
            if (
                width * 0.12 <= cell_width <= width * 0.5
                and width * 0.12 <= cell_height <= width * 0.5
                and y > height * 0.12
            ):
                cells.append((y, node))
        if cells:
            cells.sort(key=lambda item: item[0], reverse=True)
            selected = cells[0][1]
            point = node_point(selected)
            if point is not None:
                self.ui.tap_xy(*point)
                time.sleep(0.7)
                return
        for x_ratio, y_ratio in ((0.18, 0.80), (0.5, 0.80), (0.82, 0.80)):
            self.ui.tap_normalized(x_ratio, y_ratio)
            time.sleep(0.55)
            if self.ui.find_node(DONE_MARKERS + NEXT_MARKERS + ("选择", "Select"), exact=False):
                return
        raise ProfileFlowError(
            "avatar",
            "没有选中相册里的新头像，请在手机相册顶部确认照片已保存。",
        )

    def _confirm_photo_choice(self) -> None:
        for _attempt in range(4):
            texts = self.ui.texts(include_ocr=True)
            if any(
                marker.casefold() in text.casefold()
                for text in texts
                for marker in EDITOR_PAGE_MARKERS
            ):
                return
            if marker_visible(texts, AVATAR_POST_BUTTON_MARKERS):
                if not self._disable_avatar_story_post():
                    raise ProfileFlowError(
                        "avatar",
                        "头像预览仍开启了“发布此照片到限时动态”；为避免误发动态，已停止。",
                    )
                texts = self.ui.texts(include_ocr=True)
            if self.ui.tap_marker(("保存", "Save"), exact=True, include_ocr=True):
                time.sleep(1.2)
                continue
            selectors = NEXT_MARKERS + DONE_MARKERS + (
                "选择", "Select", "应用", "Apply",
            )
            if self.ui.tap_marker(selectors, exact=False):
                time.sleep(1.0)
                continue
            self.ui.tap_normalized(0.91, 0.06)
            time.sleep(0.8)
        if not (
            self.ui.find_node(EDITOR_PAGE_MARKERS, exact=False)
            or self.ui.find_node(("昵称", "Name", "简介", "Bio"), exact=False)
        ):
            raise ProfileFlowError("avatar", "头像选择后没有返回编辑资料页面。")

    def _disable_avatar_story_post(self) -> bool:
        node = self.ui.find_node(
            AVATAR_STORY_MARKERS,
            exact=False,
            include_ocr=True,
        )
        if node is None:
            return False
        rect = node_rect(node)
        if rect is None:
            return False
        x, y, _width, height = rect
        # OCR exposes the label but not the checkbox. The checkbox sits about
        # 63 points to its left on the iPhone 8 crop sheet.
        self.ui.tap_xy(max(18.0, x - 63.0), y + height / 2)
        time.sleep(0.7)
        texts = self.ui.texts(include_ocr=True)
        return not marker_visible(texts, AVATAR_POST_BUTTON_MARKERS)

    def _save_profile(self) -> None:
        self.ui.assert_healthy()
        initial_texts = self.ui.texts(include_ocr=True)
        initial_joined = "\n".join(initial_texts).casefold()
        if not any(marker.casefold() in initial_joined for marker in EDITOR_PAGE_MARKERS):
            return
        save_tapped = self.ui.tap_marker(SAVE_MARKERS, exact=False)
        if not save_tapped:
            # Current TikTok builds auto-save profile-card changes and expose
            # only the navigation back button. Tapping the old top-right save
            # coordinate is a no-op and leaves the editor open.
            if not self.ui.tap_marker(("返回", "Back"), exact=True):
                self.ui.tap_xy(34, 42)
            time.sleep(0.45)
        deadline = time.monotonic() + 12.0
        while time.monotonic() < deadline:
            texts = self.ui.texts(include_ocr=True)
            joined = "\n".join(texts).casefold()
            if any(
                marker in joined
                for marker in ("资料已更新", "profile updated", "已保存", "saved")
            ):
                return
            if not any(marker.casefold() in joined for marker in EDITOR_PAGE_MARKERS):
                return
            time.sleep(0.4)
        raise ProfileFlowError("save", "保存或返回后编辑主页仍未关闭。")

    def _verify_saved_fields(self) -> None:
        expected: list[tuple[str, Sequence[str], str]] = []
        if self.config.nickname.strip():
            expected.append(("昵称", NICKNAME_MARKERS, self.config.nickname.strip()))
        if self.config.bio.strip():
            expected.append(("简介", BIO_MARKERS, self.config.bio.strip()))
        if self.config.website.strip():
            expected.append(("URL", WEBSITE_MARKERS, self.config.website.strip()))
        if not expected:
            return
        self.ui.open_profile()
        self.ui.open_edit_profile()
        for display_name, markers, value in expected:
            try:
                target = self._find_field(markers, scroll=True)
                if target is None:
                    raise ProfileFlowError(
                        "verify",
                        f"复核时没有找到{display_name}。",
                    )
                self.ui.tap_xy(*target.tap_point)
                time.sleep(0.55)
                if not self._value_visible(value, markers):
                    raise ProfileFlowError(
                        "verify",
                        f"{display_name}保存后未在手机界面显示目标文本。",
                    )
                if not self.ui.tap_marker(CANCEL_MARKERS, exact=True):
                    self.ui.tap_xy(34, 42)
                time.sleep(0.5)
                emit_progress("verify", f"已复核{display_name}")
            except AutomationError as error:
                raise ProfileFlowError(
                    "verify",
                    f"{display_name}保存后复核失败：{error.detail}",
                ) from error
        if self.ui.find_node(EDITOR_PAGE_MARKERS, exact=False):
            self.ui.tap_marker(CANCEL_MARKERS, exact=True)


def _failure(runner: TikTokProfileRunner | None, stage: str, detail: str) -> dict[str, Any]:
    return {
        "success": False,
        "stage": stage,
        "detail": clean(detail, 1000),
        "fields_changed": list(runner.fields_changed) if runner else [],
        "warnings": list(runner.warnings) if runner else [],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TikTok 批量修改资料")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--bundle-id", default=TIKTOK_BUNDLE_ID)
    args = parser.parse_args(argv)
    runner: TikTokProfileRunner | None = None
    try:
        request = json.loads(sys.stdin.read())
        payload = request.get("payload") if isinstance(request, dict) else None
        if not isinstance(payload, dict):
            raise TikTokProfileError("资料任务格式不正确。")
        config = TikTokProfileConfig(
            nickname=str(payload.get("nickname") or ""),
            bio=str(payload.get("bio") or ""),
            website=str(payload.get("website") or ""),
            avatar_path=str(payload.get("avatar_path") or ""),
        )
        config.validate()
        runner = TikTokProfileRunner(args.port, config)
        result = runner.run()
    except TikTokProfileError as error:
        result = _failure(runner, "config", str(error))
    except ProfileFlowError as error:
        result = _failure(runner, error.stage, error.detail)
    except Exception as error:
        result = _failure(
            runner,
            "unexpected",
            str(error) or error.__class__.__name__,
        )
    finally:
        if runner is not None:
            runner.close()
    emit_result(result)
    return 0 if result.get("success") else 2


if __name__ == "__main__":
    raise SystemExit(main())
