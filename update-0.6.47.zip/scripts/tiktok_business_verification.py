from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Sequence

from iphone_control_center.services.tiktok_business import (
    TikTokBusinessConfig,
    TikTokBusinessError,
)
from tiktok_automation_common import (
    BUSINESS_FILES_FOLDER,
    BUSINESS_MARKERS,
    NEXT_MARKERS,
    PASTE_MARKERS,
    SUBMIT_MARKERS,
    UPLOAD_MARKERS,
    AutomationError,
    UiAutomation,
    choose_picker_file,
    clean,
    emit_progress,
    emit_result,
    navigate_files_to_folder,
    node_point,
    node_rect,
    node_text,
    normalize,
    open_business_form,
    save_open_file_to_photos,
    tap_file_cell,
    upload_file_to_phone,
    wait_for_business_form,
)


TIKTOK_BUNDLE_ID = "com.zhiliaoapp.musically"
PHOTO_MEDIA_FOLDER = "/var/mobile/Media/DCIM/100APPLE"
PHOTO_FILE_SUFFIXES = (".jpg", ".jpeg", ".png", ".heic")
PHOTO_TILE_MARKERS = ("图像", "照片", "Image", "Photo")
PHOTO_CONFIRM_MARKERS = ("确认", "Confirm", "Add", "添加")
CERTIFICATION_UPLOAD_MARKERS = (
    "最多上传",
    "上传公司的认证文件",
    "Upload up to",
    "Maximum upload",
    "Company certification",
)
PHOTO_LIBRARY_MARKERS = (
    "相册",
    "照片",
    "Photos",
    "Photo library",
    "Photo Library",
)
CHINESE_IME_KEYBOARD_MARKERS = (
    "空格",
    "换行",
    "删除",
    "数字",
    "听写",
)
ASCII_IME_KEYBOARD_MARKERS = (
    "space",
    "return",
    "delete",
    "numbers",
    "Dictate",
)
FIELD_PLACEHOLDER_MARKERS = (
    "输入",
    "enter ",
    "placeholder",
    "文本",
    "text field",
)
FIELD_VALIDATION_MARKERS = (
    "必填",
    "required",
    "错误",
    "error",
)
ADDRESS_SECTION_MARKERS = (
    "地址",
    "公司地址",
    "Address",
    "Business address",
    "Company address",
)
COUNTRY_MARKERS = (
    "国家/地区",
    "国家",
    "Country/Region",
    "Country",
)
STATE_MARKERS = (
    "州/省",
    "州",
    "省",
    "酋长国",
    "State/Province",
    "State",
    "Province",
    "Emirate",
)
CITY_MARKERS = ("城市", "City")
INDUSTRY_MARKERS = (
    "行业",
    "Industry",
    "Industry with audience restrictions",
    "具有受众限制的行业",
)
STREET_ADDRESS_MARKERS = (
    "输入街道地址",
    "街道地址",
    "详细地址",
    "Street address",
    "Enter street address",
    "Address line 1",
)
WEBSITE_MARKERS = (
    "公司网站",
    "Company website",
    "Business website",
    "Website",
)
WEBSITE_INPUT_MARKERS = (
    "输入公司的网站 URL",
    "Enter company website",
    "Company website URL",
    "Website URL",
)
COMPANY_MARKERS = (
    "公司名称",
    "公司法定名称",
    "Company name",
    "Company legal name",
    "Legal company name",
    "Business name",
)
LICENSE_MARKERS = (
    "营业执照编号",
    "Business license number",
    "Business registration number",
    "License number",
    "License No.",
    "Registration number",
)
BASIC_INFO_MARKERS = (
    "基本信息",
    "Basic information",
    "Basic Information",
)
SELECTOR_MARKERS = ("选择", "Select", "Choose")
PICKER_MARKERS = ("搜索", "Search", "选择", "Select", "Choose")

OPTION_ALIAS_GROUPS = (
    (
        "United Arab Emirates",
        "阿拉伯联合酋长国",
        "阿联酋",
        "UAE",
        "U.A.E.",
    ),
    ("Ajman", "阿治曼", "阿吉曼"),
    (
        "Not applicable",
        "不适用",
        "Not Applicable",
        "None",
        "N/A",
    ),
)


def option_aliases(value: str) -> tuple[str, ...]:
    """Return localized labels used by both Chinese and English TikTok builds."""
    cleaned = value.strip()
    normalized = normalize(cleaned)
    for group in OPTION_ALIAS_GROUPS:
        if normalized in {normalize(item) for item in group}:
            return group
    return (cleaned,)


def photo_picker_selection_point(
    node: dict[str, object],
) -> tuple[float, float] | None:
    rect = node_rect(node)
    if rect is None:
        return None
    left, top, width, height = rect
    if width <= 0 or height <= 0:
        return None
    # The system photo picker's check circle sits about 10% inside the
    # thumbnail's top-right corner. Tapping the image preview does nothing.
    return left + width * 0.90, top + height * 0.10


def certification_upload_point(
    nodes: Sequence[dict[str, object]],
) -> tuple[float, float] | None:
    """Return the center of the large clickable certificate upload tile."""
    for node in nodes:
        if node.get("clickable") is False:
            continue
        text = node_text(node)
        if not any(
            normalize(marker) in normalize(text)
            for marker in CERTIFICATION_UPLOAD_MARKERS
        ):
            continue
        rect = node_rect(node)
        if rect is None:
            continue
        left, top, width, height = rect
        if width < 60 or height < 60:
            continue
        return left + width / 2, top + height / 2
    return None


def keyboard_is_chinese(texts: Sequence[str]) -> bool:
    normalized = {normalize(text) for text in texts if text}
    return any(
        normalize(marker) in normalized
        for marker in CHINESE_IME_KEYBOARD_MARKERS
    )


def keyboard_is_ascii(texts: Sequence[str]) -> bool:
    normalized = {normalize(text) for text in texts if text}
    return any(
        normalize(marker) in normalized
        for marker in ASCII_IME_KEYBOARD_MARKERS
    )


class BusinessFlowError(AutomationError):
    pass


class BusinessVerificationRunner:
    def __init__(self, port: int, config: TikTokBusinessConfig) -> None:
        self.port = port
        self.config = config
        self.ui = UiAutomation(port, TIKTOK_BUNDLE_ID, timeout=90.0)
        self.warnings: list[str] = []
        self.uploaded_files: list[str] = []
        self.photos_imported: list[str] = []
        self.photo_filenames: dict[str, str] = {}

    def close(self) -> None:
        self.ui.close()

    def run(self) -> dict[str, object]:
        self.ui.connect()
        self._prepare_certification_images()
        self.ui.restart_app_clean()
        open_business_form(self.ui, self.config.entry_url)
        wait_for_business_form(self.ui)
        self._fill_basic_info()
        self._open_company_certification_page()
        self._upload_company_certification()
        self._fill_company_details()
        submit_visible = self.ui.find_node(
            SUBMIT_MARKERS,
            exact=False,
            include_ocr=True,
        ) is not None
        if not submit_visible:
            self.warnings.append(
                "资料已填写，但当前屏幕没有识别到 Submit；请人工向下检查并复核。"
            )
        return {
            "success": True,
            "stage": "ready_to_submit",
            "detail": (
                "企业认证资料已填写完成，已停在 Submit 前；"
                "软件不会点击 Submit，请人工复核后手动提交。"
            ),
            "fields_changed": [
                "国家/地区",
                "州/省",
                "城市",
                "行业",
                "详细地址",
                "公司名称",
                "营业执照编号",
                *(["公司网站"] if self.config.website.strip() else []),
                *(["认证图片"] if self.uploaded_files else []),
                *(["手机照片"] if self.photos_imported else []),
            ],
            "warnings": self.warnings,
        }

    def _prepare_certification_images(self) -> None:
        for image_path in self.config.image_paths:
            local = Path(image_path)
            upload_file_to_phone(
                self.port,
                self.ui.client,
                local,
                BUSINESS_FILES_FOLDER,
            )
            self.uploaded_files.append(local.name)
            try:
                before_photos = set(self._photo_files())
                node = navigate_files_to_folder(
                    self.ui,
                    BUSINESS_FILES_FOLDER,
                    local.name,
                )
                tap_file_cell(self.ui, node)
                save_open_file_to_photos(self.ui, local.name)
                self.photos_imported.append(local.name)
                new_photos = self._wait_for_new_photo_files(before_photos)
                if new_photos:
                    self.photo_filenames[local.name] = new_photos[-1]
                emit_progress(
                    "prepare",
                    f"认证图片已导入手机照片：{local.name}",
                )
            except Exception as error:
                self.warnings.append(
                    f"图片 {local.name} 已上传到文件 App，但自动导入相册失败：{clean(error)}"
                )
        emit_progress(
            "prepare",
            (
                f"已准备 {len(self.uploaded_files)} 张认证图片，"
                f"照片 App 成功 {len(self.photos_imported)} 张，"
                f"已定位相册文件 {len(self.photo_filenames)} 张"
            ),
        )

    def _photo_files(self) -> tuple[str, ...]:
        try:
            value = self.ui.client.tool_value(
                "list_dir",
                {"path": PHOTO_MEDIA_FOLDER},
            )
        except Exception:
            return ()
        entries = value.get("entries") if isinstance(value, dict) else None
        names: list[str] = []
        for entry in entries if isinstance(entries, list) else []:
            if not isinstance(entry, dict) or entry.get("type") != "file":
                continue
            name = str(entry.get("name") or "").strip()
            if name and name.lower().endswith(PHOTO_FILE_SUFFIXES):
                names.append(name)

        def sort_key(name: str) -> tuple[tuple[int, object], str]:
            match = re.search(r"(\d+)(?=\.[^.]+$)", name)
            return (
                (0, int(match.group(1))) if match else (1, name.casefold()),
                name.casefold(),
            )

        return tuple(sorted(names, key=sort_key))

    def _wait_for_new_photo_files(
        self,
        before: set[str],
        *,
        timeout: float = 5.0,
    ) -> tuple[str, ...]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            current = self._photo_files()
            new_files = tuple(name for name in current if name not in before)
            if new_files:
                return new_files
            time.sleep(0.25)
        return ()

    def _photo_picker_tiles(self) -> list[dict[str, object]]:
        tiles: list[tuple[float, float, dict[str, object]]] = []
        tile_markers = {normalize(marker) for marker in PHOTO_TILE_MARKERS}
        for node in self.ui.nodes(include_ocr=False):
            point = node_point(node)
            rect = node_rect(node)
            text = normalize(node_text(node))
            if point is None or rect is None or node.get("clickable") is False:
                continue
            if text not in tile_markers:
                continue
            _left, _top, width, height = rect
            if width < 45 or height < 45:
                continue
            tiles.append((point[1], point[0], node))
        tiles.sort(key=lambda item: (item[0], item[1]))
        return [item[2] for item in tiles]

    def _photo_picker_visible(self) -> bool:
        texts = self._texts()
        has_title = any(
            normalize(marker) in normalize(text)
            for text in texts
            for marker in ("相册", "Photos")
        )
        has_confirm = any(
            normalize(marker) in normalize(text)
            for text in texts
            for marker in PHOTO_CONFIRM_MARKERS
        )
        return has_title and has_confirm and bool(self._photo_picker_tiles())

    def _wait_for_photo_picker(self, *, timeout: float = 5.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._photo_picker_visible():
                return True
            time.sleep(0.25)
        return False

    def _choose_photo_picker_file(self, filename: str) -> None:
        asset_name = self.photo_filenames.get(filename)
        if not asset_name:
            raise BusinessFlowError(
                "certificate",
                f"已导入 {filename}，但没有定位到新增的相册文件。",
            )
        files = self._photo_files()
        try:
            asset_index = files.index(asset_name)
        except ValueError as error:
            raise BusinessFlowError(
                "certificate",
                f"相册索引中找不到新增文件 {asset_name}。",
            ) from error
        tiles = self._photo_picker_tiles()
        if asset_index >= len(tiles):
            raise BusinessFlowError(
                "certificate",
                (
                    f"新增图片 {asset_name} 位于第 {asset_index + 1} 张，"
                    f"但当前选择器只显示 {len(tiles)} 张；请先清理旧照片后重试。"
                ),
            )
        selection_point = photo_picker_selection_point(tiles[asset_index])
        if selection_point is None:
            raise BusinessFlowError("certificate", "没有点中认证图片缩略图。")
        # PHPicker ignores taps on the preview itself. Its hit target is the
        # small selection circle in the top-right corner of each thumbnail.
        self.ui.tap_xy(*selection_point, settle_seconds=0.45)
        selected_count = self._photo_picker_selected_count()
        if selected_count is None or selected_count < 1:
            # A second tap cancels a selection, so only retry when the count is
            # still zero; never toggle a successfully selected photo off.
            self.ui.tap_xy(*selection_point, settle_seconds=0.45)
            selected_count = self._photo_picker_selected_count()
        if selected_count is None or selected_count < 1:
            raise BusinessFlowError(
                "certificate",
                "相册缩略图右上角选择圈没有响应，计数仍为 0/6。",
            )
        if not self.ui.tap_marker(
            PHOTO_CONFIRM_MARKERS,
            exact=False,
            include_ocr=True,
        ):
            raise BusinessFlowError("certificate", "没有找到相册选择器的“确认”按钮。")
        time.sleep(0.9)
        emit_progress("certificate", f"已从相册选择认证图片：{filename}")

    def _photo_picker_selected_count(self) -> int | None:
        for text in self._texts():
            match = re.search(r"\(\s*(\d+)\s*/\s*\d+\s*\)", text)
            if match:
                return int(match.group(1))
        return None

    def _texts(self) -> list[str]:
        return self.ui.texts(include_ocr=True)

    def capture_failure(self, stage: str) -> str:
        try:
            local_app_data = os.environ.get("LOCALAPPDATA")
            root = (
                Path(local_app_data)
                if local_app_data
                else Path.home() / "AppData" / "Local"
            ) / "iPhoneControlCenter20" / "diagnostics"
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            folder = root / f"business_{stamp}_{clean(stage, 40) or 'error'}"
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "screen.jpg").write_bytes(
                self.ui.client.screenshot_jpeg()
            )
            (folder / "page.json").write_text(
                json.dumps(self._texts(), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            return str(folder)
        except Exception:
            return ""

    def _value_visible(
        self,
        value: str,
        *,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        return self._value_node(value, min_y=min_y, max_y=max_y) is not None

    def _value_node(
        self,
        value: str,
        *,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, object] | None:
        aliases = option_aliases(value)
        normalized_aliases = {normalize(alias) for alias in aliases if alias}
        if not normalized_aliases:
            return None
        for node in self.ui.nodes(include_ocr=True):
            point = node_point(node)
            text = normalize(node_text(node))
            if point is None or not text:
                continue
            if min_y is not None and point[1] < min_y:
                continue
            if max_y is not None and point[1] > max_y:
                continue
            if any(alias in text for alias in normalized_aliases):
                return node
        return None

    def _find_marker_with_scroll(
        self,
        markers: Sequence[str],
        *,
        max_swipes: int = 4,
        safe_y_ratio: float = 0.78,
    ) -> dict[str, object] | None:
        node = self.ui.find_node(markers, exact=False, include_ocr=True)
        _width, height = self.ui.screen_size()
        for _attempt in range(max_swipes + 1):
            point = node_point(node) if node is not None else None
            if point is not None and point[1] <= height * safe_y_ratio:
                return node
            self.ui.swipe_up()
            node = self.ui.find_node(markers, exact=False, include_ocr=True)
        point = node_point(node) if node is not None else None
        if point is not None and point[1] <= height * 0.9:
            return node
        return None

    def _current_field_point(
        self,
        label_markers: Sequence[str],
        fallback: tuple[float, float],
    ) -> tuple[float, float]:
        """Re-locate the input after the keyboard moves the form."""
        label = self.ui.find_node(
            label_markers,
            exact=False,
            include_ocr=True,
        )
        if label is None:
            return fallback
        point = self.ui.field_near_label(label, y_offset=34.0)
        return point or fallback

    def _picker_option_node(
        self,
        value: str,
    ) -> dict[str, object] | None:
        width, height = self.ui.screen_size()
        aliases = option_aliases(value)
        normalized_aliases = {normalize(alias) for alias in aliases if alias}
        nodes = self.ui.nodes(include_ocr=True)
        lower_bound = height * 0.28
        for node in nodes:
            point = node_point(node)
            text = normalize(node_text(node))
            if point is None or not text:
                continue
            if any(
                normalize(marker) in text
                for marker in ("搜索", "Search")
            ):
                lower_bound = max(lower_bound, point[1] + 25.0)
        preferred: list[tuple[float, dict[str, object]]] = []
        fallback: list[tuple[float, dict[str, object]]] = []
        for node in nodes:
            point = node_point(node)
            text = normalize(node_text(node))
            if point is None or not text:
                continue
            x, y = point
            if not (lower_bound <= y <= height * 0.94):
                continue
            if x >= width * 0.46:
                continue
            if not any(alias in text for alias in normalized_aliases):
                continue
            if node.get("clickable") is True:
                preferred.append((y, node))
            else:
                fallback.append((y, node))
        candidates = preferred or fallback
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]

    def _choose_picker_option(
        self,
        point: tuple[float, float],
        value: str,
        display_name: str,
        *,
        optional: bool = False,
    ) -> bool:
        self.ui.tap_xy(*point)
        time.sleep(0.65)
        for _attempt in range(7):
            node = self._picker_option_node(value)
            if node is not None:
                self.ui.tap_node(node)
                time.sleep(0.65)
                visible = self._value_visible(value)
                emit_progress(
                    "form",
                    f"已选择{display_name}：{option_aliases(value)[0]}",
                )
                if not visible:
                    self.warnings.append(
                        f"{display_name}已点击，但页面暂未识别到目标值。"
                    )
                return True
            self.ui.swipe_up()
        if optional:
            self.warnings.append(f"没有在{display_name}选项中找到目标值，已跳过。")
            return False
        raise BusinessFlowError(
            "business_field",
            f"没有在{display_name}选项中找到“{value}”。"
            "已兼容中文与英文界面，请检查这项资料是否受当前国家限制。",
        )

    def _select_dropdown(
        self,
        label_markers: Sequence[str],
        value: str,
        display_name: str,
        *,
        optional: bool = False,
    ) -> None:
        if self._value_visible(value):
            emit_progress("form", f"{display_name}已是目标值，跳过")
            return
        label = self._find_marker_with_scroll(label_markers)
        if label is None:
            if optional:
                self.warnings.append(f"当前页面没有{display_name}，已跳过。")
                return
            raise BusinessFlowError(
                "business_field",
                f"企业认证页面没有找到{display_name}。",
            )
        point = self.ui.field_near_label(label, y_offset=34.0)
        if point is None:
            raise BusinessFlowError(
                "business_field",
                f"{display_name}没有可点击位置。",
            )
        self._choose_picker_option(
            point,
            value,
            display_name,
            optional=optional,
        )

    def _wait_for_value_visible(self, value: str, *, timeout: float = 2.5) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._value_visible(value):
                return True
            time.sleep(0.2)
        return self._value_visible(value)

    def _field_contains(self, point: tuple[float, float], value: str) -> bool:
        wanted = normalize(value)
        x, y = point
        for node in self.ui.nodes(include_ocr=True):
            rect = node_rect(node)
            text = normalize(node_text(node))
            if rect is None or not text or text != wanted:
                continue
            left, top, width, height = rect
            if left <= x <= left + width and top <= y <= top + height:
                return True
            # Opening the keyboard can move the whole form by one row before
            # the follow-up accessibility snapshot. Accept only an exact value
            # node in the same horizontal band and near the original field.
            center_y = top + height / 2
            if (
                abs(center_y - y) <= 120
                and left - 40 <= x <= left + width + 40
            ):
                return True
        return False

    def _wait_for_field_value(
        self,
        point: tuple[float, float],
        value: str,
        *,
        timeout: float = 2.5,
    ) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self._field_contains(point, value):
                return True
            time.sleep(0.2)
        return self._field_contains(point, value)

    def _clear_clipboard(self) -> None:
        try:
            self.ui.tool("set_clipboard", {"text": ""})
        except Exception:
            pass

    def _field_has_text(self, point: tuple[float, float]) -> bool:
        x, y = point
        nodes = self.ui.nodes(include_ocr=True)
        controls = [
            node for node in nodes if str(node.get("type") or "") == "control"
        ]
        for node in controls or nodes:
            rect = node_rect(node)
            text = normalize(node_text(node))
            if rect is None or not text:
                continue
            if not any(
                character.isalnum() or "\u4e00" <= character <= "\u9fff"
                for character in text
            ):
                continue
            left, top, width, height = rect
            center_y = top + height / 2
            if not (
                left <= x <= left + width and abs(center_y - y) <= 80
            ):
                continue
            if any(
                normalize(marker) in text
                for marker in FIELD_PLACEHOLDER_MARKERS
            ):
                continue
            if any(
                normalize(marker) in text
                for marker in FIELD_VALIDATION_MARKERS
            ):
                continue
            if text in {
                normalize("公司法定名称"),
                normalize("营业执照编号"),
                normalize("提交"),
                normalize("完成"),
            }:
                continue
            return True
        return False

    def _clear_field_for_input(self, point: tuple[float, float]) -> bool:
        if not self._field_has_text(point):
            return True
        for _attempt in range(2):
            self.ui.clear_focused_field(anchor=point)
            if self._wait_for_empty_field(point, timeout=1.5):
                return True
            for _index in range(100):
                self.ui.press_key("backspace")
                time.sleep(0.01)
            if self._wait_for_empty_field(point, timeout=1.2):
                return True
        return False

    def _wait_for_empty_field(
        self,
        point: tuple[float, float],
        *,
        timeout: float,
    ) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if not self._field_has_text(point):
                return True
            time.sleep(0.2)
        return not self._field_has_text(point)

    def _ensure_ascii_keyboard(self) -> None:
        """Avoid Chinese IME predictive prefixes while filling business fields."""
        for _attempt in range(3):
            texts = self._texts()
            if keyboard_is_ascii(texts) and not keyboard_is_chinese(texts):
                return
            if not keyboard_is_chinese(texts):
                return
            globe = self.ui.find_node(
                ("下一个键盘", "Next keyboard"),
                exact=True,
                include_ocr=True,
            )
            if globe is not None:
                self.ui.tap_node(globe)
            else:
                width, height = self.ui.screen_size()
                self.ui.tap_xy(width * 0.165, height * 0.93)
            time.sleep(0.65)
            self.ui.tap_marker(
                ("继续", "Continue"),
                exact=True,
                include_ocr=True,
            )
            time.sleep(0.35)
        if keyboard_is_chinese(self._texts()):
            self.warnings.append(
                "输入法仍为中文，已继续尝试填写；如出现联想前缀会自动重试。"
            )

    def _paste_value(self, point: tuple[float, float], value: str) -> bool:
        try:
            self.ui.tool("set_clipboard", {"text": value})
            time.sleep(0.2)
            for gesture in ("long_press", "double_tap"):
                arguments = {
                    "x": round(point[0]),
                    "y": round(point[1]),
                }
                if gesture == "long_press":
                    arguments["duration"] = 900
                try:
                    self.ui.tool(gesture, arguments)
                except Exception:
                    continue
                time.sleep(0.35)
                pasted_menu = False
                for _attempt in range(8):
                    if self.ui.tap_marker(
                        PASTE_MARKERS,
                        exact=False,
                        include_ocr=True,
                    ):
                        pasted_menu = True
                        break
                    time.sleep(0.15)
                if not pasted_menu:
                    continue
                if self._wait_for_field_value(point, value):
                    self._clear_clipboard()
                    return True
            self._clear_clipboard()
            return False
        except Exception:
            self._clear_clipboard()
            return False

    def _type_value(self, point: tuple[float, float], value: str) -> bool:
        self.ui.tap_xy(*point)
        time.sleep(0.25)
        try:
            if value.isascii():
                # input_text goes through the IME and can prepend autocorrect /
                # prediction phrases. Hardware key events insert ASCII exactly.
                self.ui.tool(
                    "type_text",
                    {"text": value, "delay_ms": 25},
                )
            else:
                self.ui.tool("input_text", {"text": value})
        except Exception:
            return False
        return self._wait_for_field_value(point, value)

    def _fill_text(
        self,
        label_markers: Sequence[str],
        value: str,
        display_name: str,
        *,
        optional: bool = False,
    ) -> None:
        value = value.strip()
        if not value:
            if optional:
                return
            raise BusinessFlowError("business_field", f"{display_name}不能为空。")
        label = self._find_marker_with_scroll(label_markers)
        if label is None:
            if optional:
                self.warnings.append(f"页面没有显示{display_name}，已跳过。")
                return
            raise BusinessFlowError(
                "business_field",
                f"企业认证页面没有找到{display_name}。",
            )
        rect = node_rect(label)
        width, height = self.ui.screen_size()
        is_input_node = bool(
            rect is not None
            and rect[2] >= width * 0.55
            and rect[3] >= max(28.0, height * 0.045)
            and label.get("clickable") is not False
        )
        point = (
            node_point(label)
            if is_input_node
            else self.ui.field_near_label(label, y_offset=34.0)
        )
        if point is None:
            raise BusinessFlowError(
                "business_field",
                f"{display_name}没有可点击位置。",
            )
        if self._field_contains(point, value):
            emit_progress("form", f"{display_name}已是目标值，跳过")
            return
        for attempt in range(1, 4):
            self.ui.tap_xy(*point)
            time.sleep(0.3)
            self._ensure_ascii_keyboard()
            point = self._current_field_point(label_markers, point)
            if not self._clear_field_for_input(point):
                emit_progress(
                    "form",
                    f"{display_name}旧内容未能清空，正在重试",
                )
                continue
            self.ui.tap_xy(*point)
            time.sleep(0.25)
            if self._paste_value(point, value):
                emit_progress("form", f"已通过粘贴填写{display_name}")
                return
            if not self._clear_field_for_input(point):
                emit_progress(
                    "form",
                    f"{display_name}粘贴失败后未能恢复空字段，正在重试",
                )
                continue
            self.ui.tap_xy(*point)
            time.sleep(0.2)
            if self._type_value(point, value):
                emit_progress("form", f"已通过键盘填写{display_name}")
                return
            emit_progress(
                "form",
                f"{display_name}第 {attempt} 次输入未确认，正在重试",
            )
        raise BusinessFlowError(
            "business_field",
            f"{display_name}输入后未在页面识别到目标文本。",
        )

    def _next_address_selector(
        self,
        anchor_y: float,
    ) -> dict[str, object] | None:
        _width, height = self.ui.screen_size()
        nodes = self.ui.nodes(include_ocr=True)
        website_y = height - 20.0
        for node in nodes:
            point = node_point(node)
            text = normalize(node_text(node))
            if point is None or point[1] <= anchor_y + 20:
                continue
            if any(normalize(marker) in text for marker in WEBSITE_MARKERS):
                website_y = min(website_y, point[1] - 10.0)
        candidates: list[tuple[float, dict[str, object]]] = []
        selector_markers = {normalize(marker) for marker in SELECTOR_MARKERS}
        for node in nodes:
            point = node_point(node)
            text = normalize(node_text(node))
            if point is None or text not in selector_markers:
                continue
            _x, y = point
            if y <= anchor_y + 20 or y >= website_y:
                continue
            if node.get("clickable") is False:
                continue
            candidates.append((y, node))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]

    def _fill_address(self) -> None:
        country = self.config.country.strip()
        if not self._value_visible(country):
            address_label = self._find_marker_with_scroll(ADDRESS_SECTION_MARKERS)
            if address_label is None:
                raise BusinessFlowError(
                    "business_field",
                    "企业认证 Basic info 页面没有找到“地址 / Address”。",
                )
            point = self.ui.field_near_label(address_label, y_offset=60.0)
            if point is None:
                raise BusinessFlowError(
                    "business_field",
                    "“地址 / Address”没有可点击位置。",
                )
            self._choose_picker_option(point, country, "国家/地区")

        for display_name, value in (
            ("州/省", self.config.state_province),
            ("城市", self.config.city),
        ):
            value = value.strip()
            if not value:
                continue
            anchor = self._value_node(country)
            anchor_point = node_point(anchor) if anchor is not None else None
            if anchor_point is None:
                self.warnings.append(f"没有定位到{display_name}的上级地址行，已跳过。")
                continue
            selector = self._next_address_selector(anchor_point[1])
            if selector is None:
                continue
            selector_point = node_point(selector)
            if selector_point is None:
                continue
            self._choose_picker_option(
                selector_point,
                value,
                display_name,
                optional=True,
            )

        if self._value_visible(self.config.address):
            emit_progress("form", "街道地址已是目标值，跳过")
        else:
            self._fill_text(
                STREET_ADDRESS_MARKERS,
                self.config.address,
                "街道地址",
            )

    def _fill_basic_info(self) -> None:
        texts = self._texts()
        if not any(
            normalize(marker) in normalize(text)
            for text in texts
            for marker in BASIC_INFO_MARKERS
        ):
            raise BusinessFlowError(
                "business_entry",
                "当前页面不是企业认证的“基本信息 / Basic information”页面。",
            )
        self._fill_address()
        self._select_dropdown(INDUSTRY_MARKERS, self.config.industry, "行业")
        if self.config.website.strip():
            self._fill_text(
                WEBSITE_INPUT_MARKERS,
                self.config.website,
                "公司网站",
                optional=True,
            )
        next_button = self._find_marker_with_scroll(
            NEXT_MARKERS,
            max_swipes=2,
            safe_y_ratio=0.96,
        )
        if next_button is None:
            raise BusinessFlowError("business_next", "没有找到“下一步 / Next”按钮。")
        self.ui.tap_marker(NEXT_MARKERS, exact=False, include_ocr=True)
        time.sleep(1.0)

    def _open_company_certification_page(self) -> None:
        texts = self._texts()
        if any(
            marker.casefold() in text.casefold()
            for text in texts
            for marker in ("Company certification", "公司认证", "上传公司")
        ):
            return
        try:
            wait_for_business_form(self.ui, timeout=10.0)
        except AutomationError:
            pass

    def _upload_company_certification(self) -> None:
        for index, filename in enumerate(self.uploaded_files, 1):
            self.ui.assert_healthy()
            upload_point = certification_upload_point(
                self.ui.nodes(include_ocr=True)
            )
            if upload_point is not None:
                # The plus icon itself has no stable accessibility node. The
                # whole 94pt upload tile is clickable, so tap its center.
                self.ui.tap_xy(*upload_point, settle_seconds=0.5)
            elif self.ui.tap_marker(
                UPLOAD_MARKERS,
                exact=False,
                include_ocr=True,
            ):
                pass
            else:
                width, height = self.ui.screen_size()
                self.ui.tap_xy(width * 0.168, height * 0.403)

            picker_visible = self._wait_for_photo_picker(timeout=5.0)
            if not picker_visible:
                # Some TikTok builds show a source sheet before opening Photos.
                if self.ui.tap_marker(
                    PHOTO_LIBRARY_MARKERS,
                    exact=False,
                    include_ocr=True,
                ):
                    picker_visible = self._wait_for_photo_picker(timeout=5.0)

            if picker_visible and filename in self.photo_filenames:
                self._choose_photo_picker_file(filename)
            else:
                if not self.ui.tap_marker(
                    ("文件", "Files", "Choose File", "选择文件", "从文件选择"),
                    exact=False,
                    include_ocr=True,
                ):
                    raise BusinessFlowError(
                        "certificate",
                        "点击认证图片上传区域后，没有打开相册或文件选择器。",
                    )
                choose_picker_file(self.ui, BUSINESS_FILES_FOLDER, filename)
            time.sleep(1.0)
            emit_progress(
                "certificate",
                f"已上传认证图片 {index}/{len(self.uploaded_files)}：{filename}",
            )

    def _fill_company_details(self) -> None:
        self._fill_text(
            COMPANY_MARKERS,
            self.config.company_name,
            "公司名称",
            optional=True,
        )
        self._fill_text(
            LICENSE_MARKERS,
            self.config.license_number,
            "营业执照编号",
            optional=True,
        )

def _failure(
    runner: BusinessVerificationRunner | None,
    stage: str,
    detail: str,
) -> dict[str, object]:
    return {
        "success": False,
        "stage": stage,
        "detail": clean(detail, 1000),
        "fields_changed": [],
        "warnings": list(runner.warnings) if runner else [],
    }


def _failure_with_diagnostic(
    runner: BusinessVerificationRunner | None,
    stage: str,
    detail: str,
) -> dict[str, object]:
    result = _failure(runner, stage, detail)
    if runner is not None:
        diagnostic = runner.capture_failure(stage)
        if diagnostic:
            result["diagnostic_path"] = diagnostic
            warnings = result.get("warnings")
            if isinstance(warnings, list):
                warnings.append(f"失败截图与页面文字已保存：{diagnostic}")
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TikTok 企业认证")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--bundle-id", default=TIKTOK_BUNDLE_ID)
    args = parser.parse_args(argv)
    runner: BusinessVerificationRunner | None = None
    try:
        request = json.loads(sys.stdin.read())
        payload = request.get("payload") if isinstance(request, dict) else None
        if not isinstance(payload, dict):
            raise TikTokBusinessError("企业认证任务格式不正确。")
        images = payload.get("image_paths")
        if not isinstance(images, list):
            raise TikTokBusinessError("企业认证图片格式不正确。")
        config = TikTokBusinessConfig(
            country=str(payload.get("country") or ""),
            state_province=str(payload.get("state_province") or ""),
            city=str(payload.get("city") or ""),
            industry=str(payload.get("industry") or ""),
            address=str(payload.get("address") or ""),
            website=str(payload.get("website") or ""),
            company_name=str(payload.get("company_name") or ""),
            license_number=str(payload.get("license_number") or ""),
            image_paths=tuple(str(item) for item in images if str(item).strip()),
            entry_url=str(payload.get("entry_url") or ""),
        )
        config.validate()
        runner = BusinessVerificationRunner(args.port, config)
        result = runner.run()
    except TikTokBusinessError as error:
        result = _failure_with_diagnostic(runner, "config", str(error))
    except BusinessFlowError as error:
        result = _failure_with_diagnostic(runner, error.stage, error.detail)
    except Exception as error:
        result = _failure_with_diagnostic(
            runner,
            "unexpected",
            str(error) or error.__class__.__name__,
        )
    finally:
        if runner is not None:
            runner.close()
    emit_result(result)
    return 0 if result.get("success") else 2


if __name__ == "__main__":
    raise SystemExit(main())
