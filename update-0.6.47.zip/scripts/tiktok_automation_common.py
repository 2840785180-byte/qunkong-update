from __future__ import annotations

import hashlib
import http.client
import json
import posixpath
import re
import shlex
import time
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from iphone_control_center.services.ios_mcp_control import (
    McpHttpClient,
    McpProtocolError,
)


FILES_BUNDLE_ID = "com.apple.DocumentsApp"
FILE_PROVIDER_GROUP_ID = "group.com.apple.FileProvider.LocalStorage"
FILE_PROVIDER_STORAGE_NAME = "File Provider Storage"
PROFILE_FILES_FOLDER = "IC20资料"
BUSINESS_FILES_FOLDER = "IC20认证"

PERMISSION_MARKERS = (
    "允许", "Allow", "仅在使用 App 时允许", "Allow While Using App",
    "允许访问所有照片", "Allow Access to All Photos",
)
PERMISSION_DENY_MARKERS = (
    "不允许",
    "Don't Allow",
    "Don’t Allow",
    "稍后",
    "Later",
)
PERMISSION_CONTEXT_MARKERS = (
    "通知",
    "相机",
    "麦克风",
    "照片",
    "通讯录",
    "联系人",
    "定位",
    "notification",
    "camera",
    "microphone",
    "photos",
    "contacts",
    "location",
)
PHOTO_PERMISSION_PROMPT_MARKERS = (
    "想访问你的照片",
    "want to access your photos",
    "选择照片…",
    "Select Photos…",
)
ALLOW_ALL_PHOTOS_MARKERS = (
    "允许访问所有照片",
    "Allow Access to All Photos",
)
CONTACTS_CONTEXT_MARKERS = ("通讯录", "联系人", "contacts")
CONSENT_MARKERS = (
    "同意并继续", "Agree and continue", "Accept and continue", "我知道了", "Got it",
)
RATE_LIMIT_MARKERS = (
    "访问太频繁", "操作太频繁", "尝试次数过多", "请稍后再试",
    "too many attempts", "too many requests", "try again later", "rate limit",
)
SECURITY_MARKERS = (
    "安全验证", "验证你是真人", "拖动滑块", "完成安全验证",
    "captcha", "verify you are human",
)
LOGIN_REQUIRED_MARKERS = (
    "登录 TikTok", "Log in to TikTok", "登录或注册", "Log in or sign up",
)
BACK_MARKERS = ("返回", "Back")
CANCEL_MARKERS = ("取消", "Cancel")
DONE_MARKERS = ("完成", "Done")
PROFILE_TAB_MARKERS = ("个人主页", "主页", "我", "Profile", "Me")
EDIT_PROFILE_MARKERS = (
    "编辑资料", "编辑个人资料", "编辑主页", "Edit profile", "Edit Profile",
)
PROFILE_EDIT_BUTTON_MARKERS = ("编辑", "Edit")
PROFILE_EDIT_PENCIL_MARKERS = ("tux_icon_pencil",)
PROFILE_EDITOR_PAGE_MARKERS = EDIT_PROFILE_MARKERS + (
    "编辑照片或头像",
    "创建你的头像",
    "添加背景",
    "Edit photo or avatar",
    "Create your avatar",
    "Add background",
)
SAVE_MARKERS = (
    "保存", "保存更改", "完成", "Save", "Save changes", "Done",
)
CHANGE_PHOTO_MARKERS = (
    "更换照片", "更换头像", "修改照片", "Change photo",
    "Change profile photo", "Edit photo",
)
CHOOSE_LIBRARY_MARKERS = (
    "从相册选择", "从照片选择", "选择照片", "Choose from library",
    "Choose from Library", "Photo library", "Photo Library",
    "上传照片", "查看照片", "Upload photo", "Choose from photos",
)
CHOOSE_FILE_MARKERS = (
    "从文件选择", "选择文件", "浏览文件", "Choose file", "Choose File", "Browse",
)
BROWSE_MARKERS = ("浏览", "Browse")
ON_MY_IPHONE_MARKERS = ("我的 iPhone", "我的iPhone", "On My iPhone")
SAVE_IMAGE_MARKERS = (
    "存储图像", "保存图像", "存储照片", "保存照片", "Save Image", "Save Photo",
)
FILE_RENAME_KEYBOARD_MARKERS = (
    "数字", "下一个键盘", "听写", "空格", "删除",
    "Numbers", "Next keyboard", "Dictation", "Space", "Delete",
)
SHARE_MARKERS = ("共享", "Share")
CLEAR_MARKERS = ("清除文本", "Clear text", "清除", "Clear")
SELECT_ALL_MARKERS = ("全选", "Select All")
PASTE_MARKERS = ("粘贴", "Paste")
BUSINESS_MARKERS = (
    "Business registration", "Basic Information", "Company certification",
    "商业登记", "基本信息", "企业认证", "企业注册", "商业认证",
)
BUSINESS_ENTRY_MARKERS = (
    "Become a Verified Business Account",
    "成为已认证的商业账号",
    "认证商业账号",
)
BUSINESS_VERIFY_MARKERS = (
    "进行企业验证",
    "Verify your business",
    "Verify business",
)
BUSINESS_START_MARKERS = ("开始使用", "Get started", "Start")
MORE_MARKERS = ("更多", "More", "菜单", "Menu", "More options")
SETTINGS_MARKERS = (
    "设置与隐私", "设置和隐私", "Settings and privacy", "Settings & privacy",
)
ACCOUNT_MARKERS = ("账号", "Account")
ACCOUNT_SETTINGS_DEEP_LINK = "snssdk1233://account/setting"
FEED_DEEP_LINK = "snssdk1233://feed"
ACCOUNT_SETTINGS_MARKERS = (
    "账号信息",
    "Account information",
    "密码",
    "Password",
    "Become a Verified Business Account",
    "成为已认证的商业账号",
)
BUSINESS_ACCOUNT_MARKERS = (
    "商业账号", "企业账号", "Business account", "Business Account",
)
BUSINESS_REGISTRATION_MARKERS = (
    "商业注册", "企业注册", "企业认证", "商业认证",
    "Business registration", "Business verification", "Verify business",
)
ACCOUNT_SWITCH_SHEET_MARKERS = ("添加账号", "Add account")
ACCOUNT_SWITCH_CLOSE_MARKERS = ("关闭", "Close")
NEXT_MARKERS = ("下一步", "继续", "Next", "Continue")
SUBMIT_MARKERS = ("提交", "Submit")
UPLOAD_MARKERS = ("上传", "添加", "Upload", "Add", "＋", "+")

OCR_ENGINES = ("vision", "paddleocr")
OCR_BUSY_MARKERS = ("busy", "active request", "queue limit", "retry later")

# Keep SpringBoard and the proxy running while closing user apps. Closing
# SpringBoard is unsafe, and Shadowrocket is often required for TikTok access.
BACKGROUND_KEEP_BUNDLES = frozenset(
    {
        "com.apple.springboard",
        "com.apple.PosterBoard",
        "com.apple.SharingViewService",
        "com.apple.backboardd",
        "com.apple.BoardServices",
        "com.liguangming.Shadowrocket",
    }
)
APPLE_ID_PROMPT_MARKERS = (
    "验证 Apple ID",
    "Apple ID 验证",
    "Verify Apple ID",
    "Apple ID Verification",
)
APPLE_ID_DECLINE_MARKERS = ("以后", "Not Now", "Not now", "稍后", "Later", "取消")


class AutomationError(RuntimeError):
    def __init__(self, stage: str, detail: str) -> None:
        super().__init__(detail)
        self.stage = stage
        self.detail = detail


def clean(value: Any, limit: int = 1200) -> str:
    return " ".join(str(value or "").split())[:limit]


def emit_progress(stage: str, message: str) -> None:
    print(f"TIKTOK_ACTION_PROGRESS|{stage}|{clean(message, 500)}", flush=True)


def emit_result(value: dict[str, Any]) -> None:
    print(
        "TIKTOK_ACTION_RESULT|"
        + json.dumps(value, ensure_ascii=False, separators=(",", ":")),
        flush=True,
    )


def normalize(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or "")).casefold()


def node_text(node: dict[str, Any]) -> str:
    for key in ("text", "label", "value", "name", "title", "placeholder"):
        value = node.get(key)
        if value is not None and str(value).strip():
            return clean(value, 2000)
    return ""


def node_point(node: dict[str, Any]) -> tuple[float, float] | None:
    tap = node.get("tap")
    if isinstance(tap, dict):
        try:
            return float(tap["x"]), float(tap["y"])
        except (KeyError, TypeError, ValueError):
            pass
    rect = node.get("rect") or node.get("visible_rect")
    if isinstance(rect, dict):
        try:
            return (
                float(rect["x"]) + float(rect.get("width") or 0) / 2,
                float(rect["y"]) + float(rect.get("height") or 0) / 2,
            )
        except (KeyError, TypeError, ValueError):
            pass
    return None


def node_rect(node: dict[str, Any]) -> tuple[float, float, float, float] | None:
    rect = node.get("rect") or node.get("visible_rect")
    if not isinstance(rect, dict):
        return None
    try:
        return (
            float(rect["x"]),
            float(rect["y"]),
            float(rect.get("width") or 0),
            float(rect.get("height") or 0),
        )
    except (KeyError, TypeError, ValueError):
        return None


def ui_nodes(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, dict):
        return []
    nodes: list[dict[str, Any]] = []
    for key in ("elements", "ui_elements", "items", "texts"):
        raw = value.get(key)
        if isinstance(raw, list):
            nodes.extend(item for item in raw if isinstance(item, dict))
    return nodes


def running_apps(value: Any) -> list[dict[str, str]]:
    """Normalize list_running_apps responses across MCP versions."""
    raw: Any = []
    if isinstance(value, dict):
        raw = value.get("apps")
        if not isinstance(raw, list):
            for key in ("running_apps", "items", "elements"):
                candidate = value.get(key)
                if isinstance(candidate, list):
                    raw = candidate
                    break
    elif isinstance(value, list):
        raw = value

    apps: list[dict[str, str]] = []
    for item in raw if isinstance(raw, list) else []:
        if isinstance(item, str):
            bundle_id = item.strip()
            name = bundle_id
        elif isinstance(item, dict):
            bundle_id = str(
                item.get("bundleId")
                or item.get("bundle_id")
                or item.get("identifier")
                or ""
            ).strip()
            name = str(item.get("name") or item.get("title") or bundle_id).strip()
        else:
            continue
        if bundle_id:
            apps.append({"bundle_id": bundle_id, "name": name or bundle_id})
    return apps


def clean_background_apps(
    tool: Callable[[str, dict[str, Any] | None], Any],
    *,
    keep_bundles: Iterable[str] = BACKGROUND_KEEP_BUNDLES,
) -> list[str]:
    """Close user apps while preserving SpringBoard and the network proxy."""
    try:
        value = tool("list_running_apps", {})
    except Exception:
        return []
    keep = {str(bundle).strip() for bundle in keep_bundles if str(bundle).strip()}
    killed: list[str] = []
    for app in running_apps(value):
        bundle_id = app["bundle_id"]
        if bundle_id in keep:
            continue
        try:
            tool("kill_app", {"bundle_id": bundle_id})
        except Exception:
            continue
        killed.append(bundle_id)
    if killed:
        emit_progress(
            "background_cleanup",
            f"已清理手机后台 {len(killed)} 个 App，并保留系统进程与代理",
        )
    return killed


def allow_photo_library_access_if_prompted(automation: UiAutomation) -> bool:
    """Accept the one-time TikTok photo-library prompt when it is visible."""
    texts = automation.texts(include_ocr=True)
    if not marker_visible(texts, PHOTO_PERMISSION_PROMPT_MARKERS):
        return False
    if not automation.tap_marker(ALLOW_ALL_PHOTOS_MARKERS, exact=True):
        return False
    time.sleep(0.9)
    emit_progress("photos", "已允许 TikTok 访问全部照片")
    return True


def marker_visible(texts: Iterable[str], markers: Iterable[str]) -> bool:
    return any(text_matches(text, marker) for text in texts for marker in markers)


def page_marker_visible(texts: Iterable[str], markers: Iterable[str]) -> bool:
    return any(
        text_matches(text, marker, exact=True)
        for text in texts
        for marker in markers
    )


def text_matches(text: str, marker: str, *, exact: bool = False) -> bool:
    left = normalize(text)
    right = normalize(marker)
    if not left or not right:
        return False
    return left == right if exact else right in left


def find_text_node(
    nodes: Iterable[dict[str, Any]],
    markers: Sequence[str],
    *,
    exact: bool = False,
    min_x: float | None = None,
    max_x: float | None = None,
    min_y: float | None = None,
    max_y: float | None = None,
) -> dict[str, Any] | None:
    for node in nodes:
        text = node_text(node)
        if not text or not any(
            text_matches(text, marker, exact=exact) for marker in markers
        ):
            continue
        point = node_point(node)
        if point is None:
            continue
        x, y = point
        if min_x is not None and x < min_x:
            continue
        if max_x is not None and x > max_x:
            continue
        if min_y is not None and y < min_y:
            continue
        if max_y is not None and y > max_y:
            continue
        return node
    return None


def _parse_ocr_result(value: Any) -> list[dict[str, Any]]:
    roots: list[Any] = []
    if isinstance(value, list):
        roots = value
    elif isinstance(value, dict):
        for key in ("results", "items", "texts", "elements", "lines", "blocks"):
            raw = value.get(key)
            if isinstance(raw, list):
                roots.extend(raw)
        if not roots:
            roots = [value]
    elif isinstance(value, str) and value.strip():
        roots = [value]

    nodes: list[dict[str, Any]] = []
    for node in roots:
        if isinstance(node, str):
            if node.strip():
                nodes.append({"text": node.strip()})
            continue
        if not isinstance(node, dict):
            continue
        for key in ("text", "label", "value", "content", "title", "name"):
            text = node.get(key)
            if text is not None and str(text).strip():
                nodes.append({**node, "text": str(text).strip()})
                break
    return nodes


def ocr_screen_nodes(
    tool_call: Callable[[str, dict[str, Any]], Any],
    *,
    min_confidence: float = 0.3,
    attempts_per_engine: int = 3,
    region: dict[str, float] | None = None,
) -> list[dict[str, Any]]:
    """Use Vision OCR first, retry transient busy errors, then fall back."""
    for engine in OCR_ENGINES:
        for attempt in range(max(1, attempts_per_engine)):
            try:
                arguments: dict[str, Any] = {
                    "engine": engine,
                    "min_confidence": min_confidence,
                    "fast": True,
                }
                if region is not None:
                    arguments["region"] = region
                value = tool_call("ocr_screen", arguments)
            except McpProtocolError as error:
                message = str(error).casefold()
                if any(marker in message for marker in OCR_BUSY_MARKERS):
                    time.sleep(0.35 * (attempt + 1))
                    continue
                break
            except Exception:
                break
            nodes = _parse_ocr_result(value)
            if nodes:
                return nodes
            break
    # Empty OCR is not a page failure; accessibility and screenshots can still
    # provide a reliable result.
    return []


class UiAutomation:
    def __init__(
        self,
        port: int,
        bundle_id: str,
        *,
        timeout: float = 60.0,
    ) -> None:
        self.client = McpHttpClient(
            f"http://127.0.0.1:{port}",
            timeout=timeout,
        )
        self.bundle_id = bundle_id
        self._screen_width = 375.0
        self._screen_height = 667.0

    def connect(self) -> None:
        self.client.connect()
        emit_progress("connect", "已连接手机控制服务")

    def close(self) -> None:
        self.client.close()

    def tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def tap_element(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
    ) -> bool:
        """Tap accessibility text without downloading the whole UI tree first."""
        attempts: list[tuple[str, str]] = []
        if exact:
            attempts.extend((marker, "exact") for marker in markers)
        attempts.extend((marker, "contains") for marker in markers)
        for marker, match in attempts:
            try:
                result = self.tool(
                    "tap_element",
                    {
                        "text": marker,
                        "match": match,
                        "role": "control",
                        "index": 0,
                    },
                )
            except Exception:
                continue
            if isinstance(result, dict) and bool(result.get("tapped")):
                return True
        return False

    def wait_for_element(
        self,
        marker: str,
        *,
        timeout: float = 2.0,
        exact: bool = False,
        interval_ms: int = 100,
    ) -> bool:
        """Use the on-device AX poller instead of repeatedly fetching full snapshots."""
        try:
            result = self.tool(
                "wait_for_element",
                {
                    "text": marker,
                    "match": "exact" if exact else "contains",
                    "timeout_ms": min(max(round(timeout * 1000), 100), 30000),
                    "interval_ms": min(max(int(interval_ms), 100), 2000),
                },
            )
        except Exception:
            return False
        return isinstance(result, dict) and bool(result.get("found"))

    def nodes(self, *, include_ocr: bool = False) -> list[dict[str, Any]]:
        try:
            nodes = ui_nodes(
                self.tool(
                    "get_ui_elements",
                    {"visible_only": True, "clickable_only": False},
                )
            )
        except McpProtocolError:
            nodes = []
        if include_ocr:
            nodes.extend(self.ocr_nodes())
        return nodes

    def ocr_nodes(
        self,
        *,
        region: dict[str, float] | None = None,
    ) -> list[dict[str, Any]]:
        return ocr_screen_nodes(
            self.tool,
            min_confidence=0.35,
            region=region,
        )

    def texts(
        self,
        *,
        include_ocr: bool = True,
        ocr_region: dict[str, float] | None = None,
    ) -> list[str]:
        nodes = self.nodes()
        if include_ocr:
            nodes.extend(self.ocr_nodes(region=ocr_region))
        return [node_text(node) for node in nodes if node_text(node)]

    def assert_healthy(self) -> None:
        texts = self.texts(include_ocr=True)
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in RATE_LIMIT_MARKERS
        ):
            raise AutomationError(
                "rate_limit",
                "TikTok 提示操作太频繁，已停止本机任务，避免账号风险。",
            )
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in SECURITY_MARKERS
        ):
            raise AutomationError(
                "security",
                "检测到 TikTok 安全验证，请在手机上手动完成后重新执行。",
            )
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in LOGIN_REQUIRED_MARKERS
        ):
            raise AutomationError(
                "login_required",
                "TikTok 还没有登录，请先完成账号登录。",
            )

    def screen_size(self) -> tuple[float, float]:
        try:
            value = self.tool("get_screen_info", {})
        except McpProtocolError:
            return self._screen_width, self._screen_height
        if isinstance(value, dict):
            try:
                self._screen_width = float(
                    value.get("width") or self._screen_width
                )
                self._screen_height = float(
                    value.get("height") or self._screen_height
                )
            except (TypeError, ValueError):
                pass
        return self._screen_width, self._screen_height

    def tap_xy(
        self,
        x: float,
        y: float,
        *,
        settle_seconds: float = 0.42,
        refresh_size: bool = True,
    ) -> None:
        width, height = (
            self.screen_size()
            if refresh_size
            else (self._screen_width, self._screen_height)
        )
        self.tool(
            "tap_screen",
            {
                "x": min(max(round(x), 0), int(width) - 1),
                "y": min(max(round(y), 0), int(height) - 1),
            },
        )
        time.sleep(max(0.0, settle_seconds))

    def double_tap_xy(self, x: float, y: float) -> None:
        """Send a native double tap for controls that ignore single taps."""
        width, height = self.screen_size()
        self.tool(
            "double_tap",
            {
                "x": min(max(round(x), 0), int(width) - 1),
                "y": min(max(round(y), 0), int(height) - 1),
            },
        )
        time.sleep(0.55)

    def tap_normalized(self, x_ratio: float, y_ratio: float) -> None:
        width, height = self.screen_size()
        self.tap_xy(width * x_ratio, height * y_ratio)

    def tap_node(
        self,
        node: dict[str, Any],
        *,
        settle_seconds: float = 0.42,
        refresh_size: bool = True,
    ) -> bool:
        point = node_point(node)
        if point is None:
            return False
        self.tap_xy(
            *point,
            settle_seconds=settle_seconds,
            refresh_size=refresh_size,
        )
        return True

    def find_node(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        include_ocr: bool = False,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, Any] | None:
        return find_text_node(
            self.nodes(include_ocr=include_ocr),
            markers,
            exact=exact,
            min_x=min_x,
            max_x=max_x,
            min_y=min_y,
            max_y=max_y,
        )

    def tap_marker(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        include_ocr: bool = True,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        node = self.find_node(
            markers,
            exact=exact,
            include_ocr=include_ocr,
            min_x=min_x,
            max_x=max_x,
            min_y=min_y,
            max_y=max_y,
        )
        if node is None:
            return False
        return self.tap_node(node)

    def wait_for(
        self,
        markers: Sequence[str],
        *,
        timeout: float = 12.0,
        exact: bool = False,
        stage: str = "wait",
        detail: str = "",
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            texts = self.texts(include_ocr=True)
            if any(
                text_matches(text, marker, exact=exact)
                for text in texts
                for marker in markers
            ):
                return texts
            time.sleep(0.35)
        raise AutomationError(
            stage,
            detail or f"等待界面元素超时：{' / '.join(markers)}",
        )

    def wait_until_gone(
        self,
        markers: Sequence[str],
        *,
        timeout: float = 12.0,
        stage: str = "wait",
        detail: str = "",
    ) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            texts = self.texts(include_ocr=True)
            if not any(
                text_matches(text, marker)
                for text in texts
                for marker in markers
            ):
                return
            time.sleep(0.35)
        raise AutomationError(stage, detail or "界面没有按预期切换。")

    def launch_app(self, bundle_id: str | None = None) -> None:
        self.tool("launch_app", {"bundle_id": bundle_id or self.bundle_id})
        time.sleep(1.0)

    def running_apps(self) -> list[dict[str, str]]:
        try:
            return running_apps(self.tool("list_running_apps", {}))
        except McpProtocolError:
            return []

    def clear_background_apps(
        self,
        *,
        keep_bundles: Iterable[str] = BACKGROUND_KEEP_BUNDLES,
    ) -> list[str]:
        return clean_background_apps(self.tool, keep_bundles=keep_bundles)

    def wait_for_frontmost(
        self,
        bundle_id: str | None = None,
        *,
        timeout: float = 12.0,
    ) -> None:
        wanted = bundle_id or self.bundle_id
        deadline = time.monotonic() + timeout
        latest = ""
        while time.monotonic() < deadline:
            latest = self.frontmost_bundle()
            if latest == wanted:
                return
            time.sleep(0.25)
        raise AutomationError(
            "launch",
            f"App 没有进入前台，目标是 {wanted}，当前是 {latest or '未知 App'}。",
        )

    def restart_app_clean(
        self,
        bundle_id: str | None = None,
        *,
        keep_bundles: Iterable[str] = BACKGROUND_KEEP_BUNDLES,
        timeout: float = 15.0,
    ) -> list[str]:
        target = bundle_id or self.bundle_id
        killed = self.clear_background_apps(keep_bundles=keep_bundles)
        last_error: Exception | None = None
        for attempt in range(1, 3):
            try:
                self.launch_app(target)
            except Exception as error:
                # iOS can return a foreground error while a system permission
                # sheet covers the app. Dismiss the sheet before retrying.
                last_error = error
            time.sleep(0.5)
            self.dismiss_overlays()
            try:
                self.wait_for_frontmost(target, timeout=timeout)
                self.dismiss_overlays()
                return killed
            except AutomationError as error:
                last_error = error
                if attempt == 1:
                    emit_progress(
                        "launch",
                        "系统弹窗阻止 App 进入前台，正在关闭弹窗并重试",
                    )
        if last_error is not None:
            raise last_error
        return killed

    def open_url(self, url: str) -> None:
        if not url:
            return
        self.tool("open_url", {"url": url})
        time.sleep(1.4)

    def frontmost_bundle(self) -> str:
        try:
            value = self.tool("get_frontmost_app", {})
        except McpProtocolError:
            return ""
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, dict):
            for key in ("bundleId", "bundle_id", "frontmostBundleId"):
                if value.get(key):
                    return str(value[key]).strip()
            app = value.get("app")
            if isinstance(app, dict):
                return str(app.get("bundleId") or app.get("bundle_id") or "")
        return ""

    def dismiss_overlays(self) -> None:
        for _attempt in range(6):
            tapped = False
            for markers in (PERMISSION_MARKERS, CONSENT_MARKERS):
                node = self.find_node(markers, exact=True)
                if node is not None:
                    current_texts = self.texts(include_ocr=False)
                    if markers is PERMISSION_MARKERS and marker_visible(
                        current_texts,
                        CONTACTS_CONTEXT_MARKERS,
                    ):
                        deny = self.find_node(PERMISSION_DENY_MARKERS, exact=True)
                        if deny is not None:
                            self.tap_node(deny)
                            emit_progress(
                                "permission",
                                "检测到通讯录权限提示，已选择“不允许”以保护联系人",
                            )
                            tapped = True
                            time.sleep(0.6)
                            break
                    self.tap_node(node)
                    emit_progress("permission", "已自动选择系统权限")
                    tapped = True
                    time.sleep(0.45)
                    break
            if tapped:
                continue
            texts = self.texts(include_ocr=True)
            if marker_visible(texts, PERMISSION_CONTEXT_MARKERS):
                deny = self.find_node(PERMISSION_DENY_MARKERS, exact=True)
                if deny is not None:
                    self.tap_node(deny)
                    emit_progress(
                        "permission",
                        "检测到系统权限弹窗，已选择不允许以继续任务",
                    )
                    time.sleep(0.6)
                    continue
            if marker_visible(texts, APPLE_ID_PROMPT_MARKERS) and marker_visible(
                texts,
                APPLE_ID_DECLINE_MARKERS,
            ):
                if self.tap_marker(
                    APPLE_ID_DECLINE_MARKERS,
                    exact=True,
                    include_ocr=True,
                ):
                    emit_progress(
                        "system_alert",
                        "检测到 Apple ID 验证提示，已选择“以后”，没有输入任何账号",
                    )
                    time.sleep(0.6)
                    continue
            if not tapped:
                return

    def swipe_up(self) -> None:
        width, height = self.screen_size()
        self.tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.78),
                "toX": round(width * 0.5),
                "toY": round(height * 0.25),
                "duration": 480,
                "steps": 20,
            },
        )
        time.sleep(0.7)

    def swipe_down(self) -> None:
        width, height = self.screen_size()
        self.tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.25),
                "toX": round(width * 0.5),
                "toY": round(height * 0.78),
                "duration": 480,
                "steps": 20,
            },
        )
        time.sleep(0.7)

    def press_key(self, key: str) -> None:
        for tool_name in ("press_key", "key_press"):
            try:
                self.tool(tool_name, {"key": key})
                return
            except Exception:
                continue

    def input_text(self, value: str, *, settle_seconds: float = 0.6) -> None:
        try:
            self.tool("input_text", {"text": value})
        except Exception:
            self.tool("type_text", {"text": value, "delay_ms": 35})
        time.sleep(max(0.0, settle_seconds))

    def clear_focused_field(
        self,
        anchor: tuple[float, float] | None = None,
    ) -> None:
        if self.tap_marker(CLEAR_MARKERS, exact=True):
            time.sleep(0.25)
            return
        width, height = self.screen_size()
        x, y = anchor or (width * 0.45, height * 0.5)
        for _attempt in range(2):
            try:
                self.tool(
                    "long_press",
                    {
                        "x": round(x),
                        "y": round(y),
                        "duration": 900,
                    },
                )
                time.sleep(0.35)
            except Exception:
                pass
            if self.tap_marker(SELECT_ALL_MARKERS, exact=True):
                self.press_key("backspace")
                time.sleep(0.2)
                return
        for _index in range(140):
            self.press_key("backspace")
            time.sleep(0.012)
        time.sleep(0.25)

    def replace_field(self, node: dict[str, Any], value: str) -> None:
        if not self.tap_node(node):
            raise AutomationError("field", "输入框没有可点击坐标。")
        time.sleep(0.35)
        self.clear_focused_field()
        self.input_text(value)
        time.sleep(0.55)

    def field_near_label(
        self,
        label_node: dict[str, Any],
        *,
        y_offset: float = 34.0,
    ) -> tuple[float, float] | None:
        label_point = node_point(label_node)
        if label_point is None:
            return None
        _label_x, label_y = label_point
        width, height = self.screen_size()
        wanted_y = min(max(label_y + y_offset, 0), height - 1)
        candidates: list[tuple[float, dict[str, Any]]] = []
        for node in self.nodes():
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, node_width, node_height = rect
            if node_width < width * 0.55 or node_height < 18:
                continue
            if not (label_y - 15 <= y <= label_y + 100):
                continue
            distance = abs((y + node_height / 2) - wanted_y)
            candidates.append((distance, node))
        if candidates:
            candidates.sort(key=lambda item: item[0])
            return node_point(candidates[0][1])
        return width * 0.5, wanted_y

    def tap_label_field(
        self,
        markers: Sequence[str],
        *,
        y_offset: float = 34.0,
    ) -> dict[str, Any]:
        node = self.find_node(markers, exact=False)
        if node is None:
            raise AutomationError(
                "field",
                f"没有找到输入项：{' / '.join(markers)}",
            )
        point = self.field_near_label(node, y_offset=y_offset)
        if point is None:
            raise AutomationError(
                "field",
                f"输入项没有可点击位置：{' / '.join(markers)}",
            )
        self.tap_xy(*point)
        return node

    def open_profile(self, *, relaunch: bool = True) -> None:
        if relaunch:
            self.restart_app_clean()
        else:
            self.wait_for_frontmost()
        self.dismiss_overlays()
        self.assert_healthy()
        # A retry can start from Settings or an account subpage, where the
        # bottom tab bar is not available. Use TikTok's own feed route first
        # instead of firing a blind tap at the bottom of the screen.
        current_texts = self.texts(include_ocr=True)
        if marker_visible(
            current_texts,
            SETTINGS_MARKERS
            + ACCOUNT_SETTINGS_MARKERS
            + BUSINESS_MARKERS
            + ("内容偏好", "安全与权限"),
        ):
            try:
                self.open_url(FEED_DEEP_LINK)
                time.sleep(1.2)
            except Exception:
                pass
        for _attempt in range(3):
            texts = self.texts(include_ocr=True)
            joined = "\n".join(texts)
            if any(
                text_matches(joined, marker)
                for marker in ACCOUNT_SWITCH_SHEET_MARKERS
            ):
                self.tap_marker(ACCOUNT_SWITCH_CLOSE_MARKERS, exact=True)
                time.sleep(0.4)
                continue
            is_editor = any(
                text_matches(joined, marker)
                for marker in ("编辑主页", "编辑个人资料", "Edit profile")
            )
            if is_editor:
                if not self.tap_marker(CANCEL_MARKERS, exact=True):
                    self.tap_xy(34, 42)
                time.sleep(0.5)
                continue
            break
        _width, height = self.screen_size()
        tapped = self.tap_marker(
            PROFILE_TAB_MARKERS,
            exact=True,
            min_y=height * 0.76,
        )
        if not tapped:
            tapped = self.tap_marker(
                PROFILE_TAB_MARKERS,
                exact=False,
                min_y=height * 0.76,
            )
        if not tapped:
            self.tap_normalized(0.86, 0.94)
        self.wait_for(
            EDIT_PROFILE_MARKERS
            + ("粉丝", "关注", "Following", "Followers"),
            timeout=14.0,
            stage="profile",
            detail="没有打开 TikTok 个人主页，请确认主 App 已登录。",
        )

    def open_edit_profile(self) -> None:
        width, height = self.screen_size()
        last_texts: list[str] = []
        for attempt in range(1, 4):
            current = self.texts(include_ocr=True)
            if page_marker_visible(current, PROFILE_EDITOR_PAGE_MARKERS):
                return
            if self.tap_marker(
                PROFILE_EDIT_PENCIL_MARKERS,
                exact=False,
                include_ocr=False,
                min_y=0,
                max_y=100,
            ):
                time.sleep(0.7)
                last_texts = self.texts(include_ocr=True)
                if page_marker_visible(last_texts, PROFILE_EDITOR_PAGE_MARKERS):
                    return
            # TikTok 46+ exposes profile editing through the pencil in the
            # top-left corner, and that control only responds to a double tap.
            try:
                self.double_tap_xy(width * 0.075, height * 0.063)
            except Exception:
                pass
            last_texts = self.texts(include_ocr=True)
            if page_marker_visible(last_texts, PROFILE_EDITOR_PAGE_MARKERS):
                return
            tapped = self.tap_marker(
                PROFILE_EDIT_BUTTON_MARKERS,
                exact=True,
                min_x=width * 0.58,
                min_y=100,
                max_y=320,
                include_ocr=True,
            )
            if not tapped:
                tapped = self.tap_marker(
                    EDIT_PROFILE_MARKERS,
                    exact=False,
                    min_y=100,
                    max_y=320,
                    include_ocr=True,
                )
            if not tapped:
                for y_ratio in (0.18, 0.24, 0.30):
                    self.tap_normalized(0.82, y_ratio)
                    last_texts = self.texts(include_ocr=True)
                    if marker_visible(last_texts, EDIT_PROFILE_MARKERS):
                        return
            try:
                self.wait_for(
                    PROFILE_EDITOR_PAGE_MARKERS,
                    timeout=7.0,
                    exact=True,
                    stage="edit_profile",
                )
                return
            except AutomationError:
                last_texts = self.texts(include_ocr=True)
                if page_marker_visible(last_texts, PROFILE_EDITOR_PAGE_MARKERS):
                    return
                if attempt < 3:
                    emit_progress(
                        "edit_profile",
                        f"编辑资料页首次没有打开，正在重试（{attempt + 1}/3）",
                    )
                    self.open_profile(relaunch=False)
        detail = "没有打开“编辑资料”页面。"
        if last_texts:
            detail += f" 当前识别到：{' / '.join(clean(item, 40) for item in last_texts[:8])}"
        raise AutomationError("edit_profile", detail)


def run_shell(
    client: McpHttpClient,
    command: str,
    *,
    timeout: int = 30,
) -> dict[str, Any]:
    value = client.tool_value(
        "run_command",
        {"command": command, "timeout": timeout},
    )
    return value if isinstance(value, dict) else {"output": str(value), "exitCode": 0}


def ensure_files_folder(client: McpHttpClient, folder_name: str) -> str:
    info = client.tool_value("get_app_info", {"bundle_id": FILES_BUNDLE_ID})
    if not isinstance(info, dict) or not info:
        raise AutomationError("files", "无法读取“文件”App 的信息。")
    groups = info.get("group_containers")
    group_root = (
        str(groups.get(FILE_PROVIDER_GROUP_ID) or "").strip()
        if isinstance(groups, dict)
        else ""
    )
    if not group_root.startswith("/"):
        raise AutomationError("files", "没有读取到“我的 iPhone”共享目录。")
    target = posixpath.join(
        posixpath.normpath(group_root),
        FILE_PROVIDER_STORAGE_NAME,
        folder_name,
    )
    result = run_shell(client, f"mkdir -p -- {shlex.quote(target)}", timeout=10)
    if int(result.get("exitCode") or 0) != 0:
        raise AutomationError(
            "files",
            f"无法创建手机文件夹：{clean(result.get('output'))}",
        )
    return target


def upload_file_to_phone(
    port: int,
    client: McpHttpClient,
    local_path: Path,
    folder_name: str,
) -> str:
    local = Path(local_path).expanduser().resolve(strict=True)
    size = local.stat().st_size
    if size <= 0:
        raise AutomationError("upload", f"文件是空的：{local.name}")
    remote_dir = ensure_files_folder(client, folder_name)
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=600)
    digest = hashlib.sha256()
    sent = 0
    try:
        connection.putrequest("POST", "/upload_file")
        connection.putheader("Content-Type", "application/octet-stream")
        connection.putheader("Content-Length", str(size))
        connection.endheaders()
        with local.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                connection.send(chunk)
                digest.update(chunk)
                sent += len(chunk)
        response = connection.getresponse()
        body = response.read().decode("utf-8", "replace")
        if not 200 <= response.status < 300:
            raise AutomationError(
                "upload",
                f"上传文件失败 HTTP {response.status}: {clean(body)}",
            )
        try:
            value = json.loads(body)
        except json.JSONDecodeError as error:
            raise AutomationError("upload", "手机上传接口返回了无效数据。") from error
        temporary = str(value.get("path") or "") if isinstance(value, dict) else ""
        remote_size = int(value.get("size") or -1) if isinstance(value, dict) else -1
        if not temporary.startswith("/") or remote_size != size or sent != size:
            raise AutomationError("upload", "电脑与手机的文件大小不一致。")
        destination = posixpath.join(remote_dir, local.name)
        result = run_shell(
            client,
            f"if mv -f -- {shlex.quote(temporary)} {shlex.quote(destination)}; "
            f"then chown mobile:mobile {shlex.quote(destination)} 2>/dev/null || true; "
            f"chmod 0644 {shlex.quote(destination)} 2>/dev/null || true; "
            "echo IC20_MOVE_OK; else echo IC20_MOVE_FAILED; exit 9; fi",
            timeout=30,
        )
        if (
            int(result.get("exitCode") or 0) != 0
            or "IC20_MOVE_OK" not in str(result.get("output") or "")
        ):
            raise AutomationError("upload", "文件上传后无法移动到目标文件夹。")
    finally:
        connection.close()
    emit_progress("upload", f"已上传到手机：{local.name}")
    return destination


def find_file_node(
    nodes: Iterable[dict[str, Any]],
    filename: str,
) -> dict[str, Any] | None:
    wanted_name = normalize(filename)
    wanted_stem = normalize(Path(filename).stem)
    for node in nodes:
        text = normalize(node_text(node))
        if not text:
            continue
        if (
            text == wanted_name
            or text.startswith(wanted_name + ",")
            or wanted_name in text
            or (
                wanted_stem
                and (text == wanted_stem or text.startswith(wanted_stem + ","))
            )
        ):
            return node
    return None


def find_file_folder_node(
    nodes: Iterable[dict[str, Any]],
    folder_name: str,
) -> dict[str, Any] | None:
    """Find the actual folder tile, never the current-page breadcrumb."""
    wanted = normalize(folder_name)
    fallback: dict[str, Any] | None = None
    for node in nodes:
        text = normalize(node_text(node))
        if not wanted or wanted not in text:
            continue
        point = node_point(node)
        if point is None or point[1] <= 80:
            continue
        if "文件夹" in text or "folder" in text:
            return node
        rect = node_rect(node)
        if rect is not None and rect[3] >= 40:
            fallback = node
    return fallback


def find_local_storage_node(
    nodes: Iterable[dict[str, Any]],
) -> dict[str, Any] | None:
    """Find the On My iPhone row while ignoring its top breadcrumb copy."""
    for node in nodes:
        text = node_text(node)
        if not text or not any(
            text_matches(text, marker, exact=True)
            for marker in ON_MY_IPHONE_MARKERS
        ):
            continue
        point = node_point(node)
        if point is not None and point[1] > 80:
            return node
    return None


def _navigate_file_view(
    automation: UiAutomation,
    folder_name: str,
    filename: str,
    *,
    timeout: float,
) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    last_tap_signature: tuple[
        str,
        tuple[float, float, float, float] | None,
    ] | None = None
    last_tap_at = 0.0
    while time.monotonic() < deadline:
        nodes = automation.nodes(include_ocr=True)
        file_node = find_file_node(nodes, filename)
        if file_node is not None:
            # Folder-opening animation still accepts the AX snapshot before
            # grid items are ready for touch. Let it settle to avoid a tap
            # being swallowed and the retry turning into a rename gesture.
            time.sleep(0.85)
            settled_nodes = automation.nodes(include_ocr=True)
            settled_node = find_file_node(settled_nodes, filename)
            if settled_node is None:
                # One more animation-safe refresh keeps the caller from using
                # a stale tile rectangle from the folder transition.
                time.sleep(0.35)
                settled_node = find_file_node(
                    automation.nodes(include_ocr=True),
                    filename,
                )
            if settled_node is not None:
                return settled_node
            continue

        folder_node = find_file_folder_node(nodes, folder_name)
        if folder_node is not None:
            rect = node_rect(folder_node)
            signature = (normalize(node_text(folder_node)), rect)
            now = time.monotonic()
            # Files can continue exposing the old accessibility snapshot for
            # a moment after a tap. Do not tap the same tile repeatedly.
            if signature != last_tap_signature or now - last_tap_at >= 1.5:
                tap_file_cell(automation, folder_node)
                last_tap_signature = signature
                last_tap_at = now
                time.sleep(0.7)
                continue
            time.sleep(0.25)
            continue

        storage_node = find_local_storage_node(nodes)
        if storage_node is not None:
            tap_file_cell(automation, storage_node)
            time.sleep(0.7)
            continue

        # "Browse" is also the permanent bottom-tab title. Restrict this
        # recovery tap to the bottom tab, never the top breadcrumb/back bar.
        width, height = automation.screen_size()
        if automation.tap_marker(
            BROWSE_MARKERS,
            exact=True,
            include_ocr=False,
            min_x=width * 0.50,
            min_y=height * 0.75,
        ):
            time.sleep(0.7)
            continue
        time.sleep(0.35)
    raise AutomationError(
        "files",
        f"没有在“文件 App / {folder_name}”中找到 {filename}。",
    )


def tap_file_cell(automation: UiAutomation, node: dict[str, Any]) -> None:
    rect = node_rect(node)
    if rect is None:
        automation.tap_node(node)
        return
    x, y, width, height = rect
    automation.tap_xy(
        x + width / 2,
        y + min(64.0, max(28.0, height * 0.24)),
    )


def _file_rename_done_node(
    automation: UiAutomation,
    nodes: Iterable[dict[str, Any]],
) -> dict[str, Any] | None:
    """Return the keyboard Done button only while Files rename mode is active."""
    _width, height = automation.screen_size()
    done_node = find_text_node(
        nodes,
        DONE_MARKERS,
        exact=True,
        min_y=height * 0.70,
    )
    if done_node is None:
        return None
    keyboard_visible = any(
        text_matches(text, marker, exact=True)
        and point is not None
        and point[1] >= height * 0.62
        for node in nodes
        for text in (node_text(node),)
        for marker in FILE_RENAME_KEYBOARD_MARKERS
        for point in (node_point(node),)
    )
    return done_node if keyboard_visible else None


def _wait_for_file_preview(
    automation: UiAutomation,
    filename: str,
    *,
    timeout: float = 7.0,
) -> None:
    """Open Quick Look once, recovering from a stale tap entering rename mode."""
    deadline = time.monotonic() + timeout
    file_taps = 0
    last_tap_at = 0.0
    while time.monotonic() < deadline:
        _width, height = automation.screen_size()
        nodes = automation.nodes(include_ocr=True)
        preview_done = find_text_node(
            nodes,
            DONE_MARKERS,
            exact=True,
            max_y=height * 0.18,
        )
        if preview_done is not None:
            return
        rename_done = _file_rename_done_node(automation, nodes)
        if rename_done is not None:
            automation.tap_node(rename_done)
            time.sleep(0.65)
            nodes = automation.nodes(include_ocr=True)
            preview_done = find_text_node(
                nodes,
                DONE_MARKERS,
                exact=True,
                max_y=height * 0.18,
            )
            if preview_done is not None:
                return

        now = time.monotonic()
        if file_taps < 3 and now - last_tap_at >= 1.15:
            file_node = find_file_node(nodes, filename)
            if file_node is not None:
                tap_file_cell(automation, file_node)
                file_taps += 1
                last_tap_at = time.monotonic()
                continue
        time.sleep(0.35)
    raise AutomationError(
        "files",
        f"打开 {filename} 后没有进入文件预览。",
    )


def navigate_files_to_folder(
    automation: UiAutomation,
    folder_name: str,
    filename: str,
    *,
    timeout: float = 20.0,
) -> dict[str, Any]:
    automation.launch_app(FILES_BUNDLE_ID)
    return _navigate_file_view(
        automation,
        folder_name,
        filename,
        timeout=timeout,
    )


def save_open_file_to_photos(
    automation: UiAutomation,
    filename: str,
) -> None:
    # Rename mode also exposes a bottom "Done" key. Only a top toolbar Done
    # proves that Files opened Quick Look, so recover without double-tapping.
    _wait_for_file_preview(automation, filename)
    width, height = automation.screen_size()
    if not automation.tap_marker(SHARE_MARKERS, exact=True):
        automation.tap_xy(width * 0.064, height - 26)
    try:
        automation.wait_for(SAVE_IMAGE_MARKERS, timeout=6.0)
    except AutomationError:
        automation.tap_xy(width * 0.064, height - 26)
        automation.wait_for(SAVE_IMAGE_MARKERS, timeout=6.0)
    if not automation.tap_marker(SAVE_IMAGE_MARKERS, exact=False):
        raise AutomationError("photos", "没有找到“存储图像”按钮。")
    time.sleep(0.7)
    for _attempt in range(2):
        node = automation.find_node(PERMISSION_MARKERS, exact=True)
        if node is None:
            break
        automation.tap_node(node)
        time.sleep(0.45)
    automation.wait_until_gone(
        SAVE_IMAGE_MARKERS,
        timeout=15.0,
        stage="photos",
        detail="照片没有保存到相册。",
    )
    time.sleep(0.5)
    if not automation.tap_marker(DONE_MARKERS, exact=True):
        automation.tap_xy(width * 0.91, 42)
    time.sleep(0.45)


def import_image_to_photos(
    automation: UiAutomation,
    port: int,
    local_path: Path,
) -> str:
    destination = upload_file_to_phone(
        port,
        automation.client,
        local_path,
        PROFILE_FILES_FOLDER,
    )
    filename = Path(local_path).name
    node = navigate_files_to_folder(
        automation,
        PROFILE_FILES_FOLDER,
        filename,
    )
    tap_file_cell(automation, node)
    save_open_file_to_photos(automation, filename)
    emit_progress("photos", f"头像已存入相册：{filename}")
    return destination


def choose_picker_file(
    automation: UiAutomation,
    folder_name: str,
    filename: str,
) -> None:
    node = _navigate_file_view(
        automation,
        folder_name,
        filename,
        timeout=18.0,
    )
    automation.tap_node(node)
    time.sleep(0.8)


def wait_for_business_form(
    automation: UiAutomation,
    *,
    timeout: float = 18.0,
) -> list[str]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        texts = automation.texts(include_ocr=True)
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in BUSINESS_MARKERS
        ):
            return texts
        time.sleep(0.4)
    raise AutomationError(
        "business_entry",
        "没有找到 TikTok 企业认证页面。请先确认该账号可申请企业认证；"
        "如 TikTok 改版，可在“认证入口链接”中填写手机可打开的页面地址。",
    )


def _tap_marker_with_scroll(
    automation: UiAutomation,
    markers: Sequence[str],
    *,
    max_swipes: int = 4,
    exact: bool = False,
) -> bool:
    if automation.tap_marker(markers, exact=exact, include_ocr=True):
        return True
    for _attempt in range(max_swipes):
        automation.swipe_up()
        if automation.tap_marker(markers, exact=exact, include_ocr=True):
            return True
    return False


def _wait_for_business_shortcut(
    automation: UiAutomation,
    markers: Sequence[str],
    *,
    timeout: float = 12.0,
    scroll: bool = False,
) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        texts = automation.texts(include_ocr=True)
        if marker_visible(texts, markers):
            return True
        if scroll:
            automation.swipe_up()
        time.sleep(0.45)
    return False


def _account_row_node(automation: UiAutomation) -> dict[str, Any] | None:
    """Return the last exact Account row, skipping its section heading."""
    candidates: list[tuple[float, dict[str, Any]]] = []
    for node in automation.nodes(include_ocr=False):
        point = node_point(node)
        if point is None or node.get("clickable") is False:
            continue
        text = node_text(node)
        if any(text_matches(text, marker, exact=True) for marker in ACCOUNT_MARKERS):
            candidates.append((point[1], node))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[-1][1]


def _wait_for_account_settings(
    automation: UiAutomation,
    *,
    timeout: float = 4.0,
) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if marker_visible(automation.texts(include_ocr=True), ACCOUNT_SETTINGS_MARKERS):
            return True
        time.sleep(0.25)
    return False


def _open_account_settings_page(automation: UiAutomation) -> None:
    if marker_visible(automation.texts(include_ocr=True), ACCOUNT_SETTINGS_MARKERS):
        return

    # TikTok 47.8 contains the account page route even when the visible
    # "账号" settings row intermittently ignores both single and double taps.
    # The direct route was verified five consecutive times on the live device.
    try:
        automation.open_url(ACCOUNT_SETTINGS_DEEP_LINK)
        if _wait_for_account_settings(automation, timeout=4.5):
            return
    except Exception:
        pass

    node = _account_row_node(automation)
    point = node_point(node) if node is not None else None
    if point is None:
        raise AutomationError("business_entry", "没有找到可点击的“账号”行。")

    # The settings page contains both a section heading and a row labelled
    # "账号". TikTok 46+ also ignores a single tap on the row, so retry with a
    # native double tap while staying on the same coordinates.
    automation.tap_xy(*point)
    if _wait_for_account_settings(automation, timeout=1.2):
        return
    try:
        automation.double_tap_xy(*point)
    except Exception:
        automation.tap_xy(*point)
    if _wait_for_account_settings(automation, timeout=5.0):
        return
    raise AutomationError(
        "business_entry",
        "“账号”行已点击，但账号设置页没有打开。",
    )


def _open_business_form_by_navigation(automation: UiAutomation) -> None:
    try:
        _open_account_settings_page(automation)
    except AutomationError:
        # Compatibility fallback for builds whose account deep link is absent.
        automation.open_profile(relaunch=False)
        if not automation.tap_marker(MORE_MARKERS, exact=False, include_ocr=True):
            width, height = automation.screen_size()
            automation.tap_xy(width * 0.93, height * 0.063)
        if not _wait_for_business_shortcut(
            automation,
            SETTINGS_MARKERS,
            timeout=10.0,
            scroll=True,
        ):
            raise AutomationError(
                "business_entry",
                "TikTok 菜单里没有出现“设置与隐私”。",
            )
        if not _tap_marker_with_scroll(
            automation,
            SETTINGS_MARKERS,
            max_swipes=2,
        ):
            raise AutomationError("business_entry", "没有找到“设置与隐私”。")
        if not _wait_for_business_shortcut(
            automation,
            ACCOUNT_MARKERS,
            timeout=10.0,
            scroll=True,
        ):
            raise AutomationError("business_entry", "设置页面没有出现“账号”。")
        _open_account_settings_page(automation)
    if not _wait_for_business_shortcut(
        automation,
        BUSINESS_ENTRY_MARKERS + BUSINESS_VERIFY_MARKERS,
        timeout=12.0,
        scroll=True,
    ):
        raise AutomationError("business_entry", "账号页面没有出现企业认证入口。")
    if not _tap_marker_with_scroll(
        automation,
        BUSINESS_ENTRY_MARKERS + BUSINESS_VERIFY_MARKERS,
        max_swipes=5,
    ):
        raise AutomationError(
            "business_entry",
            "没有找到“Become a Verified Business Account / 进行企业验证”。",
        )
    if not _wait_for_business_shortcut(
        automation,
        BUSINESS_VERIFY_MARKERS + BUSINESS_START_MARKERS,
        timeout=12.0,
    ):
        raise AutomationError("business_entry", "没有进入企业验证说明页。")
    texts = automation.texts(include_ocr=True)
    if marker_visible(texts, BUSINESS_START_MARKERS):
        if not _tap_marker_with_scroll(
            automation,
            BUSINESS_START_MARKERS,
            max_swipes=2,
        ):
            raise AutomationError("business_entry", "没有找到“开始使用”。")
    wait_for_business_form(automation)


def open_business_form(automation: UiAutomation, entry_url: str) -> None:
    texts = automation.texts(include_ocr=True)
    if marker_visible(texts, BUSINESS_MARKERS):
        return
    navigation_error: Exception | None = None
    for attempt in range(2):
        try:
            _open_business_form_by_navigation(automation)
            return
        except Exception as error:
            navigation_error = error
            if attempt == 0:
                emit_progress(
                    "business_entry",
                    "企业认证菜单首次没有进入，正在重新定位页面",
                )
                time.sleep(0.8)

    if entry_url:
        emit_progress("business_entry", "菜单导航失败，正在尝试备用认证链接")
        automation.open_url(entry_url)
        wait_for_business_form(automation, timeout=24.0)
        return

    detail = "没有找到 TikTok 企业认证页面。"
    if isinstance(navigation_error, AutomationError):
        detail += f" {navigation_error.detail}"
    raise AutomationError(
        "business_entry",
        detail
        + " 已尝试完整菜单路径和滚动定位；可在“认证入口链接”中填写备用地址。",
    )
