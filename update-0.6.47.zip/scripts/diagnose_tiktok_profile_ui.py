from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(SCRIPT_ROOT))

from live_acceptance_mcp import McpAcceptance  # noqa: E402
from tiktok_automation_common import UiAutomation  # noqa: E402


TIKTOK_BUNDLE_ID = "com.zhiliaoapp.musically"


def main() -> int:
    parser = argparse.ArgumentParser(description="Dump TikTok edit-profile UI nodes")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--udid", default="")
    args = parser.parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    runner = McpAcceptance(output_dir, args.udid)
    ui: UiAutomation | None = None
    try:
        runner._setup()
        assert runner.snapshot is not None
        assert runner.client is not None
        ui = UiAutomation(runner.snapshot.local_port, TIKTOK_BUNDLE_ID, timeout=90.0)
        ui.connect()
        ui.launch_app()
        ui.dismiss_overlays()
        ui.open_profile()
        ui.open_edit_profile()

        nodes = ui.nodes()
        ocr_error = ""
        try:
            ocr_nodes = ui.ocr_nodes()
        except Exception as error:
            ocr_nodes = []
            ocr_error = f"{error.__class__.__name__}: {error}"
        (output_dir / "edit_profile_nodes.json").write_text(
            json.dumps(nodes, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (output_dir / "edit_profile_ocr_nodes.json").write_text(
            json.dumps(ocr_nodes, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        screenshot = runner.client.screenshot_jpeg()
        (output_dir / "edit_profile_device.jpg").write_bytes(screenshot)
        texts = ui.texts(include_ocr=False)
        summary = {
            "local_port": runner.snapshot.local_port,
            "screen": ui.screen_size(),
            "node_count": len(nodes),
            "ocr_node_count": len(ocr_nodes),
            "ocr_error": ocr_error,
            "texts": texts,
        }
        (output_dir / "edit_profile_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    finally:
        if ui is not None:
            ui.close()
        runner._close()


if __name__ == "__main__":
    raise SystemExit(main())
