﻿param(
    [switch]$Quiet
)

$ErrorActionPreference = "Continue"
$scriptPath = $MyInvocation.MyCommand.Path
$scriptDir = Split-Path -Parent $scriptPath
$projectRoot = Split-Path -Parent $scriptDir
$installRoot = Join-Path $env:LOCALAPPDATA "Programs\群控小助手"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logDir = Join-Path $projectRoot "work"
if (-not (Test-Path -LiteralPath $logDir)) {
    $logDir = $env:TEMP
}
$logPath = Join-Path $logDir "一键退出后台_$timestamp.log"

function Write-Status {
    param([string]$Text)
    if (-not $Quiet) {
        Write-Host $Text
    }
    try {
        Add-Content -LiteralPath $logPath -Value $Text -Encoding UTF8
    } catch {
    }
}

function Normalize-Root {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ""
    }
    try {
        return [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
    } catch {
        return $Path.TrimEnd('\')
    }
}

function Test-PathUnderRoot {
    param(
        [string]$Value,
        [string]$Root
    )
    if ([string]::IsNullOrWhiteSpace($Value) -or [string]::IsNullOrWhiteSpace($Root)) {
        return $false
    }
    $normalized = $Value.Trim('"')
    return $normalized.StartsWith(
        $Root,
        [System.StringComparison]::OrdinalIgnoreCase
    )
}

$roots = @(
    (Normalize-Root $projectRoot),
    (Normalize-Root $installRoot)
) | Where-Object { $_ } | Select-Object -Unique

if (-not $Quiet) {
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host "  群控小助手 - 一键退出所有后台" -ForegroundColor Cyan
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host "只关闭本项目、已安装版和本机转发进程。" -ForegroundColor Gray
    Write-Host "不会删除软件、账号、视频或手机数据。" -ForegroundColor Gray
    Write-Host ""
}

Write-Status "时间：$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Status "项目目录：$projectRoot"
Write-Status "安装目录：$installRoot"

$allProcesses = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
$targets = @(
    $allProcesses | Where-Object {
        $process = $_
        if ($process.ProcessId -eq $PID) {
            return $false
        }
        if ($process.Name -in @("cmd.exe", "powershell.exe", "pwsh.exe")) {
            return $false
        }

        foreach ($root in $roots) {
            if (Test-PathUnderRoot -Value ([string]$process.ExecutablePath) -Root $root) {
                return $true
            }
        }

        $commandLine = [string]$process.CommandLine
        if ([string]::IsNullOrWhiteSpace($commandLine)) {
            return $false
        }
        $isProjectCommand = $commandLine -match "iphone_control_center" -or
            $commandLine -match "pymobiledevice3\s+usbmux\s+forward"
        if (-not $isProjectCommand) {
            return $false
        }
        foreach ($root in $roots) {
            if (Test-PathUnderRoot -Value $commandLine -Root $root) {
                return $true
            }
        }
        return $false
    }
)

$targets = $targets | Sort-Object ProcessId -Unique
if (@($targets).Count -eq 0) {
    Write-Status "当前没有需要关闭的项目后台进程。"
    if (-not $Quiet) {
        Write-Host "已确认：没有残留后台。" -ForegroundColor Green
        Write-Host "日志：$logPath" -ForegroundColor DarkGray
    }
    exit 0
}

$stoppedIds = New-Object System.Collections.Generic.List[int]
foreach ($process in $targets) {
    $id = [int]$process.ProcessId
    $description = "$($process.Name) (PID $id)"
    Write-Status "正在关闭：$description"
    try {
        Stop-Process -Id $id -Force -ErrorAction Stop
        $stoppedIds.Add($id)
    } catch {
        Write-Status "关闭失败：$description - $($_.Exception.Message)"
    }
}

Start-Sleep -Milliseconds 1200
$remainingIds = @(
    $stoppedIds | Where-Object {
        Get-Process -Id $_ -ErrorAction SilentlyContinue
    }
)

if ($remainingIds.Count -gt 0) {
    foreach ($id in $remainingIds) {
        try {
            Stop-Process -Id $id -Force -ErrorAction Stop
        } catch {
        }
    }
    Start-Sleep -Milliseconds 500
}

$remaining = @(
    $stoppedIds | Where-Object {
        Get-Process -Id $_ -ErrorAction SilentlyContinue
    }
)

Write-Status "已关闭 $($stoppedIds.Count - $remaining.Count) 个后台进程。"
if ($remaining.Count -eq 0) {
    Write-Status "结果：全部后台已退出。"
    if (-not $Quiet) {
        Write-Host ""
        Write-Host "完成：后台已全部退出。" -ForegroundColor Green
        Write-Host "日志：$logPath" -ForegroundColor DarkGray
    }
    exit 0
}

Write-Status "结果：仍有 $($remaining.Count) 个进程未退出：$($remaining -join ', ')"
if (-not $Quiet) {
    Write-Host ""
    Write-Host "仍有进程未退出，请查看日志。" -ForegroundColor Yellow
    Write-Host "日志：$logPath" -ForegroundColor DarkGray
}
exit 2
