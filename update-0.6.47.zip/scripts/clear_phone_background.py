from __future__ import annotations

import argparse
import asyncio
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from iphone_control_center.services.ios_mcp_control import (  # noqa: E402
    IOS_MCP_REMOTE_PORT,
    McpHttpClient,
)
from pymobiledevice3.tcp_forwarder import UsbmuxTcpForwarder  # noqa: E402
from tiktok_automation_common import BACKGROUND_KEEP_BUNDLES, running_apps  # noqa: E402


FORWARD_READY_TIMEOUT_SECONDS = 15.0
SYSTEM_BUNDLE_PREFIXES = ("com.apple.",)


def emit(message: str) -> None:
    print(message, flush=True)


def short_udid(udid: str) -> str:
    value = str(udid or "").strip()
    return value[-6:].upper() if len(value) > 6 else value.upper()


def device_label(device: dict[str, Any]) -> str:
    name = str(device.get("DeviceName") or "iPhone").strip()
    version = str(device.get("ProductVersion") or "").strip()
    suffix = f" iOS {version}" if version else ""
    return f"{name} · {short_udid(str(device.get('Identifier') or ''))}{suffix}"


def list_usb_devices() -> list[dict[str, Any]]:
    completed = subprocess.run(
        [sys.executable, "-m", "pymobiledevice3", "usbmux", "list", "--usb"],
        cwd=PROJECT_ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=30,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "").strip()
        raise RuntimeError(detail or "无法读取 USB 连接的 iPhone")
    try:
        data = json.loads(completed.stdout or "[]")
    except json.JSONDecodeError as error:
        raise RuntimeError("USB 设备列表格式错误") from error
    if not isinstance(data, list):
        return []
    devices: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        if str(item.get("DeviceClass") or "iPhone") != "iPhone":
            continue
        udid = str(item.get("Identifier") or item.get("UniqueDeviceID") or "").strip()
        if not udid:
            continue
        normalized = dict(item)
        normalized["Identifier"] = udid
        devices.append(normalized)
    return sorted(devices, key=lambda item: str(item["Identifier"]))


def killable_apps(client: McpHttpClient) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    value = client.tool_value("list_running_apps", {})
    apps = running_apps(value)
    keep = {str(bundle).strip() for bundle in BACKGROUND_KEEP_BUNDLES}
    killable: list[dict[str, str]] = []
    kept: list[dict[str, str]] = []
    seen: set[str] = set()
    for app in apps:
        bundle_id = str(app.get("bundle_id") or "").strip()
        if not bundle_id or bundle_id in seen:
            continue
        seen.add(bundle_id)
        if bundle_id in keep or any(
            bundle_id.lower().startswith(prefix)
            for prefix in SYSTEM_BUNDLE_PREFIXES
        ):
            kept.append(app)
        else:
            killable.append(app)
    return killable, kept


async def inspect_device(
    index: int,
    total: int,
    device: dict[str, Any],
    *,
    dry_run: bool,
) -> dict[str, Any]:
    udid = str(device["Identifier"])
    label = device_label(device)
    emit(f"[{index}/{total}] {label}：正在连接手机控制服务…")
    ready = asyncio.Event()
    forwarder = UsbmuxTcpForwarder(
        udid,
        IOS_MCP_REMOTE_PORT,
        src_port=0,
        listening_event=ready,
        usbmux_connection_type="USB",
    )
    task = asyncio.create_task(forwarder.start(address="127.0.0.1"))
    client: McpHttpClient | None = None
    result: dict[str, Any] = {
        "udid": udid,
        "label": label,
        "success": False,
        "killed": [],
        "kept": [],
        "failed": [],
        "detail": "",
    }
    try:
        await asyncio.wait_for(ready.wait(), timeout=FORWARD_READY_TIMEOUT_SECONDS)
        port = int(forwarder.listening_port or 0)
        if port <= 0:
            raise RuntimeError("Windows 没有分配到 USB 转发端口")
        client = McpHttpClient(f"http://127.0.0.1:{port}", timeout=20.0)
        await asyncio.to_thread(client.connect)
        killable, kept = await asyncio.to_thread(killable_apps, client)
        result["kept"] = [app["name"] for app in kept]
        if dry_run:
            result["success"] = True
            result["detail"] = "预检完成，未关闭任何 App"
            emit(
                f"    预检：可清理 {len(killable)} 个，保留 {len(kept)} 个"
            )
            for app in killable:
                emit(f"    - {app['name']} ({app['bundle_id']})")
            return result

        killed: list[dict[str, str]] = []
        failed: list[dict[str, str]] = []
        for app in killable:
            bundle_id = app["bundle_id"]
            try:
                await asyncio.to_thread(
                    client.tool_value,
                    "kill_app",
                    {"bundle_id": bundle_id},
                )
                killed.append(app)
            except Exception as error:
                failed.append(
                    {
                        **app,
                        "error": f"{error.__class__.__name__}: {error}",
                    }
                )
        await asyncio.sleep(0.6)
        try:
            remaining, _ = await asyncio.to_thread(killable_apps, client)
            if remaining:
                remaining_by_id = {
                    app["bundle_id"]: app["name"] for app in remaining
                }
                for app in list(failed):
                    if app["bundle_id"] not in remaining_by_id:
                        failed.remove(app)
                already = {app["bundle_id"] for app in killed}
                for app in remaining:
                    if app["bundle_id"] not in already:
                        failed.append({**app, "error": "清理后仍在运行"})
        except Exception:
            pass
        result["killed"] = [app["name"] for app in killed]
        result["failed"] = [app["name"] for app in failed]
        result["success"] = not failed
        result["detail"] = (
            f"已清理 {len(killed)} 个 App"
            if not failed
            else f"已清理 {len(killed)} 个，{len(failed)} 个未关闭"
        )
        emit(f"    {result['detail']}")
        if kept:
            emit(f"    保留：{'、'.join(app['name'] for app in kept)}")
    except Exception as error:
        result["detail"] = f"{error.__class__.__name__}: {error}"
        emit(f"    失败：{result['detail']}")
    finally:
        if client is not None:
            try:
                await asyncio.to_thread(client.close)
            except Exception:
                pass
        forwarder.stop()
        try:
            await asyncio.wait_for(task, timeout=5.0)
        except Exception:
            task.cancel()
    return result


async def run(args: argparse.Namespace) -> int:
    emit("正在扫描 USB 连接的 iPhone…")
    devices = await asyncio.to_thread(list_usb_devices)
    if not devices:
        emit("没有发现 USB 连接的 iPhone。请连接手机、解锁并保持数据线连接。")
        return 2
    emit(f"发现 {len(devices)} 台 iPhone。")
    results: list[dict[str, Any]] = []
    for index, device in enumerate(devices, 1):
        results.append(
            await inspect_device(index, len(devices), device, dry_run=args.dry_run)
        )

    success_count = sum(1 for item in results if item.get("success"))
    total_killed = sum(len(item.get("killed") or []) for item in results)
    failed_count = len(results) - success_count
    emit("")
    if args.dry_run:
        emit(f"预检结果：成功 {success_count} 台，连接失败 {failed_count} 台。")
    else:
        emit(
            f"清理结果：成功 {success_count} 台，失败 {failed_count} 台，"
            f"共关闭 {total_killed} 个手机 App。"
        )

    log_dir = PROJECT_ROOT / "work"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"手机后台清理_{datetime.now():%Y%m%d_%H%M%S}.json"
    log_path.write_text(
        json.dumps(
            {
                "dry_run": bool(args.dry_run),
                "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "devices": results,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    emit(f"记录：{log_path}")
    return 0 if failed_count == 0 else 2


def main() -> int:
    parser = argparse.ArgumentParser(description="一键清理已连接 iPhone 的后台 App")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只显示将清理的 App，不实际关闭",
    )
    args = parser.parse_args()
    return asyncio.run(run(args))


if __name__ == "__main__":
    raise SystemExit(main())
