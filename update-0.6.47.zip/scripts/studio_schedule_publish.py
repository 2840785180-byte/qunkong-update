from __future__ import annotations

import argparse
import io
import json
import re
import sys
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Sequence

from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))
sys.path.insert(0, str(SCRIPT_ROOT))

from tiktok_automation_common import (  # noqa: E402
    AutomationError,
    LOGIN_REQUIRED_MARKERS,
    RATE_LIMIT_MARKERS,
    SECURITY_MARKERS,
    UiAutomation,
    clean,
    find_text_node,
    node_point,
    node_rect,
    node_text,
    normalize,
    run_shell,
    text_matches,
)
from iphone_control_center.services.publish_state import (  # noqa: E402
    PublishItemState,
    PublishStage,
    PublishStateStore,
    publish_item_key,
)
from iphone_control_center.services.compatibility import selector_profile  # noqa: E402


STUDIO_BUNDLE_ID = "com.ss.iphone.tt.creator"

LOGIN_MARKERS = (
    "登录 TikTok Studio",
    "使用手机号码/电子邮箱/用户名登录",
    "Log in to TikTok Studio",
    "Use phone/email/username",
)
CREATE_TAB_MARKERS = (
    "创作",
    "制作",
    "发布",
    "Create",
    "Create post",
    "Produce",
)
CREATE_ENTRY_MARKERS = (
    "上传",
    "发布视频",
    "上传视频",
    "选择视频",
    "开始创作",
    "去上传",
    "创建视频",
    "新建视频",
    "Upload",
    "Post video",
    "Upload video",
    "Select video",
    "Choose video",
    "Start creating",
    "Create video",
    "New video",
)
CREATE_PAGE_MARKERS = (
    "照片编辑器",
    "一键成片",
    "草稿",
    "Photo editor",
    "Templates",
    "Drafts",
)
CREATE_DRAFT_MARKERS = ("草稿", "Drafts")
NEXT_UPLOAD_READY_MARKERS = (
    "上传",
    "正在上传",
    "Upload",
    "Uploading",
)
RECENT_MARKERS = (
    "最近项目",
    "最近",
    "所有照片",
    "Recents",
    "Recent",
    "All photos",
    "Photos",
    "相册",
)
PHOTO_PICKER_PAGE_MARKERS = RECENT_MARKERS + (
    "已选择",
    "最多可选择",
    "最多可选",
    "选择",
    "Select",
    "Selected",
)
VIDEO_FILTER_MARKERS = ("视频", "Videos", "Video")
NEXT_MARKERS = ("下一步", "继续", "Next", "Continue", "添加", "Add")
VIDEO_EDITOR_MARKERS = (
    "添加音乐",
    "编辑",
    "模板",
    "文本",
    "贴纸",
    "Add sound",
    "Edit",
    "Templates",
    "Text",
    "Stickers",
)
CAPTION_MARKERS = (
    "添加描述",
    "添加文案",
    "聊聊你的视频",
    "说说这个视频",
    "Write a caption",
    "Add a caption",
    "Caption",
    "Description",
    "描述",
    "文案",
    "添加一个吸睛标题",
    "撰写详细的描述",
)
MORE_MARKERS = ("更多选项", "更多", "More options", "More")
SCHEDULE_MARKERS = (
    "定时发布",
    "预约发布",
    "定时",
    "排定",
    "Schedule post",
    "Schedule",
)
DATE_MARKERS = ("日期", "选择日期", "Date", "Select date")
TIME_MARKERS = ("时间", "选择时间", "Time", "Select time")
DONE_MARKERS = ("完成", "确定", "应用", "Done", "Set", "Apply")
CONFIRM_SCHEDULE_MARKERS = (
    "定时发布",
    "预约发布",
    "已选择时间",
    "Scheduled time",
    "Schedule post",
)
SUBMIT_MARKERS = (
    "预约",
    "排定",
    "排期",
    "定时发布",
    "Schedule",
    "Schedule post",
)
SUCCESS_MARKERS = (
    "已排定",
    "预约成功",
    "已预约",
    "Scheduled",
    "Your post has been scheduled",
    "帖子已排定",
)
IMMEDIATE_PUBLISH_MARKERS = ("立即发布", "Post now", "Publish now")
SUBMIT_BUSY_MARKERS = (
    "正在发布",
    "正在排定",
    "正在提交",
    "请稍候",
    "Posting",
    "Scheduling",
    "Submitting",
    "Please wait",
)

DATE_PATTERN = re.compile(r"(20\d{2})\s*[年/-]\s*(\d{1,2})\s*[月/-]\s*(\d{1,2})")
TIME_PATTERN = re.compile(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)")

# Poll the accessibility tree frequently and use OCR only as a fallback. This
# keeps each Studio post responsive without skipping the safety checks.
FAST_POLL_INTERVAL_SECONDS = 0.12
OCR_POLL_INTERVAL_SECONDS = 0.75
CAPTION_VERIFY_TIMEOUT_SECONDS = 0.65
PICKER_SETTLE_SECONDS = 0.14
# Live calibration on Studio 44 / iOS 16 measured about four rows per
# 216-point stroke. Keep the estimate conservative and always verify the
# final wheel values before tapping Done.
PICKER_BATCH_STEP_ROWS = 4.0
PICKER_BATCH_SETTLE_SECONDS = 0.22
PICKER_BATCH_FINAL_SETTLE_SECONDS = 0.16
PICKER_MAX_BATCH_SWIPES = 6
PICKER_FAST_MAX_ROUNDS = 8
PICKER_DIRECT_ROW_RADIUS = 6
PICKER_MAX_SCROLL_STEPS = 24
PICKER_ROW_SPACING = 39.0
PICKER_ROW_TAP_RADIUS = 3
PICKER_SWIPE_TRAVEL = 108.0
PICKER_SWIPE_ROWS = 4.0
PICKER_VISIBLE_TAP_RADIUS = 2
PICKER_FAST_ROUNDS = 3
DEFAULT_SCHEDULE_ROW_RATIO = (0.78, 0.798)
LEGACY_SCHEDULE_ROW_RATIO = (0.78, 0.585)
MEDIA_TILE_ROLE = "element"
PICKER_SMALL_SWIPE_MIN_TRAVEL = 16.0
PICKER_SMALL_SWIPE_TRAVEL_PER_ROW = 13.0
KEYBOARD_KEY_MARKERS = (
    "q",
    "w",
    "e",
    "空格",
    "Space",
    "换行",
    "Return",
    "确认",
    "Double tap to finish editing",
    "双击以完成编辑",
)
RETRYABLE_STAGES = frozenset(
    {
        "studio_home",
        "create_page",
        "video_entry",
        "photo_picker",
        "editor",
        "caption",
        "schedule",
    }
)
CREATE_TAB_Y_RATIOS = (0.94, 0.955, 0.91)
CREATE_UPLOAD_COORDINATE_RATIOS = ((0.52, 0.31), (0.5, 0.34))
CREATE_PAGE_SETTLE_SECONDS = 0.22
PHOTO_PICKER_ENTRY_TIMEOUT_SECONDS = 1.6
OCR_FALLBACK_DELAY_SECONDS = 0.70


def apply_selector_overrides(payload: dict[str, Any]) -> str:
    selectors = payload.get("selectors")
    if not isinstance(selectors, dict):
        return "default"
    allowed = {
        "CREATE_TAB_MARKERS",
        "CREATE_ENTRY_MARKERS",
        "CREATE_PAGE_MARKERS",
        "RECENT_MARKERS",
        "VIDEO_FILTER_MARKERS",
        "NEXT_MARKERS",
        "CAPTION_MARKERS",
        "SCHEDULE_MARKERS",
        "DATE_MARKERS",
        "TIME_MARKERS",
        "DONE_MARKERS",
        "SUBMIT_MARKERS",
        "SUCCESS_MARKERS",
    }
    for name in allowed:
        values = selectors.get(name)
        if not isinstance(values, list):
            continue
        cleaned = tuple(str(value).strip() for value in values if str(value).strip())
        if cleaned:
            globals()[name] = cleaned
    profile = selectors.get("profile")
    return str(profile[0]) if isinstance(profile, list) and profile else "default"


def _ui_profile_path(profile_name: str) -> Path:
    safe_name = re.sub(r"[^0-9A-Za-z._-]+", "_", profile_name or "default")
    return PROJECT_ROOT / "work" / "页面配置" / f"{safe_name}.json"


def load_ui_profile_snapshot(profile_name: str) -> dict[str, Any]:
    path = _ui_profile_path(profile_name)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def save_ui_profile_snapshot(
    profile_name: str,
    payload: dict[str, Any],
) -> Path:
    path = _ui_profile_path(profile_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    current = load_ui_profile_snapshot(profile_name)
    current.update(payload)
    current["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(current, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def emit_progress(stage: str, message: str) -> None:
    print(f"STUDIO_SCHEDULE_PROGRESS|{stage}|{clean(message, 500)}", flush=True)


def emit_result(value: dict[str, Any]) -> None:
    print(
        "STUDIO_SCHEDULE_RESULT|"
        + json.dumps(value, ensure_ascii=False, separators=(",", ":")),
        flush=True,
    )


def read_payload() -> dict[str, Any]:
    raw = sys.stdin.buffer.read() if sys.stdin is not None else b""
    if not raw.strip():
        raise ValueError("TikTok Studio 预约任务没有收到数据。")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("TikTok Studio 预约任务数据格式不正确。") from error
    if not isinstance(payload, dict):
        raise ValueError("TikTok Studio 预约任务格式不正确。")
    device = payload.get("device")
    items = payload.get("items")
    if (
        not isinstance(device, dict)
        or not isinstance(items, list)
        or not items
        or any(not isinstance(item, dict) for item in items)
    ):
        raise ValueError("TikTok Studio 预约任务缺少手机或视频信息。")
    return payload


def schedule_instant(item: dict[str, Any]) -> datetime:
    raw = str(item.get("publish_at_utc") or "").strip()
    try:
        instant = datetime.fromisoformat(raw)
    except ValueError as error:
        raise AutomationError("task", f"预约时间格式不正确：{raw}") from error
    if instant.tzinfo is None:
        instant = instant.replace(tzinfo=timezone.utc)
    return instant.astimezone(timezone.utc)


def parse_phone_offset_minutes(value: Any) -> int | None:
    text = str(value or "").strip()
    match = re.search(r"([+-])(\d{2})(\d{2})", text)
    if match is None:
        return None
    minutes = int(match.group(2)) * 60 + int(match.group(3))
    return minutes if match.group(1) == "+" else -minutes


def local_schedule_time(item: dict[str, Any], offset_minutes: int) -> datetime:
    return schedule_instant(item).astimezone(
        timezone(timedelta(minutes=int(offset_minutes)), name="PhoneLocal")
    )


def contains_text(texts: Sequence[str], markers: Sequence[str], *, exact: bool = False) -> bool:
    return any(
        text_matches(text, marker, exact=exact)
        for text in texts
        for marker in markers
    )


def blocking_page_error(texts: Sequence[str]) -> tuple[str, str] | None:
    if contains_text(texts, RATE_LIMIT_MARKERS):
        return (
            "rate_limit",
            "TikTok 提示操作太频繁，已停止本机预约，避免账号风险。",
        )
    if contains_text(texts, SECURITY_MARKERS):
        return (
            "security",
            "检测到 TikTok 安全验证，请在手机上手动完成后重新执行。",
        )
    if contains_text(texts, LOGIN_MARKERS + LOGIN_REQUIRED_MARKERS):
        return "login_required", "TikTok Studio 尚未登录或登录已失效。"
    return None


def find_exact_node(
    nodes: Sequence[dict[str, Any]],
    value: str,
    *,
    min_y: float = 0,
    max_y: float = 10000,
) -> dict[str, Any] | None:
    normalized = normalize(value)
    for node in nodes:
        point = node_point(node)
        if point is None or not (min_y <= point[1] <= max_y):
            continue
        if normalize(node_text(node)) == normalized:
            return node
    return None


def node_is_selected(node: dict[str, Any]) -> bool | None:
    false_values = {"0", "false", "no", "off", "unchecked", "未选", "未选中"}
    true_values = {"1", "true", "yes", "on", "selected", "checked", "已选", "已选中"}
    for key in ("selected", "checked", "isSelected", "is_selected", "state", "value"):
        raw = node.get(key)
        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return bool(raw)
        text = normalize(raw)
        if text in true_values:
            return True
        if text in false_values:
            return False
    return None


def immediate_publish_is_active(nodes: Sequence[dict[str, Any]]) -> bool:
    return any(
        text_matches(node_text(node), marker, exact=True)
        and node_is_selected(node) is True
        for node in nodes
        for marker in IMMEDIATE_PUBLISH_MARKERS
    )


class StudioScheduleRunner:
    def __init__(self, port: int, payload: dict[str, Any]) -> None:
        self.payload = payload
        self.device = payload["device"]
        self.items = [item for item in payload["items"] if isinstance(item, dict)]
        self.output_dir = Path(
            str(payload.get("output_dir") or PROJECT_ROOT / "work" / "Studio自动预约")
        ).expanduser().resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        raw_state_path = str(payload.get("state_path") or "").strip()
        self.state_path = (
            Path(raw_state_path).expanduser().resolve()
            if raw_state_path
            else self.output_dir / "发布断点状态.json"
        )
        self.state_store = PublishStateStore(self.state_path)
        self.state_store.load()
        self._current_item_key = ""
        self._current_item_label = ""
        self._submit_tapped = False
        self.dry_run = bool(payload.get("dry_run"))
        self.retry_limit = min(max(int(payload.get("retry_limit") or 1), 0), 3)
        self.selector_profile_name = str(payload.get("selector_profile") or "default")
        self.runtime_profile: dict[str, Any] = {}
        device = self.device if isinstance(self.device, dict) else {}
        slot_no = int(device.get("slot_no") or 0)
        self.state_store.ensure_items(
            PublishItemState(
                item_key=publish_item_key(
                    slot_no=slot_no,
                    filename=str(item.get("filename") or ""),
                    publish_at_utc=str(item.get("publish_at_utc") or ""),
                    competition=str(item.get("competition") or ""),
                ),
                slot_no=slot_no,
                filename=str(item.get("filename") or ""),
                publish_at_utc=str(item.get("publish_at_utc") or ""),
            )
            for item in self.items
        )
        self.state_store.save()
        self.ui = UiAutomation(port, STUDIO_BUNDLE_ID, timeout=90.0)
        self.offset_minutes = 0
        self.scheduled_count = 0
        self.failed_count = 0
        self.records: list[dict[str, Any]] = []
        self.scheduled_elapsed_seconds = 0.0
        self.started_monotonic = time.monotonic()
        self.selection_started_monotonic = 0.0
        self.submit_clicked_monotonic = 0.0
        self.publish_completed_monotonic = 0.0
        self._touch_prepared = False
        self.create_tab_y_ratios = tuple(CREATE_TAB_Y_RATIOS)
        self.create_upload_coordinate_ratios = tuple(
            CREATE_UPLOAD_COORDINATE_RATIOS
        )
        self.schedule_row_ratio = DEFAULT_SCHEDULE_ROW_RATIO
        self.next_button_ratio = (0.82, 0.93)
        self._picker_rows_per_swipe: dict[str, float] = {}

    def _item_key(self, item: dict[str, Any]) -> str:
        device = getattr(self, "device", {})
        device = device if isinstance(device, dict) else {}
        return publish_item_key(
            slot_no=int(device.get("slot_no") or 0),
            filename=str(item.get("filename") or ""),
            publish_at_utc=str(item.get("publish_at_utc") or ""),
            competition=str(item.get("competition") or ""),
        )

    def _mark_current(
        self,
        stage: PublishStage,
        *,
        status: str | None = None,
        detail: str = "",
        screenshot: str = "",
        attempts: int | None = None,
    ) -> None:
        item_key = getattr(self, "_current_item_key", "")
        state_store = getattr(self, "state_store", None)
        if not item_key or state_store is None:
            return
        state_store.mark(
            item_key,
            stage,
            status=status,
            detail=detail,
            screenshot=screenshot,
            attempts=attempts,
        )

    def _stored_state(self, item_key: str):
        state_store = getattr(self, "state_store", None)
        return state_store.get(item_key) if state_store is not None else None

    def _retry_stage(
        self,
        stage: str,
        operation,
        *,
        reset=None,
    ):
        last_error: AutomationError | None = None
        retry_limit = int(getattr(self, "retry_limit", 0))
        for attempt in range(retry_limit + 1):
            try:
                return operation()
            except AutomationError as error:
                last_error = error
                if error.stage not in RETRYABLE_STAGES or attempt >= retry_limit:
                    raise
                emit_progress(
                    "retry",
                    f"{stage} 第 {attempt + 1} 次重试：{clean(error.detail, 180)}",
                )
                self._mark_current(
                    PublishStage.FAILED,
                    status="retrying",
                    detail=f"{stage} 第 {attempt + 1} 次重试",
                )
                if reset is not None:
                    try:
                        reset()
                    except Exception:
                        pass
                time.sleep(0.5 + attempt * 0.5)
        if last_error is not None:
            raise last_error

    def run(self) -> int:
        self.runtime_profile = dict(getattr(self, "runtime_profile", {}) or {})
        try:
            self.ui.connect()
            self._refresh_runtime_profile()
            self._open_studio()
            self.offset_minutes = self._read_phone_timezone()
            emit_progress(
                "timezone",
                f"手机本地时区偏移 {self.offset_minutes // 60:+d} 小时",
            )
            for index, item in enumerate(self.items, 1):
                label = str(item.get("filename") or f"第 {index} 条视频")
                item_started_at = time.monotonic()
                item_started_utc = datetime.now(timezone.utc)
                self._current_item_key = self._item_key(item)
                self._current_item_label = label
                previous_state = self._stored_state(self._current_item_key)
                if previous_state is not None and previous_state.status in {
                    "scheduled",
                    "success",
                }:
                    self.scheduled_count += 1
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "status": "scheduled",
                            "stage": "resume",
                            "detail": "断点状态显示该条已完成，本次未重复提交。",
                            "duration_seconds": 0.0,
                        }
                    )
                    emit_progress("resume", f"{index}/{len(self.items)} 已在断点中完成，跳过")
                    continue
                if previous_state is not None and previous_state.status == "submitted_unknown":
                    self.failed_count += 1
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "status": "failed",
                            "stage": "submit_unknown",
                            "detail": "上次点击预约后未确认成功，为防止重复预约已停止本机。请先在创作记录人工复核。",
                            "duration_seconds": 0.0,
                        }
                    )
                    emit_progress("submit_unknown", f"{label} 需要人工复核，已停止本机后续预约")
                    break
                try:
                    self._mark_current(
                        PublishStage.QUEUED,
                        status="running",
                        detail="开始处理",
                        attempts=(previous_state.attempts + 1 if previous_state else 1),
                    )
                    emit_progress("prepare", f"{index}/{len(self.items)} · {label}")
                    self._assert_not_blocked()
                    local_time = local_schedule_time(item, self.offset_minutes)
                    if schedule_instant(item) <= datetime.now(timezone.utc) + timedelta(
                        minutes=1
                    ):
                        raise AutomationError(
                            "schedule_time",
                            f"预约时间 {local_time:%Y-%m-%d %H:%M} 已过或不足 1 分钟，"
                            "已停止本机后续预约。",
                        )
                    self._mark_current(PublishStage.OPEN_CREATE)
                    self._retry_stage("create_page", self._open_create_page)
                    self._mark_current(PublishStage.PICK_VIDEO)
                    self._retry_stage(
                        "photo_picker",
                        lambda: self._select_video(
                            int(item.get("album_index") or 0),
                            index,
                            label,
                        ),
                        reset=self._open_create_page,
                    )
                    self._mark_current(PublishStage.CAPTION)
                    self._retry_stage(
                        "caption",
                        lambda: self._fill_caption(
                            str(item.get("caption") or ""),
                            item.get("hashtags"),
                        ),
                    )
                    self._mark_current(PublishStage.SCHEDULE)
                    self._retry_stage(
                        "schedule",
                        lambda: self._configure_schedule(local_time),
                    )
                    if self.dry_run:
                        screenshot = self.ui.client.screenshot_jpeg()
                        dry_run_path = self.output_dir / f"预演_{index:03d}.jpg"
                        dry_run_path.write_bytes(screenshot)
                        self._mark_current(
                            PublishStage.SCHEDULE,
                            status="dry_run",
                            detail="已到达预约确认页，预演模式未提交。",
                            screenshot=str(dry_run_path),
                        )
                        self.records.append(
                            {
                                "clip_order": int(item.get("clip_order") or index),
                                "filename": label,
                                "competition": str(item.get("competition") or ""),
                                "publish_at_utc": str(item.get("publish_at_utc") or ""),
                                "publish_at_target": str(item.get("publish_at_target") or ""),
                                "publish_at_phone": local_time.isoformat(timespec="minutes"),
                                "status": "dry_run",
                                "stage": "preview",
                                "detail": "预演已到确认页，未提交。",
                                "screenshot": str(dry_run_path),
                                "duration_seconds": round(max(0.0, time.monotonic() - item_started_at), 2),
                                "publish_action_seconds": round(
                                    max(
                                        0.0,
                                        time.monotonic() - self.selection_started_monotonic,
                                    ),
                                    2,
                                ),
                            }
                        )
                        emit_progress("dry_run", f"预演已到确认页，未提交：{dry_run_path}")
                        break
                    self._mark_current(PublishStage.SUBMIT, status="submitting")
                    self._submit_schedule(local_time)
                    self.publish_completed_monotonic = time.monotonic()
                    self.scheduled_count += 1
                    self._mark_current(
                        PublishStage.COMPLETE,
                        status="scheduled",
                        detail="已在 TikTok Studio 完成定时发布",
                    )
                    item_duration = round(
                        max(0.0, time.monotonic() - item_started_at), 2
                    )
                    self.scheduled_elapsed_seconds += item_duration
                    average_duration = (
                        self.scheduled_elapsed_seconds / self.scheduled_count
                    )
                    publish_action_seconds = 0.0
                    if self.selection_started_monotonic > 0:
                        publish_action_seconds = round(
                            max(
                                0.0,
                                self.publish_completed_monotonic
                                - self.selection_started_monotonic,
                            ),
                            2,
                        )
                        emit_progress(
                            "publish_action",
                            "选视频 → 确认预约成功 "
                            f"{publish_action_seconds:.2f} 秒",
                        )
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "publish_at_phone": local_time.isoformat(timespec="minutes"),
                            "status": "scheduled",
                            "detail": "已在 TikTok Studio 完成定时发布",
                            "started_at": item_started_utc.isoformat(timespec="seconds"),
                            "duration_seconds": item_duration,
                            "publish_action_seconds": publish_action_seconds,
                        }
                    )
                    emit_progress(
                        "scheduled",
                        f"{index}/{len(self.items)} 完成 · 本条 {item_duration:.1f} 秒"
                        f" · 选视频到提交成功 {publish_action_seconds:.2f} 秒"
                        f" · 平均 {average_duration:.1f} 秒/条",
                    )
                    if index < len(self.items):
                        next_upload_ready = self._wait_for_next_upload_entry(
                            timeout=2.0,
                        )
                        emit_progress(
                            "next_video",
                            (
                                "2 秒内已检测到上传/正在上传，开始下一条"
                                if next_upload_ready
                                else "2 秒内未检测到上传入口，下一条将重新定位后继续"
                            ),
                        )
                except AutomationError as error:
                    self.failed_count += 1
                    failure_status = (
                        "submitted_unknown"
                        if error.stage == "submit" and self._submit_tapped
                        else "failed"
                    )
                    self._mark_current(
                        PublishStage.FAILED,
                        status=failure_status,
                        detail=clean(error.detail, 1200),
                    )
                    item_duration = round(
                        max(0.0, time.monotonic() - item_started_at), 2
                    )
                    self.records.append(
                        {
                            "clip_order": int(item.get("clip_order") or index),
                            "filename": label,
                            "competition": str(item.get("competition") or ""),
                            "publish_at_utc": str(item.get("publish_at_utc") or ""),
                            "publish_at_target": str(item.get("publish_at_target") or ""),
                            "status": "failed",
                            "stage": error.stage,
                            "detail": clean(error.detail, 1200),
                            "started_at": item_started_utc.isoformat(timespec="seconds"),
                            "duration_seconds": item_duration,
                        }
                    )
                    for skipped_index, skipped_item in enumerate(
                        self.items[index:],
                        start=index + 1,
                    ):
                        skipped_key = self._item_key(skipped_item)
                        state_store = getattr(self, "state_store", None)
                        if state_store is not None:
                            state_store.mark(
                                skipped_key,
                                PublishStage.NOT_RUN,
                                status="not_run",
                                detail="因前一条预约失败，本机后续预约已停止。",
                            )
                        self.records.append(
                            {
                                "clip_order": int(
                                    skipped_item.get("clip_order") or skipped_index
                                ),
                                "filename": str(
                                    skipped_item.get("filename")
                                    or f"第 {skipped_index} 条视频"
                                ),
                                "competition": str(
                                    skipped_item.get("competition") or ""
                                ),
                                "publish_at_utc": str(
                                    skipped_item.get("publish_at_utc") or ""
                                ),
                                "publish_at_target": str(
                                    skipped_item.get("publish_at_target") or ""
                                ),
                                "status": "not_run",
                                "stage": "not_run",
                                "detail": "因前一条预约失败，本机后续预约已停止。",
                                "duration_seconds": 0.0,
                            }
                        )
                    # Stop this phone on the first failure so a broken page cannot
                    # cause duplicate submissions or an accidental immediate post.
                    break

            creator_visible, screenshot = self._open_creator_for_review()
            preview_count = sum(
                1 for record in self.records if record.get("status") == "dry_run"
            )
            success = (
                preview_count > 0 if self.dry_run else self.scheduled_count == len(self.items)
            )
            average_item_seconds = (
                round(self.scheduled_elapsed_seconds / self.scheduled_count, 2)
                if self.scheduled_count
                else 0.0
            )
            result = {
                "success": success,
                "stage": (
                    "dry_run_complete"
                    if self.dry_run and success
                    else ("complete" if success else "scheduled_with_failures")
                ),
                "detail": (
                    f"预演已到确认页，共 {preview_count} 条，没有提交。"
                    if self.dry_run and success
                    else (
                        f"已完成 {self.scheduled_count}/{len(self.items)} 条预约，"
                        "并打开创作页面供复核。"
                        if success
                        else f"只完成 {self.scheduled_count}/{len(self.items)} 条预约。"
                    )
                ),
                "dry_run": self.dry_run,
                "preview_count": preview_count,
                "selector_profile": self.selector_profile_name,
                "total_count": len(self.items),
                "scheduled_count": self.scheduled_count,
                "failed_count": self.failed_count,
                "not_run_count": max(
                    0,
                    len(self.items) - self.scheduled_count - self.failed_count,
                ),
                "items": self.records,
                "creator_visible": creator_visible,
                "creator_screenshot": screenshot,
                "phone_timezone": f"{self.offset_minutes // 60:+d}",
                "runtime_profile": dict(self.runtime_profile),
                "average_item_seconds": average_item_seconds,
                "duration_seconds": round(
                    max(0.0, time.monotonic() - self.started_monotonic), 2
                ),
            }
            emit_result(result)
            return 0 if success else 1
        except AutomationError as error:
            result = self._failure_result(error.stage, error.detail)
            emit_result(result)
            return 1
        except Exception as error:
            print(traceback.format_exc(), file=sys.stderr, flush=True)
            result = self._failure_result(
                "unexpected",
                f"{error.__class__.__name__}: {clean(error, 1000)}",
            )
            emit_result(result)
            return 1
        finally:
            self.ui.close()

    def _failure_result(self, stage: str, detail: str) -> dict[str, Any]:
        failed_attempts = sum(
            1 for record in self.records if record.get("status") == "failed"
        )
        not_run_count = max(0, len(self.items) - self.scheduled_count - failed_attempts)
        return {
            "success": False,
            "stage": stage,
            "detail": clean(detail, 1500) or "TikTok Studio 预约失败",
            "total_count": len(self.items),
            "scheduled_count": self.scheduled_count,
            "failed_count": failed_attempts,
            "not_run_count": not_run_count,
            "items": self.records,
            "creator_visible": False,
            "creator_screenshot": "",
            "phone_timezone": f"{self.offset_minutes // 60:+d}",
            "runtime_profile": dict(getattr(self, "runtime_profile", {}) or {}),
            "average_item_seconds": (
                round(self.scheduled_elapsed_seconds / self.scheduled_count, 2)
                if self.scheduled_count
                else 0.0
            ),
            "duration_seconds": round(
                max(0.0, time.monotonic() - self.started_monotonic), 2
            ),
        }

    def _wait_for_markers(
        self,
        markers: Sequence[str],
        *,
        timeout: float,
        exact: bool = False,
    ) -> list[str] | None:
        """Poll AX quickly, refreshing OCR only at a bounded interval."""
        deadline = time.monotonic() + timeout
        next_ocr_at = time.monotonic() + OCR_FALLBACK_DELAY_SECONDS
        while True:
            now = time.monotonic()
            include_ocr = now >= next_ocr_at
            texts = self.ui.texts(include_ocr=include_ocr)
            if include_ocr:
                next_ocr_at = now + OCR_POLL_INTERVAL_SECONDS
            if contains_text(texts, markers, exact=exact):
                return texts
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            time.sleep(min(FAST_POLL_INTERVAL_SECONDS, remaining))

    def _wait_for_marker_groups(
        self,
        groups: Sequence[tuple[Sequence[str], bool]],
        *,
        blockers: Sequence[str] = (),
        timeout: float,
    ) -> list[str] | None:
        """Wait for any marker group while keeping exact and fuzzy matches separate."""
        deadline = time.monotonic() + timeout
        next_ocr_at = time.monotonic() + OCR_FALLBACK_DELAY_SECONDS
        while True:
            now = time.monotonic()
            include_ocr = now >= next_ocr_at
            texts = self.ui.texts(include_ocr=include_ocr)
            if include_ocr:
                next_ocr_at = now + OCR_POLL_INTERVAL_SECONDS
            if blockers and contains_text(texts, blockers):
                return texts
            if any(contains_text(texts, markers, exact=exact) for markers, exact in groups):
                return texts
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            time.sleep(min(FAST_POLL_INTERVAL_SECONDS, remaining))

    def _tap_marker_fast(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        """Try the accessibility tree first; add OCR only when needed."""
        if min_y is None and max_y is None:
            tap_element = getattr(self.ui, "tap_element", None)
            if callable(tap_element):
                try:
                    if tap_element(markers, exact=exact):
                        return True
                except Exception:
                    pass
        common = {
            "exact": exact,
            "min_y": min_y,
            "max_y": max_y,
        }
        if self.ui.tap_marker(markers, include_ocr=False, **common):
            return True
        return self.ui.tap_marker(markers, include_ocr=True, **common)

    def _screen_bytes(self) -> bytes:
        try:
            return self.ui.client.screenshot_jpeg()
        except Exception:
            return b""

    def _page_signature(self) -> tuple[tuple[str, int, int, int, int], ...]:
        """Fingerprint stable controls, not animated video pixels."""
        try:
            nodes = self.ui.nodes(include_ocr=False)
        except Exception:
            return ()
        signature: list[tuple[str, int, int, int, int]] = []
        for node in nodes:
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, width, height = rect
            signature.append(
                (
                    normalize(node_text(node)),
                    round(x),
                    round(y),
                    round(width),
                    round(height),
                )
            )
        return tuple(sorted(signature))

    def _tap_marker_with_touch_retry(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        expected_markers: Sequence[str] = (),
        min_y: float | None = None,
        max_y: float | None = None,
        change_timeout: float = 0.7,
    ) -> bool:
        """Retry an unresponsive tap twice, then reset the touch channel."""
        before_signature: tuple[tuple[str, int, int, int, int], ...] = ()
        before_image = b""
        if not expected_markers:
            before_signature = self._page_signature()
            before_image = b"" if before_signature else self._screen_bytes()
        common = {
            "exact": exact,
            "min_y": min_y,
            "max_y": max_y,
        }
        for attempt in (1, 2):
            tapped = False
            if attempt == 1 and min_y is None and max_y is None:
                tap_element = getattr(self.ui, "tap_element", None)
                if callable(tap_element):
                    try:
                        tapped = bool(tap_element(markers, exact=exact))
                    except Exception:
                        tapped = False
            if not tapped:
                tapped = self._tap_marker_fast(markers, **common)
            if not tapped:
                return False
            if expected_markers:
                wait_native = getattr(self.ui, "wait_for_element", None)
                if callable(wait_native):
                    for marker in expected_markers[:2]:
                        try:
                            if wait_native(
                                marker,
                                timeout=change_timeout,
                                exact=False,
                                interval_ms=100,
                            ):
                                return True
                        except Exception:
                            pass
            deadline = time.monotonic() + change_timeout
            while time.monotonic() < deadline:
                if expected_markers:
                    texts = self.ui.texts(include_ocr=False)
                    if contains_text(texts, expected_markers, exact=False):
                        return True
                time.sleep(0.1)
            if not expected_markers:
                after_signature = self._page_signature()
                if (
                    before_signature
                    and after_signature
                    and after_signature != before_signature
                ):
                    return True
                if not before_signature or not after_signature:
                    after_image = self._screen_bytes()
                    if before_image and after_image and after_image != before_image:
                        return True
                    before_image = after_image
                before_signature = after_signature
            if attempt == 1:
                emit_progress(
                    "touch_retry",
                    f"第一次点击无页面变化，正在点击第二次：{' / '.join(markers[:2])}",
                )
        self._reset_touch_channel_with_lock_wake()
        if expected_markers:
            texts = self.ui.texts(include_ocr=False)
            if contains_text(texts, expected_markers, exact=False):
                return True
        if not expected_markers:
            before_signature = self._page_signature()
            before_image = b"" if before_signature else self._screen_bytes()
        for attempt in (1, 2):
            if not self._tap_marker_fast(markers, **common):
                return False
            if expected_markers:
                wait_native = getattr(self.ui, "wait_for_element", None)
                if callable(wait_native):
                    for marker in expected_markers[:2]:
                        try:
                            if wait_native(
                                marker,
                                timeout=change_timeout,
                                exact=False,
                                interval_ms=100,
                            ):
                                return True
                        except Exception:
                            pass
            deadline = time.monotonic() + change_timeout
            while time.monotonic() < deadline:
                if expected_markers:
                    texts = self.ui.texts(include_ocr=False)
                    if contains_text(texts, expected_markers, exact=False):
                        return True
                time.sleep(0.1)
            if not expected_markers:
                after_signature = self._page_signature()
                if (
                    before_signature
                    and after_signature
                    and after_signature != before_signature
                ):
                    return True
                if not before_signature or not after_signature:
                    after_image = self._screen_bytes()
                    if before_image and after_image and after_image != before_image:
                        return True
                    before_image = after_image
                before_signature = after_signature
            if attempt == 1:
                emit_progress(
                    "touch_retry",
                    f"锁屏唤醒后仍未跳转，正在再次点击：{' / '.join(markers[:2])}",
                )
        return False

    def _open_studio(self) -> None:
        emit_progress("studio_home", "正在清理后台并打开 TikTok Studio")
        self.ui.restart_app_clean(STUDIO_BUNDLE_ID)
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        for attempt in range(2):
            self._dismiss_studio_overlays()
            texts = self._wait_for_markers(
                CREATE_TAB_MARKERS + blockers,
                timeout=15.0,
            )
            if texts is not None:
                blocker = blocking_page_error(texts)
                if blocker is not None:
                    raise AutomationError(*blocker)
                if contains_text(texts, CREATE_TAB_MARKERS):
                    return
            if attempt == 0:
                emit_progress(
                    "studio_home",
                    "Studio 首页加载较慢，正在再次启动 TikTok Studio",
                )
                self.ui.restart_app_clean(STUDIO_BUNDLE_ID)
        raise AutomationError("studio_home", "没有打开 TikTok Studio 首页或创作入口。")

    def _assert_not_blocked(self) -> None:
        blocker = blocking_page_error(self.ui.texts(include_ocr=True))
        if blocker is not None:
            raise AutomationError(*blocker)

    def _read_phone_timezone(self) -> int:
        try:
            value = run_shell(self.ui.client, "date +%z", timeout=8)
            if int(value.get("exitCode") or 0) == 0:
                offset = parse_phone_offset_minutes(value.get("output"))
                if offset is not None:
                    return offset
        except Exception:
            pass
        raise AutomationError("timezone", "无法读取手机本地时区，为避免错时预约已停止。")

    def _refresh_runtime_profile(self) -> None:
        """Detect the exact Studio/iOS/screen/language tuple before UI work."""
        self.create_tab_y_ratios = tuple(
            getattr(self, "create_tab_y_ratios", CREATE_TAB_Y_RATIOS)
        )
        self.create_upload_coordinate_ratios = tuple(
            getattr(
                self,
                "create_upload_coordinate_ratios",
                CREATE_UPLOAD_COORDINATE_RATIOS,
            )
        )
        self.schedule_row_ratio = tuple(
            getattr(self, "schedule_row_ratio", DEFAULT_SCHEDULE_ROW_RATIO)
        )
        self.next_button_ratio = tuple(
            getattr(self, "next_button_ratio", (0.82, 0.93))
        )
        device = getattr(self, "device", {})
        device = device if isinstance(device, dict) else {}
        info: dict[str, Any] = {}
        screen: dict[str, Any] = {}
        device_info: dict[str, Any] = {}
        try:
            value = self.ui.tool("get_app_info", {"bundle_id": STUDIO_BUNDLE_ID})
            info = value if isinstance(value, dict) else {}
        except Exception:
            pass
        try:
            value = self.ui.tool("get_screen_info", {})
            screen = value if isinstance(value, dict) else {}
        except Exception:
            pass
        try:
            value = self.ui.tool("get_device_info", {})
            device_info = value if isinstance(value, dict) else {}
        except Exception:
            pass
        language = str(device.get("language") or "zh").strip() or "zh"
        try:
            language_result = run_shell(
                self.ui.client,
                "defaults read NSGlobalDomain AppleLanguages 2>/dev/null | head -n 3",
                timeout=5,
            )
            language_output = str(language_result.get("output") or "").casefold()
            if "en" in language_output:
                language = "en"
            elif "zh" in language_output or "zh-hans" in language_output:
                language = "zh"
        except Exception:
            pass
        studio_version = str(info.get("short_version") or info.get("version") or "")
        ios_version = str(
            device_info.get("systemVersion")
            or device.get("ios_version")
            or ""
        )
        width = int(screen.get("width") or device.get("screen_width") or 0)
        height = int(screen.get("height") or device.get("screen_height") or 0)
        if width > 0 and height > 0:
            self.ui._screen_width = float(width)
            self.ui._screen_height = float(height)
        profile = selector_profile(
            ios_version,
            language,
            studio_version=studio_version,
            screen_width=width,
            screen_height=height,
        )
        self.selector_profile_name = apply_selector_overrides({"selectors": profile})
        saved = load_ui_profile_snapshot(self.selector_profile_name)
        controls = saved.get("controls") if isinstance(saved.get("controls"), dict) else {}
        saved_tab_ratios = controls.get("create_tab_y_ratios")
        if isinstance(saved_tab_ratios, list) and saved_tab_ratios:
            try:
                self.create_tab_y_ratios = tuple(
                    float(value) for value in saved_tab_ratios
                )
            except (TypeError, ValueError):
                pass
        saved_upload_ratios = controls.get("create_upload_coordinate_ratios")
        if isinstance(saved_upload_ratios, list) and saved_upload_ratios:
            try:
                self.create_upload_coordinate_ratios = tuple(
                    (float(pair[0]), float(pair[1]))
                    for pair in saved_upload_ratios
                    if isinstance(pair, (list, tuple)) and len(pair) == 2
                )
            except (TypeError, ValueError):
                pass
        saved_schedule_row = controls.get("schedule_row_ratio")
        if isinstance(saved_schedule_row, (list, tuple)) and len(saved_schedule_row) == 2:
            try:
                saved_ratio = (
                    float(saved_schedule_row[0]),
                    float(saved_schedule_row[1]),
                )
                # Existing installs saved the old row position before live
                # calibration. Ignore that one value, but keep any other
                # screen-specific calibration chosen by the user.
                if not (
                    abs(saved_ratio[0] - LEGACY_SCHEDULE_ROW_RATIO[0]) < 0.01
                    and abs(saved_ratio[1] - LEGACY_SCHEDULE_ROW_RATIO[1]) < 0.01
                ):
                    self.schedule_row_ratio = saved_ratio
            except (TypeError, ValueError):
                pass
        saved_next_button = controls.get("next_button_ratio")
        if isinstance(saved_next_button, (list, tuple)) and len(saved_next_button) == 2:
            try:
                self.next_button_ratio = (
                    float(saved_next_button[0]),
                    float(saved_next_button[1]),
                )
            except (TypeError, ValueError):
                pass
        saved_picker_rows = controls.get("picker_rows_per_swipe")
        if isinstance(saved_picker_rows, dict):
            loaded_rows: dict[str, float] = {}
            for column in ("date", "hour", "minute"):
                try:
                    value = float(saved_picker_rows.get(column))
                except (TypeError, ValueError):
                    continue
                if 4.0 <= value <= 14.0:
                    loaded_rows[column] = value
            if loaded_rows:
                self._picker_rows_per_swipe = loaded_rows
        self.runtime_profile = {
            "profile": self.selector_profile_name,
            "ios_version": ios_version,
            "studio_version": studio_version,
            "language": language,
            "screen_width": width,
            "screen_height": height,
            "machine": str(device_info.get("machine") or ""),
            "controls": {
                "create_tab_y_ratios": list(self.create_tab_y_ratios),
                "create_upload_coordinate_ratios": [
                    list(pair) for pair in self.create_upload_coordinate_ratios
                ],
                "schedule_row_ratio": list(self.schedule_row_ratio),
                "next_button_ratio": list(self.next_button_ratio),
                "picker_rows_per_swipe": dict(
                    getattr(self, "_picker_rows_per_swipe", {})
                ),
            },
        }
        config_path = save_ui_profile_snapshot(
            self.selector_profile_name,
            {
                "runtime": {
                    key: value
                    for key, value in self.runtime_profile.items()
                    if key != "controls"
                },
                "controls": self.runtime_profile["controls"],
                "selectors": {
                    name: list(globals().get(name) or ())
                    for name in (
                        "CREATE_TAB_MARKERS",
                        "CREATE_ENTRY_MARKERS",
                        "CREATE_PAGE_MARKERS",
                        "RECENT_MARKERS",
                        "VIDEO_FILTER_MARKERS",
                        "NEXT_MARKERS",
                        "CAPTION_MARKERS",
                        "SCHEDULE_MARKERS",
                        "DATE_MARKERS",
                        "TIME_MARKERS",
                        "DONE_MARKERS",
                        "SUBMIT_MARKERS",
                        "SUCCESS_MARKERS",
                    )
                },
            },
        )
        self.runtime_profile["config_path"] = str(config_path)
        emit_progress(
            "ui_profile",
            f"页面配置 {self.selector_profile_name} · Studio {studio_version or '未知'}",
        )

    def _dismiss_studio_overlays(self) -> None:
        dismiss = getattr(self.ui, "dismiss_overlays", None)
        if not callable(dismiss):
            return
        try:
            dismiss()
        except Exception:
            pass

    def _wait_for_create_page_safely(self, *, timeout: float) -> list[str] | None:
        self._dismiss_studio_overlays()
        return self._wait_for_create_page(timeout=timeout)

    def _save_create_page_diagnostics(self) -> str:
        output_dir = getattr(self, "output_dir", None)
        if output_dir is None:
            return ""
        image_path = Path(output_dir) / "发布入口失败.jpg"
        text_path = Path(output_dir) / "发布入口失败.txt"
        try:
            client = getattr(self.ui, "client", None)
            screenshot = getattr(client, "screenshot_jpeg", None)
            if callable(screenshot):
                image_path.write_bytes(screenshot())
            texts = self.ui.texts(include_ocr=True)
            text_path.write_text("\n".join(texts), encoding="utf-8")
            return str(image_path)
        except Exception:
            return ""

    def _open_create_page(self) -> None:
        width, height = self.ui.screen_size()
        if self._wait_for_create_page_safely(timeout=5.0) is not None:
            return

        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        for restart_attempt in range(2):
            self._dismiss_studio_overlays()
            if self._tap_create_tab(width, height, accessibility_first=True):
                texts = self._wait_for_create_page_safely(timeout=5.0)
                if texts is not None:
                    return

            # Different iPhone safe areas place the bottom icon at different
            # heights. Try the icon and label zones instead of the very bottom
            # home-indicator area only.
            for y_ratio in getattr(self, "create_tab_y_ratios", CREATE_TAB_Y_RATIOS):
                self._tap_create_tab(
                    width,
                    height,
                    accessibility_first=False,
                    coordinate_ratio=y_ratio,
                )
                texts = self._wait_for_create_page_safely(timeout=3.5)
                if texts is not None:
                    return

            if self._tap_marker_fast(
                CREATE_TAB_MARKERS + ("开始创作", "Start creating"),
                exact=True,
                max_y=height * 0.22,
            ):
                texts = self._wait_for_create_page_safely(timeout=4.0)
                if texts is not None:
                    return

            if restart_attempt == 1:
                break

            emit_progress("create_page", "创作页没有切换，正在重新打开 TikTok Studio")
            try:
                self.ui.restart_app_clean(STUDIO_BUNDLE_ID)
            except AutomationError as error:
                raise AutomationError(
                    "create_page",
                    f"重新打开 TikTok Studio 失败：{clean(error.detail, 260)}",
                ) from error
            home_texts = self._wait_for_markers(
                CREATE_TAB_MARKERS + blockers,
                timeout=18.0,
            )
            if home_texts is None:
                break
            blocker = blocking_page_error(home_texts)
            if blocker is not None:
                raise AutomationError(*blocker)

        current = " / ".join(self.ui.texts(include_ocr=True)[:16])
        detail = "没有找到 TikTok Studio 的发布视频入口。"
        if current:
            detail += f" 当前页面：{clean(current, 360)}"
        diagnostic = self._save_create_page_diagnostics()
        if diagnostic:
            detail += f" 现场已保存：{diagnostic}"
        raise AutomationError("create_page", detail)

    def _wait_for_create_page(self, *, timeout: float) -> list[str] | None:
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        # The Studio home feed also contains the same "Upload" and editor
        # shortcuts as the create tab. Only the drafts section distinguishes
        # the real create page from that inert home feed.
        ready_markers = CREATE_DRAFT_MARKERS + blockers
        texts = self._wait_for_markers(
            ready_markers + blockers,
            timeout=timeout,
        )
        if texts is None:
            return None
        blocker = blocking_page_error(texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if contains_text(texts, CREATE_DRAFT_MARKERS):
            return texts
        return None

    def _tap_create_tab(
        self,
        width: float,
        height: float,
        *,
        accessibility_first: bool,
        coordinate_ratio: float | None = None,
    ) -> bool:
        if accessibility_first:
            nodes = self.ui.nodes(include_ocr=False)
            node = find_text_node(
                nodes,
                CREATE_TAB_MARKERS,
                exact=True,
                min_y=height * 0.70,
            )
            if node is not None and self.ui.tap_node(node):
                return True
            return self._tap_marker_fast(
                CREATE_TAB_MARKERS,
                exact=False,
                min_y=height * 0.70,
            )
        if coordinate_ratio is None:
            coordinate_ratio = getattr(
                self,
                "create_tab_y_ratios",
                CREATE_TAB_Y_RATIOS,
            )[0]
        self.ui.tap_xy(width * 0.5, height * coordinate_ratio)
        return True

    def _wait_for_photo_picker(self, *, timeout: float) -> list[str] | None:
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self._dismiss_studio_overlays()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            texts = self._wait_for_markers(
                PHOTO_PICKER_PAGE_MARKERS + blockers,
                timeout=min(1.1, remaining),
            )
            if texts is not None:
                return texts
        return None

    def _photo_picker_next_enabled(self) -> bool:
        """Read the picker button color because its accessibility state is stale."""
        width, height = self.ui.screen_size()
        nodes = self.ui.nodes(include_ocr=False)
        next_node = find_text_node(
            nodes,
            NEXT_MARKERS,
            exact=True,
            min_y=height * 0.80,
        )
        rect = node_rect(next_node) if next_node is not None else None
        if rect is None:
            return False
        x, y, button_width, button_height = rect
        client = getattr(self.ui, "client", None)
        screenshot_jpeg = getattr(client, "screenshot_jpeg", None)
        if not callable(screenshot_jpeg):
            # Test doubles and legacy clients do not expose pixels. They are
            # still required to prove that the next page marker appears.
            return True
        image_bytes = self._screen_bytes()
        if not image_bytes:
            return False
        try:
            image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        except Exception:
            return False
        sample_y = min(
            image.height - 1,
            max(0, round(y + min(8.0, button_height * 0.20))),
        )
        samples: list[tuple[int, int, int]] = []
        for ratio in (0.25, 0.50, 0.75):
            sample_x = min(
                image.width - 1,
                max(0, round(x + button_width * ratio)),
            )
            samples.append(image.getpixel((sample_x, sample_y)))
        return all(red >= 180 and green <= 130 for red, green, _blue in samples)

    def _wait_for_photo_picker_selection(self, *, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while True:
            if self._photo_picker_next_enabled():
                return True
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            time.sleep(min(0.12, remaining))

    def _open_video_picker_entry(self) -> list[str] | None:
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        if self._wait_for_create_page_safely(timeout=0.8) is None:
            self._open_create_page()
        time.sleep(0.12)
        self._dismiss_studio_overlays()
        entry_sent = self._tap_video_entry_fast()
        if entry_sent:
            picker_texts = self._wait_for_photo_picker(
                timeout=PHOTO_PICKER_ENTRY_TIMEOUT_SECONDS,
            )
            if picker_texts is not None:
                return picker_texts

        self._dismiss_studio_overlays()
        current_texts = self.ui.texts(include_ocr=True)
        blocker = blocking_page_error(current_texts)
        if blocker is not None:
            return current_texts
        if contains_text(current_texts, PHOTO_PICKER_PAGE_MARKERS):
            return current_texts
        if not contains_text(
            current_texts,
            CREATE_DRAFT_MARKERS + CREATE_TAB_MARKERS,
        ):
            current_texts = self._recover_video_picker_entry()
            if current_texts is not None:
                return current_texts
            return None

        emit_progress(
            "video_entry",
            "上传入口没有响应，正在用无障碍控件重试一次",
        )
        if self._tap_marker_fast(("Upload", "上传"), exact=True):
            picker_texts = self._wait_for_photo_picker(
                timeout=PHOTO_PICKER_ENTRY_TIMEOUT_SECONDS,
            )
            if picker_texts is not None:
                return picker_texts

        # A stale Studio create page can expose an inert Upload control. Only
        # reset the touch channel after the cheap coordinate/AX paths fail.
        recovered_texts = self._recover_video_picker_entry()
        if recovered_texts is not None:
            return recovered_texts
        frontmost = getattr(self.ui, "frontmost_bundle", None)
        if callable(frontmost):
            try:
                if frontmost() != STUDIO_BUNDLE_ID:
                    raise AutomationError(
                        "video_entry",
                        "点击上传后 TikTok Studio 被切到后台，正在重新打开创作页。",
                    )
            except AutomationError:
                raise
            except Exception:
                pass
        return None

    def _tap_video_entry_fast(self) -> bool:
        # On the calibrated create page, the raw button point is both faster and
        # more reliable than an accessibility action on Studio 44 / iOS 16.
        screen_size = getattr(self.ui, "screen_size", None)
        tap_xy = getattr(self.ui, "tap_xy", None)
        if callable(screen_size) and callable(tap_xy):
            try:
                width, height = screen_size()
                ratios = getattr(
                    self,
                    "create_upload_coordinate_ratios",
                    CREATE_UPLOAD_COORDINATE_RATIOS,
                )
                x_ratio, y_ratio = ratios[0]
                try:
                    tap_xy(
                        width * x_ratio,
                        height * y_ratio,
                        settle_seconds=0.06,
                        refresh_size=False,
                    )
                except TypeError:
                    tap_xy(width * x_ratio, height * y_ratio)
                return True
            except Exception:
                pass
        # Send exactly one raw touch on fallback UIs. A second accessibility
        # tap can cancel the upload transition on iPhone 8 / iOS 16.7.16.
        tap_element = getattr(self.ui, "tap_element", None)
        if callable(tap_element):
            try:
                if tap_element(("Upload", "上传"), exact=True):
                    return True
                if tap_element(CREATE_ENTRY_MARKERS, exact=False):
                    return True
            except Exception:
                pass
        if self._tap_marker_fast(("Upload", "上传"), exact=True):
            return True
        return self._tap_marker_fast(CREATE_ENTRY_MARKERS, exact=False)

    def _prepare_upload_touch_channel(self) -> None:
        """iOS 16 Studio needs one lock/wake after cold launch before Upload responds."""
        self._reset_touch_channel_with_lock_wake()
        try:
            create_ready = self._wait_for_create_page_safely(timeout=1.0) is not None
        except Exception:
            create_ready = False
        if not create_ready:
            self._open_create_page()
            time.sleep(CREATE_PAGE_SETTLE_SECONDS)

    def _reset_touch_channel_with_lock_wake(self) -> None:
        """Reset an iOS MCP touch session without discarding Studio form state."""
        emit_progress(
            "touch_recovery",
            "点击无响应，正在锁屏并唤醒以重置触摸通道",
        )
        try:
            self.ui.tool("press_power", {"duration": 100})
            time.sleep(0.2)
            unlocked = False
            for sequence in ("power_then_home", "home_twice", "auto"):
                try:
                    self.ui.tool(
                        "wake_and_home",
                        {
                            "sequence": sequence,
                            "duration": 100,
                            "delay_ms": 250,
                        },
                    )
                except Exception:
                    if sequence == "auto":
                        raise
                time.sleep(0.3)
                locked, screen_on = self._read_lock_state()
                if locked is not True and screen_on is not False:
                    unlocked = True
                    break
                if locked is True:
                    try:
                        self.ui.tool("press_home", {"duration": 100})
                    except Exception:
                        pass
                    time.sleep(0.25)
            if not unlocked:
                locked, screen_on = self._read_lock_state()
                raise AutomationError(
                    "touch_recovery",
                    f"锁屏唤醒后仍不可操作（locked={locked}, screen_on={screen_on}）。",
                )
            studio_still_frontmost = self._studio_is_frontmost()
            if not studio_still_frontmost:
                emit_progress(
                    "touch_recovery",
                    "Studio 已被系统切到后台，正在恢复当前会话，不清理表单",
                )
                self.ui.launch_app(STUDIO_BUNDLE_ID)
            else:
                emit_progress(
                    "touch_recovery",
                    "Studio 仍在前台，已保留当前文案/预约页面",
                )
            self.ui.wait_for_frontmost(STUDIO_BUNDLE_ID, timeout=8.0)
            if not studio_still_frontmost:
                self._dismiss_studio_overlays()
        except Exception as error:
            raise AutomationError(
                "touch_recovery",
                f"锁屏唤醒恢复失败：{clean(error, 300)}",
            ) from error
        emit_progress("touch_recovery", "锁屏唤醒完成，触摸通道已刷新并保留页面")

    def _studio_is_frontmost(self) -> bool:
        """Return whether the active app is still Studio after a wake."""
        getter = getattr(self.ui, "frontmost_bundle", None)
        if not callable(getter):
            return False
        try:
            return getter() == STUDIO_BUNDLE_ID
        except Exception:
            return False

    def _read_lock_state(self) -> tuple[bool | None, bool | None]:
        """Read only lock/screen flags; never guess that a phone is unlocked."""
        try:
            state = self.ui.tool("get_screen_info", {})
        except Exception:
            return None, None
        if not isinstance(state, dict):
            return None, None
        nested = state.get("device_state") or state.get("deviceState") or {}
        merged: dict[str, Any] = {}
        if isinstance(nested, dict):
            merged.update(nested)
        merged.update(state)

        def as_bool(value: Any) -> bool | None:
            if isinstance(value, bool):
                return value
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                normalized = value.strip().casefold()
                if normalized in {"true", "yes", "1", "on", "locked"}:
                    return True
                if normalized in {"false", "no", "0", "off", "unlocked"}:
                    return False
            return None

        locked = as_bool(
            merged.get("locked", merged.get("is_locked", merged.get("isLocked")))
        )
        screen_on = as_bool(
            merged.get(
                "screen_on",
                merged.get("screenOn", merged.get("is_screen_on")),
            )
        )
        return locked, screen_on

    def _recover_video_picker_entry(self) -> list[str] | None:
        emit_progress(
            "video_entry",
            "上传入口无响应，正在通过锁屏唤醒恢复触摸通道",
        )
        try:
            self._reset_touch_channel_with_lock_wake()
            try:
                create_ready = self._wait_for_create_page_safely(timeout=1.0) is not None
            except Exception:
                create_ready = False
            if not create_ready:
                self._open_create_page()
            time.sleep(CREATE_PAGE_SETTLE_SECONDS)
            if self._tap_video_entry_fast():
                picker_texts = self._wait_for_photo_picker(
                    timeout=PHOTO_PICKER_ENTRY_TIMEOUT_SECONDS,
                )
                if picker_texts is not None:
                    return picker_texts
        except AutomationError as error:
            emit_progress(
                "touch_recovery",
                f"锁屏唤醒后仍未打开相册：{clean(error.detail, 220)}",
            )

        emit_progress(
            "video_entry",
            "锁屏唤醒后仍无响应，正在冷启动 TikTok Studio 再试",
        )
        try:
            self.ui.restart_app_clean(STUDIO_BUNDLE_ID)
            self._open_create_page()
            time.sleep(CREATE_PAGE_SETTLE_SECONDS)
        except AutomationError as error:
            emit_progress(
                "video_entry",
                f"冷启动恢复失败：{clean(error.detail, 220)}",
            )
            return None
        if not self._tap_video_entry_fast():
            return None
        return self._wait_for_photo_picker(
            timeout=PHOTO_PICKER_ENTRY_TIMEOUT_SECONDS,
        )

    def _tap_next_button_fast(self) -> bool:
        """Tap Next by native AX text first, with a calibrated coordinate fallback."""
        tap_element = getattr(self.ui, "tap_element", None)
        if callable(tap_element):
            try:
                if tap_element(NEXT_MARKERS, exact=True):
                    return True
            except Exception:
                pass
        width, height = self.ui.screen_size()
        if abs(width - 375.0) > 1.0 or abs(height - 667.0) > 1.0:
            return False
        ratio = getattr(self, "next_button_ratio", (0.82, 0.93))
        try:
            x_ratio, y_ratio = float(ratio[0]), float(ratio[1])
        except (IndexError, TypeError, ValueError):
            x_ratio, y_ratio = 0.82, 0.93
        self.ui.tap_xy(
            width * x_ratio,
            height * y_ratio,
            settle_seconds=0.06,
            refresh_size=False,
        )
        return True

    def _select_video(
        self,
        album_index: int,
        item_number: int,
        filename: str,
    ) -> None:
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        picker_texts = self._open_video_picker_entry()
        if picker_texts is None:
            current_texts = self.ui.texts(include_ocr=True)
            blocker = blocking_page_error(current_texts)
            if blocker is not None:
                raise AutomationError(*blocker)
            if not contains_text(
                current_texts,
                CREATE_PAGE_MARKERS + CREATE_ENTRY_MARKERS + CREATE_TAB_MARKERS,
            ):
                raise AutomationError(
                    "video_entry",
                    "创作页已经跳走，没有找到“发布视频 / 上传视频”入口。",
                )
            raise AutomationError("photo_picker", "TikTok Studio 没有打开相册选择页。")
        blocker = blocking_page_error(picker_texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        # Prefer the video filter when the picker opens on all media.
        if self._tap_marker_fast(VIDEO_FILTER_MARKERS, exact=True, max_y=180):
            time.sleep(0.2)
        tile = self._find_media_tile(album_index, filename)
        if tile is None:
            raise AutomationError(
                "photo_picker",
                f"相册中没有找到 {filename}（备用序号 {album_index + 1}）。",
            )
        point = node_point(tile)
        if point is None:
            raise AutomationError("photo_picker", "相册视频没有可点击坐标。")
        self.selection_started_monotonic = time.monotonic()
        self.publish_completed_monotonic = 0.0
        if not self._tap_media_tile(tile):
            raise AutomationError("photo_picker", "相册视频格子无法点击。")
        if not self._wait_for_photo_picker_selection(timeout=1.1):
            # Repeating a thumbnail tap is safe; the disabled Next button cannot
            # leave the picker until the selection is visibly enabled.
            self.ui.tap_xy(
                *point,
                settle_seconds=0.28,
                refresh_size=False,
            )
            if not self._wait_for_photo_picker_selection(timeout=0.9):
                raise AutomationError(
                    "photo_picker",
                    f"第 {item_number} 条视频没有选中，下一步按钮仍未启用。",
                )
        emit_progress(
            "video_selected",
            f"已选中第 {item_number} 条视频 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )

        width, height = self.ui.screen_size()
        picker_next_ok = self._tap_next_button_fast()
        if not picker_next_ok:
            picker_next_ok = self._tap_marker_with_touch_retry(
                NEXT_MARKERS,
                exact=True,
                min_y=height * 0.80,
                expected_markers=VIDEO_EDITOR_MARKERS + CAPTION_MARKERS,
                change_timeout=0.55,
            )
        if not picker_next_ok:
            raise AutomationError(
                "editor",
                "视频已选中，但相册页“下一步”没有响应。",
            )
        emit_progress(
            "video_next",
            "已从相册进入视频编辑页 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )
        transition_texts = self._wait_for_marker_groups(
            (
                (CAPTION_MARKERS, False),
                (VIDEO_EDITOR_MARKERS, False),
            ),
            blockers=blockers,
            timeout=10.0,
        )
        if transition_texts is None:
            if self._tap_marker_with_touch_retry(
                NEXT_MARKERS,
                exact=True,
                min_y=height * 0.80,
                expected_markers=VIDEO_EDITOR_MARKERS + CAPTION_MARKERS,
                change_timeout=0.7,
            ):
                transition_texts = self._wait_for_marker_groups(
                    (
                        (CAPTION_MARKERS, False),
                        (VIDEO_EDITOR_MARKERS, False),
                    ),
                    blockers=blockers,
                    timeout=3.0,
                )
        if transition_texts is None:
            raise AutomationError("editor", "相册下一步后没有进入编辑页。")
        blocker = blocking_page_error(transition_texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if contains_text(transition_texts, CAPTION_MARKERS, exact=False):
            return
        editor_next_ok = self._tap_next_button_fast()
        if not editor_next_ok:
            editor_next_ok = self._tap_marker_with_touch_retry(
                NEXT_MARKERS,
                exact=True,
                min_y=height * 0.80,
                expected_markers=CAPTION_MARKERS,
                change_timeout=0.55,
            )
        if not editor_next_ok:
            raise AutomationError("editor", "编辑页“下一步”没有响应。")
        emit_progress(
            "video_next",
            "已从编辑页进入文案填写页 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )
        caption_texts = self._wait_for_marker_groups(
            ((CAPTION_MARKERS, False),),
            blockers=blockers,
            timeout=8.0,
        )
        if caption_texts is None:
            if self._tap_marker_with_touch_retry(
                NEXT_MARKERS,
                exact=True,
                min_y=height * 0.80,
                expected_markers=CAPTION_MARKERS,
                change_timeout=0.7,
            ):
                caption_texts = self._wait_for_marker_groups(
                    ((CAPTION_MARKERS, False),),
                    blockers=blockers,
                    timeout=3.0,
                )
        if caption_texts is None:
            raise AutomationError(
                "editor",
                f"第 {item_number} 条视频没有进入发布填写页。",
            )
        self._post_form_ready = True
        self._fresh_post_form = True
        emit_progress(
            "album_completed",
            "视频已选中并进入发布填写页 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )

    @staticmethod
    def _media_tile_matches_filename(text: str, filename: str) -> bool:
        value = str(text or "").strip()
        name = Path(filename).name
        if not value or not name:
            return False
        for candidate in (name, Path(name).stem):
            if candidate and re.search(
                rf"(?<![\w]){re.escape(candidate)}(?![\w])",
                value,
                flags=re.IGNORECASE,
            ):
                return True
        return False

    def _visible_media_tiles(self) -> list[dict[str, Any]]:
        width, height = self.ui.screen_size()
        nodes = self.ui.nodes(include_ocr=False)
        role_indexes: dict[str, int] = {}
        for node in nodes:
            role = str(node.get("role") or node.get("type") or "").strip().casefold()
            role_index = role_indexes.get(role, 0)
            role_indexes[role] = role_index + 1
            node["_ui_role"] = role
            node["_ui_role_index"] = role_index
        controls = {
            normalize(item)
            for item in (
                *CREATE_TAB_MARKERS,
                *RECENT_MARKERS,
                *VIDEO_FILTER_MARKERS,
                *NEXT_MARKERS,
                *DONE_MARKERS,
                "返回",
                "取消",
                "关闭",
                "Back",
                "Cancel",
                "Close",
            )
        }
        tiles: list[tuple[float, float, dict[str, Any]]] = []
        seen: set[tuple[int, int, int, int]] = set()
        for node in nodes:
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, tile_width, tile_height = rect
            if tile_width < 68 or tile_height < 68:
                continue
            if x < 0 or y < 65 or y + tile_height > height - 45:
                continue
            if tile_width > width * 0.92 or tile_height > height * 0.45:
                continue
            if node_text(node) and normalize(node_text(node)) in controls:
                continue
            key = (round(x), round(y), round(tile_width), round(tile_height))
            if key in seen:
                continue
            seen.add(key)
            tiles.append((y, x, node))
        tiles.sort(key=lambda item: (item[0], item[1]))
        return [item[2] for item in tiles]

    def _tap_media_tile(self, tile: dict[str, Any]) -> bool:
        """Tap a gallery cell by AX role/index, then fall back to coordinates."""
        role = str(tile.get("_ui_role") or "").strip()
        role_index = tile.get("_ui_role_index")
        if role and isinstance(role_index, int) and role_index >= 0:
            try:
                result = self.ui.tool(
                    "tap_element",
                    {"role": role, "index": role_index},
                )
                if result is not False and not (
                    isinstance(result, dict) and result.get("tapped") is False
                ):
                    time.sleep(0.18)
                    return True
            except Exception:
                pass
        point = node_point(tile)
        if point is None:
            return False
        self.ui.tap_xy(
            *point,
            settle_seconds=0.20,
            refresh_size=False,
        )
        return True

    @staticmethod
    def _tile_signature(
        tiles: Sequence[dict[str, Any]],
    ) -> tuple[tuple[tuple[int, int, int, int], str], ...]:
        signature = []
        for node in tiles:
            rect = node_rect(node)
            if rect is not None:
                signature.append(
                    (tuple(round(value) for value in rect), node_text(node))
                )
        return tuple(signature)

    def _find_media_tile(
        self,
        index: int,
        filename: str = "",
    ) -> dict[str, Any] | None:
        if index < 0:
            return None
        remaining = index
        tiles = self._visible_media_tiles()
        for _attempt in range(60):
            if filename:
                named_tile = next(
                    (
                        node
                        for node in tiles
                        if self._media_tile_matches_filename(node_text(node), filename)
                    ),
                    None,
                )
                if named_tile is not None:
                    return named_tile
            if remaining < len(tiles):
                return tiles[remaining]
            if not tiles:
                return None
            previous_signature = self._tile_signature(tiles)
            self.ui.swipe_up()
            refreshed = self._visible_media_tiles()
            if not refreshed or self._tile_signature(refreshed) == previous_signature:
                return None
            remaining = max(0, remaining - len(tiles))
            tiles = refreshed
        return None

    def _fill_caption(self, caption: str, hashtags: object) -> None:
        tag_text = " ".join(
            str(value).strip()
            for value in (hashtags if isinstance(hashtags, (list, tuple)) else [])
            if str(value).strip()
        )
        complete = " ".join(part for part in (caption.strip(), tag_text) if part)
        if not complete:
            raise AutomationError("caption", "这条视频没有可填写的文案。")
        if getattr(self, "_fresh_post_form", False):
            width, height = self.ui.screen_size()
            self.ui.tap_xy(
                width * 0.50,
                height * 0.44,
                settle_seconds=0.06,
                refresh_size=False,
            )
            self.ui.input_text(complete, settle_seconds=0.14)
            caption_prefix = caption.strip().split("#", 1)[0].strip()
            wanted = normalize(caption_prefix[:10]) or normalize(complete[:8])
            texts = self.ui.texts(include_ocr=False)
            if any(wanted in normalize(text) for text in texts if text):
                self._fresh_post_form = False
                self._caption_keyboard_dismissed = (
                    self._dismiss_caption_keyboard_fast()
                )
                return
            # The fixed coordinate only applies to the newly opened composer.
            # Fall through to the marker-based path when verification misses.
            self._fresh_post_form = False
        tap_element = getattr(self.ui, "tap_element", None)
        tapped_caption = False
        if callable(tap_element):
            try:
                tapped_caption = bool(tap_element(CAPTION_MARKERS, exact=False))
            except Exception:
                tapped_caption = False
        node = None if tapped_caption else self.ui.find_node(CAPTION_MARKERS, exact=False)
        if node is None:
            node = None if tapped_caption else self._largest_editable_node()
        if not tapped_caption and (
            node is None
            or not self.ui.tap_node(
                node,
                settle_seconds=0.16,
                refresh_size=False,
            )
        ):
            raise AutomationError("caption", "没有找到发布文案输入框。")
        time.sleep(0.2)
        node_value = node_text(node) if node is not None else ""
        is_empty_placeholder = any(
            text_matches(node_value, marker) for marker in CAPTION_MARKERS
        )
        if node is not None and not is_empty_placeholder:
            self._clear_caption_field(node)
        self.ui.input_text(complete, settle_seconds=0.18)
        # OCR often confuses Latin letters such as f/o in hashtags. Verify the
        # human-written caption prefix and leave hashtags to the exact input.
        caption_prefix = caption.strip().split("#", 1)[0].strip()
        caption_probe = normalize(caption_prefix[:10]) or normalize(complete[:8])
        wanted = caption_probe
        current_texts = self.ui.texts(include_ocr=False)
        texts = (
            current_texts
            if any(wanted in normalize(text) for text in current_texts if text)
            else None
        )
        if texts is None:
            texts = self._wait_for_caption(
                wanted,
                timeout=CAPTION_VERIFY_TIMEOUT_SECONDS,
            )
        if texts is None:
            # The first text event can land while the keyboard is animating.
            # Replace the field instead of typing a second copy into it.
            self._clear_caption_field(node)
            self.ui.input_text(complete, settle_seconds=0.18)
            texts = self._wait_for_caption(
                wanted,
                timeout=CAPTION_VERIFY_TIMEOUT_SECONDS,
            )
        if texts is None:
            raise AutomationError("caption", "发布文案输入后无法复核，已停止以免发错内容。")
        self._caption_keyboard_dismissed = self._dismiss_caption_keyboard_fast()
        emit_progress(
            "caption_completed",
            "文案已填写并复核 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )

    @staticmethod
    def _keyboard_is_visible_in_nodes(nodes: Sequence[dict[str, Any]]) -> bool:
        return any(
            text_matches(node_text(node), marker, exact=True)
            for node in nodes
            for marker in KEYBOARD_KEY_MARKERS
        )

    def _dismiss_caption_keyboard_if_visible(self) -> bool:
        """Dismiss the caption keyboard using the proven native Back control."""
        try:
            nodes = self.ui.nodes(include_ocr=False)
        except Exception:
            return False
        if not self._keyboard_is_visible_in_nodes(nodes):
            return False
        tap_element = getattr(self.ui, "tap_element", None)
        if callable(tap_element):
            try:
                if tap_element(("返回", "Back"), exact=True):
                    time.sleep(0.14)
                    try:
                        refreshed = self.ui.nodes(include_ocr=False)
                    except Exception:
                        return True
                    if not self._keyboard_is_visible_in_nodes(refreshed):
                        return True
            except Exception:
                pass
        try:
            width = float(getattr(self.ui, "_screen_width", 375.0))
            height = float(getattr(self.ui, "_screen_height", 667.0))
            self.ui.tool(
                "swipe_screen",
                {
                    "fromX": round(width * 0.52),
                    "fromY": round(height * 0.45),
                    "toX": round(width * 0.52),
                    "toY": round(height * 0.87),
                    "duration": 270,
                    "steps": 12,
                },
            )
            time.sleep(0.28)
        except Exception:
            return False
        try:
            nodes = self.ui.nodes(include_ocr=False)
        except Exception:
            return True
        return not self._keyboard_is_visible_in_nodes(nodes)

    def _dismiss_caption_keyboard_fast(self) -> bool:
        """Hide the keyboard through the native Back control and verify it."""
        try:
            nodes = self.ui.nodes(include_ocr=False)
        except Exception:
            return False
        if not self._keyboard_is_visible_in_nodes(nodes):
            return True
        tap_element = getattr(self.ui, "tap_element", None)
        if callable(tap_element):
            try:
                if tap_element(("返回", "Back"), exact=True):
                    time.sleep(0.14)
                    try:
                        refreshed = self.ui.nodes(include_ocr=False)
                    except Exception:
                        return True
                    if not self._keyboard_is_visible_in_nodes(refreshed):
                        return True
            except Exception:
                pass
        return self._dismiss_caption_keyboard_if_visible()

    def _schedule_picker_is_open(self, local_time: datetime) -> bool:
        try:
            nodes = self.ui.nodes(include_ocr=False)
        except Exception:
            return False
        texts = [node_text(node) for node in nodes if node_text(node)]
        if not contains_text(texts, DONE_MARKERS, exact=True):
            return False
        selection = self._picker_selection(local_time)
        return selection.get("date") is not None and (
            selection.get("hour") is not None
            or selection.get("minute") is not None
        )

    def _clear_caption_field(self, node: dict[str, Any] | None) -> None:
        """Clear an existing caption without walking hundreds of backspaces."""
        point = node_point(node) if node is not None else None
        if point is None:
            width, height = self.ui.screen_size()
            point = (width * 0.50, height * 0.44)
        if point is not None:
            self.ui.tap_xy(*point)
            time.sleep(0.15)
            try:
                self.ui.tool(
                    "long_press",
                    {"x": round(point[0]), "y": round(point[1]), "duration": 650},
                )
                time.sleep(0.15)
            except Exception:
                pass
            if self.ui.tap_marker(("全选", "Select All"), exact=True):
                self.ui.press_key("backspace")
                time.sleep(0.15)
                return
        self.ui.clear_focused_field(anchor=point)

    def _wait_for_caption(self, wanted: str, *, timeout: float) -> list[str] | None:
        width, height = self.ui.screen_size()
        caption_region = {
            "x": 0.0,
            "y": height * 0.09,
            "width": width,
            "height": height * 0.25,
        }
        deadline = time.monotonic() + timeout
        first_poll = True
        next_ocr_at = time.monotonic()
        while True:
            now = time.monotonic()
            include_ocr = not first_poll and now >= next_ocr_at
            first_poll = False
            texts = self.ui.texts(
                include_ocr=include_ocr,
                ocr_region=caption_region,
            )
            if include_ocr:
                next_ocr_at = now + 0.5
            if any(wanted in normalize(text) for text in texts if text):
                return texts
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            time.sleep(min(0.06, remaining))

    def _largest_editable_node(self) -> dict[str, Any] | None:
        width, height = self.ui.screen_size()
        candidates: list[tuple[float, dict[str, Any]]] = []
        for node in self.ui.nodes(include_ocr=False):
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, w, h = rect
            if w < width * 0.55 or h < 38 or y < 90 or y > height * 0.82:
                continue
            marker = str(node.get("type") or node.get("role") or "").casefold()
            if bool(node.get("editable")) or "text" in marker or "field" in marker:
                candidates.append((w * h, node))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]

    def _configure_schedule(self, local_time: datetime) -> None:
        # _fill_caption already dismissed the keyboard with one explicit swipe.
        # Only pay for another full AX snapshot when that step did not run.
        if not getattr(self, "_caption_keyboard_dismissed", False):
            self._dismiss_caption_keyboard_if_visible()
        if self._configure_schedule_fast(local_time):
            if not self._wait_for_schedule_time(local_time, timeout=1.1):
                raise AutomationError(
                    "schedule_time",
                    f"快速预约后无法复核 {local_time:%Y-%m-%d %H:%M}，已停止，未提交。",
                )
            emit_progress(
                "schedule_completed",
                "预约时间已复核 · "
                f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
            )
            return
        picker_selection = self._picker_selection(local_time)
        picker_ready = picker_selection.get("date") is not None and (
            picker_selection.get("hour") is not None
            or picker_selection.get("minute") is not None
        )
        if picker_ready:
            self._set_schedule_datetime(local_time, selection=picker_selection)
            if not self._wait_for_schedule_time(local_time, timeout=2.5):
                raise AutomationError(
                    "schedule_time",
                    f"无法确认预约时间 {local_time:%Y-%m-%d %H:%M}，已停止，未提交发布。",
                )
            emit_progress(
                "schedule_completed",
                "预约时间已复核 · "
                f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
            )
            return
        if not self._tap_marker_with_touch_retry(
            SCHEDULE_MARKERS,
            exact=False,
            expected_markers=("发布时间", "Schedule time"),
            change_timeout=0.7,
        ):
            if self._tap_marker_fast(MORE_MARKERS, exact=False):
                time.sleep(0.25)
            if not self._tap_marker_with_touch_retry(
                SCHEDULE_MARKERS,
                exact=False,
                expected_markers=("发布时间", "Schedule time"),
                change_timeout=0.7,
            ):
                raise AutomationError("schedule", "发布页没有找到“定时发布 / Schedule”。")
        self._set_schedule_datetime(local_time)
        if not self._wait_for_schedule_time(local_time, timeout=2.5):
            raise AutomationError(
                "schedule_time",
                f"无法确认预约时间 {local_time:%Y-%m-%d %H:%M}，已停止，未提交发布。",
            )
        emit_progress(
            "schedule_completed",
            "预约时间已复核 · "
            f"{time.monotonic() - self.selection_started_monotonic:.1f} 秒",
        )

    def _configure_schedule_fast(self, local_time: datetime) -> bool:
        """Use the known Studio form layout before the slower marker fallback."""
        width, height = self.ui.screen_size()
        # The schedule row is the middle option above More options. Tap once:
        # repeating the same coordinate after the sheet opens can change the
        # wheel selection and force an otherwise fast run into the slow path.
        # On iOS 16 the left side of this row toggles scheduling off. The date
        # and time value on the right is the control that opens the wheel sheet.
        schedule_row_ratio = getattr(
            self,
            "schedule_row_ratio",
            DEFAULT_SCHEDULE_ROW_RATIO,
        )
        center_x = width * schedule_row_ratio[0]
        schedule_y = height * schedule_row_ratio[1]
        self.ui.tap_xy(
            center_x,
            schedule_y,
            settle_seconds=0.065,
            refresh_size=False,
        )
        # Read the picker itself instead of first paying for a separate
        # wait_for_element RPC. The first successful snapshot is exactly what
        # the wheel calibration needs.
        time.sleep(0.10)
        deadline = time.monotonic() + 1.1
        selection: dict[str, Any] | None = None
        nodes: Sequence[dict[str, Any]] = []
        while True:
            nodes = self.ui.nodes(include_ocr=False)
            selection = self._picker_selection_from_nodes(nodes, local_time)
            if self._picker_selection_ready(selection):
                break
            if time.monotonic() >= deadline:
                break
            time.sleep(0.12)
        if not self._picker_selection_ready(selection):
            try:
                debug_dir = self.output_dir / "快速预约诊断"
                debug_dir.mkdir(parents=True, exist_ok=True)
                (debug_dir / "picker_nodes.json").write_text(
                    json.dumps(nodes, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                (debug_dir / "picker_screen.jpg").write_bytes(
                    self.ui.client.screenshot_jpeg()
                )
            except Exception:
                pass
            return False
        if self._set_schedule_datetime_fast(local_time, selection):
            return True
        try:
            debug_dir = self.output_dir / "快速预约诊断"
            debug_dir.mkdir(parents=True, exist_ok=True)
            (debug_dir / "wheel_nodes.json").write_text(
                json.dumps(self.ui.nodes(include_ocr=False), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            (debug_dir / "wheel_screen.jpg").write_bytes(
                self.ui.client.screenshot_jpeg()
            )
        except Exception:
            pass
        self._close_schedule_picker_fast()
        return False

    @staticmethod
    def _picker_selection_ready(selection: dict[str, Any] | None) -> bool:
        return isinstance(selection, dict) and selection.get("date") is not None and (
            selection.get("hour") is not None
            or selection.get("minute") is not None
        )

    @staticmethod
    def _short_picker_delta(column: str, current: int, target: int) -> int:
        # Studio 44 on iOS 16 clamps its time wheels at 00/23/59 instead of
        # wrapping. Always move in the visible numeric direction; trying to
        # "shortcut" 45 -> 13 through 59 costs a full recovery cycle.
        return int(target) - int(current)

    def _tap_picker_row_offset(
        self,
        column: str,
        target: int,
        current: int,
        selection: dict[str, Any],
    ) -> bool:
        point = selection.get("points", {}).get(column)
        if point is None:
            return False
        delta = self._short_picker_delta(column, current, target)
        if delta == 0:
            return True
        if abs(delta) > PICKER_VISIBLE_TAP_RADIUS:
            return False
        self.ui.tap_xy(
            point[0],
            point[1] + delta * PICKER_ROW_SPACING,
            settle_seconds=0.10,
            refresh_size=False,
        )
        return True

    def _adjust_picker_value_fast(
        self,
        column: str,
        target: int,
        selection: dict[str, Any],
        local_time: datetime,
    ) -> bool:
        """Change one wheel value using calibrated batch swipes and verify it.

        Per-row taps are too slow for a 59 -> 20 minute correction and are the
        most likely gesture to be silently dropped on iOS 16. Use the existing
        wheel calibration, which also verifies and recovers the touch channel.
        """
        current = selection.get(column)
        if current is None:
            return False
        if int(current) == int(target):
            return True

        delta = self._short_picker_delta(column, int(current), int(target))
        emit_progress(
            "schedule_fast",
            f"{column} {current} → {target}（最短路径 {delta:+d}，批量滑动）",
        )
        changed = self._scroll_picker_column(
            column,
            int(target),
            local_time=local_time,
            selection=selection,
        )
        refreshed = self._picker_selection(local_time)
        value = refreshed.get(column)
        emit_progress(
            "schedule_fast",
            f"{column} 复核：{value} / 目标 {target} · "
            f"{'通过' if changed and value == target else '未通过'}",
        )
        if changed and value == target:
            return True

        # One explicit recovery covers a bridge that stopped accepting swipes.
        # If the picker closed, the caller safely falls back to reopening it.
        self._reset_touch_channel_with_lock_wake()
        time.sleep(0.20)
        refreshed = self._picker_selection(local_time)
        if not self._picker_selection_ready(refreshed):
            return False
        if refreshed.get(column) == target:
            return True
        changed = self._scroll_picker_column(
            column,
            int(target),
            local_time=local_time,
            selection=refreshed,
        )
        value = self._picker_selection(local_time).get(column)
        emit_progress(
            "schedule_fast",
            f"{column} 触摸重置后复核：{value} / 目标 {target} · "
            f"{'通过' if changed and value == target else '未通过'}",
        )
        return changed and value == target

    def _swipe_picker_column_distance(
        self,
        column: str,
        target: int,
        current: int,
        selection: dict[str, Any],
    ) -> bool:
        point = selection.get("points", {}).get(column)
        if point is None:
            return False
        delta = self._short_picker_delta(column, current, target)
        x = point[0]
        center_y = point[1]
        remaining = delta
        while remaining:
            direction = 1 if remaining > 0 else -1
            # One-row taps are slower by a few hundred milliseconds but avoid
            # wheel momentum overshooting the target by one value.
            step = direction
            try:
                self.ui.tap_xy(
                    x,
                    center_y + step * PICKER_ROW_SPACING,
                    settle_seconds=0.075,
                    refresh_size=False,
                )
            except Exception:
                return False
            remaining -= step
        return True

    def _select_visible_picker_date(
        self,
        local_time: datetime,
        selection: dict[str, Any],
    ) -> bool:
        if selection.get("date") == local_time.date():
            return True
        for row_date, point, rect in selection.get("date_rows", []):
            if row_date != local_time.date():
                continue
            if rect[3] > self.ui.screen_size()[1] * 0.13:
                continue
            self.ui.tap_xy(
                point[0],
                point[1],
                settle_seconds=0.10,
                refresh_size=False,
            )
            return True
        current = selection.get("date")
        point = selection.get("points", {}).get("date")
        if current is not None and point is not None:
            delta = (local_time.date() - current).days
            if 0 < abs(delta) <= PICKER_VISIBLE_TAP_RADIUS:
                self.ui.tap_xy(
                    point[0],
                    point[1] + delta * PICKER_ROW_SPACING,
                    settle_seconds=0.10,
                    refresh_size=False,
                )
                return True
        return False

    def _set_schedule_datetime_fast(
        self,
        local_time: datetime,
        selection: dict[str, Any] | None,
    ) -> bool:
        if not isinstance(selection, dict):
            return False

        started_at = time.monotonic()
        # Date and the two time wheels are independent columns. Send all three
        # predicted corrections first and pay for only one AX snapshot at the
        # end instead of re-reading the whole page between every column.
        if selection.get("date") != local_time.date():
            if not self._select_visible_picker_date(local_time, selection):
                emit_progress("schedule_fast", "日期滚轮没有可点击的目标行。")
                return False
        for column, target in (
            ("hour", local_time.hour),
            ("minute", local_time.minute),
        ):
            current = selection.get(column)
            if current is None:
                emit_progress("schedule_fast", f"{column} 当前值读取失败。")
                return False
            if current == target:
                continue
            if not self._send_picker_adjustment_fast(
                column,
                int(target),
                selection,
            ):
                emit_progress("schedule_fast", f"{column} 滚轮无法定位。")
                return False

        # One final verification is mandatory before tapping Done. Small
        # residual errors are corrected without going back to the slow path.
        time.sleep(0.18)
        for _round in range(max(3, PICKER_FAST_ROUNDS)):
            current_selection = self._picker_selection(local_time)
            if not self._picker_selection_ready(current_selection):
                emit_progress("schedule_fast", "预约面板复核读取失败。")
                return False
            if self._picker_datetime_matches(current_selection, local_time):
                self._tap_schedule_done(current_selection)
                emit_progress(
                    "schedule_fast",
                    "滚轮批量修正完成 · "
                    f"{time.monotonic() - started_at:.2f} 秒",
                )
                return True

            adjusted = False
            for column, target in (
                ("date", local_time.date()),
                ("hour", local_time.hour),
                ("minute", local_time.minute),
            ):
                current = current_selection.get(column)
                if current is None:
                    emit_progress("schedule_fast", f"复核时 {column} 为空。")
                    return False
                if current == target:
                    continue
                if column == "date":
                    adjusted = self._select_visible_picker_date(
                        local_time,
                        current_selection,
                    )
                else:
                    adjusted = self._send_picker_adjustment_fast(
                        column,
                        int(target),
                        current_selection,
                    )
                if adjusted:
                    break
            if not adjusted:
                emit_progress("schedule_fast", "预约时间无法精确复核。")
                return False
            time.sleep(0.14)
        return False

    def _send_picker_adjustment_fast(
        self,
        column: str,
        target: int,
        selection: dict[str, Any],
    ) -> bool:
        """Predict a wheel correction without an immediate full AX re-read."""
        current = selection.get(column)
        point = selection.get("points", {}).get(column)
        if current is None or point is None:
            return False
        delta = self._short_picker_delta(column, int(current), int(target))
        if delta == 0:
            return True
        x, center_y = point
        distance = abs(delta)
        short_gesture = distance <= PICKER_DIRECT_ROW_RADIUS
        if short_gesture:
            # Live testing showed row taps can jump three values or do nothing.
            # One short wheel swipe is faster and its result is verified below.
            gesture_count = 1
            travel = min(
                PICKER_SWIPE_TRAVEL,
                max(
                    PICKER_SMALL_SWIPE_MIN_TRAVEL,
                    distance * PICKER_SMALL_SWIPE_TRAVEL_PER_ROW,
                ),
            )
        else:
            estimates = getattr(self, "_picker_rows_per_swipe", {})
            try:
                step_rows = float(estimates.get(column, PICKER_BATCH_STEP_ROWS))
            except (TypeError, ValueError):
                step_rows = PICKER_BATCH_STEP_ROWS
            step_rows = min(max(step_rows, 4.0), 14.0)
            gesture_count = max(
                1,
                min(
                    PICKER_MAX_BATCH_SWIPES,
                    int(distance / step_rows + 0.5),
                ),
            )
            travel = PICKER_SWIPE_TRAVEL
        increasing = delta > 0
        for gesture_number in range(gesture_count):
            if increasing:
                start_y = center_y + travel
                end_y = center_y - travel
            else:
                start_y = center_y - travel
                end_y = center_y + travel
            try:
                self.ui.tool(
                    "swipe_screen",
                    {
                        "fromX": round(x),
                        "fromY": round(start_y),
                        "toX": round(x),
                        "toY": round(end_y),
                        "duration": 220 if short_gesture else 300,
                        "steps": 12 if short_gesture else 16,
                    },
                )
            except Exception:
                return False
            if gesture_number + 1 < gesture_count:
                time.sleep(PICKER_BATCH_SETTLE_SECONDS)
        time.sleep(PICKER_BATCH_FINAL_SETTLE_SECONDS)
        return True

    def _close_schedule_picker_fast(self) -> bool:
        """Close a partially edited picker before trying the slow fallback."""
        for marker in ("关闭", "取消", "Close", "Cancel"):
            try:
                if self.ui.tap_element((marker,), exact=True):
                    time.sleep(0.24)
                    return True
            except Exception:
                continue
        return False

    def _wait_for_schedule_time(self, local_time: datetime, *, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        next_ocr_at = time.monotonic()
        width, height = self.ui.screen_size()
        schedule_region = {
            "x": width * 0.48,
            "y": height * 0.53,
            "width": width * 0.52,
            "height": height * 0.11,
        }
        while True:
            now = time.monotonic()
            texts = self.ui.texts(include_ocr=False)
            if self._schedule_time_is_visible(texts, local_time):
                return True
            if now >= next_ocr_at:
                try:
                    ocr_nodes = self.ui.ocr_nodes(region=schedule_region)
                except Exception:
                    ocr_nodes = []
                ocr_texts = [node_text(node) for node in ocr_nodes if node_text(node)]
                if self._schedule_time_is_visible(ocr_texts, local_time):
                    return True
                next_ocr_at = time.monotonic() + 0.22
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            time.sleep(min(FAST_POLL_INTERVAL_SECONDS, remaining))

    def _set_schedule_datetime(
        self,
        local_time: datetime,
        *,
        selection: dict[str, Any] | None = None,
    ) -> None:
        selection = selection or self._picker_selection(local_time)
        wheel_ready = selection.get("date") is not None and (
            selection.get("hour") is not None
            or selection.get("minute") is not None
        )
        if wheel_ready:
            if self._select_calendar_day(local_time, selection=selection):
                if selection.get("date") != local_time.date():
                    selection = self._picker_selection(local_time)
                if not self._select_clock_time(local_time, selection=selection):
                    raise AutomationError(
                        "schedule_time",
                        "日期或时间滚轮没有精确落到目标值，已停止，未提交。",
                    )
                final_selection = self._picker_selection(local_time)
                if not self._picker_datetime_matches(final_selection, local_time):
                    if not self._select_clock_time(
                        local_time,
                        selection=final_selection,
                    ):
                        raise AutomationError(
                            "schedule_time",
                            "预约时间复核不一致，已停止，未提交。",
                        )
                    final_selection = self._picker_selection(local_time)
                if not self._picker_datetime_matches(final_selection, local_time):
                    raise AutomationError(
                        "schedule_time",
                        "预约时间复核不一致，已停止，未提交。",
                    )
                self._tap_schedule_done(final_selection)
                return
        # Some builds expose editable date and time fields. Fill those first.
        if self._fill_datetime_fields(local_time):
            self._tap_schedule_done({})
            return
        # Otherwise use the visible calendar day and clock values.
        if self._select_calendar_day(local_time):
            self._select_clock_time(local_time)
            self._tap_schedule_done({})
            return
        raise AutomationError(
            "schedule_time",
            "当前 TikTok Studio 日期选择器没有可识别的输入框或日期网格。",
        )

    @staticmethod
    def _picker_datetime_matches(
        selection: dict[str, Any],
        local_time: datetime,
    ) -> bool:
        return (
            selection.get("date") == local_time.date()
            and selection.get("hour") == local_time.hour
            and selection.get("minute") == local_time.minute
        )

    def _tap_schedule_done(self, selection: dict[str, Any]) -> None:
        """Tap the picker Done button from the already-read control snapshot."""
        point = selection.get("points", {}).get("done")
        if point is not None:
            self.ui.tap_xy(
                *point,
                settle_seconds=0.10,
                refresh_size=False,
            )
            return
        if not self._tap_marker_fast(DONE_MARKERS, exact=True):
            raise AutomationError("schedule_time", "预约时间面板没有找到“完成”按钮。")
        time.sleep(PICKER_SETTLE_SECONDS)

    def _wait_for_next_upload_entry(self, *, timeout: float = 2.0) -> bool:
        """Wait briefly for the Studio create entry before the next queue item."""
        texts = self._wait_for_markers(
            NEXT_UPLOAD_READY_MARKERS,
            timeout=timeout,
        )
        return texts is not None and contains_text(
            texts,
            NEXT_UPLOAD_READY_MARKERS,
            exact=False,
        )

    def _fill_datetime_fields(self, local_time: datetime) -> bool:
        nodes = self.ui.nodes(include_ocr=True)
        date_node = None
        time_node = None
        for node in nodes:
            text = node_text(node)
            if date_node is None and any(text_matches(text, marker) for marker in DATE_MARKERS):
                date_node = node
            if time_node is None and any(text_matches(text, marker) for marker in TIME_MARKERS):
                time_node = node
        if date_node is None or time_node is None:
            return False
        if not self.ui.tap_node(date_node):
            return False
        self.ui.clear_focused_field(anchor=node_point(date_node))
        self.ui.input_text(local_time.strftime("%Y-%m-%d"))
        if not self.ui.tap_node(time_node):
            return False
        self.ui.clear_focused_field(anchor=node_point(time_node))
        self.ui.input_text(local_time.strftime("%H:%M"))
        return True

    @staticmethod
    def _parse_picker_date(text: str, default_year: int, default_month: int) -> Any:
        normalized = normalize(text)
        full = re.search(r"(20\d{2})[年/-](\d{1,2})[月/-](\d{1,2})", normalized)
        if full is not None:
            try:
                return datetime(
                    int(full.group(1)),
                    int(full.group(2)),
                    int(full.group(3)),
                ).date()
            except ValueError:
                return None
        short = re.search(r"(\d{1,2})月(\d{1,2})", normalized)
        if short is None:
            short = re.search(r"(?<!\d)(\d{1,2})/(\d{1,2})(?!\d)", normalized)
        if short is not None:
            month, day = int(short.group(1)), int(short.group(2))
            year = default_year
            if month == 1 and default_month == 12:
                year += 1
            elif month == 12 and default_month == 1:
                year -= 1
            try:
                return datetime(year, month, day).date()
            except ValueError:
                return None
        return None

    def _phone_local_date(self) -> Any:
        offset_minutes = int(getattr(self, "offset_minutes", 0))
        return datetime.now(timezone.utc).astimezone(
            timezone(timedelta(minutes=offset_minutes))
        ).date()

    def _picker_selection(self, local_time: datetime) -> dict[str, Any]:
        """Read the three wheel columns without clicking any accessibility node."""
        return self._picker_selection_from_nodes(
            self.ui.nodes(include_ocr=False),
            local_time,
        )

    def _picker_selection_from_nodes(
        self,
        nodes: Sequence[dict[str, Any]],
        local_time: datetime,
    ) -> dict[str, Any]:
        """Parse a picker from an already-fetched AX snapshot."""
        width, height = self.ui.screen_size()
        selection: dict[str, Any] = {
            "date": None,
            "hour": None,
            "minute": None,
            "points": {},
            "rects": {},
            "date_rows": [],
        }
        for node in nodes:
            rect = node_rect(node)
            text = node_text(node)
            point = node_point(node)
            if rect is None or point is None or not text:
                continue
            if any(text_matches(text, marker, exact=True) for marker in DONE_MARKERS):
                selection["points"]["done"] = point
                selection["rects"]["done"] = rect
            x, y, node_width, node_height = rect
            center_x = x + node_width / 2
            center_y = point[1]
            if center_y < height * 0.35 or center_y > height * 0.82:
                continue
            date_value = self._parse_picker_date(
                text,
                local_time.year,
                local_time.month,
            )
            normalized_text = normalize(text)
            if normalized_text.startswith("今天") or normalized_text.startswith(
                "today"
            ):
                date_value = self._phone_local_date()
            elif normalized_text.startswith("明天") or normalized_text.startswith(
                "tomorrow"
            ):
                date_value = self._phone_local_date() + timedelta(days=1)
            if center_x < width * 0.45 and date_value is not None:
                if node_height >= height * 0.22:
                    selection["date"] = date_value
                    selection["points"]["date"] = point
                    selection["rects"]["date"] = rect
                else:
                    selection["date_rows"].append((date_value, point, rect))
                continue
            if node_height < height * 0.22 or node_width < width * 0.10:
                continue
            digits = re.fullmatch(r"(\d{1,2})", normalize(text))
            if digits is None:
                continue
            value = int(digits.group(1))
            if center_x < width * 0.75 and 0 <= value <= 23:
                selection["hour"] = value
                selection["points"]["hour"] = point
                selection["rects"]["hour"] = rect
            elif center_x >= width * 0.75 and 0 <= value <= 59:
                selection["minute"] = value
                selection["points"]["minute"] = point
                selection["rects"]["minute"] = rect
        return selection

    def _scroll_picker_column(
        self,
        column: str,
        target: Any,
        *,
        local_time: datetime,
        selection: dict[str, Any] | None = None,
    ) -> bool:
        """Select one wheel value using a direct tap or calibrated batch swipes."""
        selection = selection or self._picker_selection(local_time)
        current = selection.get(column)
        if current == target:
            return True

        stalled = 0
        use_long_path = False
        for round_number in range(PICKER_FAST_MAX_ROUNDS):
            if round_number:
                selection = self._picker_selection(local_time)
            current = selection.get(column)
            point = selection.get("points", {}).get(column)
            if current is None or point is None:
                return False
            if current == target:
                return True

            if column == "date":
                distance = abs(target.toordinal() - current.toordinal())
                increasing = target > current
            else:
                # Hours and minutes are circular. Choosing the shorter path
                # turns 59 -> 20 into +21 instead of tapping backwards 39 times.
                delta = self._short_picker_delta(column, int(current), int(target))
                if use_long_path and delta:
                    # Some iOS wheel builds stop at the list edge instead of
                    # wrapping. After one silent edge hit, use the other route.
                    modulus = 24 if column == "hour" else 60
                    delta = delta - modulus if delta > 0 else delta + modulus
                distance = abs(delta)
                increasing = delta > 0

            if distance <= PICKER_DIRECT_ROW_RADIUS and self._tap_nearby_picker_row(
                column,
                target,
                current,
                local_time,
                selection,
            ):
                return True

            # Use only full calibrated strokes and re-read after each batch.
            # A partial final stroke was the main cause of 0 -> 13 overshooting
            # to 21 and then oscillating around the target.
            estimates = getattr(self, "_picker_rows_per_swipe", {})
            step_rows = min(max(float(estimates.get(column, PICKER_BATCH_STEP_ROWS)), 4.0), 13.0)
            full_strokes = 0
            if distance:
                full_strokes = max(
                    1,
                    min(PICKER_MAX_BATCH_SWIPES, int(distance / step_rows)),
                )
            gesture_count = full_strokes
            x = point[0]
            center_y = point[1]
            for _gesture_number in range(full_strokes):
                if increasing:
                    start_y = center_y + PICKER_SWIPE_TRAVEL
                    end_y = center_y - PICKER_SWIPE_TRAVEL
                else:
                    start_y = center_y - PICKER_SWIPE_TRAVEL
                    end_y = center_y + PICKER_SWIPE_TRAVEL
                self.ui.tool(
                    "swipe_screen",
                    {
                        "fromX": round(x),
                        "fromY": round(start_y),
                        "toX": round(x),
                        "toY": round(end_y),
                        "duration": 300,
                        "steps": 16,
                    },
                )
                if _gesture_number + 1 < gesture_count:
                    time.sleep(PICKER_BATCH_SETTLE_SECONDS)
            time.sleep(
                PICKER_BATCH_FINAL_SETTLE_SECONDS if gesture_count > 1 else PICKER_SETTLE_SECONDS
            )
            after_selection = self._picker_selection(local_time)
            after = after_selection.get(column)
            if after == target:
                return True
            if full_strokes and after is not None and column != "date":
                modulus = 24 if column == "hour" else 60
                raw_moved = int(after) - int(current)
                if increasing and raw_moved < 0:
                    raw_moved += modulus
                elif not increasing and raw_moved > 0:
                    raw_moved -= modulus
                rows_per_stroke = abs(raw_moved) / max(1, full_strokes)
                if 4.0 <= rows_per_stroke <= 14.0:
                    estimates[column] = (
                        round((step_rows + rows_per_stroke) / 2.0, 2)
                        if column in estimates
                        else round(rows_per_stroke, 2)
                    )
                    setattr(self, "_picker_rows_per_swipe", estimates)
            next_distance = abs(int(target) - int(after)) if (
                after is not None and column != "date"
            ) else None
            if (
                next_distance is not None
                and next_distance <= PICKER_DIRECT_ROW_RADIUS
            ):
                if self._tap_nearby_picker_row(
                    column,
                    target,
                    after,
                    local_time,
                    after_selection,
                ):
                    return True
            if after == current:
                stalled += 1
                if column != "date" and stalled == 1 and not use_long_path:
                    use_long_path = True
                    emit_progress(
                        "touch_recovery",
                        f"{column} 短路径在边界没有移动，改走另一方向",
                    )
                    continue
                if stalled >= 2:
                    emit_progress(
                        "touch_recovery",
                        f"{column} 滚轮没有响应，正在重置触摸通道",
                    )
                    self._reset_touch_channel_with_lock_wake()
                    time.sleep(PICKER_SETTLE_SECONDS)
                    stalled = 0
            else:
                stalled = 0
                use_long_path = False
            emit_progress(
                "schedule_time",
                f"正在设置{column}：{current} → {target} "
                f"（第 {round_number + 1} 批，{gesture_count} 次滑动）",
            )
        selection = self._picker_selection(local_time)
        return selection.get(column) == target

    def _tap_nearby_picker_row(
        self,
        column: str,
        target: Any,
        current: Any,
        local_time: datetime,
        selection: dict[str, Any],
    ) -> bool:
        """Tap a row by wheel spacing, avoiding a slow OCR pass for clock values."""
        if current == target:
            return True
        if current is None:
            return self._tap_visible_picker_row(
                column,
                target,
                local_time,
                selection,
                radius=PICKER_DIRECT_ROW_RADIUS,
            )
        if column == "date":
            # Adjacent dates in the same month occupy evenly spaced wheel rows.
            # Cross-month/day-row OCR remains the fallback.
            try:
                delta_days = (target - current).days
            except (AttributeError, TypeError):
                return False
            if getattr(current, "year", None) != getattr(target, "year", None) or getattr(
                current, "month", None
            ) != getattr(target, "month", None):
                return self._tap_visible_picker_row(
                    column,
                    target,
                    local_time,
                    selection,
                    radius=PICKER_DIRECT_ROW_RADIUS,
                )
            point = selection.get("points", {}).get(column)
            tap_xy = getattr(self.ui, "tap_xy", None)
            if point is None or not callable(tap_xy):
                return self._tap_visible_picker_row(
                    column,
                    target,
                    local_time,
                    selection,
                    radius=PICKER_DIRECT_ROW_RADIUS,
                )
            center_x, center_y = point
            target_y = center_y + delta_days * PICKER_ROW_SPACING
            _width, height = self.ui.screen_size()
            if target_y <= height * 0.30 or target_y >= height * 0.85:
                return False
            tap_xy(
                center_x,
                target_y,
                settle_seconds=PICKER_SETTLE_SECONDS,
                refresh_size=False,
            )
            return self._picker_selection(local_time).get(column) == target
        try:
            delta = int(target) - int(current)
        except (TypeError, ValueError):
            return False
        if abs(delta) > PICKER_DIRECT_ROW_RADIUS:
            return False
        point = selection.get("points", {}).get(column)
        if point is None:
            return False
        tap_xy = getattr(self.ui, "tap_xy", None)
        if not callable(tap_xy):
            return self._tap_visible_picker_row(
                column,
                target,
                local_time,
                selection,
                radius=PICKER_DIRECT_ROW_RADIUS,
            )
        center_x, center_y = point
        target_y = center_y + delta * PICKER_ROW_SPACING
        _width, height = self.ui.screen_size()
        if target_y <= height * 0.30 or target_y >= height * 0.85:
            return False
        tap_xy(
            center_x,
            target_y,
            settle_seconds=PICKER_SETTLE_SECONDS,
            refresh_size=False,
        )
        return self._picker_selection(local_time).get(column) == target

    def _tap_visible_picker_row(
        self,
        column: str,
        target: Any,
        local_time: datetime,
        selection: dict[str, Any],
        *,
        radius: int = PICKER_ROW_TAP_RADIUS,
    ) -> bool:
        """Tap an already visible OCR row; iOS centers the tapped row."""
        current = selection.get(column)
        point = selection.get("points", {}).get(column)
        if current == target or point is None:
            return current == target
        ocr_nodes = getattr(self.ui, "ocr_nodes", None)
        tap_xy = getattr(self.ui, "tap_xy", None)
        if ocr_nodes is None or tap_xy is None:
            return False
        width, _height = self.ui.screen_size()
        center_x, center_y = point
        safe_radius = max(1, min(int(radius), 6))
        region = {
            "x": 0.0,
            "y": max(0.0, center_y - PICKER_ROW_SPACING * (safe_radius + 0.7)),
            "width": width,
            "height": PICKER_ROW_SPACING * (safe_radius * 2 + 1.4),
        }
        try:
            nodes = ocr_nodes(region=region)
        except Exception:
            return False
        for node in nodes:
            rect = node_rect(node)
            node_position = node_point(node)
            text = node_text(node)
            if rect is None or node_position is None or not text:
                continue
            x, _y, node_width, _node_height = rect
            node_center_x = x + node_width / 2
            node_center_y = node_position[1]
            if abs(node_center_x - center_x) > width * 0.13:
                continue
            if abs(node_center_y - center_y) > (
                PICKER_ROW_SPACING * (safe_radius + 0.45)
            ):
                continue
            # A low-confidence OCR read of the highlighted row can turn 11 into 1.
            # Never treat the current center row as a different target.
            if abs(node_center_y - center_y) < PICKER_ROW_SPACING * 0.5:
                continue
            value: Any = None
            if column == "date":
                value = self._parse_picker_date(
                    text,
                    local_time.year,
                    local_time.month,
                )
                normalized_text = normalize(text)
                if normalized_text.startswith("今天") or normalized_text.startswith(
                    "today"
                ):
                    value = self._phone_local_date()
                elif normalized_text.startswith(
                    "明天"
                ) or normalized_text.startswith("tomorrow"):
                    value = self._phone_local_date() + timedelta(days=1)
            else:
                digits = re.fullmatch(r"(\d{1,2})", normalize(text))
                if digits is not None:
                    value = int(digits.group(1))
            if value != target:
                continue
            tap_xy(
                node_position[0],
                node_center_y,
                settle_seconds=PICKER_SETTLE_SECONDS,
                refresh_size=False,
            )
            return self._picker_selection(local_time).get(column) == target
        return False

    def _select_calendar_day(
        self,
        local_time: datetime,
        *,
        selection: dict[str, Any] | None = None,
    ) -> bool:
        target = local_time.date()
        if self._scroll_picker_column(
            "date",
            target,
            local_time=local_time,
            selection=selection,
        ):
            return True
        # Older Studio builds may expose a day button instead of a wheel.
        nodes = self.ui.nodes(include_ocr=True)
        day_node = find_exact_node(nodes, str(local_time.day))
        if day_node is not None:
            point = node_point(day_node)
            if point is not None:
                self.ui.tap_xy(*point)
                time.sleep(0.2)
                return True
        return False

    def _select_clock_time(
        self,
        local_time: datetime,
        *,
        selection: dict[str, Any] | None = None,
    ) -> bool:
        clock_selection = selection or self._picker_selection(local_time)
        if clock_selection.get("hour") != local_time.hour:
            if not self._scroll_picker_column(
                "hour",
                local_time.hour,
                local_time=local_time,
                selection=clock_selection,
            ):
                return False
            # Let any wheel inertia settle before reading the minute value.
            time.sleep(PICKER_SETTLE_SECONDS)
            clock_selection = self._picker_selection(local_time)
        if clock_selection.get("minute") == local_time.minute:
            return True
        return self._scroll_picker_column(
            "minute",
            local_time.minute,
            local_time=local_time,
            selection=clock_selection,
        )

    @staticmethod
    def _schedule_time_is_visible(texts: Sequence[str], local_time: datetime) -> bool:
        joined = normalize("\n".join(texts))
        date_candidates = {
            f"{local_time.year}-{local_time.month:02d}-{local_time.day:02d}",
            f"{local_time.year}/{local_time.month}/{local_time.day}",
            f"{local_time.year}年{local_time.month}月{local_time.day}日",
            f"{local_time.month}月{local_time.day}日",
            local_time.strftime("%b %d, %Y"),
            local_time.strftime("%B %d, %Y"),
        }
        twelve_hour = local_time.strftime("%I:%M %p")
        time_candidates = {
            f"{local_time.hour:02d}:{local_time.minute:02d}",
            twelve_hour,
            twelve_hour.lstrip("0"),
        }
        return any(normalize(value) in joined for value in date_candidates) and any(
            normalize(value) in joined for value in time_candidates
        )

    def _tap_submit_button(self) -> bool:
        nodes = self.ui.nodes(include_ocr=True)
        submit_node = find_text_node(nodes, SUBMIT_MARKERS, exact=False)
        if submit_node is not None and self.ui.tap_node(submit_node):
            return True
        return self._tap_marker_fast(SUBMIT_MARKERS, exact=False)

    def _wait_submit_outcome(
        self,
        local_time: datetime,
        *,
        timeout: float,
    ) -> tuple[str, list[str]]:
        blockers = (
            RATE_LIMIT_MARKERS
            + SECURITY_MARKERS
            + LOGIN_REQUIRED_MARKERS
            + LOGIN_MARKERS
        )
        result_texts = self._wait_for_marker_groups(
            (
                (SUCCESS_MARKERS, False),
                (CREATE_TAB_MARKERS, True),
                (SUBMIT_BUSY_MARKERS, False),
            ),
            blockers=blockers,
            timeout=timeout,
        )
        current_texts = result_texts or self.ui.texts(include_ocr=True)
        blocker = blocking_page_error(current_texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if contains_text(current_texts, SUCCESS_MARKERS):
            return "success", current_texts
        if contains_text(current_texts, SUBMIT_BUSY_MARKERS):
            return "busy", current_texts
        still_on_form = contains_text(
            current_texts,
            CONFIRM_SCHEDULE_MARKERS + SCHEDULE_MARKERS,
        ) and self._schedule_time_is_visible(current_texts, local_time)
        if contains_text(current_texts, CREATE_TAB_MARKERS, exact=True) and not still_on_form:
            return "success", current_texts
        if still_on_form or contains_text(current_texts, SUBMIT_MARKERS, exact=False):
            return "still_form", current_texts
        return "timeout", current_texts

    def _submit_schedule(self, local_time: datetime) -> None:
        self._submit_tapped = False
        nodes = self.ui.nodes(include_ocr=True)
        texts = [node_text(node) for node in nodes if node_text(node)]
        blocker = blocking_page_error(texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if immediate_publish_is_active(nodes):
            raise AutomationError("submit", "页面仍处于立即发布模式，已停止预约。")
        if not contains_text(texts, CONFIRM_SCHEDULE_MARKERS, exact=False):
            raise AutomationError("submit", "没有检测到定时发布状态，已停止提交。")
        if not self._schedule_time_is_visible(texts, local_time):
            raise AutomationError("submit", "提交前预约时间复核失败，已停止提交。")

        for attempt in (1, 2):
            if not self._tap_submit_button():
                raise AutomationError("submit", "没有找到预约发布按钮。")
            self._submit_tapped = True
            now = time.monotonic()
            if attempt == 1:
                self.submit_clicked_monotonic = now
                selection_started = getattr(self, "selection_started_monotonic", 0.0)
                if selection_started > 0:
                    emit_progress(
                        "publish_action",
                        "选视频 → 点击排期 "
                        f"{self.submit_clicked_monotonic - selection_started:.2f} 秒",
                    )
            self._mark_current(
                PublishStage.SUBMIT,
                status="submitted_unverified",
                detail=f"第 {attempt} 次点击排期，正在复核结果。",
            )
            outcome, result_texts = self._wait_submit_outcome(
                local_time,
                timeout=1.45,
            )
            if outcome == "success":
                return
            if outcome == "busy":
                outcome, result_texts = self._wait_submit_outcome(
                    local_time,
                    timeout=8.0,
                )
                if outcome == "success":
                    return
                raise AutomationError(
                    "submit",
                    "排期按钮已进入提交状态，但没有在限定时间内确认成功。",
                )
            if outcome == "still_form" and attempt == 1:
                emit_progress("submit", "第一次点击排期无反应，正在点击第二次")
                time.sleep(0.18)
                continue
            if outcome == "still_form":
                break
            # The form disappeared without a toast. Give navigation more time
            # before treating it as a failed submission.
            outcome, result_texts = self._wait_submit_outcome(
                local_time,
                timeout=8.0,
            )
            if outcome == "success":
                return
            raise AutomationError("submit", "提交后没有检测到预约成功提示。")

        emit_progress(
            "touch_recovery",
            "点击排期两次仍无反应，正在自动锁屏唤醒后重试",
        )
        self._reset_touch_channel_with_lock_wake()
        time.sleep(0.35)
        current_texts = self.ui.texts(include_ocr=True)
        blocker = blocking_page_error(current_texts)
        if blocker is not None:
            raise AutomationError(*blocker)
        if contains_text(current_texts, SUCCESS_MARKERS):
            return
        still_on_form = contains_text(
            current_texts,
            CONFIRM_SCHEDULE_MARKERS + SCHEDULE_MARKERS,
        ) and self._schedule_time_is_visible(current_texts, local_time)
        if not still_on_form:
            if contains_text(current_texts, CREATE_TAB_MARKERS, exact=True):
                return
            raise AutomationError(
                "submit",
                "锁屏唤醒后没有回到原预约页，为避免重复预约已停止。",
            )
        if not self._tap_submit_button():
            raise AutomationError("submit", "锁屏唤醒后没有找到预约发布按钮。")
        self._mark_current(
            PublishStage.SUBMIT,
            status="submitted_unverified",
            detail="锁屏唤醒后已再次点击排期，正在复核结果。",
        )
        outcome, _result_texts = self._wait_submit_outcome(local_time, timeout=20.0)
        if outcome == "success":
            return
        raise AutomationError("submit", "锁屏唤醒重试后仍未确认预约成功。")

    def _open_creator_for_review(self) -> tuple[bool, str]:
        try:
            self._open_create_page()
            screenshot = self.ui.client.screenshot_jpeg()
            path = self.output_dir / "创作页面复核.jpg"
            path.write_bytes(screenshot)
            emit_progress("creator_review", f"已打开创作页面供复核：{path}")
            return True, str(path)
        except Exception as error:
            emit_progress("creator_review", f"创作页面复核失败：{clean(error, 300)}")
            return False, ""


def diagnose(output_dir: Path, port: int) -> int:
    output_dir.mkdir(parents=True, exist_ok=True)
    ui = UiAutomation(port, STUDIO_BUNDLE_ID, timeout=90.0)
    try:
        ui.connect()
        ui.launch_app(STUDIO_BUNDLE_ID)
        ui.dismiss_overlays()
        nodes = ui.nodes(include_ocr=False)
        ocr_nodes = ui.ocr_nodes()
        (output_dir / "studio_nodes.json").write_text(
            json.dumps(nodes, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (output_dir / "studio_ocr_nodes.json").write_text(
            json.dumps(ocr_nodes, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (output_dir / "studio_current.jpg").write_bytes(ui.client.screenshot_jpeg())
        print(f"Studio diagnostic saved to {output_dir}", flush=True)
        return 0
    finally:
        ui.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="在 TikTok Studio 逐条设置定时发布")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--diagnose-dir", type=Path)
    args = parser.parse_args()
    if args.diagnose_dir is not None:
        return diagnose(args.diagnose_dir.resolve(), args.port)
    try:
        payload = read_payload()
        payload["selector_profile"] = apply_selector_overrides(payload)
    except Exception as error:
        emit_result(
            {
                "success": False,
                "stage": "task",
                "detail": clean(error),
                "total_count": 0,
                "scheduled_count": 0,
                "failed_count": 0,
                "items": [],
                "creator_visible": False,
                "creator_screenshot": "",
                "phone_timezone": "",
            }
        )
        return 2
    return StudioScheduleRunner(args.port, payload).run()


if __name__ == "__main__":
    raise SystemExit(main())
