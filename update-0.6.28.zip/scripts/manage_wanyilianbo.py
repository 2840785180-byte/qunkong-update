from __future__ import annotations

import argparse
import asyncio
import http.client
import json
import sys
import time
import urllib.error
import urllib.request
from contextlib import suppress
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.services.ios_mcp_control import (  # noqa: E402
    McpHttpClient,
    McpProtocolError,
)
from iphone_control_center.services.player_support import (  # noqa: E402
    PLAYER_APP_NAME,
    PLAYER_BUNDLE_ID,
    bundled_player_ipa,
    validate_player_ipa,
)
from iphone_control_center.services.usb_discovery import (  # noqa: E402
    PymobiledeviceUSBProbe,
)


MCP_REMOTE_PORT = 8090
FORWARD_READY_TIMEOUT_SECONDS = 12.0
HEALTH_READY_TIMEOUT_SECONDS = 20.0
INSTALL_POLL_TIMEOUT_SECONDS = 120.0


class PlayerManageError(RuntimeError):
    pass


def _compact(value: BaseException | str, limit: int = 500) -> str:
    return " ".join(str(value).split())[:limit]


def _progress(message: str) -> None:
    print(f"PLAYER_PROGRESS {message}", flush=True)
    print(f"==> {message}", flush=True)


def _status(state: str, version: str = "") -> None:
    suffix = f" {version}" if version else ""
    print(f"PLAYER_STATUS {state.upper()}{suffix}", flush=True)


def _discover_udid(explicit_udid: str) -> str:
    snapshot = PymobiledeviceUSBProbe().scan()
    devices = [device for device in snapshot.devices if device.udid]
    if explicit_udid:
        wanted = explicit_udid.strip().lower()
        matched = [device for device in devices if device.udid.lower() == wanted]
        if not matched:
            raise PlayerManageError("没有找到指定 UDID 的 USB iPhone。")
        return matched[0].udid
    paired = [device for device in devices if device.is_paired is True]
    candidates = paired or [device for device in devices if device.is_paired is not False]
    if not candidates:
        raise PlayerManageError(
            "没有识别到已配对的 USB iPhone。请保持解锁并点“信任此电脑”。"
        )
    if len(candidates) > 1:
        listing = "、".join(device.udid[-8:] for device in candidates)
        raise PlayerManageError(
            f"发现多台手机（{listing}），请从第 02 步指定当前手机后重试。"
        )
    return candidates[0].udid


def _health_once(port: int) -> dict[str, Any] | None:
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}/health",
        headers={"Accept": "application/json"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=2.0) as response:
            payload = json.loads(response.read().decode("utf-8", "replace"))
    except (OSError, urllib.error.URLError, json.JSONDecodeError):
        return None
    if (
        isinstance(payload, dict)
        and str(payload.get("status") or "").lower() == "ok"
        and str(payload.get("server") or "") == "ios-mcp"
    ):
        return payload
    return None


async def _start_forward(udid: str) -> tuple[Any, asyncio.Task[Any], int]:
    from pymobiledevice3.tcp_forwarder import UsbmuxTcpForwarder

    listening = asyncio.Event()
    forwarder = UsbmuxTcpForwarder(
        udid,
        MCP_REMOTE_PORT,
        src_port=0,
        listening_event=listening,
        usbmux_connection_type="USB",
    )
    task = asyncio.create_task(
        forwarder.start(address="127.0.0.1"),
        name="ic20-player-manage-forward",
    )
    try:
        await asyncio.wait_for(listening.wait(), timeout=FORWARD_READY_TIMEOUT_SECONDS)
    except Exception as error:
        forwarder.stop()
        with suppress(Exception):
            await asyncio.wait_for(task, timeout=3.0)
        raise PlayerManageError("无法建立手机 USB 控制端口。") from error
    local_port = int(forwarder.listening_port or 0)
    if local_port <= 0:
        forwarder.stop()
        with suppress(Exception):
            await asyncio.wait_for(task, timeout=3.0)
        raise PlayerManageError("Windows 没有分配到可用的手机控制端口。")
    return forwarder, task, local_port


def _upload_file(port: int, package_path: Path) -> str:
    size = package_path.stat().st_size
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=600)
    try:
        connection.putrequest("POST", "/upload_file")
        connection.putheader("Host", f"127.0.0.1:{port}")
        connection.putheader("Content-Type", "application/octet-stream")
        connection.putheader("X-Filename", package_path.name)
        connection.putheader("Content-Length", str(size))
        connection.endheaders()
        with package_path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                connection.send(chunk)
        response = connection.getresponse()
        body = response.read().decode("utf-8", "replace")
    except (OSError, http.client.HTTPException) as error:
        raise PlayerManageError(f"无法把播放器安装包传到手机：{_compact(error)}") from error
    finally:
        connection.close()
    if not 200 <= response.status < 300:
        raise PlayerManageError(
            f"播放器安装包上传失败 HTTP {response.status}：{_compact(body)}"
        )
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as error:
        raise PlayerManageError("播放器上传接口返回了无效结果。") from error
    remote_path = str(payload.get("path") or "").strip() if isinstance(payload, dict) else ""
    if not remote_path:
        raise PlayerManageError("播放器上传接口没有返回手机内文件路径。")
    return remote_path


def _installed_info(client: McpHttpClient) -> dict[str, Any] | None:
    try:
        value = client.tool_value("get_app_info", {"bundle_id": PLAYER_BUNDLE_ID})
    except McpProtocolError as error:
        if "app not installed" in str(error).lower():
            return None
        raise
    return value if isinstance(value, dict) else None


def _version_from_info(info: dict[str, Any] | None) -> str:
    if not info:
        return ""
    return str(info.get("short_version") or info.get("version") or "").strip()


def _wait_for_installed(client: McpHttpClient) -> dict[str, Any]:
    deadline = time.monotonic() + INSTALL_POLL_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        info = _installed_info(client)
        if info is not None:
            return info
        time.sleep(1.0)
    raise PlayerManageError("播放器安装命令已执行，但手机上仍未检测到应用。")


def _remove_remote_file(client: McpHttpClient, remote_path: str) -> None:
    if not remote_path:
        return
    try:
        client.tool_value(
            "run_command",
            {"command": f"rm -f {remote_path!r}"},
        )
    except Exception:
        pass


def _manage_installed_app(
    client: McpHttpClient,
    *,
    mcp_port: int,
    action: str,
    package_path: Path,
    package_info: Any,
) -> int:
    installed = _installed_info(client)
    if installed is not None:
        version = _version_from_info(installed)
        _status("installed", version)
        print(f"{PLAYER_APP_NAME}已安装" + (f"（{version}）" if version else ""), flush=True)
    else:
        _status("missing")
        print(f"未检测到{PLAYER_APP_NAME}，准备安装。", flush=True)
        if action == "check":
            return 0

    should_install = installed is None
    if should_install:
        if not package_path.is_file():
            raise PlayerManageError(f"安装包内缺少播放器文件：{package_path}")
        _progress(f"正在上传{PLAYER_APP_NAME}安装包")
        remote_path = _upload_file(mcp_port, package_path)
        try:
            _progress(f"正在安装{PLAYER_APP_NAME}")
            client.tool_value("install_app", {"path": remote_path})
            installed = _wait_for_installed(client)
        finally:
            _remove_remote_file(client, remote_path)
        version = _version_from_info(installed)
        _status("installed", version)
        print(
            f"{PLAYER_APP_NAME} {package_info.short_version} 安装完成"
            + (f"，手机报告版本 {version}" if version else ""),
            flush=True,
        )

    if action in {"auto", "open"} or action == "install":
        if installed is None:
            installed = _wait_for_installed(client)
        _progress(f"正在打开{PLAYER_APP_NAME}")
        client.tool_value("launch_app", {"bundle_id": PLAYER_BUNDLE_ID})
        print("PLAYER_OPENED", flush=True)
    print("PLAYER_READY", flush=True)
    return 0


async def run(args: argparse.Namespace) -> int:
    package_path = Path(args.ipa).expanduser().resolve()
    package_info, digest = validate_player_ipa(package_path)
    print(f"播放器安装包校验通过：{package_path.name} · SHA-256 {digest}", flush=True)

    forwarder: Any = None
    forward_task: asyncio.Task[Any] | None = None
    client: McpHttpClient | None = None
    try:
        if args.mcp_port:
            port = int(args.mcp_port)
        else:
            udid = await asyncio.to_thread(_discover_udid, args.udid)
            _progress("正在连接手机控制服务")
            forwarder, forward_task, port = await _start_forward(udid)

        deadline = time.monotonic() + HEALTH_READY_TIMEOUT_SECONDS
        health: dict[str, Any] | None = None
        while time.monotonic() < deadline:
            health = await asyncio.to_thread(_health_once, port)
            if health is not None:
                break
            await asyncio.sleep(0.5)
        if health is None:
            raise PlayerManageError(
                "手机端控制服务没有响应。请先完成第 02 步组件检查与安装。"
            )

        client = McpHttpClient(f"http://127.0.0.1:{port}", timeout=300.0)
        await asyncio.to_thread(client.connect)
        print(f"iOS MCP {client.server_version or '未知版本'} 已连接", flush=True)
        return await asyncio.to_thread(
            _manage_installed_app,
            client,
            mcp_port=port,
            action=args.action,
            package_path=package_path,
            package_info=package_info,
        )
    finally:
        if client is not None:
            client.close()
        if forwarder is not None:
            forwarder.stop()
        if forward_task is not None:
            with suppress(Exception):
                await asyncio.wait_for(forward_task, timeout=5.0)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="检查、安装并打开万能播放器（通过群控小助手的 USB iOS MCP）"
    )
    parser.add_argument(
        "--action",
        choices=("auto", "check", "install", "ensure", "open"),
        default="auto",
        help="auto=缺就安装并打开；ensure=缺才安装；check=只检查",
    )
    parser.add_argument("--udid", default="", help="指定当前 USB iPhone 的 UDID")
    parser.add_argument("--mcp-port", type=int, default=0, help="复用已有本地 MCP 端口")
    parser.add_argument(
        "--ipa",
        type=Path,
        default=bundled_player_ipa(PROJECT_ROOT),
        help="内置万能播放器 IPA 路径",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        return asyncio.run(run(args))
    except PlayerManageError as error:
        print("", flush=True)
        print(f"万能播放器操作失败：{_compact(error)}", flush=True)
        return 1
    except KeyboardInterrupt:
        print("操作已取消。", flush=True)
        return 130
    except Exception as error:
        print("", flush=True)
        print(f"万能播放器操作异常：{_compact(error)}", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
