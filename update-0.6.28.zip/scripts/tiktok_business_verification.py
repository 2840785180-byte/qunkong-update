from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Sequence

from iphone_control_center.services.tiktok_business import (
    TikTokBusinessConfig,
    TikTokBusinessError,
)
from tiktok_automation_common import (
    BUSINESS_FILES_FOLDER,
    BUSINESS_MARKERS,
    NEXT_MARKERS,
    SUBMIT_MARKERS,
    UPLOAD_MARKERS,
    AutomationError,
    UiAutomation,
    choose_picker_file,
    clean,
    emit_progress,
    emit_result,
    open_business_form,
    upload_file_to_phone,
    wait_for_business_form,
)


TIKTOK_BUNDLE_ID = "com.zhiliaoapp.musically"
COUNTRY_MARKERS = ("国家/地区", "Country/Region", "Country")
STATE_MARKERS = ("州/省", "State/Province", "State", "Province")
CITY_MARKERS = ("城市", "City")
INDUSTRY_MARKERS = (
    "行业",
    "Industry",
    "Industry with audience restrictions",
)
ADDRESS_MARKERS = ("详细地址", "地址", "Address")
WEBSITE_MARKERS = ("公司网站", "Company website", "Website")
COMPANY_MARKERS = ("公司名称", "Company name", "Legal company name")
LICENSE_MARKERS = ("营业执照编号", "Business license number", "License number")


class BusinessFlowError(AutomationError):
    pass


class BusinessVerificationRunner:
    def __init__(self, port: int, config: TikTokBusinessConfig) -> None:
        self.port = port
        self.config = config
        self.ui = UiAutomation(port, TIKTOK_BUNDLE_ID, timeout=90.0)
        self.warnings: list[str] = []
        self.uploaded_files: list[str] = []

    def close(self) -> None:
        self.ui.close()

    def run(self) -> dict[str, object]:
        self.ui.connect()
        for image_path in self.config.image_paths:
            upload_file_to_phone(
                self.port,
                self.ui.client,
                Path(image_path),
                BUSINESS_FILES_FOLDER,
            )
            self.uploaded_files.append(Path(image_path).name)
        emit_progress(
            "prepare",
            f"已准备 {len(self.uploaded_files)} 张企业认证图片",
        )
        self.ui.launch_app()
        self.ui.dismiss_overlays()
        open_business_form(self.ui, self.config.entry_url)
        wait_for_business_form(self.ui)
        self._fill_basic_info()
        self._open_company_certification_page()
        self._upload_company_certification()
        self._fill_company_details()
        submit_visible = self.ui.find_node(
            SUBMIT_MARKERS,
            exact=False,
            include_ocr=True,
        ) is not None
        if not submit_visible:
            self.warnings.append(
                "资料已填写，但当前屏幕没有识别到 Submit；请人工向下检查并复核。"
            )
        return {
            "success": True,
            "stage": "ready_to_submit",
            "detail": (
                "企业认证资料已填写完成，已停在 Submit 前；"
                "软件不会点击 Submit，请人工复核后手动提交。"
            ),
            "fields_changed": [
                "国家/地区",
                "州/省",
                "城市",
                "行业",
                "详细地址",
                "公司名称",
                "营业执照编号",
                *(["公司网站"] if self.config.website.strip() else []),
                *(["认证图片"] if self.uploaded_files else []),
            ],
            "warnings": self.warnings,
        }

    def _texts(self) -> list[str]:
        return self.ui.texts(include_ocr=True)

    def _value_visible(self, value: str) -> bool:
        wanted = clean(value).casefold()
        if not wanted:
            return True
        return any(wanted in clean(text).casefold() for text in self._texts())

    def _select_dropdown(
        self,
        label_markers: Sequence[str],
        value: str,
        display_name: str,
    ) -> None:
        if self._value_visible(value):
            emit_progress("form", f"{display_name}已是目标值，跳过")
            return
        label = self.ui.find_node(label_markers, exact=False)
        if label is None:
            raise BusinessFlowError(
                "business_field",
                f"企业认证页面没有找到{display_name}。",
            )
        point = self.ui.field_near_label(label, y_offset=34.0)
        if point is None:
            raise BusinessFlowError(
                "business_field",
                f"{display_name}没有可点击位置。",
            )
        self.ui.tap_xy(*point)
        time.sleep(0.6)
        for _attempt in range(5):
            if self.ui.tap_marker((value,), exact=True, include_ocr=True):
                time.sleep(0.5)
                emit_progress("form", f"已选择{display_name}：{value}")
                return
            self.ui.swipe_up()
        raise BusinessFlowError(
            "business_field",
            f"没有在{display_name}选项中找到“{value}”，请检查配置或手动选择。",
        )

    def _fill_text(
        self,
        label_markers: Sequence[str],
        value: str,
        display_name: str,
        *,
        optional: bool = False,
    ) -> None:
        value = value.strip()
        if not value:
            if optional:
                return
            raise BusinessFlowError("business_field", f"{display_name}不能为空。")
        label = self.ui.find_node(label_markers, exact=False)
        if label is None:
            if optional:
                self.warnings.append(f"页面没有显示{display_name}，已跳过。")
                return
            raise BusinessFlowError(
                "business_field",
                f"企业认证页面没有找到{display_name}。",
            )
        point = self.ui.field_near_label(label, y_offset=34.0)
        if point is None:
            raise BusinessFlowError(
                "business_field",
                f"{display_name}没有可点击位置。",
            )
        self.ui.tap_xy(*point)
        time.sleep(0.3)
        self.ui.clear_focused_field()
        self.ui.input_text(value)
        time.sleep(0.5)
        emit_progress("form", f"已填写{display_name}")

    def _fill_basic_info(self) -> None:
        self._select_dropdown(COUNTRY_MARKERS, self.config.country, "国家/地区")
        self._select_dropdown(STATE_MARKERS, self.config.state_province, "州/省")
        self._select_dropdown(CITY_MARKERS, self.config.city, "城市")
        self._select_dropdown(INDUSTRY_MARKERS, self.config.industry, "行业")
        self._fill_text(ADDRESS_MARKERS, self.config.address, "详细地址")
        if self.config.website.strip():
            self._fill_text(
                WEBSITE_MARKERS,
                self.config.website,
                "公司网站",
                optional=True,
            )
        if not self.ui.tap_marker(NEXT_MARKERS, exact=False):
            raise BusinessFlowError("business_next", "没有找到“下一步 / Next”按钮。")
        time.sleep(1.0)

    def _open_company_certification_page(self) -> None:
        texts = self._texts()
        if any(
            marker.casefold() in text.casefold()
            for text in texts
            for marker in ("Company certification", "公司认证", "上传公司")
        ):
            return
        try:
            wait_for_business_form(self.ui, timeout=10.0)
        except AutomationError:
            pass

    def _upload_company_certification(self) -> None:
        for index, filename in enumerate(self.uploaded_files, 1):
            self.ui.assert_healthy()
            tapped = self.ui.tap_marker(
                UPLOAD_MARKERS,
                exact=False,
                include_ocr=True,
            )
            if not tapped:
                width, height = self.ui.screen_size()
                self.ui.tap_xy(width * 0.48, height * 0.31)
            time.sleep(0.8)
            self.ui.tap_marker(
                ("文件", "Files", "Choose File", "选择文件", "从文件选择"),
                exact=False,
                include_ocr=True,
            )
            choose_picker_file(self.ui, BUSINESS_FILES_FOLDER, filename)
            time.sleep(1.0)
            emit_progress(
                "certificate",
                f"已上传认证图片 {index}/{len(self.uploaded_files)}：{filename}",
            )
            if not any(filename in text for text in self._texts()):
                self.warnings.append(
                    f"图片 {filename} 已选择，但页面没有显示原文件名。"
                )

    def _fill_company_details(self) -> None:
        self._fill_text(COMPANY_MARKERS, self.config.company_name, "公司名称")
        self._fill_text(LICENSE_MARKERS, self.config.license_number, "营业执照编号")

def _failure(
    runner: BusinessVerificationRunner | None,
    stage: str,
    detail: str,
) -> dict[str, object]:
    return {
        "success": False,
        "stage": stage,
        "detail": clean(detail, 1000),
        "fields_changed": [],
        "warnings": list(runner.warnings) if runner else [],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TikTok 企业认证")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--bundle-id", default=TIKTOK_BUNDLE_ID)
    args = parser.parse_args(argv)
    runner: BusinessVerificationRunner | None = None
    try:
        request = json.loads(sys.stdin.read())
        payload = request.get("payload") if isinstance(request, dict) else None
        if not isinstance(payload, dict):
            raise TikTokBusinessError("企业认证任务格式不正确。")
        images = payload.get("image_paths")
        if not isinstance(images, list):
            raise TikTokBusinessError("企业认证图片格式不正确。")
        config = TikTokBusinessConfig(
            country=str(payload.get("country") or ""),
            state_province=str(payload.get("state_province") or ""),
            city=str(payload.get("city") or ""),
            industry=str(payload.get("industry") or ""),
            address=str(payload.get("address") or ""),
            website=str(payload.get("website") or ""),
            company_name=str(payload.get("company_name") or ""),
            license_number=str(payload.get("license_number") or ""),
            image_paths=tuple(str(item) for item in images if str(item).strip()),
            entry_url=str(payload.get("entry_url") or ""),
        )
        config.validate()
        runner = BusinessVerificationRunner(args.port, config)
        result = runner.run()
    except TikTokBusinessError as error:
        result = _failure(runner, "config", str(error))
    except BusinessFlowError as error:
        result = _failure(runner, error.stage, error.detail)
    except Exception as error:
        result = _failure(
            runner,
            "unexpected",
            str(error) or error.__class__.__name__,
        )
    finally:
        if runner is not None:
            runner.close()
    emit_result(result)
    return 0 if result.get("success") else 2


if __name__ == "__main__":
    raise SystemExit(main())
