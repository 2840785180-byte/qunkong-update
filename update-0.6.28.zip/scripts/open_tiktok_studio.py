from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.services.ios_mcp_control import IOS_MCP_REMOTE_PORT, McpHttpClient

BUNDLE_ID = "com.ss.iphone.tt.creator"
RESULT_PATH = PROJECT_ROOT / "work" / "tiktok_studio_open_result.json"


def connected_paired_targets() -> list[tuple[int, str]]:
    database_path = Path(os.environ.get("LOCALAPPDATA", r"C:\Users\win10\AppData\Local")) / "iPhoneControlCenter20" / "data" / "devices.db"
    with sqlite3.connect(database_path) as connection:
        rows = connection.execute(
            "SELECT slot_no, udid FROM device_slots "
            "WHERE is_paired = 1 AND connection_mode != 'none' AND udid IS NOT NULL "
            "ORDER BY slot_no"
        ).fetchall()
    return [(int(slot), str(udid)) for slot, udid in rows]


async def open_studio(slot_no: int, udid: str) -> dict:
    from pymobiledevice3.tcp_forwarder import UsbmuxTcpForwarder

    listening = asyncio.Event()
    forwarder = UsbmuxTcpForwarder(
        udid,
        IOS_MCP_REMOTE_PORT,
        src_port=0,
        listening_event=listening,
        usbmux_connection_type="USB",
    )
    forward_task = asyncio.create_task(forwarder.start(address="127.0.0.1"))
    client = None
    try:
        await asyncio.wait_for(listening.wait(), timeout=15.0)
        port = int(forwarder.listening_port or 0)
        if port <= 0:
            raise RuntimeError("USB forwarding did not allocate a local port")

        client = McpHttpClient(f"http://127.0.0.1:{port}")
        await asyncio.to_thread(client.connect)
        screen = await asyncio.to_thread(client.tool_value, "get_screen_info", {})
        screen = screen if isinstance(screen, dict) else {}
        screen_on = screen.get("screen_on")
        sequence = "home_twice" if screen_on is True else "power_then_home"
        await asyncio.to_thread(
            client.call_tool,
            "wake_and_home",
            {"sequence": sequence, "duration": 100, "delay_ms": 300},
        )

        await asyncio.to_thread(
            client.call_tool,
            "launch_app",
            {"bundle_id": BUNDLE_ID},
        )

        frontmost = ""
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            value = await asyncio.to_thread(client.tool_value, "get_frontmost_app", {})
            if isinstance(value, str):
                frontmost = value.strip()
            elif isinstance(value, dict):
                frontmost = str(
                    value.get("bundleId")
                    or value.get("bundle_id")
                    or value.get("frontmostBundleId")
                    or ""
                ).strip()
            if frontmost == BUNDLE_ID:
                break
            await asyncio.sleep(0.25)

        return {
            "slot": slot_no,
            "udid": udid,
            "bundle_id": BUNDLE_ID,
            "frontmost": frontmost,
            "verified": frontmost == BUNDLE_ID,
        }
    finally:
        if client is not None:
            client.close()
        forwarder.stop()
        try:
            await asyncio.wait_for(forward_task, timeout=5.0)
        except Exception:
            forward_task.cancel()


async def main() -> int:
    targets = connected_paired_targets()
    if not targets:
        result = {"ok": False, "error": "No connected paired iPhone was found.", "results": []}
        RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
        RESULT_PATH.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False))
        return 2

    results = []
    for slot_no, udid in targets:
        try:
            results.append(await open_studio(slot_no, udid))
        except Exception as error:
            results.append({
                "slot": slot_no,
                "udid": udid,
                "bundle_id": BUNDLE_ID,
                "verified": False,
                "error": f"{error.__class__.__name__}: {error}",
            })

    result = {"ok": all(item.get("verified") is True for item in results), "results": results}
    RESULT_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULT_PATH.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
