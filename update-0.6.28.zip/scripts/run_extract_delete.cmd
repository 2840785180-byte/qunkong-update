@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "APP_ROOT=%~dp0.."
"%APP_ROOT%\runtime\python.exe" "%~dp0extract_wanyilianbo_videos.py" --delete-mode auto %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
echo Exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%
