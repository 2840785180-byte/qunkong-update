[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
try {
    $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $Utf8NoBom
    [Console]::InputEncoding = $Utf8NoBom
    $OutputEncoding = $Utf8NoBom
}
catch {
}

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptRoot
$Python = Join-Path $ProjectRoot "runtime\python.exe"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

Write-Step "Checking the portable runtime"
if (-not (Test-Path -LiteralPath $Python)) {
    throw "The embedded Python runtime is missing. Restore the runtime folder inside this app folder."
}

$probe = "import PySide6, pymobiledevice3, psutil, paramiko; print('Portable Python dependencies: OK')"
& $Python -c $probe
if ($LASTEXITCODE -ne 0) {
    throw "The embedded Python runtime cannot load its required components."
}

Write-Step "Checking Apple Mobile Device Service"
$service = Get-Service -Name "Apple Mobile Device Service" -ErrorAction SilentlyContinue
if ($null -eq $service) {
    throw "Apple Mobile Device Service was not found. Install iTunes or Apple Devices first."
}
if ($service.Status -ne "Running") {
    try {
        Start-Service -Name "Apple Mobile Device Service" -ErrorAction Stop
        $service.Refresh()
    }
    catch {
        throw "Apple Mobile Device Service is not running. Start it from Windows Services, then retry."
    }
}
if ($service.Status -ne "Running") {
    throw "Apple Mobile Device Service is not running. Start it from Windows Services, then retry."
}
Write-Host "Apple Mobile Device Service: Running" -ForegroundColor Green

Write-Step "Portable app environment is ready"
Write-Host "Built-in environment and iPhone driver are ready." -ForegroundColor Green
exit 0
