from __future__ import annotations

import argparse
import json
import re
import sys
import time
from collections.abc import Callable
from random import Random
from typing import Any

from iphone_control_center.services.ios_mcp_control import (
    McpHttpClient,
    McpProtocolError,
)
from iphone_control_center.services.tiktok_warmup import (
    TIKTOK_BUNDLE_ID,
    TikTokWarmupConfig,
    WarmupConfigError,
    comment_steps,
    random_like_steps,
    random_search_steps,
)


PERMISSION_MARKERS = (
    "允许",
    "Allow",
    "仅在使用 App 时允许",
    "Allow While Using App",
)
CONSENT_MARKERS = (
    "同意并继续",
    "Agree and continue",
    "Accept and continue",
)
RATE_LIMIT_MARKERS = (
    "访问太频繁",
    "操作太频繁",
    "稍后再试",
    "too many attempts",
    "try again later",
)
SECURITY_MARKERS = (
    "安全验证",
    "验证码",
    "captcha",
    "verify you are human",
)
LOGIN_REQUIRED_MARKERS = (
    "登录 TikTok",
    "Log in to TikTok",
    "登录或注册",
    "Log in or sign up",
    "Sign up for TikTok",
)
SEARCH_MARKERS = ("搜索", "Search", "搜索 TikTok", "Search TikTok")
HOME_MARKERS = ("首页", "Home", "For You", "推荐")
VIDEO_CONTROL_MARKERS = (
    "评论",
    "Comment",
    "分享",
    "Share",
    "点赞",
    "Like",
    "收藏",
    "Save",
)


def emit_progress(stage: str, message: str) -> None:
    safe = " ".join(str(message).split())[:500]
    print(f"WARMUP_PROGRESS|{stage}|{safe}", flush=True)


def emit_result(value: dict[str, Any]) -> None:
    print(
        "WARMUP_RESULT|" + json.dumps(value, ensure_ascii=False, separators=(",", ":")),
        flush=True,
    )


class WarmupFlowError(RuntimeError):
    def __init__(self, stage: str, detail: str) -> None:
        super().__init__(detail)
        self.stage = stage
        self.detail = detail


class TikTokWarmupRunner:
    def __init__(
        self,
        port: int,
        config: TikTokWarmupConfig,
        bundle_id: str = TIKTOK_BUNDLE_ID,
    ) -> None:
        self.client = McpHttpClient(f"http://127.0.0.1:{port}", timeout=60.0)
        self.config = config
        self.bundle_id = bundle_id
        self.rng = Random(config.seed)
        self.feed_watched = 0
        self.feed_swipes = 0
        self.search_runs = 0
        self.search_watched = 0
        self.likes = 0
        self.comments = 0
        self.interaction_errors = 0
        self.rests = 0
        self._active_started_at = time.monotonic()

    def run(self) -> dict[str, Any]:
        self.rests = getattr(self, "rests", 0)
        self._active_started_at = time.monotonic()
        self.client.connect()
        emit_progress("connect", "已连接手机控制服务")
        self._open_tiktok()
        if not (
            self.config.search_enabled
            and self.config.search_random_insert_enabled
        ):
            self._run_search_flow()
        self._run_feed_flow()
        self._return_to_recommendation()
        emit_progress("success", "自动养号任务完成")
        return {
            "success": True,
            "stage": "success",
            "detail": "自动养号任务完成",
            "feed_watched": self.feed_watched,
            "feed_swipes": self.feed_swipes,
            "search_runs": self.search_runs,
            "search_watched": self.search_watched,
            "likes": self.likes,
            "comments": self.comments,
            "interaction_errors": self.interaction_errors,
            "rests": self.rests,
        }

    def close(self) -> None:
        self.client.close()

    def _tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def _nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "get_ui_elements",
                {"visible_only": True, "clickable_only": False},
            )
        except McpProtocolError:
            return []
        if isinstance(value, dict):
            for key in ("elements", "ui_elements", "items"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    return [node for node in nodes if isinstance(node, dict)]
        return []

    def _ocr_nodes(self) -> list[dict[str, Any]]:
        try:
            value = self._tool(
                "ocr_screen",
                {"engine": "paddleocr", "min_confidence": 0.35},
            )
        except McpProtocolError:
            return []
        roots: list[Any] = []
        if isinstance(value, list):
            roots = value
        elif isinstance(value, dict):
            for key in ("results", "items", "texts", "elements", "lines"):
                nodes = value.get(key)
                if isinstance(nodes, list):
                    roots.extend(nodes)
        result: list[dict[str, Any]] = []
        for node in roots:
            if isinstance(node, str) and node.strip():
                result.append({"text": node.strip()})
            elif isinstance(node, dict):
                for key in ("text", "label", "value", "content"):
                    value = node.get(key)
                    if value is not None and str(value).strip():
                        result.append({**node, "text": str(value).strip()})
                        break
        return result

    def _texts(self, *, include_ocr: bool = False) -> list[str]:
        nodes = self._nodes()
        if include_ocr:
            nodes.extend(self._ocr_nodes())
        return [self._node_text(node) for node in nodes if self._node_text(node)]

    @staticmethod
    def _node_text(node: dict[str, Any]) -> str:
        for key in ("text", "label", "value", "name", "title"):
            value = node.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""

    @staticmethod
    def _normalize(value: str) -> str:
        return re.sub(r"\s+", "", str(value)).casefold()

    def _contains_any(self, texts: list[str], markers: tuple[str, ...]) -> bool:
        joined = self._normalize(" ".join(texts))
        return any(self._normalize(marker) in joined for marker in markers)

    def _frontmost_bundle(self) -> str:
        try:
            value = self._tool("get_frontmost_app", {})
        except McpProtocolError:
            return ""
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, dict):
            for key in ("bundleId", "bundle_id", "frontmostBundleId"):
                if value.get(key):
                    return str(value[key]).strip()
            app = value.get("app")
            if isinstance(app, dict):
                return str(app.get("bundleId") or app.get("bundle_id") or "")
        return ""

    def _screen_size(self) -> tuple[int, int]:
        try:
            value = self._tool("get_screen_info", {})
        except McpProtocolError:
            return (375, 667)
        if not isinstance(value, dict):
            return (375, 667)
        try:
            width = int(value.get("width") or 375)
            height = int(value.get("height") or 667)
        except (TypeError, ValueError):
            return (375, 667)
        return (width if width > 0 else 375, height if height > 0 else 667)

    def _tap_xy(self, x: float, y: float) -> None:
        width, height = self._screen_size()
        self._tool(
            "tap_screen",
            {
                "x": min(max(round(x), 0), width - 1),
                "y": min(max(round(y), 0), height - 1),
            },
        )

    def _tap_normalized(self, x_ratio: float, y_ratio: float) -> None:
        width, height = self._screen_size()
        self._tap_xy(width * x_ratio, height * y_ratio)
        time.sleep(0.45)

    def _tap_text(self, marker: str, *, exact: bool = True) -> bool:
        try:
            value = self._tool(
                "tap_element",
                {
                    "text": marker,
                    "match": "exact" if exact else "contains",
                    "role": "control",
                    "index": 0,
                },
            )
        except McpProtocolError:
            return False
        return isinstance(value, dict) and bool(value.get("tapped"))

    @staticmethod
    def _node_position(node: dict[str, Any]) -> tuple[float, float] | None:
        tap = node.get("tap")
        if isinstance(tap, dict) and tap.get("x") is not None and tap.get("y") is not None:
            try:
                return float(tap["x"]), float(tap["y"])
            except (TypeError, ValueError):
                pass
        rect = node.get("rect") or node.get("visible_rect")
        if isinstance(rect, dict):
            try:
                return (
                    float(rect["x"]) + float(rect.get("width") or 0) / 2,
                    float(rect["y"]) + float(rect.get("height") or 0) / 2,
                )
            except (KeyError, TypeError, ValueError):
                pass
        if isinstance(rect, (list, tuple)) and len(rect) >= 4:
            try:
                return (
                    float(rect[0]) + float(rect[2]) / 2,
                    float(rect[1]) + float(rect[3]) / 2,
                )
            except (TypeError, ValueError):
                pass
        return None

    def _find_node(
        self,
        markers: tuple[str, ...],
        *,
        exact: bool = False,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, Any] | None:
        for node in self._nodes():
            text = self._node_text(node)
            if not text:
                continue
            normalized = self._normalize(text)
            matched = any(
                (normalized == self._normalize(marker))
                if exact
                else (self._normalize(marker) in normalized)
                for marker in markers
            )
            if not matched:
                continue
            position = self._node_position(node)
            if position is None:
                continue
            x, y = position
            if min_x is not None and x < min_x:
                continue
            if max_x is not None and x > max_x:
                continue
            if min_y is not None and y < min_y:
                continue
            if max_y is not None and y > max_y:
                continue
            return node
        return None

    def _tap_node(self, node: dict[str, Any]) -> bool:
        position = self._node_position(node)
        if position is None:
            return False
        self._tap_xy(*position)
        time.sleep(0.45)
        return True

    def _tap_marker(
        self,
        markers: tuple[str, ...],
        *,
        exact: bool = True,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        for marker in markers:
            if self._tap_text(marker, exact=exact):
                time.sleep(0.45)
                return True
        node = self._find_node(
            markers,
            exact=exact,
            min_x=min_x,
            max_x=max_x,
            min_y=min_y,
            max_y=max_y,
        )
        return self._tap_node(node) if node is not None else False

    def _swipe_up(self) -> None:
        width, height = self._screen_size()
        self._tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.78),
                "toX": round(width * 0.5),
                "toY": round(height * 0.25),
                "duration": 480,
                "steps": 20,
            },
        )
        time.sleep(self.rng.uniform(0.7, 1.2))

    def _swipe_down(self) -> None:
        width, height = self._screen_size()
        self._tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.28),
                "toX": round(width * 0.5),
                "toY": round(height * 0.78),
                "duration": 420,
                "steps": 20,
            },
        )
        time.sleep(0.45)

    def _assert_healthy(self, texts: list[str]) -> None:
        if self._contains_any(texts, RATE_LIMIT_MARKERS):
            raise WarmupFlowError(
                "rate_limit",
                "TikTok 提示操作太频繁，已停止本机任务，避免账号风险。",
            )
        if self._contains_any(texts, SECURITY_MARKERS):
            raise WarmupFlowError(
                "security",
                "TikTok 要求安全验证，请在手机完成验证后再执行。",
            )
        if self._contains_any(texts, LOGIN_REQUIRED_MARKERS):
            raise WarmupFlowError(
                "login_required",
                "TikTok 主 App 还没有登录，请先完成账号登录。",
            )

    def _dismiss_overlays(self) -> None:
        for _attempt in range(2):
            texts = self._texts(include_ocr=True)
            self._assert_healthy(texts)
            joined = self._normalize(" ".join(texts))
            permission_context = any(
                marker in joined
                for marker in (
                    "通知",
                    "相机",
                    "麦克风",
                    "照片",
                    "notification",
                    "camera",
                    "microphone",
                    "photos",
                )
            )
            if permission_context and self._contains_any(texts, PERMISSION_MARKERS):
                if self._tap_marker(PERMISSION_MARKERS, exact=False):
                    emit_progress("permission", "已自动选择允许系统权限")
                    time.sleep(0.8)
                    continue
            if self._contains_any(texts, CONSENT_MARKERS):
                if self._tap_marker(CONSENT_MARKERS, exact=False):
                    emit_progress("consent", "已自动同意 TikTok 登录提示")
                    time.sleep(0.8)
                    continue
            break

    def _wait_frontmost(self, timeout: float = 12.0) -> None:
        deadline = time.monotonic() + timeout
        latest = ""
        while time.monotonic() < deadline:
            latest = self._frontmost_bundle()
            if latest == self.bundle_id:
                return
            time.sleep(0.3)
        raise WarmupFlowError(
            "launch",
            f"TikTok 没有进入前台，当前前台是 {latest or '未知 App'}。",
        )

    def _open_tiktok(self) -> None:
        emit_progress("launch", "正在唤醒手机并打开 TikTok")
        try:
            self._tool("wake_and_home", {"sequence": "auto"})
        except McpProtocolError:
            pass
        last_error = ""
        for attempt in range(1, 4):
            try:
                self._tool("launch_app", {"bundle_id": self.bundle_id})
                self._wait_frontmost(timeout=7.0)
                break
            except (WarmupFlowError, McpProtocolError) as error:
                last_error = " ".join(str(error).split())[:240]
                if attempt < 3:
                    emit_progress(
                        "launch",
                        f"TikTok 首次没有打开，正在重试（{attempt + 1}/3）",
                    )
                    time.sleep(1.0 * attempt)
        else:
            raise WarmupFlowError(
                "launch",
                f"TikTok 连续 3 次没有打开，请确认手机已解锁且 App 正常。{last_error}",
            )
        time.sleep(1.2)
        self._dismiss_overlays()
        emit_progress("launch", "TikTok 已在前台")

    def _maybe_take_rest(
        self,
        *,
        source: str = "",
        completed: int = 0,
        total: int = 0,
    ) -> None:
        if not self.config.rest_enabled:
            return
        now = time.monotonic()
        started_at = getattr(self, "_active_started_at", now)
        active_seconds = max(0.0, now - started_at)
        if active_seconds < self.config.rest_after_minutes * 60:
            return

        elapsed_minutes = max(1, int(active_seconds // 60))
        progress_text = (
            f"，{source}已完成 {completed}/{total} 条"
            if source and total > 0
            else ""
        )
        emit_progress(
            "rest_start",
            f"已连续操作 {elapsed_minutes} 分钟{progress_text}，"
            f"正在锁屏休息 {self.config.rest_duration_minutes} 分钟",
        )
        try:
            self._tool("press_power", {"duration": 100})
        except Exception as error:
            raise WarmupFlowError(
                "rest_lock",
                f"防检测休息需要锁屏，但锁屏失败：{' '.join(str(error).split())[:240]}",
            ) from error
        time.sleep(0.8)
        self._wait_for_rest()
        self._open_tiktok()
        self.rests += 1
        self._active_started_at = time.monotonic()
        emit_progress(
            "rest_end",
            f"已休息 {self.config.rest_duration_minutes} 分钟并重新打开 TikTok，"
            "从原视频进度继续养号",
        )

    def _wait_for_rest(self) -> None:
        remaining = self.config.rest_duration_minutes * 60
        while remaining > 0:
            chunk = min(60, remaining)
            time.sleep(chunk)
            remaining -= chunk
            if remaining > 0:
                emit_progress(
                    "rest_wait",
                    f"防检测休息中，剩余约 {max(1, (remaining + 59) // 60)} 分钟",
                )

    def _input_text(self, value: str) -> None:
        try:
            self._tool("input_text", {"text": value})
        except Exception:
            self._tool("type_text", {"text": value, "delay_ms": 45})
        time.sleep(0.6)

    def _wait_until(
        self,
        predicate: Callable[[list[str]], bool],
        *,
        timeout: float,
        stage: str,
        detail: str,
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        latest: list[str] = []
        while time.monotonic() < deadline:
            latest = self._texts(include_ocr=True)
            self._assert_healthy(latest)
            if predicate(latest):
                return latest
            time.sleep(0.35)
        raise WarmupFlowError(stage, detail)

    def _video_is_liked(self) -> bool:
        width, height = self._screen_size()
        for node in self._nodes():
            text = self._normalize(self._node_text(node))
            if "取消点赞" in text or "unlike" in text:
                return True
            position = self._node_position(node)
            if position is None:
                continue
            x, y = position
            if x < width * 0.65 or y < height * 0.35:
                continue
            if text in {"点赞", "like"} and bool(
                node.get("selected") or node.get("checked")
            ):
                return True
        return False

    def _like_current_video(self) -> bool:
        if self._video_is_liked():
            emit_progress("like", "当前视频已经点过赞，跳过避免取消点赞")
            return False
        width, height = self._screen_size()
        node = self._find_node(
            ("点赞", "Like", "喜欢", "赞"),
            exact=False,
            min_x=width * 0.65,
            max_x=width * 0.99,
            min_y=height * 0.35,
            max_y=height * 0.8,
        )
        if node is not None:
            self._tap_node(node)
        else:
            self._tap_normalized(0.92, 0.55)
        time.sleep(0.7)
        self.likes += 1
        emit_progress("like", f"已随机点赞，本次累计 {self.likes} 条")
        return True

    def _press_enter(self) -> None:
        try:
            self._tool("press_key", {"key": "enter"})
        except Exception:
            try:
                self._tool("press_key", {"key": "return"})
            except Exception:
                pass

    def _comment_current_video(self) -> bool:
        width, height = self._screen_size()
        opened = self._tap_marker(
            ("评论", "Comment", "Comments"),
            exact=False,
            min_x=width * 0.65,
            max_x=width * 0.99,
            min_y=height * 0.35,
            max_y=height * 0.9,
        )
        if not opened:
            self._tap_normalized(0.92, 0.64)
        time.sleep(1.0)
        field = self._find_node(
            ("添加评论", "Add comment", "写评论", "说点什么", "Post a comment"),
            exact=False,
            min_y=height * 0.45,
            max_y=height * 0.98,
        )
        if field is not None:
            self._tap_node(field)
        else:
            self._tap_normalized(0.45, 0.86)
        time.sleep(0.4)
        comment = self.rng.choice(self.config.comments)
        self._input_text(comment)
        sent = self._tap_marker(
            ("发送", "Send", "Post", "发表", "发布"),
            exact=False,
            min_y=height * 0.55,
            max_y=height * 0.99,
        )
        if not sent:
            self._press_enter()
        time.sleep(0.9)
        if not self._tap_marker(("关闭", "Close", "取消", "Cancel"), exact=False):
            self._swipe_down()
        self.comments += 1
        emit_progress("comment", f"已随机发布评论，本次累计 {self.comments} 条")
        return True

    def _watch_videos(
        self,
        video_count: int,
        *,
        like_enabled: bool,
        comment_enabled: bool,
        source: str,
        search_insert_steps: tuple[int, ...] = (),
    ) -> None:
        like_steps = set(
            random_like_steps(video_count, like_enabled, rng=self.rng)
        )
        comment_positions = set(
            comment_steps(video_count, self.config.comment_interval)
            if comment_enabled
            else ()
        )
        for index in range(1, video_count + 1):
            self._maybe_take_rest(
                source=source,
                completed=index - 1,
                total=video_count,
            )
            time.sleep(
                self.rng.randint(
                    self.config.watch_seconds_min,
                    self.config.watch_seconds_max,
                )
            )
            texts = self._texts(include_ocr=True)
            self._assert_healthy(texts)
            if index in like_steps:
                try:
                    self._like_current_video()
                except WarmupFlowError:
                    raise
                except Exception as error:
                    self.interaction_errors += 1
                    emit_progress(
                        "like_warning",
                        f"随机点赞未完成：{' '.join(str(error).split())[:180]}",
                    )
            if index in comment_positions:
                try:
                    self._comment_current_video()
                except WarmupFlowError:
                    raise
                except Exception as error:
                    self.interaction_errors += 1
                    emit_progress(
                        "comment_warning",
                        f"随机评论未完成：{' '.join(str(error).split())[:180]}",
                    )
            if source in {"feed", "推荐页"}:
                self.feed_watched += 1
            else:
                self.search_watched += 1
            if index == 1 or index == video_count or index % 10 == 0:
                emit_progress(
                    "watch",
                    f"{source}已观看 {index}/{video_count} 条视频",
                )
            if search_insert_steps and index in search_insert_steps:
                search_number = search_insert_steps.index(index) + 1
                emit_progress(
                    "search_insert",
                    f"推荐页随机插入第 {search_number}/{len(search_insert_steps)} 次搜索",
                )
                self._run_single_search_flow(
                    search_number,
                    len(search_insert_steps),
                )
            if index < video_count:
                self._swipe_up()
                self.feed_swipes += 1

    def _has_video_controls(self, texts: list[str]) -> bool:
        return self._contains_any(texts, VIDEO_CONTROL_MARKERS)

    def _has_search_page(self, texts: list[str]) -> bool:
        return self._contains_any(texts, SEARCH_MARKERS)

    def _open_search_page(self) -> None:
        if self._has_search_page(self._texts(include_ocr=True)):
            return
        width, height = self._screen_size()
        if self._tap_marker(
            SEARCH_MARKERS,
            exact=True,
            min_y=0,
            max_y=height * 0.25,
        ):
            time.sleep(1.0)
            if self._has_search_page(self._texts(include_ocr=True)):
                return
        for x_ratio, y_ratio in ((0.91, 0.09), (0.91, 0.13), (0.84, 0.09)):
            self._tap_normalized(x_ratio, y_ratio)
            time.sleep(1.0)
            if self._has_search_page(self._texts(include_ocr=True)):
                return
        raise WarmupFlowError(
            "search",
            "没有找到 TikTok 搜索入口，请确认主 App 页面正常。",
        )

    def _focus_search_field(self) -> None:
        height = self._screen_size()[1]
        node = self._find_node(
            SEARCH_MARKERS,
            exact=False,
            min_y=0,
            max_y=height * 0.28,
        )
        if node is not None:
            self._tap_node(node)
        else:
            self._tap_normalized(0.45, 0.12)
        time.sleep(0.5)

    def _clear_search_field(self) -> None:
        if self._tap_marker(("清除文本", "Clear text", "清除"), exact=True):
            time.sleep(0.2)
            return
        for _ in range(48):
            try:
                self._tool("press_key", {"key": "backspace"})
            except Exception:
                break

    def _open_first_search_result(self, keyword: str) -> None:
        self._press_enter()
        time.sleep(2.2)
        if self._has_video_controls(self._texts(include_ocr=True)):
            return
        self._tap_marker(("视频", "Videos"), exact=True)
        width, height = self._screen_size()
        keyword_node = None
        normalized_keyword = self._normalize(keyword)
        for node in self._nodes():
            text = self._node_text(node)
            position = self._node_position(node)
            if position is None or not text:
                continue
            x, y = position
            if y <= height * 0.2 or normalized_keyword not in self._normalize(text):
                continue
            if 0 <= x <= width * 0.95:
                keyword_node = node
                break
        if keyword_node is not None:
            self._tap_node(keyword_node)
            time.sleep(1.2)
            if self._has_video_controls(self._texts(include_ocr=True)):
                return
        for x_ratio, y_ratio in ((0.28, 0.34), (0.5, 0.52), (0.75, 0.34)):
            self._tap_normalized(x_ratio, y_ratio)
            time.sleep(1.0)
            if self._has_video_controls(self._texts(include_ocr=True)):
                return
        raise WarmupFlowError(
            "search_result",
            "搜索完成，但没有打开搜索结果里的视频。",
        )

    def _return_to_recommendation(self) -> bool:
        for _attempt in range(4):
            texts = self._texts(include_ocr=True)
            self._assert_healthy(texts)
            if not self._has_search_page(texts) and self._has_video_controls(texts):
                return True
            if self._tap_marker(HOME_MARKERS, exact=True):
                time.sleep(1.1)
                continue
            if self._tap_marker(("返回", "Back"), exact=True):
                time.sleep(1.0)
                continue
            self._tap_normalized(0.1, 0.94)
            time.sleep(1.0)
        texts = self._texts(include_ocr=True)
        return not self._has_search_page(texts)

    def _run_feed_flow(self) -> None:
        search_insert_steps = (
            random_search_steps(
                self.config.feed_video_count,
                self.config.search_count,
                rng=self.rng,
            )
            if self.config.search_enabled
            and self.config.search_random_insert_enabled
            else ()
        )
        emit_progress(
            "feed",
            f"开始推荐页养号：{self.config.feed_video_count} 条"
            + (
                f"，将随机插入 {len(search_insert_steps)} 次搜索"
                if search_insert_steps
                else ""
            ),
        )
        self._dismiss_overlays()
        self._watch_videos(
            self.config.feed_video_count,
            like_enabled=self.config.feed_like_enabled,
            comment_enabled=self.config.comment_enabled,
            source="推荐页",
            search_insert_steps=search_insert_steps,
        )

    def _run_search_flow(self) -> None:
        if (
            not self.config.search_enabled
            or self.config.search_random_insert_enabled
        ):
            return
        self._return_to_recommendation()
        for index in range(1, self.config.search_count + 1):
            self._run_single_search_flow(index, self.config.search_count)
        emit_progress(
            "search_done",
            "搜索定向流完成，已返回推荐页，继续执行推荐页养号",
        )

    def _run_single_search_flow(self, index: int, total: int) -> None:
        self._maybe_take_rest(source="搜索定向流")
        emit_progress(
            "search",
            f"第 {index}/{total} 次搜索：{self.config.search_keyword}",
        )
        self._open_search_page()
        self._focus_search_field()
        self._clear_search_field()
        self._input_text(self.config.search_keyword)
        self._open_first_search_result(self.config.search_keyword)
        self.search_runs += 1
        self._watch_videos(
            self.config.search_video_count,
            like_enabled=self.config.search_like_enabled,
            comment_enabled=self.config.comment_enabled,
            source="搜索视频",
        )
        if not self._return_to_recommendation():
            raise WarmupFlowError(
                "return_feed",
                "搜索观看条数已达到，但没有返回推荐页面。",
            )


def _failure_result(
    runner: TikTokWarmupRunner | None,
    stage: str,
    detail: str,
) -> dict[str, Any]:
    return {
        "success": False,
        "stage": stage,
        "detail": " ".join(str(detail).split())[:800],
        "feed_watched": runner.feed_watched if runner else 0,
        "feed_swipes": runner.feed_swipes if runner else 0,
        "search_runs": runner.search_runs if runner else 0,
        "search_watched": runner.search_watched if runner else 0,
        "likes": runner.likes if runner else 0,
        "comments": runner.comments if runner else 0,
        "interaction_errors": runner.interaction_errors if runner else 0,
        "rests": getattr(runner, "rests", 0) if runner else 0,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TikTok 自动养号任务")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--bundle-id", default=TIKTOK_BUNDLE_ID)
    args = parser.parse_args(argv)

    runner: TikTokWarmupRunner | None = None
    try:
        payload = json.loads(sys.stdin.read())
        config = TikTokWarmupConfig.from_payload(payload)
        runner = TikTokWarmupRunner(args.port, config, args.bundle_id)
        result = runner.run()
    except (WarmupConfigError, json.JSONDecodeError) as error:
        result = _failure_result(None, "config", str(error))
    except WarmupFlowError as error:
        result = _failure_result(runner, error.stage, error.detail)
    except Exception as error:
        result = _failure_result(
            runner,
            "unexpected",
            str(error) or error.__class__.__name__,
        )
    finally:
        if runner is not None:
            runner.close()
    emit_result(result)
    return 0 if result.get("success") else 2


if __name__ == "__main__":
    raise SystemExit(main())
