from __future__ import annotations

import argparse
import asyncio
import base64
import inspect
import json
import sys
import time
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable
from xml.etree import ElementTree

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QImage
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QWidget


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from iphone_control_center.core.context import AppContext, create_context  # noqa: E402
from iphone_control_center.services.screen_capture import ScreenStreamState  # noqa: E402
from iphone_control_center.services.wda_control import WdaControlState  # noqa: E402
from iphone_control_center.ui.main_window import MainWindow  # noqa: E402
from iphone_control_center.ui.theme import apply_theme  # noqa: E402


EXPECTED_UDID = "5b45e731bf69a088a6c00a2873d82ae6b8b8f68d"
EXPECTED_PRODUCT_TYPE = "iPhone10,1"
EXPECTED_IOS_VERSION = "14.4.1"
EXPECTED_BUILD_VERSION = "18D61"
EXPECTED_STEP_TOTAL = 18
TEXT_PROBE = "IC20probe"


class AcceptanceError(RuntimeError):
    pass


@dataclass(slots=True)
class StepResult:
    name: str
    success: bool
    detail: str
    command_id: str | None = None
    command_message: str | None = None
    gui_screenshot: str | None = None
    device_screenshot: str | None = None
    frame_sequence: int | None = None
    image_change: float | None = None


@dataclass(slots=True)
class DeviceState:
    locked: bool
    active_bundle_id: str
    active_app_name: str
    elements: list[dict[str, str]]
    screenshot_png: bytes | None = None

    @property
    def keyboard_present(self) -> bool:
        return any(
            element.get("type") == "XCUIElementTypeKeyboard"
            and element.get("visible") == "true"
            for element in self.elements
        )

    @property
    def home_screen_visible(self) -> bool:
        return any(
            element.get("name") == "Home screen icons"
            and element.get("visible") == "true"
            for element in self.elements
        )

    def text_field(self) -> dict[str, str] | None:
        return next(
            (
                element
                for element in self.elements
                if element.get("type")
                in {
                    "XCUIElementTypeSearchField",
                    "XCUIElementTypeTextField",
                    "XCUIElementTypeSecureTextField",
                }
                and element.get("visible") == "true"
            ),
            None,
        )

    def find(
        self,
        element_type: str,
        *,
        name: str | None = None,
    ) -> dict[str, str] | None:
        return next(
            (
                element
                for element in self.elements
                if element.get("type") == element_type
                and (name is None or element.get("name") == name)
                and element.get("visible") == "true"
            ),
            None,
        )


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _mean_brightness(path: Path) -> float:
    image = QImage(str(path))
    if image.isNull():
        return 0.0
    total = 0.0
    count = 0
    step_x = max(image.width() // 50, 1)
    step_y = max(image.height() // 80, 1)
    for y in range(0, image.height(), step_y):
        for x in range(0, image.width(), step_x):
            color = image.pixelColor(x, y)
            total += 0.2126 * color.red() + 0.7152 * color.green() + 0.0722 * color.blue()
            count += 1
    return round(total / count, 2) if count else 0.0


def _image_change(first: Path, second: Path) -> float:
    left = QImage(str(first))
    right = QImage(str(second))
    if left.isNull() or right.isNull() or left.size() != right.size():
        return 0.0
    total = 0.0
    count = 0
    step_x = max(left.width() // 60, 1)
    step_y = max(left.height() // 90, 1)
    for y in range(0, left.height(), step_y):
        for x in range(0, left.width(), step_x):
            a = left.pixelColor(x, y)
            b = right.pixelColor(x, y)
            total += (
                abs(a.red() - b.red())
                + abs(a.green() - b.green())
                + abs(a.blue() - b.blue())
            ) / 3.0
            count += 1
    return round(total / count, 2) if count else 0.0


async def _read_wda_state(
    *,
    include_screenshot: bool = False,
    include_source: bool = True,
    source_attempts: int = 3,
    source_timeout: float = 8.0,
) -> DeviceState:
    from pymobiledevice3.lockdown import create_using_usbmux
    from pymobiledevice3.services.wda import WdaServiceClient

    client = None
    lockdown = None
    try:
        lockdown = await create_using_usbmux(
            serial=EXPECTED_UDID,
            identifier=EXPECTED_UDID,
            label="iPhoneControlCenter20StateAssertion",
            autopair=False,
            connection_type="USB",
            pair_timeout=2,
        )
        client = WdaServiceClient(lockdown)

        async def get_value(path: str, *, timeout: float = 6.0) -> object:
            response = await asyncio.wait_for(
                client._request_json("GET", path, None),
                timeout=timeout,
            )
            return response.get("value")

        locked_value = await get_value("/wda/locked")
        active_value = await get_value("/wda/activeAppInfo")
        if not isinstance(locked_value, bool):
            raise AcceptanceError(f"WDA 锁定状态格式异常: {locked_value!r}")
        if not isinstance(active_value, dict):
            raise AcceptanceError(f"WDA 活动 App 格式异常: {active_value!r}")
        elements: list[dict[str, str]] = []
        if include_source:
            source_error: Exception | None = None
            attempts = max(int(source_attempts), 1)
            for attempt in range(attempts):
                try:
                    source_value = await get_value(
                        "/source",
                        timeout=source_timeout,
                    )
                    if not isinstance(source_value, str):
                        raise AcceptanceError("WDA 未返回可解析的 UI 源码")
                    root = ElementTree.fromstring(source_value)
                    elements = [
                        dict(element.attrib)
                        for element in root.iter()
                        if element.attrib.get("type")
                    ]
                    break
                except (ElementTree.ParseError, TimeoutError, asyncio.TimeoutError) as error:
                    source_error = error
                    if attempt < attempts - 1:
                        await asyncio.sleep(0.35)
            else:
                assert source_error is not None
                raise AcceptanceError(
                    "WDA UI 源码连续 3 次读取失败: "
                    f"{source_error.__class__.__name__}: {source_error}"
                ) from source_error
        screenshot_png = None
        if include_screenshot:
            screenshot_value = await get_value("/screenshot", timeout=10.0)
            if not isinstance(screenshot_value, str):
                raise AcceptanceError("WDA 未返回锁屏/唤醒截图")
            screenshot_png = base64.b64decode(screenshot_value)
            if screenshot_png[:8] != b"\x89PNG\r\n\x1a\n":
                raise AcceptanceError("WDA 返回的截图不是 PNG")

        return DeviceState(
            locked=locked_value,
            active_bundle_id=str(active_value.get("bundleId") or ""),
            active_app_name=str(active_value.get("name") or ""),
            elements=elements,
            screenshot_png=screenshot_png,
        )
    except AcceptanceError:
        raise
    except Exception as error:
        raise AcceptanceError(
            f"读取 WDA 真实设备状态失败: {error.__class__.__name__}: {error}"
        ) from error
    finally:
        if lockdown is not None:
            try:
                result = lockdown.close()
                if inspect.isawaitable(result):
                    await result
            except Exception:
                pass


async def _read_device_identity() -> dict[str, str | None]:
    from pymobiledevice3.lockdown import create_using_usbmux

    client = None
    try:
        client = await create_using_usbmux(
            serial=EXPECTED_UDID,
            identifier=EXPECTED_UDID,
            label="iPhoneControlCenter20LiveAcceptance",
            autopair=False,
            connection_type="USB",
            pair_timeout=2,
        )
        metadata = dict(await client.get_value())
        return {
            "udid": str(metadata.get("UniqueDeviceID") or "").lower(),
            "product_type": str(metadata.get("ProductType") or ""),
            "ios_version": str(metadata.get("ProductVersion") or ""),
            "build_version": str(metadata.get("BuildVersion") or ""),
        }
    finally:
        if client is not None:
            try:
                result = client.close()
                if inspect.isawaitable(result):
                    await result
            except Exception:
                pass


class LiveAcceptance:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir.resolve()
        self.data_dir = self.output_dir / "data"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.app = QApplication.instance() or QApplication([sys.argv[0]])
        self.app.setApplicationName("iPhone Control Center 20 Live Acceptance")
        apply_theme(self.app)
        self.context: AppContext | None = None
        self.window: MainWindow | None = None
        self.slot_no: int | None = None
        self.command_events: list[dict[str, object]] = []
        self.steps: list[StepResult] = []
        self.identity: dict[str, str | None] = {}
        self.frame_width = 0
        self.frame_height = 0
        self.wda_window_width = 0
        self.wda_window_height = 0
        self.started = time.monotonic()

    def process(self, seconds: float = 0.0) -> None:
        deadline = time.monotonic() + seconds
        while True:
            self.app.processEvents()
            if time.monotonic() >= deadline:
                return
            time.sleep(0.02)

    def wait_until(
        self,
        predicate: Callable[[], object | None],
        *,
        timeout: float,
        label: str,
    ) -> object:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.process(0.04)
            value = predicate()
            if value:
                return value
        raise AcceptanceError(f"{label}（等待 {timeout:.0f} 秒仍未完成）")

    def on_command_finished(
        self,
        slot_no: int,
        command_id: str,
        success: bool,
        message: str,
    ) -> None:
        self.command_events.append(
            {
                "slot_no": slot_no,
                "command_id": command_id,
                "success": success,
                "message": message,
                "monotonic": time.monotonic(),
            }
        )

    def wait_command(self, start_index: int, *, timeout: float) -> dict[str, object]:
        def completed() -> object | None:
            if len(self.command_events) <= start_index:
                return None
            return self.command_events[start_index]

        event = self.wait_until(completed, timeout=timeout, label="WDA 命令完成")
        assert isinstance(event, dict)
        if not event.get("success"):
            raise AcceptanceError(str(event.get("message") or "WDA 命令执行失败"))
        return event

    def read_device_state(
        self,
        *,
        include_screenshot: bool = False,
        include_source: bool = True,
    ) -> DeviceState:
        return asyncio.run(
            _read_wda_state(
                include_screenshot=include_screenshot,
                include_source=include_source,
            )
        )

    def read_settings_state_tolerant(self) -> DeviceState:
        """Read Settings UI when possible without failing on its root /source."""
        try:
            return asyncio.run(
                _read_wda_state(
                    include_source=True,
                    source_attempts=1,
                    source_timeout=3.0,
                )
            )
        except AcceptanceError:
            # iOS 14 Settings can stall /source on the root list. Active-app
            # state is still enough to continue the gesture checks.
            return self.read_device_state(include_source=False)

    def wait_device_state(
        self,
        predicate: Callable[[DeviceState], bool],
        *,
        timeout: float,
        label: str,
        include_source: bool = True,
    ) -> DeviceState:
        last_state: DeviceState | None = None
        last_error: str | None = None

        def verified_state() -> object | None:
            nonlocal last_state, last_error
            try:
                state = self.read_device_state(include_source=include_source)
            except Exception as error:
                last_error = str(error)
                return None
            last_state = state
            return state if predicate(state) else None

        try:
            state = self.wait_until(verified_state, timeout=timeout, label=label)
        except AcceptanceError as error:
            detail = ""
            if last_state is not None:
                detail = (
                    f"，最后状态锁定={last_state.locked}，"
                    f"活动 App={last_state.active_bundle_id!r}，"
                    f"键盘={last_state.keyboard_present}"
                )
            elif last_error:
                detail = f"，最后错误：{last_error}"
            raise AcceptanceError(f"{error}{detail}") from error
        assert isinstance(state, DeviceState)
        return state

    def verify_last_step(
        self,
        condition: bool,
        *,
        success_detail: str,
        failure_detail: str,
    ) -> None:
        if not condition:
            if self.steps:
                self.steps[-1].success = False
                self.steps[-1].detail += f"；验证失败：{failure_detail}"
            raise AcceptanceError(failure_detail)
        if self.steps:
            self.steps[-1].detail += f"；{success_detail}"

    def element_center_pixels(self, element: dict[str, str]) -> tuple[int, int]:
        if min(
            self.frame_width,
            self.frame_height,
            self.wda_window_width,
            self.wda_window_height,
        ) <= 0:
            raise AcceptanceError("设备画面与 WDA 窗口尺寸尚未就绪")
        try:
            x = float(element["x"])
            y = float(element["y"])
            width = float(element["width"])
            height = float(element["height"])
        except (KeyError, TypeError, ValueError) as error:
            raise AcceptanceError(f"WDA 元素坐标无效: {element}") from error
        return (
            round(
                (x + width / 2.0)
                * self.frame_width
                / self.wda_window_width
            ),
            round(
                (y + height / 2.0)
                * self.frame_height
                / self.wda_window_height
            ),
        )

    def click_device_element(
        self,
        element: dict[str, str],
        *,
        name: str,
        settle_ms: int = 900,
    ) -> None:
        x, y = self.element_center_pixels(element)
        self.click_canvas(x, y, name=name, settle_ms=settle_ms)

    def gui_screenshot(self, label: str) -> Path:
        assert self.window is not None
        path = self.output_dir / f"gui_{label}.png"
        if not self.window.grab().save(str(path), "PNG"):
            raise AcceptanceError(f"无法保存 GUI 截图: {path}")
        return path

    def current_frame(self, *, timeout: float = 4.0) -> dict[str, object]:
        assert self.context is not None and self.slot_no is not None

        def available() -> object | None:
            snapshot = self.context.screen_capture.snapshot(self.slot_no)
            return snapshot.frame if snapshot is not None and snapshot.frame is not None else None

        frame = self.wait_until(available, timeout=timeout, label="真实屏幕帧")
        return self._frame_payload(frame)

    def newer_frame(self, after_sequence: int, *, timeout: float = 6.0) -> dict[str, object]:
        assert self.context is not None and self.slot_no is not None

        def newer() -> object | None:
            snapshot = self.context.screen_capture.snapshot(self.slot_no)
            if snapshot is None or snapshot.frame is None:
                return None
            return snapshot.frame if snapshot.frame.sequence > after_sequence else None

        try:
            frame = self.wait_until(newer, timeout=timeout, label="新屏幕帧")
        except AcceptanceError:
            snapshot = self.context.screen_capture.snapshot(self.slot_no)
            frame = snapshot.frame if snapshot is not None else None
        if frame is None:
            raise AcceptanceError("真实屏幕帧不可用")
        return self._frame_payload(frame)

    @staticmethod
    def _frame_payload(frame: object) -> dict[str, object]:
        return {
            "png": frame.png,
            "sequence": frame.sequence,
            "width": frame.width,
            "height": frame.height,
            "capture_latency_ms": round(frame.capture_latency_ms, 1),
            "measured_fps": round(frame.measured_fps, 2),
        }

    def save_device_screenshot(self, label: str, *, after_sequence: int) -> tuple[Path, dict[str, object]]:
        frame = self.newer_frame(after_sequence)
        path = self.output_dir / f"device_{label}.png"
        path.write_bytes(frame["png"])
        return path, frame

    def add_step(
        self,
        name: str,
        *,
        detail: str,
        gui_path: Path | None = None,
        device_path: Path | None = None,
        frame: dict[str, object] | None = None,
        command: dict[str, object] | None = None,
        image_change: float | None = None,
    ) -> None:
        self.steps.append(
            StepResult(
                name=name,
                success=True,
                detail=detail,
                command_id=str(command.get("command_id")) if command else None,
                command_message=str(command.get("message")) if command else None,
                gui_screenshot=str(gui_path) if gui_path else None,
                device_screenshot=str(device_path) if device_path else None,
                frame_sequence=int(frame["sequence"]) if frame else None,
                image_change=image_change,
            )
        )
        print(
            f"IC20_PROGRESS {len(self.steps)} {EXPECTED_STEP_TOTAL} {name}",
            flush=True,
        )

    def click_widget(
        self,
        widget: QWidget,
        *,
        name: str,
        timeout: float = 35.0,
        settle_ms: int = 800,
    ) -> None:
        if not widget.isVisible() or not widget.isEnabled():
            raise AcceptanceError(f"GUI 控件不可用: {name}")
        before = self.current_frame()
        before_path = self.output_dir / f"device_{name}_before.png"
        before_path.write_bytes(before["png"])
        start = len(self.command_events)
        QTest.mouseClick(
            widget,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
            widget.rect().center(),
        )
        command = self.wait_command(start, timeout=timeout)
        QTest.qWait(settle_ms)
        after_path, frame = self.save_device_screenshot(
            f"{name}_after",
            after_sequence=int(before["sequence"]),
        )
        change = _image_change(before_path, after_path)
        self.add_step(
            name,
            detail=f"{name} 由真实 Qt 按钮触发",
            gui_path=self.gui_screenshot(f"{name}_after"),
            device_path=after_path,
            frame=frame,
            command=command,
            image_change=change,
        )

    def wait_canvas_frame(
        self,
        *,
        min_sequence: int = 0,
        timeout: float = 8.0,
    ) -> object:
        assert self.window is not None
        canvas = self.window.screen_stage.canvas

        def displayed() -> object | None:
            frame = canvas.frame_info
            rect = canvas.image_rect()
            if (
                frame is None
                or frame.sequence < min_sequence
                or rect.isNull()
                or rect.width() <= 1
                or rect.height() <= 1
            ):
                return None
            return frame

        return self.wait_until(
            displayed,
            timeout=timeout,
            label="GUI 画布显示真实屏幕帧",
        )

    def canvas_point(self, x: int, y: int, *, min_sequence: int = 0) -> QPoint:
        assert self.window is not None
        canvas = self.window.screen_stage.canvas
        self.wait_canvas_frame(min_sequence=min_sequence)
        frame = canvas.frame_info
        rect = canvas.image_rect()
        if frame is None or rect.isNull():
            raise AcceptanceError("手机画面尚未就绪，无法映射点击坐标")
        return QPoint(
            round(rect.left() + (x / frame.width) * rect.width()),
            round(rect.top() + (y / frame.height) * rect.height()),
        )

    def click_canvas(
        self,
        x: int,
        y: int,
        *,
        name: str,
        settle_ms: int = 1100,
    ) -> None:
        assert self.window is not None
        canvas = self.window.screen_stage.canvas
        before = self.current_frame()
        before_path = self.output_dir / f"device_{name}_before.png"
        before_path.write_bytes(before["png"])
        point = self.canvas_point(x, y, min_sequence=int(before["sequence"]))
        start = len(self.command_events)
        QTest.mouseClick(
            canvas,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
            point,
        )
        command = self.wait_command(start, timeout=35.0)
        QTest.qWait(settle_ms)
        after_path, frame = self.save_device_screenshot(
            f"{name}_after",
            after_sequence=int(before["sequence"]),
        )
        change = _image_change(before_path, after_path)
        self.add_step(
            name,
            detail=f"真实手机画面点击 ({x}, {y}) 像素",
            gui_path=self.gui_screenshot(f"{name}_after"),
            device_path=after_path,
            frame=frame,
            command=command,
            image_change=change,
        )

    def swipe_canvas(
        self,
        start_xy: tuple[int, int],
        end_xy: tuple[int, int],
        *,
        name: str,
        hold_ms: int = 520,
        settle_ms: int = 800,
        min_image_change: float | None = None,
    ) -> None:
        assert self.window is not None
        canvas = self.window.screen_stage.canvas
        before = self.current_frame()
        before_path = self.output_dir / f"device_{name}_before.png"
        before_path.write_bytes(before["png"])
        start_point = self.canvas_point(
            *start_xy,
            min_sequence=int(before["sequence"]),
        )
        end_point = self.canvas_point(
            *end_xy,
            min_sequence=int(before["sequence"]),
        )
        start = len(self.command_events)
        QTest.mousePress(
            canvas,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
            start_point,
        )
        QTest.qWait(hold_ms)
        QTest.mouseRelease(
            canvas,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
            end_point,
        )
        command = self.wait_command(start, timeout=35.0)
        QTest.qWait(settle_ms)
        after_path, frame = self.save_device_screenshot(
            f"{name}_after",
            after_sequence=int(before["sequence"]),
        )
        change = _image_change(before_path, after_path)
        self.add_step(
            name,
            detail=f"真实手机画面滑动 {start_xy} -> {end_xy} 像素",
            gui_path=self.gui_screenshot(f"{name}_after"),
            device_path=after_path,
            frame=frame,
            command=command,
            image_change=change,
        )
        if min_image_change is not None and change < min_image_change:
            self.verify_last_step(
                False,
                success_detail="",
                failure_detail=(
                    f"滑动后画面变化 {change:.2f} 低于阈值 {min_image_change:.2f}"
                ),
            )

    def verify_identity(self) -> None:
        self.identity = asyncio.run(_read_device_identity())
        expected = {
            "udid": EXPECTED_UDID,
            "product_type": EXPECTED_PRODUCT_TYPE,
            "ios_version": EXPECTED_IOS_VERSION,
            "build_version": EXPECTED_BUILD_VERSION,
        }
        mismatches = [
            f"{key}={self.identity.get(key)!r}，期望 {value!r}"
            for key, value in expected.items()
            if str(self.identity.get(key, "")).lower() != value.lower()
        ]
        if mismatches:
            raise AcceptanceError("目标真机身份不匹配，已拒绝测试：" + "；".join(mismatches))
        self.add_step(
            "target_identity",
            detail=(
                f"USB Lockdown 身份匹配：{EXPECTED_PRODUCT_TYPE} / iOS "
                f"{EXPECTED_IOS_VERSION} / {EXPECTED_BUILD_VERSION} / {EXPECTED_UDID}"
            ),
        )

    def start_ui(self) -> None:
        self.context = create_context(self.data_dir)
        self.context.wda_control.command_finished.connect(self.on_command_finished)
        self.window = MainWindow(self.context)
        self.window.resize(1580, 940)
        self.window.show()
        self.window.raise_()
        self.window.activateWindow()
        self.process(0.4)

        def target_slot() -> object | None:
            assert self.context is not None
            return next(
                (
                    slot
                    for slot in self.context.device_manager.slots
                    if (slot.udid or "").lower() == EXPECTED_UDID
                    and slot.state.is_online
                ),
                None,
            )

        slot = self.wait_until(target_slot, timeout=30.0, label="USB 发现目标 iPhone")
        self.slot_no = int(getattr(slot, "slot_no"))
        model = str(getattr(slot, "model", ""))
        if EXPECTED_PRODUCT_TYPE not in model:
            raise AcceptanceError(f"GUI 槽位型号异常: {model!r}")
        if getattr(slot, "ios_version", None) != EXPECTED_IOS_VERSION:
            raise AcceptanceError(f"GUI 槽位 iOS 版本异常: {getattr(slot, 'ios_version', None)!r}")

        self.window.device_list.list_widget.setCurrentRow(
            self.window.device_list.list_widget.row(
                self.window.device_list._items[self.slot_no]
            )
        )
        self.process(0.3)
        self.add_step(
            "device_binding",
            detail=f"真实 USB 设备已绑定 GUI 槽位 iPhone {self.slot_no:02d}",
            gui_path=self.gui_screenshot("device_bound"),
        )

    def wait_ready(self) -> None:
        assert self.context is not None and self.window is not None and self.slot_no is not None

        def wda_ready() -> object | None:
            snapshot = self.context.wda_control.snapshot(self.slot_no)
            if snapshot is None:
                return None
            if snapshot.state == WdaControlState.ERROR:
                raise AcceptanceError(f"WDA 启动失败: {snapshot.detail}")
            return snapshot if snapshot.state == WdaControlState.READY else None

        wda = self.wait_until(wda_ready, timeout=150.0, label="WDA 就绪")

        def screen_ready() -> object | None:
            snapshot = self.context.screen_capture.snapshot(self.slot_no)
            if snapshot is None or snapshot.state == ScreenStreamState.ERROR:
                return None
            return snapshot if snapshot.state == ScreenStreamState.STREAMING and snapshot.frame else None

        screen = self.wait_until(screen_ready, timeout=45.0, label="真实屏幕流")
        frame = screen.frame
        assert frame is not None
        if not all(control.isEnabled() for control in self.window.screen_stage.interaction_controls):
            raise AcceptanceError("WDA 已就绪，但 GUI 交互控件未启用")
        if (frame.width, frame.height) != (750, 1334):
            raise AcceptanceError(f"画面分辨率异常: {frame.width}x{frame.height}")
        if getattr(wda, "window_width") != 375 or getattr(wda, "window_height") != 667:
            raise AcceptanceError(
                f"WDA 窗口尺寸异常: {getattr(wda, 'window_width')}x{getattr(wda, 'window_height')}"
            )
        self.wait_canvas_frame(min_sequence=int(frame.sequence), timeout=8.0)
        self.frame_width = int(frame.width)
        self.frame_height = int(frame.height)
        self.wda_window_width = int(getattr(wda, "window_width"))
        self.wda_window_height = int(getattr(wda, "window_height"))
        path = self.output_dir / "device_ready.png"
        path.write_bytes(frame.png)
        self.add_step(
            "ready_state",
            detail=(
                f"真实画面 {frame.width}x{frame.height}；WDA 375x667 pt；"
                f"采集 {frame.capture_latency_ms:.0f} ms；交互控件全部启用"
            ),
            gui_path=self.gui_screenshot("ready"),
            device_path=path,
            frame={"sequence": frame.sequence},
        )

    def run_interactions(self) -> None:
        assert self.window is not None
        stage = self.window.screen_stage

        def search_value(state: DeviceState) -> str | None:
            field = state.text_field()
            return str(field.get("value") or "") if field is not None else None

        self.click_widget(stage.home_button, name="gui_home_initial", settle_ms=900)
        state = self.wait_device_state(
            lambda current: current.active_bundle_id == "com.apple.springboard",
            timeout=10.0,
            label="Home 后回到 SpringBoard",
        )
        self.verify_last_step(
            state.home_screen_visible,
            success_detail="WDA 确认活动 App 为 com.apple.springboard，主屏幕可见",
            failure_detail="Home 命令已执行，但 WDA 未看到主屏幕",
        )

        state = self.read_device_state()
        settings_icon = state.find("XCUIElementTypeIcon", name="Settings")
        if settings_icon is None:
            raise AcceptanceError("主屏幕上未找到可访问的 Settings 图标")
        self.click_device_element(
            settings_icon,
            name="gui_tap_open_settings",
            settle_ms=1200,
        )
        state = self.wait_device_state(
            lambda current: current.active_bundle_id == "com.apple.Preferences",
            timeout=12.0,
            label="点击 Settings 后进入设置 App",
            include_source=False,
        )
        self.verify_last_step(
            True,
            success_detail="WDA 确认活动 App 为 com.apple.Preferences",
            failure_detail="设置 App 未成为活动 App",
        )

        # A previous run may have left Settings on its search hierarchy. Read
        # source once with a short timeout so a visible Cancel button can be
        # cleared, then tolerate /source stalls on the root list.
        state = self.read_settings_state_tolerant()
        cancel_button = state.find("XCUIElementTypeButton", name="Cancel")
        if cancel_button is not None:
            self.click_device_element(
                cancel_button,
                name="gui_cancel_settings_search",
                settle_ms=1200,
            )
            cancel_change = self.steps[-1].image_change or 0.0
            self.verify_last_step(
                cancel_change >= 1.0,
                success_detail=(
                    f"点击 Cancel 后真实画面变化 {cancel_change:.2f}，已退出搜索页"
                ),
                failure_detail="点击 Cancel 后画面未变化",
            )

        self.swipe_canvas(
            (360, 1100),
            (360, 300),
            name="gui_swipe_up",
            settle_ms=900,
            min_image_change=2.0,
        )
        self.swipe_canvas(
            (360, 300),
            (360, 1150),
            name="gui_swipe_down",
            settle_ms=900,
            min_image_change=2.0,
        )

        # iOS 14 Settings can stop answering /source while its root list is
        # visible. Use the known search-bar location, then assert keyboard and
        # field values once the app enters its lighter search hierarchy.
        self.click_canvas(
            375,
            272,
            name="gui_tap_settings_search",
            settle_ms=700,
        )
        try:
            state = self.wait_device_state(
                lambda current: current.keyboard_present,
                timeout=7.0,
                label="聚焦 Settings 搜索框并显示键盘",
            )
        except AcceptanceError:
            self.click_canvas(
                375,
                272,
                name="gui_tap_settings_search_retry",
                settle_ms=700,
            )
            state = self.wait_device_state(
                lambda current: current.keyboard_present,
                timeout=7.0,
                label="第二次聚焦 Settings 搜索框",
            )
            self.verify_last_step(
                True,
                success_detail="WDA 确认软键盘已出现",
                failure_detail="Settings 搜索框没有获得焦点",
            )
        else:
            self.verify_last_step(
                True,
                success_detail="WDA 确认软键盘已出现",
                failure_detail="Settings 搜索框没有获得焦点",
            )

        state = self.read_device_state()
        if search_value(state):
            clear_button = state.find("XCUIElementTypeButton", name="Clear text")
            if clear_button is None:
                raise AcceptanceError("Settings 搜索框已有内容，但找不到清除按钮")
            self.click_device_element(
                clear_button,
                name="gui_clear_settings_search",
                settle_ms=600,
            )
            state = self.wait_device_state(
                lambda current: not search_value(current),
                timeout=8.0,
                label="清除 Settings 搜索框旧内容",
            )
            self.verify_last_step(
                True,
                success_detail="WDA 确认搜索框已为空",
                failure_detail="Settings 搜索框旧内容未清除",
            )

        QTest.qWait(300)
        before_text = self.current_frame()
        before_text_path = self.output_dir / "device_gui_text_before.png"
        before_text_path.write_bytes(before_text["png"])
        stage.text_input.clear()
        QTest.keyClicks(stage.text_input, TEXT_PROBE)
        if stage.text_input.text() != TEXT_PROBE:
            raise AcceptanceError("GUI 文字输入框未收到 QTest 键盘输入")
        start = len(self.command_events)
        QTest.mouseClick(
            stage.send_text_button,
            Qt.MouseButton.LeftButton,
            Qt.KeyboardModifier.NoModifier,
            stage.send_text_button.rect().center(),
        )
        text_command = self.wait_command(start, timeout=35.0)
        if stage.text_input.text():
            raise AcceptanceError("文字发送后 GUI 输入框未清空")
        state = self.wait_device_state(
            lambda current: search_value(current) == TEXT_PROBE,
            timeout=10.0,
            label=f"Settings 搜索框真实值为 {TEXT_PROBE!r}",
        )
        text_path, text_frame = self.save_device_screenshot(
            "gui_text_after",
            after_sequence=int(before_text["sequence"]),
        )
        text_change = _image_change(before_text_path, text_path)
        self.add_step(
            "gui_text_input",
            detail=(
                f"Qt 键盘输入 {TEXT_PROBE!r}，由“输入”按钮发送到 iPhone；"
                f"WDA 读回搜索框值 {search_value(state)!r}"
            ),
            gui_path=self.gui_screenshot("gui_text_after"),
            device_path=text_path,
            frame=text_frame,
            command=text_command,
            image_change=text_change,
        )

        self.click_widget(stage.delete_button, name="gui_delete", settle_ms=650)
        deleted_value = TEXT_PROBE[:-1]
        state = self.wait_device_state(
            lambda current: search_value(current) == deleted_value,
            timeout=10.0,
            label=f"删除后搜索框真实值为 {deleted_value!r}",
        )
        self.verify_last_step(
            True,
            success_detail=(
                f"WDA 读回搜索框值 {search_value(state)!r}，比输入值少 1 个字符"
            ),
            failure_detail="退格命令后搜索框内容没有减少",
        )

        self.click_widget(stage.enter_button, name="gui_return", settle_ms=900)
        state = self.wait_device_state(
            lambda current: not current.keyboard_present,
            timeout=10.0,
            label="回车后软键盘关闭",
        )
        self.verify_last_step(
            not state.keyboard_present,
            success_detail="WDA 确认回车后软键盘已关闭",
            failure_detail="回车命令后软键盘仍然显示",
        )

        self.click_widget(
            stage.home_button,
            name="gui_home_after_settings",
            settle_ms=1000,
        )
        try:
            state = self.wait_device_state(
                lambda current: current.active_bundle_id == "com.apple.springboard",
                timeout=5.0,
                label="Home 后离开 Settings",
                include_source=False,
            )
        except AcceptanceError:
            self.click_widget(
                stage.home_button,
                name="gui_home_after_settings_retry",
                settle_ms=1000,
            )
            state = self.wait_device_state(
                lambda current: current.active_bundle_id == "com.apple.springboard",
                timeout=10.0,
                label="第二次 Home 后离开 Settings",
                include_source=False,
            )
            self.verify_last_step(
                True,
                success_detail="第二次 Home 后 WDA 确认回到 SpringBoard",
                failure_detail="Home 仍未回到主屏幕",
            )
        else:
            self.verify_last_step(
                True,
                success_detail="WDA 确认活动 App 已回到 SpringBoard",
                failure_detail="Home 后仍停留在 Settings",
            )

        self.swipe_canvas(
            (650, 760),
            (100, 760),
            name="gui_swipe_left",
            settle_ms=800,
            min_image_change=2.0,
        )
        self.swipe_canvas(
            (100, 760),
            (650, 760),
            name="gui_swipe_right",
            settle_ms=800,
            min_image_change=2.0,
        )

        self.click_widget(stage.lock_button, name="gui_lock", settle_ms=1000)
        self.wait_device_state(
            lambda current: current.locked,
            timeout=12.0,
            label="锁屏后 WDA /wda/locked 为 true",
            include_source=False,
        )
        lock_frames: list[tuple[Path, float]] = []
        for index in range(3):
            locked_state = self.read_device_state(include_screenshot=True)
            if not locked_state.locked or locked_state.screenshot_png is None:
                raise AcceptanceError("锁屏状态或 WDA 截图缺失")
            path = self.output_dir / f"device_gui_lock_verified_{index + 1}.png"
            path.write_bytes(locked_state.screenshot_png)
            lock_frames.append((path, _mean_brightness(path)))
            QTest.qWait(250)
        max_lock_brightness = max(value for _, value in lock_frames)
        lock_evidence = lock_frames[0][0]
        self.steps[-1].device_screenshot = str(lock_evidence)
        self.verify_last_step(
            max_lock_brightness < 20.0,
            success_detail=(
                "WDA /wda/locked=true；连续 3 帧黑屏亮度 "
                f"{[round(value, 1) for _, value in lock_frames]}"
            ),
            failure_detail=(
                f"WDA 报告已锁定，但截图亮度 {max_lock_brightness:.1f} 不像熄屏"
            ),
        )

        self.click_widget(stage.wake_button, name="gui_wake", settle_ms=1200)
        state = self.wait_device_state(
            lambda current: not current.locked and current.home_screen_visible,
            timeout=12.0,
            label="唤醒后解除锁定并回到主屏幕",
        )
        wake_state = self.read_device_state(include_screenshot=True)
        if wake_state.screenshot_png is None:
            raise AcceptanceError("唤醒后 WDA 截图缺失")
        wake_path = self.output_dir / "device_gui_wake_verified.png"
        wake_path.write_bytes(wake_state.screenshot_png)
        wake_brightness = _mean_brightness(wake_path)
        self.steps[-1].device_screenshot = str(wake_path)
        self.verify_last_step(
            wake_brightness > 20.0,
            success_detail=(
                "WDA /wda/locked=false；主屏幕可见；截图亮度 "
                f"{wake_brightness:.1f}"
            ),
            failure_detail="唤醒后仍为黑屏",
        )

        self.click_widget(stage.home_button, name="gui_home_final", settle_ms=1000)
        state = self.wait_device_state(
            lambda current: current.active_bundle_id == "com.apple.springboard"
            and current.home_screen_visible,
            timeout=10.0,
            label="最终 Home 回到主屏幕",
        )
        self.verify_last_step(
            state.home_screen_visible,
            success_detail="WDA 最终确认主屏幕可见",
            failure_detail="最终状态不是主屏幕",
        )

        final_device = Path(self.steps[-1].device_screenshot or "")
        if final_device.exists():
            (self.output_dir / "device_final_home.png").write_bytes(final_device.read_bytes())
        self.gui_screenshot("final_home")

    def close(self) -> None:
        if self.window is not None:
            self.window.close()
            self.process(0.3)
        if self.context is not None:
            self.context.close()
            self.process(0.2)

    def write_report(self, *, success: bool, error: str | None = None) -> Path:
        started_at = datetime.fromtimestamp(
            time.time() - (time.monotonic() - self.started)
        ).astimezone().isoformat(timespec="seconds")
        report = {
            "success": success,
            "error": error,
            "started_at": started_at,
            "duration_seconds": round(time.monotonic() - self.started, 2),
            "expected_identity": {
                "udid": EXPECTED_UDID,
                "product_type": EXPECTED_PRODUCT_TYPE,
                "ios_version": EXPECTED_IOS_VERSION,
                "build_version": EXPECTED_BUILD_VERSION,
            },
            "actual_identity": self.identity,
            "slot_no": self.slot_no,
            "steps": [asdict(step) for step in self.steps],
            "command_events": self.command_events,
            "scope": "current USB-connected iPhone 8 only; no Wi-Fi or multi-device claim",
        }
        path = self.output_dir / "acceptance.json"
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def run(self) -> int:
        success = False
        error: str | None = None
        try:
            print("IC20_PHASE checking_identity", flush=True)
            self.verify_identity()
            print("IC20_PHASE opening_ui", flush=True)
            self.start_ui()
            print("IC20_PHASE waiting_ready", flush=True)
            self.wait_ready()
            print("IC20_PHASE interactions", flush=True)
            self.run_interactions()
            success = True
        except Exception as exc:
            error = f"{exc.__class__.__name__}: {exc}"
            self.steps.append(StepResult(name="failure", success=False, detail=error))
            (self.output_dir / "traceback.txt").write_text(
                traceback.format_exc(), encoding="utf-8"
            )
        finally:
            try:
                self.close()
            except Exception as close_error:
                if error is None:
                    error = f"关闭失败: {close_error}"
                    success = False
        report_path = self.write_report(success=success, error=error)
        print(json.dumps({"success": success, "error": error, "report": str(report_path)}, ensure_ascii=False))
        return 0 if success else 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="iPhone Control Center 20 真机 GUI 验收")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=PROJECT_ROOT / "work" / f"live_acceptance_{_timestamp()}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    return LiveAcceptance(args.output_dir).run()


if __name__ == "__main__":
    raise SystemExit(main())
