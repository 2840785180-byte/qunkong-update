[CmdletBinding()]
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$PytestArguments
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$PortablePython = Join-Path $ProjectRoot "runtime\python.exe"
$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
$Python = if (Test-Path -LiteralPath $PortablePython) { $PortablePython } else { $VenvPython }

if (-not (Test-Path -LiteralPath $Python)) {
    throw "No project runtime was found. Restore the runtime folder or run README.md setup."
}

$env:PYTHONPATH = Join-Path $ProjectRoot "src"
$env:QT_QPA_PLATFORM = "offscreen"
Push-Location $ProjectRoot
try {
    & $Python -m pytest @PytestArguments
    exit $LASTEXITCODE
}
finally {
    Pop-Location
}
