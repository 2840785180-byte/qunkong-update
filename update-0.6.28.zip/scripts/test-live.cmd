@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0test-live.ps1" -OpenReport %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo Live acceptance finished successfully.
) else (
    echo Live acceptance failed with exit code %EXIT_CODE%.
)
pause
exit /b %EXIT_CODE%
