from __future__ import annotations

import hashlib
import http.client
import json
import posixpath
import re
import shlex
import time
from pathlib import Path
from typing import Any, Iterable, Sequence

from iphone_control_center.services.ios_mcp_control import (
    McpHttpClient,
    McpProtocolError,
)


FILES_BUNDLE_ID = "com.apple.DocumentsApp"
FILE_PROVIDER_GROUP_ID = "group.com.apple.FileProvider.LocalStorage"
FILE_PROVIDER_STORAGE_NAME = "File Provider Storage"
PROFILE_FILES_FOLDER = "IC20资料"
BUSINESS_FILES_FOLDER = "IC20认证"

PERMISSION_MARKERS = (
    "允许", "Allow", "仅在使用 App 时允许", "Allow While Using App",
    "允许访问所有照片", "Allow Access to All Photos",
)
CONSENT_MARKERS = (
    "同意并继续", "Agree and continue", "Accept and continue", "我知道了", "Got it",
)
RATE_LIMIT_MARKERS = (
    "访问太频繁", "操作太频繁", "尝试次数过多", "请稍后再试",
    "too many attempts", "too many requests", "try again later", "rate limit",
)
SECURITY_MARKERS = (
    "安全验证", "验证你是真人", "拖动滑块", "完成安全验证",
    "captcha", "verify you are human",
)
LOGIN_REQUIRED_MARKERS = (
    "登录 TikTok", "Log in to TikTok", "登录或注册", "Log in or sign up",
)
BACK_MARKERS = ("返回", "Back")
CANCEL_MARKERS = ("取消", "Cancel")
DONE_MARKERS = ("完成", "Done")
PROFILE_TAB_MARKERS = ("个人主页", "主页", "我", "Profile", "Me")
EDIT_PROFILE_MARKERS = (
    "编辑资料", "编辑个人资料", "编辑主页", "Edit profile", "Edit Profile",
)
SAVE_MARKERS = (
    "保存", "保存更改", "完成", "Save", "Save changes", "Done",
)
CHANGE_PHOTO_MARKERS = (
    "更换照片", "更换头像", "修改照片", "Change photo",
    "Change profile photo", "Edit photo",
)
CHOOSE_LIBRARY_MARKERS = (
    "从相册选择", "从照片选择", "选择照片", "Choose from library",
    "Choose from Library", "Photo library", "Photo Library",
)
CHOOSE_FILE_MARKERS = (
    "从文件选择", "选择文件", "浏览文件", "Choose file", "Choose File", "Browse",
)
BROWSE_MARKERS = ("浏览", "Browse")
ON_MY_IPHONE_MARKERS = ("我的 iPhone", "我的iPhone", "On My iPhone")
SAVE_IMAGE_MARKERS = (
    "存储图像", "保存图像", "存储照片", "保存照片", "Save Image", "Save Photo",
)
SHARE_MARKERS = ("共享", "Share")
CLEAR_MARKERS = ("清除文本", "Clear text", "清除", "Clear")
SELECT_ALL_MARKERS = ("全选", "Select All")
PASTE_MARKERS = ("粘贴", "Paste")
BUSINESS_MARKERS = (
    "Business registration", "Business verification", "Company certification",
    "企业认证", "企业注册", "商业认证",
)
MORE_MARKERS = ("更多", "More", "菜单", "Menu", "More options")
SETTINGS_MARKERS = (
    "设置与隐私", "设置和隐私", "Settings and privacy", "Settings & privacy",
)
ACCOUNT_MARKERS = ("账号", "Account")
BUSINESS_ACCOUNT_MARKERS = (
    "商业账号", "企业账号", "Business account", "Business Account",
)
BUSINESS_REGISTRATION_MARKERS = (
    "商业注册", "企业注册", "企业认证", "商业认证",
    "Business registration", "Business verification", "Verify business",
)
NEXT_MARKERS = ("下一步", "继续", "Next", "Continue")
SUBMIT_MARKERS = ("提交", "Submit")
UPLOAD_MARKERS = ("上传", "添加", "Upload", "Add", "＋", "+")


class AutomationError(RuntimeError):
    def __init__(self, stage: str, detail: str) -> None:
        super().__init__(detail)
        self.stage = stage
        self.detail = detail


def clean(value: Any, limit: int = 1200) -> str:
    return " ".join(str(value or "").split())[:limit]


def emit_progress(stage: str, message: str) -> None:
    print(f"TIKTOK_ACTION_PROGRESS|{stage}|{clean(message, 500)}", flush=True)


def emit_result(value: dict[str, Any]) -> None:
    print(
        "TIKTOK_ACTION_RESULT|"
        + json.dumps(value, ensure_ascii=False, separators=(",", ":")),
        flush=True,
    )


def normalize(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or "")).casefold()


def node_text(node: dict[str, Any]) -> str:
    for key in ("text", "label", "value", "name", "title", "placeholder"):
        value = node.get(key)
        if value is not None and str(value).strip():
            return clean(value, 2000)
    return ""


def node_point(node: dict[str, Any]) -> tuple[float, float] | None:
    tap = node.get("tap")
    if isinstance(tap, dict):
        try:
            return float(tap["x"]), float(tap["y"])
        except (KeyError, TypeError, ValueError):
            pass
    rect = node.get("rect") or node.get("visible_rect")
    if isinstance(rect, dict):
        try:
            return (
                float(rect["x"]) + float(rect.get("width") or 0) / 2,
                float(rect["y"]) + float(rect.get("height") or 0) / 2,
            )
        except (KeyError, TypeError, ValueError):
            pass
    return None


def node_rect(node: dict[str, Any]) -> tuple[float, float, float, float] | None:
    rect = node.get("rect") or node.get("visible_rect")
    if not isinstance(rect, dict):
        return None
    try:
        return (
            float(rect["x"]),
            float(rect["y"]),
            float(rect.get("width") or 0),
            float(rect.get("height") or 0),
        )
    except (KeyError, TypeError, ValueError):
        return None


def ui_nodes(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, dict):
        return []
    nodes: list[dict[str, Any]] = []
    for key in ("elements", "ui_elements", "items", "texts"):
        raw = value.get(key)
        if isinstance(raw, list):
            nodes.extend(item for item in raw if isinstance(item, dict))
    return nodes


def text_matches(text: str, marker: str, *, exact: bool = False) -> bool:
    left = normalize(text)
    right = normalize(marker)
    if not left or not right:
        return False
    return left == right if exact else right in left


def find_text_node(
    nodes: Iterable[dict[str, Any]],
    markers: Sequence[str],
    *,
    exact: bool = False,
    min_x: float | None = None,
    max_x: float | None = None,
    min_y: float | None = None,
    max_y: float | None = None,
) -> dict[str, Any] | None:
    for node in nodes:
        text = node_text(node)
        if not text or not any(
            text_matches(text, marker, exact=exact) for marker in markers
        ):
            continue
        point = node_point(node)
        if point is None:
            continue
        x, y = point
        if min_x is not None and x < min_x:
            continue
        if max_x is not None and x > max_x:
            continue
        if min_y is not None and y < min_y:
            continue
        if max_y is not None and y > max_y:
            continue
        return node
    return None


class UiAutomation:
    def __init__(
        self,
        port: int,
        bundle_id: str,
        *,
        timeout: float = 60.0,
    ) -> None:
        self.client = McpHttpClient(
            f"http://127.0.0.1:{port}",
            timeout=timeout,
        )
        self.bundle_id = bundle_id
        self._screen_width = 375.0
        self._screen_height = 667.0

    def connect(self) -> None:
        self.client.connect()
        emit_progress("connect", "已连接手机控制服务")

    def close(self) -> None:
        self.client.close()

    def tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        return self.client.tool_value(name, arguments or {})

    def nodes(self, *, include_ocr: bool = False) -> list[dict[str, Any]]:
        try:
            nodes = ui_nodes(
                self.tool(
                    "get_ui_elements",
                    {"visible_only": True, "clickable_only": False},
                )
            )
        except McpProtocolError:
            nodes = []
        if include_ocr and not nodes:
            nodes.extend(self.ocr_nodes())
        return nodes

    def ocr_nodes(self) -> list[dict[str, Any]]:
        try:
            value = self.tool(
                "ocr_screen",
                {"engine": "paddleocr", "min_confidence": 0.35},
            )
        except McpProtocolError:
            return []
        roots: list[Any] = []
        if isinstance(value, list):
            roots = value
        elif isinstance(value, dict):
            for key in ("results", "items", "texts", "elements", "lines"):
                raw = value.get(key)
                if isinstance(raw, list):
                    roots.extend(raw)
        nodes: list[dict[str, Any]] = []
        for node in roots:
            if isinstance(node, str) and node.strip():
                nodes.append({"text": node.strip()})
            elif isinstance(node, dict):
                for key in ("text", "label", "value", "content"):
                    value = node.get(key)
                    if value is not None and str(value).strip():
                        nodes.append({**node, "text": str(value).strip()})
                        break
        return nodes

    def texts(self, *, include_ocr: bool = True) -> list[str]:
        nodes = self.nodes()
        if include_ocr:
            nodes.extend(self.ocr_nodes())
        return [node_text(node) for node in nodes if node_text(node)]

    def assert_healthy(self) -> None:
        texts = self.texts(include_ocr=True)
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in RATE_LIMIT_MARKERS
        ):
            raise AutomationError(
                "rate_limit",
                "TikTok 提示操作太频繁，已停止本机任务，避免账号风险。",
            )
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in SECURITY_MARKERS
        ):
            raise AutomationError(
                "security",
                "检测到 TikTok 安全验证，请在手机上手动完成后重新执行。",
            )
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in LOGIN_REQUIRED_MARKERS
        ):
            raise AutomationError(
                "login_required",
                "TikTok 还没有登录，请先完成账号登录。",
            )

    def screen_size(self) -> tuple[float, float]:
        try:
            value = self.tool("get_screen_info", {})
        except McpProtocolError:
            return self._screen_width, self._screen_height
        if isinstance(value, dict):
            try:
                self._screen_width = float(
                    value.get("width") or self._screen_width
                )
                self._screen_height = float(
                    value.get("height") or self._screen_height
                )
            except (TypeError, ValueError):
                pass
        return self._screen_width, self._screen_height

    def tap_xy(self, x: float, y: float) -> None:
        width, height = self.screen_size()
        self.tool(
            "tap_screen",
            {
                "x": min(max(round(x), 0), int(width) - 1),
                "y": min(max(round(y), 0), int(height) - 1),
            },
        )
        time.sleep(0.42)

    def tap_normalized(self, x_ratio: float, y_ratio: float) -> None:
        width, height = self.screen_size()
        self.tap_xy(width * x_ratio, height * y_ratio)

    def tap_node(self, node: dict[str, Any]) -> bool:
        point = node_point(node)
        if point is None:
            return False
        self.tap_xy(*point)
        return True

    def find_node(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        include_ocr: bool = False,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> dict[str, Any] | None:
        return find_text_node(
            self.nodes(include_ocr=include_ocr),
            markers,
            exact=exact,
            min_x=min_x,
            max_x=max_x,
            min_y=min_y,
            max_y=max_y,
        )

    def tap_marker(
        self,
        markers: Sequence[str],
        *,
        exact: bool = False,
        include_ocr: bool = True,
        min_x: float | None = None,
        max_x: float | None = None,
        min_y: float | None = None,
        max_y: float | None = None,
    ) -> bool:
        node = self.find_node(
            markers,
            exact=exact,
            include_ocr=include_ocr,
            min_x=min_x,
            max_x=max_x,
            min_y=min_y,
            max_y=max_y,
        )
        if node is None:
            return False
        return self.tap_node(node)

    def wait_for(
        self,
        markers: Sequence[str],
        *,
        timeout: float = 12.0,
        exact: bool = False,
        stage: str = "wait",
        detail: str = "",
    ) -> list[str]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            texts = self.texts(include_ocr=True)
            if any(
                text_matches(text, marker, exact=exact)
                for text in texts
                for marker in markers
            ):
                return texts
            time.sleep(0.35)
        raise AutomationError(
            stage,
            detail or f"等待界面元素超时：{' / '.join(markers)}",
        )

    def wait_until_gone(
        self,
        markers: Sequence[str],
        *,
        timeout: float = 12.0,
        stage: str = "wait",
        detail: str = "",
    ) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            texts = self.texts(include_ocr=True)
            if not any(
                text_matches(text, marker)
                for text in texts
                for marker in markers
            ):
                return
            time.sleep(0.35)
        raise AutomationError(stage, detail or "界面没有按预期切换。")

    def launch_app(self, bundle_id: str | None = None) -> None:
        self.tool("launch_app", {"bundle_id": bundle_id or self.bundle_id})
        time.sleep(1.0)

    def open_url(self, url: str) -> None:
        if not url:
            return
        self.tool("open_url", {"url": url})
        time.sleep(1.4)

    def frontmost_bundle(self) -> str:
        try:
            value = self.tool("get_frontmost_app", {})
        except McpProtocolError:
            return ""
        if isinstance(value, str):
            return value.strip()
        if isinstance(value, dict):
            for key in ("bundleId", "bundle_id", "frontmostBundleId"):
                if value.get(key):
                    return str(value[key]).strip()
            app = value.get("app")
            if isinstance(app, dict):
                return str(app.get("bundleId") or app.get("bundle_id") or "")
        return ""

    def dismiss_overlays(self) -> None:
        for _attempt in range(3):
            tapped = False
            for markers in (PERMISSION_MARKERS, CONSENT_MARKERS):
                node = self.find_node(markers, exact=True)
                if node is not None:
                    self.tap_node(node)
                    tapped = True
                    time.sleep(0.45)
                    break
            if not tapped:
                return

    def swipe_up(self) -> None:
        width, height = self.screen_size()
        self.tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.78),
                "toX": round(width * 0.5),
                "toY": round(height * 0.25),
                "duration": 480,
                "steps": 20,
            },
        )
        time.sleep(0.7)

    def swipe_down(self) -> None:
        width, height = self.screen_size()
        self.tool(
            "swipe_screen",
            {
                "fromX": round(width * 0.5),
                "fromY": round(height * 0.25),
                "toX": round(width * 0.5),
                "toY": round(height * 0.78),
                "duration": 480,
                "steps": 20,
            },
        )
        time.sleep(0.7)

    def press_key(self, key: str) -> None:
        for tool_name in ("press_key", "key_press"):
            try:
                self.tool(tool_name, {"key": key})
                return
            except Exception:
                continue

    def input_text(self, value: str) -> None:
        try:
            self.tool("input_text", {"text": value})
        except Exception:
            self.tool("type_text", {"text": value, "delay_ms": 35})
        time.sleep(0.6)

    def clear_focused_field(self) -> None:
        if self.tap_marker(CLEAR_MARKERS, exact=True):
            time.sleep(0.25)
            return
        width, height = self.screen_size()
        for _attempt in range(2):
            try:
                self.tool(
                    "long_press",
                    {
                        "x": round(width * 0.45),
                        "y": round(height * 0.5),
                        "duration": 850,
                    },
                )
                time.sleep(0.35)
            except Exception:
                pass
            if self.tap_marker(SELECT_ALL_MARKERS, exact=True):
                self.press_key("backspace")
                time.sleep(0.2)
                return
        for _index in range(140):
            self.press_key("backspace")
            time.sleep(0.012)
        time.sleep(0.25)

    def replace_field(self, node: dict[str, Any], value: str) -> None:
        if not self.tap_node(node):
            raise AutomationError("field", "输入框没有可点击坐标。")
        time.sleep(0.35)
        self.clear_focused_field()
        self.input_text(value)
        time.sleep(0.55)

    def field_near_label(
        self,
        label_node: dict[str, Any],
        *,
        y_offset: float = 34.0,
    ) -> tuple[float, float] | None:
        label_point = node_point(label_node)
        if label_point is None:
            return None
        _label_x, label_y = label_point
        width, height = self.screen_size()
        wanted_y = min(max(label_y + y_offset, 0), height - 1)
        candidates: list[tuple[float, dict[str, Any]]] = []
        for node in self.nodes():
            rect = node_rect(node)
            if rect is None:
                continue
            x, y, node_width, node_height = rect
            if node_width < width * 0.55 or node_height < 18:
                continue
            if not (label_y - 15 <= y <= label_y + 100):
                continue
            distance = abs((y + node_height / 2) - wanted_y)
            candidates.append((distance, node))
        if candidates:
            candidates.sort(key=lambda item: item[0])
            return node_point(candidates[0][1])
        return width * 0.5, wanted_y

    def tap_label_field(
        self,
        markers: Sequence[str],
        *,
        y_offset: float = 34.0,
    ) -> dict[str, Any]:
        node = self.find_node(markers, exact=False)
        if node is None:
            raise AutomationError(
                "field",
                f"没有找到输入项：{' / '.join(markers)}",
            )
        point = self.field_near_label(node, y_offset=y_offset)
        if point is None:
            raise AutomationError(
                "field",
                f"输入项没有可点击位置：{' / '.join(markers)}",
            )
        self.tap_xy(*point)
        return node

    def open_profile(self) -> None:
        self.launch_app()
        self.dismiss_overlays()
        self.assert_healthy()
        _width, height = self.screen_size()
        tapped = self.tap_marker(
            PROFILE_TAB_MARKERS,
            exact=True,
            min_y=height * 0.76,
        )
        if not tapped:
            tapped = self.tap_marker(
                PROFILE_TAB_MARKERS,
                exact=False,
                min_y=height * 0.76,
            )
        if not tapped:
            self.tap_normalized(0.86, 0.94)
        self.wait_for(
            EDIT_PROFILE_MARKERS
            + ("粉丝", "关注", "Following", "Followers"),
            timeout=14.0,
            stage="profile",
            detail="没有打开 TikTok 个人主页，请确认主 App 已登录。",
        )

    def open_edit_profile(self) -> None:
        if not self.tap_marker(EDIT_PROFILE_MARKERS, exact=False):
            for y_ratio in (0.18, 0.24, 0.30):
                self.tap_normalized(0.5, y_ratio)
                if self.find_node(EDIT_PROFILE_MARKERS, exact=False):
                    break
        self.wait_for(
            ("昵称", "简介", "Name", "Nickname", "Bio", "Website"),
            timeout=12.0,
            stage="edit_profile",
            detail="没有打开“编辑资料”页面。",
        )


def run_shell(
    client: McpHttpClient,
    command: str,
    *,
    timeout: int = 30,
) -> dict[str, Any]:
    value = client.tool_value(
        "run_command",
        {"command": command, "timeout": timeout},
    )
    return value if isinstance(value, dict) else {"output": str(value), "exitCode": 0}


def ensure_files_folder(client: McpHttpClient, folder_name: str) -> str:
    info = client.tool_value("get_app_info", {"bundle_id": FILES_BUNDLE_ID})
    if not isinstance(info, dict) or not info:
        raise AutomationError("files", "无法读取“文件”App 的信息。")
    groups = info.get("group_containers")
    group_root = (
        str(groups.get(FILE_PROVIDER_GROUP_ID) or "").strip()
        if isinstance(groups, dict)
        else ""
    )
    if not group_root.startswith("/"):
        raise AutomationError("files", "没有读取到“我的 iPhone”共享目录。")
    target = posixpath.join(
        posixpath.normpath(group_root),
        FILE_PROVIDER_STORAGE_NAME,
        folder_name,
    )
    result = run_shell(client, f"mkdir -p -- {shlex.quote(target)}", timeout=10)
    if int(result.get("exitCode") or 0) != 0:
        raise AutomationError(
            "files",
            f"无法创建手机文件夹：{clean(result.get('output'))}",
        )
    return target


def upload_file_to_phone(
    port: int,
    client: McpHttpClient,
    local_path: Path,
    folder_name: str,
) -> str:
    local = Path(local_path).expanduser().resolve(strict=True)
    size = local.stat().st_size
    if size <= 0:
        raise AutomationError("upload", f"文件是空的：{local.name}")
    remote_dir = ensure_files_folder(client, folder_name)
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=600)
    digest = hashlib.sha256()
    sent = 0
    try:
        connection.putrequest("POST", "/upload_file")
        connection.putheader("Content-Type", "application/octet-stream")
        connection.putheader("Content-Length", str(size))
        connection.endheaders()
        with local.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                connection.send(chunk)
                digest.update(chunk)
                sent += len(chunk)
        response = connection.getresponse()
        body = response.read().decode("utf-8", "replace")
        if not 200 <= response.status < 300:
            raise AutomationError(
                "upload",
                f"上传文件失败 HTTP {response.status}: {clean(body)}",
            )
        try:
            value = json.loads(body)
        except json.JSONDecodeError as error:
            raise AutomationError("upload", "手机上传接口返回了无效数据。") from error
        temporary = str(value.get("path") or "") if isinstance(value, dict) else ""
        remote_size = int(value.get("size") or -1) if isinstance(value, dict) else -1
        if not temporary.startswith("/") or remote_size != size or sent != size:
            raise AutomationError("upload", "电脑与手机的文件大小不一致。")
        destination = posixpath.join(remote_dir, local.name)
        result = run_shell(
            client,
            f"if mv -f -- {shlex.quote(temporary)} {shlex.quote(destination)}; "
            f"then chown mobile:mobile {shlex.quote(destination)} 2>/dev/null || true; "
            f"chmod 0644 {shlex.quote(destination)} 2>/dev/null || true; "
            "echo IC20_MOVE_OK; else echo IC20_MOVE_FAILED; exit 9; fi",
            timeout=30,
        )
        if (
            int(result.get("exitCode") or 0) != 0
            or "IC20_MOVE_OK" not in str(result.get("output") or "")
        ):
            raise AutomationError("upload", "文件上传后无法移动到目标文件夹。")
    finally:
        connection.close()
    emit_progress("upload", f"已上传到手机：{local.name}")
    return destination


def find_file_node(
    nodes: Iterable[dict[str, Any]],
    filename: str,
) -> dict[str, Any] | None:
    wanted_name = normalize(filename)
    wanted_stem = normalize(Path(filename).stem)
    for node in nodes:
        text = normalize(node_text(node))
        if not text:
            continue
        if (
            text == wanted_name
            or text.startswith(wanted_name + ",")
            or wanted_name in text
            or (
                wanted_stem
                and (text == wanted_stem or text.startswith(wanted_stem + ","))
            )
        ):
            return node
    return None


def tap_file_cell(automation: UiAutomation, node: dict[str, Any]) -> None:
    rect = node_rect(node)
    if rect is None:
        automation.tap_node(node)
        return
    x, y, width, height = rect
    automation.tap_xy(
        x + width / 2,
        y + min(64.0, max(28.0, height * 0.24)),
    )


def navigate_files_to_folder(
    automation: UiAutomation,
    folder_name: str,
    filename: str,
    *,
    timeout: float = 20.0,
) -> dict[str, Any]:
    automation.launch_app(FILES_BUNDLE_ID)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        nodes = automation.nodes(include_ocr=True)
        file_node = find_file_node(nodes, filename)
        if file_node is not None:
            return file_node
        if automation.tap_marker(BROWSE_MARKERS, exact=True, include_ocr=False):
            time.sleep(0.5)
            continue
        if automation.tap_marker(
            ON_MY_IPHONE_MARKERS,
            exact=True,
            include_ocr=False,
        ):
            time.sleep(0.5)
            continue
        if automation.tap_marker(
            (folder_name,),
            exact=False,
            include_ocr=False,
        ):
            time.sleep(0.5)
            continue
        time.sleep(0.35)
    raise AutomationError(
        "files",
        f"没有在“文件 App / {folder_name}”中找到 {filename}。",
    )


def save_open_file_to_photos(
    automation: UiAutomation,
    filename: str,
) -> None:
    try:
        automation.wait_for(DONE_MARKERS, timeout=7.0, exact=True)
    except AutomationError:
        node = find_file_node(automation.nodes(), filename)
        if node is not None:
            point = node_point(node)
            if point is not None:
                automation.tool(
                    "double_tap",
                    {"x": round(point[0]), "y": round(point[1])},
                )
        automation.wait_for(DONE_MARKERS, timeout=7.0, exact=True)
    width, height = automation.screen_size()
    if not automation.tap_marker(SHARE_MARKERS, exact=True):
        automation.tap_xy(width * 0.064, height - 26)
    try:
        automation.wait_for(SAVE_IMAGE_MARKERS, timeout=6.0)
    except AutomationError:
        automation.tap_xy(width * 0.064, height - 26)
        automation.wait_for(SAVE_IMAGE_MARKERS, timeout=6.0)
    if not automation.tap_marker(SAVE_IMAGE_MARKERS, exact=False):
        raise AutomationError("photos", "没有找到“存储图像”按钮。")
    time.sleep(0.7)
    for _attempt in range(2):
        node = automation.find_node(PERMISSION_MARKERS, exact=True)
        if node is None:
            break
        automation.tap_node(node)
        time.sleep(0.45)
    automation.wait_until_gone(
        SAVE_IMAGE_MARKERS,
        timeout=15.0,
        stage="photos",
        detail="照片没有保存到相册。",
    )
    time.sleep(0.5)
    if not automation.tap_marker(DONE_MARKERS, exact=True):
        automation.tap_xy(width * 0.91, 42)
    time.sleep(0.45)


def import_image_to_photos(
    automation: UiAutomation,
    port: int,
    local_path: Path,
) -> str:
    destination = upload_file_to_phone(
        port,
        automation.client,
        local_path,
        PROFILE_FILES_FOLDER,
    )
    filename = Path(local_path).name
    node = navigate_files_to_folder(
        automation,
        PROFILE_FILES_FOLDER,
        filename,
    )
    tap_file_cell(automation, node)
    save_open_file_to_photos(automation, filename)
    emit_progress("photos", f"头像已存入相册：{filename}")
    return destination


def choose_picker_file(
    automation: UiAutomation,
    folder_name: str,
    filename: str,
) -> None:
    deadline = time.monotonic() + 18.0
    while time.monotonic() < deadline:
        nodes = automation.nodes(include_ocr=True)
        file_node = find_file_node(nodes, filename)
        if file_node is not None:
            automation.tap_node(file_node)
            time.sleep(0.8)
            return
        if automation.tap_marker(BROWSE_MARKERS, exact=True, include_ocr=False):
            time.sleep(0.5)
            continue
        if automation.tap_marker(
            ON_MY_IPHONE_MARKERS,
            exact=True,
            include_ocr=False,
        ):
            time.sleep(0.5)
            continue
        if automation.tap_marker(
            (folder_name,),
            exact=False,
            include_ocr=False,
        ):
            time.sleep(0.5)
            continue
        time.sleep(0.35)
    raise AutomationError(
        "file_picker",
        f"文件选择器里没有找到 {filename}。",
    )


def wait_for_business_form(
    automation: UiAutomation,
    *,
    timeout: float = 18.0,
) -> list[str]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        texts = automation.texts(include_ocr=True)
        if any(
            text_matches(text, marker)
            for text in texts
            for marker in BUSINESS_MARKERS
        ):
            return texts
        time.sleep(0.4)
    raise AutomationError(
        "business_entry",
        "没有找到 TikTok 企业认证页面。请先确认该账号可申请企业认证；"
        "如 TikTok 改版，可在“认证入口链接”中填写手机可打开的页面地址。",
    )


def open_business_form(automation: UiAutomation, entry_url: str) -> None:
    texts = automation.texts(include_ocr=True)
    if any(
        text_matches(text, marker)
        for text in texts
        for marker in BUSINESS_MARKERS
    ):
        return
    if entry_url:
        automation.open_url(entry_url)
        wait_for_business_form(automation)
        return
    automation.launch_app()
    automation.dismiss_overlays()
    automation.open_profile()
    if not automation.tap_marker(MORE_MARKERS, exact=False):
        width, height = automation.screen_size()
        automation.tap_xy(width * 0.92, height * 0.08)
    automation.wait_for(
        SETTINGS_MARKERS + BUSINESS_REGISTRATION_MARKERS,
        timeout=10.0,
        stage="business_entry",
        detail="TikTok 菜单里没有出现设置或企业认证入口。",
    )
    automation.tap_marker(SETTINGS_MARKERS, exact=False, include_ocr=True)
    time.sleep(0.7)
    automation.tap_marker(ACCOUNT_MARKERS, exact=False, include_ocr=True)
    time.sleep(0.6)
    automation.tap_marker(BUSINESS_ACCOUNT_MARKERS, exact=False, include_ocr=True)
    time.sleep(0.7)
    automation.tap_marker(
        BUSINESS_REGISTRATION_MARKERS,
        exact=False,
        include_ocr=True,
    )
    wait_for_business_form(automation)
