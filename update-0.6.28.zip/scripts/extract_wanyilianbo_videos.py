from __future__ import annotations

import argparse
import base64
import concurrent.futures
import hashlib
import json
import logging
import os
import posixpath
import re
import shlex
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


MCP_PROTOCOL_VERSION = "2025-03-26"
DEFAULT_APP_NAME = "万能联播"
VIDEO_EXTENSIONS = {
    ".3gp", ".avi", ".flv", ".m2ts", ".m4v", ".mkv", ".mov", ".mp4",
    ".mpeg", ".mpg", ".mts", ".ts", ".webm", ".wmv",
}
THUMBNAIL_MARKERS = ("thumb", "thumbnail", "poster", "cover", "preview")
DELETE_LABELS = ("删除", "移除", "delete", "trash")
CONFIRM_LABELS = ("确认删除", "删除", "确定", "delete")


class ExtractionError(RuntimeError):
    pass


class McpProtocolError(ExtractionError):
    pass


def now_text() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def clean(value: Any, limit: int = 800) -> str:
    return " ".join(str(value or "").split())[:limit]


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if result == result else None


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as handle:
        handle.write(json_bytes(value))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


class McpClient:
    """Small MCP Streamable HTTP client for the jailbreak iOS MCP service."""

    def __init__(self, base_url: str, *, timeout: float = 45.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session_id: str | None = None
        self.server_version = ""
        self._request_id = 0

    def connect(self) -> dict[str, Any]:
        health = self._get_json("/health")
        if str(health.get("status") or "").lower() != "ok":
            raise McpProtocolError("手机端口健康检查未通过")
        if str(health.get("server") or "") != "ios-mcp":
            raise McpProtocolError("该端口不是 iOS MCP 服务")
        self.server_version = str(health.get("version") or "")
        initialized = self._rpc(
            "initialize",
            {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {
                    "name": "WanNengLianBo Video Extractor",
                    "version": "1.0.0",
                },
            },
        )
        if not self.session_id:
            raise McpProtocolError("iOS MCP 没有返回 Mcp-Session-Id")
        self._post(
            {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}},
            notification=True,
        )
        return initialized

    def tool_value(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        result = self._rpc("tools/call", {"name": name, "arguments": arguments or {}})
        if result.get("isError") is True:
            raise McpProtocolError(_tool_text(result) or f"工具 {name} 执行失败")
        structured = result.get("structuredContent")
        if isinstance(structured, dict):
            return structured
        text = _tool_text(result)
        if not text:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text

    def screenshot_jpeg(self) -> bytes:
        result = self._rpc("tools/call", {"name": "screenshot", "arguments": {"debug": False}})
        if result.get("isError") is True:
            raise McpProtocolError(_tool_text(result) or "手机截图失败")
        content = result.get("content")
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict) and item.get("type") == "image":
                    try:
                        data = base64.b64decode(str(item.get("data") or ""), validate=False)
                    except ValueError as error:
                        raise McpProtocolError("截图 Base64 数据无效") from error
                    if data:
                        return data
        raise McpProtocolError("iOS MCP 没有返回截图")

    def download_file(
        self,
        remote_path: str,
        temporary_path: Path,
        *,
        expected_size: int = 0,
    ) -> dict[str, Any]:
        query = urllib.parse.urlencode({"path": remote_path})
        request = urllib.request.Request(
            f"{self.base_url}/download_file?{query}",
            headers={"Accept": "application/octet-stream"},
            method="GET",
        )
        temporary_path.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        written = 0
        content_length = 0
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                content_length = to_int(response.headers.get("Content-Length"))
                if expected_size > 0 and content_length > 0 and content_length != expected_size:
                    raise ExtractionError(
                        f"下载响应大小不一致：预期 {expected_size}，响应 {content_length}"
                    )
                with temporary_path.open("wb") as handle:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        handle.write(chunk)
                        digest.update(chunk)
                        written += len(chunk)
                    handle.flush()
                    os.fsync(handle.fileno())
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", "replace")
            raise McpProtocolError(
                f"下载失败 HTTP {error.code}: {clean(detail) or error.reason}"
            ) from error
        except (OSError, urllib.error.URLError) as error:
            raise McpProtocolError(f"下载失败：{clean(error)}") from error
        except Exception:
            temporary_path.unlink(missing_ok=True)
            raise

        if written <= 0:
            temporary_path.unlink(missing_ok=True)
            raise ExtractionError("下载得到空文件")
        if expected_size > 0 and written != expected_size:
            temporary_path.unlink(missing_ok=True)
            raise ExtractionError(f"下载大小校验失败：预期 {expected_size}，实际 {written}")
        with temporary_path.open("rb") as handle:
            head = handle.read(256)
        if head.lstrip().lower().startswith((b"<html", b"<!doctype", b"{\"error")):
            temporary_path.unlink(missing_ok=True)
            raise ExtractionError("下载内容像网页或错误信息，不是视频")
        return {"size": written, "sha256": digest.hexdigest(), "content_length": content_length}

    def close(self) -> None:
        self.session_id = None

    def _get_json(self, path: str) -> dict[str, Any]:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            headers={"Accept": "application/json"},
            method="GET",
        )
        try:
            with urllib.request.urlopen(request, timeout=5.0) as response:
                body = response.read().decode("utf-8", "replace")
        except (OSError, urllib.error.URLError) as error:
            raise McpProtocolError(f"无法连接 iOS MCP：{clean(error)}") from error
        try:
            data = json.loads(body)
        except json.JSONDecodeError as error:
            raise McpProtocolError("健康检查返回了无效 JSON") from error
        if not isinstance(data, dict):
            raise McpProtocolError("健康检查返回格式异常")
        return data

    def _rpc(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        self._request_id += 1
        response = self._post(
            {
                "jsonrpc": "2.0",
                "id": self._request_id,
                "method": method,
                "params": params,
            }
        )
        if response is None:
            raise McpProtocolError(f"iOS MCP 没有响应 {method}")
        error = response.get("error")
        if isinstance(error, dict):
            raise McpProtocolError(str(error.get("message") or error.get("code") or method))
        result = response.get("result")
        if not isinstance(result, dict):
            raise McpProtocolError(f"iOS MCP {method} 返回格式异常")
        return result

    def _post(
        self,
        payload: dict[str, Any],
        *,
        notification: bool = False,
    ) -> dict[str, Any] | None:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
            headers["MCP-Protocol-Version"] = MCP_PROTOCOL_VERSION
        request = urllib.request.Request(
            f"{self.base_url}/mcp",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                session_id = response.headers.get("Mcp-Session-Id")
                if session_id:
                    self.session_id = session_id
                if notification or response.status == 202:
                    response.read()
                    return None
                content_type = response.headers.get("Content-Type") or ""
                body = response.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as error:
            detail = error.read().decode("utf-8", "replace")
            raise McpProtocolError(
                f"iOS MCP HTTP {error.code}: {clean(detail) or error.reason}"
            ) from error
        except (OSError, urllib.error.URLError) as error:
            raise McpProtocolError(f"iOS MCP 请求失败：{clean(error)}") from error
        if not body.strip():
            return None
        if "text/event-stream" in content_type.lower():
            return _select_sse_response(body, payload.get("id"))
        try:
            data = json.loads(body)
        except json.JSONDecodeError as error:
            raise McpProtocolError("iOS MCP 返回了无效 JSON") from error
        if not isinstance(data, dict):
            raise McpProtocolError("iOS MCP 返回格式异常")
        return data


def _tool_text(result: dict[str, Any]) -> str:
    content = result.get("content")
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text":
            text = str(item.get("text") or "").strip()
            if text:
                parts.append(text)
    return "\n".join(parts)


def _select_sse_response(body: str, request_id: Any) -> dict[str, Any] | None:
    selected: dict[str, Any] | None = None
    for block in body.replace("\r\n", "\n").split("\n\n"):
        data_lines = [line[5:].lstrip() for line in block.splitlines() if line.startswith("data:")]
        if not data_lines:
            continue
        try:
            event = json.loads("\n".join(data_lines))
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict) and (request_id is None or event.get("id") == request_id):
            selected = event
    return selected


def discover_mcp_ports() -> list[int]:
    ports: set[int] = set()
    try:
        import psutil  # type: ignore

        for connection in psutil.net_connections(kind="tcp"):
            if connection.status != getattr(psutil, "CONN_LISTEN", "LISTEN"):
                continue
            port = to_int(getattr(connection.laddr, "port", 0))
            if 0 < port < 65536:
                ports.add(port)
    except Exception:
        try:
            output = subprocess.run(
                ["netstat", "-ano", "-p", "TCP"],
                capture_output=True,
                text=True,
                timeout=12,
                check=False,
                encoding="utf-8",
                errors="replace",
            ).stdout
        except OSError:
            output = ""
        for line in output.splitlines():
            match = re.search(r"\bTCP\s+\S+:(\d+)\s+\S+\s+LISTENING\b", line, re.IGNORECASE)
            if match:
                ports.add(to_int(match.group(1)))
    return sorted(port for port in ports if 1024 <= port <= 65535)


def probe_mcp(base_url: str) -> dict[str, Any] | None:
    try:
        request = urllib.request.Request(
            f"{base_url}/health", headers={"Accept": "application/json"}, method="GET"
        )
        with urllib.request.urlopen(request, timeout=0.45) as response:
            payload = json.loads(response.read().decode("utf-8", "replace"))
    except Exception:
        return None
    if isinstance(payload, dict) and payload.get("server") == "ios-mcp":
        return payload
    return None


def discover_mcp_base_url() -> str:
    ports = discover_mcp_ports()
    if not ports:
        raise ExtractionError("没有发现本机 iOS MCP 监听端口，请先打开群控小助手并选中手机")
    found: list[tuple[str, dict[str, Any]]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=48) as pool:
        jobs = {
            pool.submit(probe_mcp, f"http://127.0.0.1:{port}"): port
            for port in ports
        }
        for job in concurrent.futures.as_completed(jobs):
            health = job.result()
            if health:
                found.append((f"http://127.0.0.1:{jobs[job]}", health))
    if not found:
        raise ExtractionError(
            "没有端口响应 iOS MCP。请确认群控小助手已显示“可用”，手机已解锁且 USB 保持连接"
        )
    if len(found) > 1:
        listing = "，".join(f"{url} ({item.get('version', '?')})" for url, item in found)
        raise ExtractionError(f"发现多台手机控制端口：{listing}；请用 --port 指定其中一台")
    return found[0][0]


@dataclass(slots=True)
class TextHit:
    text: str
    x: int | None
    y: int | None
    confidence: float | None = None
    source: str = "ocr"


@dataclass(slots=True)
class ScreenState:
    frontmost_bundle: str
    frontmost_name: str
    texts: list[TextHit]
    elements: list[dict[str, Any]]
    raw_ocr: Any


def _point(value: Any) -> tuple[int, int] | None:
    if isinstance(value, dict):
        x = to_float(value.get("x", value.get("X")))
        y = to_float(value.get("y", value.get("Y")))
        if x is not None and y is not None:
            return round(x), round(y)
    if isinstance(value, (list, tuple)) and len(value) >= 2:
        x = to_float(value[0])
        y = to_float(value[1])
        if x is not None and y is not None:
            return round(x), round(y)
    return None


def _center(value: Any) -> tuple[int, int] | None:
    if isinstance(value, dict):
        point = _point(value.get("center_point") or value.get("center"))
        if point:
            return point
        x = to_float(value.get("x"))
        y = to_float(value.get("y"))
        width = to_float(value.get("width"))
        height = to_float(value.get("height"))
        if None not in (x, y, width, height):
            return round(x + width / 2), round(y + height / 2)
        left = to_float(value.get("left"))
        top = to_float(value.get("top"))
        right = to_float(value.get("right"))
        bottom = to_float(value.get("bottom"))
        if None not in (left, top, right, bottom):
            return round((left + right) / 2), round((top + bottom) / 2)
    if isinstance(value, (list, tuple)):
        if len(value) >= 4:
            coords = [to_float(item) for item in value[:4]]
            if all(item is not None for item in coords):
                x, y, width, height = coords
                return round(x + width / 2), round(y + height / 2)
        return _point(value)
    return None


def _collect_text_hits(value: Any, source: str = "ocr") -> list[TextHit]:
    hits: list[TextHit] = []

    def visit(node: Any) -> None:
        if isinstance(node, dict):
            text = str(node.get("text") or node.get("label") or node.get("title") or "").strip()
            if text:
                point = (
                    _point(node.get("tap"))
                    or _point(node.get("tap_point"))
                    or _point(node.get("hit_test_point"))
                    or _point(node.get("center_point"))
                    or _center(node.get("rect"))
                    or _center(node.get("frame"))
                    or _center(node.get("visible_rect"))
                )
                hits.append(
                    TextHit(
                        text=text,
                        x=point[0] if point else None,
                        y=point[1] if point else None,
                        confidence=to_float(node.get("confidence")),
                        source=source,
                    )
                )
            for child in node.values():
                if isinstance(child, (dict, list)):
                    visit(child)
        elif isinstance(node, list):
            for item in node:
                visit(item)

    visit(value)
    unique: dict[tuple[str, int | None, int | None], TextHit] = {}
    for hit in hits:
        key = (clean(hit.text, 300).casefold(), hit.x, hit.y)
        unique.setdefault(key, hit)
    return list(unique.values())


def normalize_text(value: str) -> str:
    return re.sub(r"[\s\W_]+", "", value, flags=re.UNICODE).casefold()


def decode_filename(value: str) -> str:
    return urllib.parse.unquote(value).replace("\u3000", " ").strip()


def filename_title_candidates(name: str) -> list[str]:
    stem = decode_filename(Path(name).stem)
    values = {stem, re.sub(r"[_\-.]+", " ", stem)}
    return [value.strip() for value in values if len(normalize_text(value)) >= 4]


def safe_filename(value: str, *, max_length: int = 180) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", decode_filename(value)).strip(" .")
    if not value:
        value = "video"
    if len(value) > max_length:
        suffix = Path(value).suffix[:16]
        stem = Path(value).stem[: max_length - 40]
        value = stem + "-" + hashlib.sha1(value.encode("utf-8")).hexdigest()[:12] + suffix
    return value


class PhoneScreen:
    def __init__(
        self,
        client: McpClient,
        output_dir: Path,
        *,
        ocr_engine: str,
        min_confidence: float,
    ) -> None:
        self.client = client
        self.output_dir = output_dir
        self.diagnostic_dir = output_dir / "诊断截图"
        self.diagnostic_dir.mkdir(parents=True, exist_ok=True)
        self.ocr_engine = ocr_engine
        self.min_confidence = min_confidence
        self.width, self.height = self._load_screen_size()

    def _load_screen_size(self) -> tuple[int, int]:
        info = self.client.tool_value("get_screen_info", {})
        if not isinstance(info, dict):
            raise ExtractionError("iOS MCP 没有返回屏幕信息")
        width = to_int(info.get("width") or info.get("screenWidth"))
        height = to_int(info.get("height") or info.get("screenHeight"))
        if width <= 0 or height <= 0:
            raise ExtractionError("iOS MCP 返回的屏幕尺寸无效")
        return width, height

    def ensure_awake_and_unlocked(self) -> None:
        self.client.tool_value("wake_and_home", {"sequence": "auto"})
        time.sleep(0.5)
        info = self.client.tool_value("get_screen_info", {})
        state = info.get("device_state") if isinstance(info, dict) else None
        if isinstance(state, dict) and state.get("locked") is True:
            raise ExtractionError("手机仍处于锁屏状态。请先解锁并保持屏幕点亮，再重新运行")
        if isinstance(state, dict) and state.get("screen_on") is False:
            raise ExtractionError("手机屏幕处于关闭状态，请手动点亮并解锁后重试")

    def frontmost(self) -> tuple[str, str]:
        value = self.client.tool_value("get_frontmost_app", {})
        if not isinstance(value, dict):
            return "", ""
        bundle = str(value.get("bundleId") or value.get("bundle_id") or "")
        name = str(value.get("name") or value.get("displayName") or value.get("display_name") or "")
        return bundle, name

    def go_home(self) -> None:
        for _ in range(3):
            self.client.tool_value("press_home", {"duration_ms": 90})
            time.sleep(0.65)
            bundle, name = self.frontmost()
            if "springboard" in bundle.casefold() or "springboard" in name.casefold():
                return
        raise ExtractionError("连续按 Home 后仍未回到主屏幕")

    def capture(self, name: str) -> Path:
        path = self.diagnostic_dir / f"{datetime.now():%H%M%S}_{safe_filename(name)}.jpg"
        path.write_bytes(self.client.screenshot_jpeg())
        return path

    def ocr_value(self) -> Any:
        engines = [self.ocr_engine] if self.ocr_engine != "auto" else ["vision", "paddleocr"]
        last_error: Exception | None = None
        for engine in engines:
            try:
                return self.client.tool_value(
                    "ocr_screen",
                    {
                        "engine": engine,
                        "languages": ["zh-Hans", "en-US"],
                        "min_confidence": self.min_confidence,
                    },
                )
            except Exception as error:
                last_error = error
        try:
            return self.client.tool_value(
                "describe_screen",
                {"include_ocr": True, "include_screenshot": False, "engine": "vision"},
            )
        except Exception:
            if last_error is not None:
                raise ExtractionError(f"屏幕 OCR 失败：{clean(last_error)}") from last_error
            raise

    def elements(self) -> list[dict[str, Any]]:
        value = self.client.tool_value(
            "get_ui_elements",
            {"visible_only": True, "clickable_only": False, "max_elements": 2000},
        )
        if isinstance(value, dict) and isinstance(value.get("elements"), list):
            return [item for item in value["elements"] if isinstance(item, dict)]
        return []

    def look(self, *, name: str = "screen", save_screenshot: bool = False) -> ScreenState:
        raw = self.ocr_value()
        bundle, app_name = self.frontmost()
        texts = _collect_text_hits(raw)
        elements = self.elements()
        if not texts:
            texts = _collect_text_hits(elements, "accessibility")
        if save_screenshot:
            self.capture(name)
            (self.diagnostic_dir / f"{name}_ocr.json").write_bytes(json_bytes(raw))
        return ScreenState(bundle, app_name, texts, elements, raw)

    def find_text(self, state: ScreenState, wanted: str) -> TextHit | None:
        target = normalize_text(wanted)
        exact = [
            hit for hit in state.texts
            if normalize_text(hit.text) == target and hit.x is not None and hit.y is not None
        ]
        if exact:
            return exact[0]
        partial = [
            hit for hit in state.texts
            if target in normalize_text(hit.text) and hit.x is not None and hit.y is not None
        ]
        return min(partial, key=lambda item: len(item.text)) if partial else None

    def tap(self, x: int, y: int) -> None:
        self.client.tool_value("tap_screen", {"x": x, "y": y})
        time.sleep(0.7)

    def long_press(self, x: int, y: int, duration_ms: int = 850) -> None:
        self.client.tool_value("long_press", {"x": x, "y": y, "duration_ms": duration_ms})
        time.sleep(0.65)

    def swipe(self, direction: str, *, duration_ms: int = 380, y_ratio: float = 0.62) -> None:
        if direction == "left":
            start_x, end_x = round(self.width * 0.84), round(self.width * 0.16)
            start_y = end_y = round(self.height * y_ratio)
        elif direction == "right":
            start_x, end_x = round(self.width * 0.16), round(self.width * 0.84)
            start_y = end_y = round(self.height * y_ratio)
        elif direction == "up":
            start_x = end_x = round(self.width * 0.50)
            start_y, end_y = round(self.height * 0.76), round(self.height * 0.28)
        elif direction == "down":
            start_x = end_x = round(self.width * 0.50)
            start_y, end_y = round(self.height * 0.28), round(self.height * 0.76)
        else:
            raise ValueError(direction)
        self.client.tool_value(
            "swipe_screen",
            {
                "fromX": start_x,
                "fromY": start_y,
                "toX": end_x,
                "toY": end_y,
                "duration": duration_ms,
                "steps": 22,
            },
        )
        time.sleep(0.75)

    def page_signature(self, state: ScreenState) -> str:
        useful: list[str] = []
        for hit in state.texts:
            text = normalize_text(hit.text)
            if not text or re.fullmatch(r"(\d{1,2}[:：]\d{2}|周[一二三四五六日天]|\d+月\d+日|\d+%)", text):
                continue
            useful.append(text)
        if useful:
            return hashlib.sha1("\n".join(sorted(useful)).encode("utf-8")).hexdigest()
        try:
            return hashlib.sha1(self.client.screenshot_jpeg()).hexdigest()
        except Exception:
            return ""


def list_installed_apps(client: McpClient) -> list[dict[str, Any]]:
    value = client.tool_value("list_apps", {"filter": "user"})
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        for key in ("apps", "applications", "items"):
            apps = value.get(key)
            if isinstance(apps, list):
                return [item for item in apps if isinstance(item, dict)]
    return []


def app_matches(app: dict[str, Any], wanted: str) -> bool:
    target = normalize_text(wanted)
    names = [
        app.get("displayName"), app.get("localizedName"), app.get("name"),
        app.get("label"), app.get("bundleId"), app.get("bundle_id"),
    ]
    return any(target in normalize_text(str(value)) for value in names if value)


def find_app_from_list(client: McpClient, wanted: str) -> dict[str, Any] | None:
    matches = [app for app in list_installed_apps(client) if app_matches(app, wanted)]
    exact = [
        app for app in matches
        if any(
            normalize_text(str(app.get(key) or "")) == normalize_text(wanted)
            for key in ("displayName", "localizedName", "name", "label")
        )
    ]
    chosen = exact or matches
    unique: dict[str, dict[str, Any]] = {}
    for app in chosen:
        key = str(
            app.get("bundleId") or app.get("bundle_id") or app.get("displayName") or app.get("name") or ""
        ).casefold()
        unique.setdefault(key or str(len(unique)), app)
    chosen = list(unique.values())
    if len(chosen) > 1:
        listing = "，".join(
            f"{app.get('displayName') or app.get('name')}={app.get('bundleId') or app.get('bundle_id')}"
            for app in chosen
        )
        raise ExtractionError(f"找到多个名称相近的应用：{listing}；请用 --bundle-id 指定")
    return chosen[0] if chosen else None


def locate_and_open_app(
    screen: PhoneScreen,
    client: McpClient,
    app_name: str,
    bundle_id: str | None,
    max_pages: int,
) -> str:
    known_app = find_app_from_list(client, app_name) if not bundle_id else None
    known_bundle = bundle_id or str(
        (known_app or {}).get("bundleId") or (known_app or {}).get("bundle_id") or ""
    )
    screen.ensure_awake_and_unlocked()

    for direction in ("left", "right"):
        screen.go_home()
        seen: set[str] = set()
        for page in range(max_pages + 1):
            state = screen.look(name=f"home_{direction}_{page}", save_screenshot=True)
            hit = screen.find_text(state, app_name)
            if hit is not None and hit.x is not None and hit.y is not None:
                logging.info(
                    "OCR 在第 %d 页识别到“%s”，坐标 (%d, %d)",
                    page + 1, hit.text, hit.x, hit.y,
                )
                screen.tap(hit.x, hit.y)
                time.sleep(1.2)
                current_bundle, current_name = screen.frontmost()
                if current_bundle != state.frontmost_bundle or app_name in current_name:
                    return current_bundle or known_bundle
            signature = screen.page_signature(state)
            if signature and signature in seen:
                break
            seen.add(signature)
            screen.swipe(direction)

    if known_bundle:
        logging.warning("首页 OCR 未找到“%s”，改为按应用列表启动 %s", app_name, known_bundle)
        client.tool_value("launch_app", {"bundle_id": known_bundle})
        time.sleep(1.2)
        bundle, name = screen.frontmost()
        if bundle == known_bundle or app_name in name:
            return known_bundle
    raise ExtractionError(f"没有找到或打开“{app_name}”。请确认已安装且主屏可正常看到")


def all_strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from all_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from all_strings(child)


def get_app_roots(client: McpClient, bundle_id: str) -> list[str]:
    info = client.tool_value("get_app_info", {"bundle_id": bundle_id})
    if not isinstance(info, dict) or not info:
        raise ExtractionError(f"无法读取应用信息：{bundle_id}")
    roots: list[str] = []
    for key in ("data_container", "group_containers", "containers"):
        for value in all_strings(info.get(key)):
            normalized = posixpath.normpath(value)
            if value.startswith("/") and normalized not in roots:
                roots.append(normalized)
    if not roots:
        raise ExtractionError("应用信息中没有找到数据目录；该应用可能没有本地视频")
    return roots


@dataclass(slots=True)
class RemoteVideo:
    path: str
    size: int
    modified: str


def list_entries(client: McpClient, path: str) -> list[dict[str, Any]]:
    value = client.tool_value("list_dir", {"path": path})
    if not isinstance(value, dict) or not isinstance(value.get("entries"), list):
        return []
    return [item for item in value["entries"] if isinstance(item, dict)]


def scan_video_files(
    client: McpClient,
    roots: list[str],
    *,
    max_depth: int,
    max_files: int,
    min_size: int,
) -> list[RemoteVideo]:
    results: list[RemoteVideo] = []
    visited: set[str] = set()
    stack: list[tuple[str, int]] = [(root, 0) for root in roots]
    inspected = 0
    while stack and inspected < max_files:
        directory, depth = stack.pop()
        directory = posixpath.normpath(directory)
        if directory in visited or depth > max_depth:
            continue
        visited.add(directory)
        try:
            entries = list_entries(client, directory)
        except Exception as error:
            logging.warning("无法读取目录 %s：%s", directory, clean(error))
            continue
        for entry in entries:
            inspected += 1
            if inspected > max_files:
                break
            # File names may legitimately start or end with spaces. Stripping
            # them here changes the remote path and makes list_dir/download_file
            # disagree (the server then returns HTTP 404).
            name_value = entry.get("name")
            if not isinstance(name_value, str) or not name_value:
                continue
            name = name_value
            if name in (".", ".."):
                continue
            remote_path = str(entry.get("path") or posixpath.join(directory, name))
            entry_type = str(entry.get("type") or "").casefold()
            is_directory = entry_type in ("directory", "dir", "folder") or entry.get("is_directory") is True
            is_symlink = entry_type in ("symlink", "link") or entry.get("is_symlink") is True
            if is_symlink:
                continue
            if is_directory:
                stack.append((remote_path, depth + 1))
                continue
            if Path(name).suffix.casefold() not in VIDEO_EXTENSIONS:
                continue
            if any(marker in name.casefold() for marker in THUMBNAIL_MARKERS):
                continue
            size = to_int(entry.get("size"))
            if size and size < min_size:
                continue
            results.append(
                RemoteVideo(
                    path=remote_path,
                    size=size,
                    modified=str(entry.get("mtime") or entry.get("modified") or ""),
                )
            )
    unique: dict[str, RemoteVideo] = {}
    for item in results:
        unique.setdefault(item.path, item)
    return sorted(unique.values(), key=lambda item: (item.modified, item.path))


def path_is_under_roots(path: str, roots: list[str]) -> bool:
    normalized = posixpath.normpath(path)
    return any(
        normalized == root or normalized.startswith(root.rstrip("/") + "/")
        for root in roots
    )


def remote_file_exists(client: McpClient, path: str) -> bool:
    parent = posixpath.dirname(path)
    name = posixpath.basename(path)
    try:
        return any(str(entry.get("name") or "") == name for entry in list_entries(client, parent))
    except Exception:
        return True


def run_shell(client: McpClient, command: str, *, timeout: int = 10) -> dict[str, Any]:
    value = client.tool_value("run_command", {"command": command, "timeout": timeout})
    return value if isinstance(value, dict) else {"exitCode": 0, "output": str(value or "")}


def delete_via_shell(client: McpClient, path: str) -> tuple[bool, str]:
    quoted = shlex.quote(path)
    checks = [
        (
            "直接删除",
            f"rm -f -- {quoted}; if [ -e {quoted} ]; then echo DIRECT_DELETE_FAILED; exit 3; "
            "else echo DELETE_OK; fi",
        ),
        (
            "sudo 删除",
            f"sudo -n /bin/rm -f -- {quoted}; if [ -e {quoted} ]; then echo SUDO_DELETE_FAILED; "
            "exit 4; else echo SUDO_DELETE_OK; fi",
        ),
    ]
    messages: list[str] = []
    for label, command in checks:
        try:
            result = run_shell(client, command, timeout=10)
            exit_code = to_int(result.get("exitCode", result.get("exit_code")), -999)
            messages.append(f"{label}: exit={exit_code} {clean(result.get('output'), 500)}")
            if exit_code == 0 and not remote_file_exists(client, path):
                return True, f"{label}成功"
        except Exception as error:
            messages.append(f"{label}异常: {clean(error)}")
    return False, "；".join(messages)


def load_delete_mapping(path: Path | None) -> dict[str, str]:
    if path is None or not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ExtractionError(f"删除标题映射读取失败：{clean(error)}") from error
    if not isinstance(value, dict):
        raise ExtractionError("删除标题映射必须是 JSON 对象")
    return {str(key): str(title) for key, title in value.items()}


def find_unique_text_hit(state: ScreenState, candidates: list[str]) -> TextHit | None:
    normalized_candidates = [normalize_text(item) for item in candidates if normalize_text(item)]
    matches: list[TextHit] = []
    for hit in state.texts:
        if hit.x is None or hit.y is None:
            continue
        normalized = normalize_text(hit.text)
        if any(candidate in normalized for candidate in normalized_candidates):
            matches.append(hit)
    unique = {(hit.text, hit.x, hit.y): hit for hit in matches}
    return next(iter(unique.values())) if len(unique) == 1 else None

def find_title_with_scroll(
    screen: PhoneScreen,
    candidates: list[str],
    *,
    max_steps: int = 6,
) -> TextHit | None:
    state = screen.look(name="delete_find_item", save_screenshot=True)
    hit = find_unique_text_hit(state, candidates)
    if hit is not None:
        return hit
    for direction in ("up", "down"):
        for _ in range(max_steps):
            screen.swipe(direction, duration_ms=320)
            state = screen.look(name=f"delete_scan_{direction}", save_screenshot=False)
            hit = find_unique_text_hit(state, candidates)
            if hit is not None:
                return hit
    return None


def tap_any_label(screen: PhoneScreen, labels: tuple[str, ...], *, name: str) -> bool:
    state = screen.look(name=name)
    for label in labels:
        hit = screen.find_text(state, label)
        if hit is not None and hit.x is not None and hit.y is not None:
            screen.tap(hit.x, hit.y)
            return True
    return False


def target_still_visible(screen: PhoneScreen, client: McpClient, remote_path: str, text: str) -> bool:
    state = screen.look(name="delete_verify", save_screenshot=True)
    ocr_still_visible = any(normalize_text(item.text) == normalize_text(text) for item in state.texts)
    return ocr_still_visible or remote_file_exists(client, remote_path)


def delete_via_ui(
    screen: PhoneScreen,
    client: McpClient,
    bundle_id: str,
    remote_path: str,
    title: str | None,
) -> tuple[bool, str]:
    candidates = [title] if title else []
    candidates.extend(filename_title_candidates(posixpath.basename(remote_path)))
    candidates = [item for item in candidates if item]
    screen.ensure_awake_and_unlocked()
    if screen.frontmost()[0] != bundle_id:
        client.tool_value("launch_app", {"bundle_id": bundle_id})
        time.sleep(1.0)

    hit = find_title_with_scroll(screen, candidates)
    if hit is None:
        return False, "页面上没有唯一匹配的视频标题，为避免误删已跳过界面删除"
    assert hit.x is not None and hit.y is not None
    original_text = hit.text

    screen.long_press(hit.x, hit.y)
    acted = tap_any_label(screen, DELETE_LABELS, name="delete_menu")
    if not acted:
        screen.swipe("left", duration_ms=300, y_ratio=max(0.1, min(0.9, hit.y / screen.height)))
        acted = tap_any_label(screen, DELETE_LABELS, name="delete_menu_after_swipe")
    if not acted:
        return False, "长按或左滑后没有识别到删除按钮"

    time.sleep(0.8)
    if not target_still_visible(screen, client, remote_path, original_text):
        return True, "界面删除并复核成功"
    if tap_any_label(screen, CONFIRM_LABELS, name="delete_confirm"):
        time.sleep(1.0)
    if not target_still_visible(screen, client, remote_path, original_text):
        return True, "界面确认删除并复核成功"
    return False, "执行删除后仍能识别到该视频或原文件"


def free_space_ok(output_dir: Path, required: int) -> bool:
    try:
        free = shutil.disk_usage(output_dir).free
    except OSError:
        return True
    return free >= required + max(64 * 1024 * 1024, required // 5)


def download_and_verify(client: McpClient, remote: RemoteVideo, output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    local_name = safe_filename(posixpath.basename(remote.path))
    local_path = output_dir / local_name
    if local_path.exists():
        local_path = output_dir / (
            Path(local_name).stem
            + "-"
            + hashlib.sha1(remote.path.encode("utf-8")).hexdigest()[:10]
            + Path(local_name).suffix
        )
    temporary = local_path.with_name(local_path.name + ".part")
    if not free_space_ok(output_dir, remote.size):
        raise ExtractionError("本机磁盘剩余空间不足")
    metadata = client.download_file(remote.path, temporary, expected_size=remote.size)
    os.replace(temporary, local_path)
    return {
        "remote_path": remote.path,
        "local_path": str(local_path),
        "expected_size": remote.size,
        "size": metadata["size"],
        "sha256": metadata["sha256"],
        "modified": remote.modified,
        "verified": remote.size <= 0 or metadata["size"] == remote.size,
        "downloaded_at": now_text(),
        "deleted": False,
        "delete_detail": "",
    }


def write_manifest(path: Path, records: list[dict[str, Any]]) -> None:
    atomic_write_json(
        path,
        {"updated_at": now_text(), "record_count": len(records), "records": records},
    )


def load_manifest_records(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    records = value.get("records") if isinstance(value, dict) else None
    return [item for item in records if isinstance(item, dict)] if isinstance(records, list) else []


def delete_remote_source(
    screen: PhoneScreen,
    client: McpClient,
    bundle_id: str,
    video: RemoteVideo,
    delete_mapping: dict[str, str],
    delete_mode: str,
) -> tuple[bool, str]:
    filename = posixpath.basename(video.path)
    title = delete_mapping.get(video.path) or delete_mapping.get(filename)
    deleted = False
    detail = ""
    if delete_mode in ("auto", "ui"):
        try:
            deleted, detail = delete_via_ui(screen, client, bundle_id, video.path, title)
        except Exception as error:
            detail = f"界面删除异常：{clean(error)}"
        logging.info("界面删除：%s", detail)
    if not deleted and delete_mode in ("auto", "shell"):
        deleted, detail = delete_via_shell(client, video.path)
        logging.info("命令行删除：%s", detail)
    return deleted, detail


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    script_file = Path(__file__).resolve()
    project_root = script_file.parents[1] if len(script_file.parents) >= 2 else Path.cwd()
    parser = argparse.ArgumentParser(
        description="通过群控小助手的 iOS MCP 提取万能联播视频，校验后删除源文件"
    )
    parser.add_argument("--port", type=int, help="群控小助手当前手机的本地 MCP 端口")
    parser.add_argument("--base-url", help="例如 http://127.0.0.1:52341")
    parser.add_argument("--app-name", default=DEFAULT_APP_NAME)
    parser.add_argument("--bundle-id", help="万能联播的 bundle id；名称识别失败时使用")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_root / "work" / "万能联播视频",
        help="视频、清单和诊断截图保存目录",
    )
    parser.add_argument("--max-home-pages", type=int, default=6)
    parser.add_argument("--max-depth", type=int, default=14)
    parser.add_argument("--max-files", type=int, default=30000)
    parser.add_argument("--min-size-mb", type=float, default=0.5)
    parser.add_argument("--ocr-engine", choices=("auto", "vision", "paddleocr"), default="auto")
    parser.add_argument("--min-confidence", type=float, default=0.30)
    parser.add_argument(
        "--delete-mode",
        choices=("auto", "ui", "shell", "none"),
        default="auto",
        help="auto=先界面后命令行；none=只下载不删除",
    )
    parser.add_argument("--delete-mapping", type=Path, help="文件名到界面标题的 JSON 映射")
    parser.add_argument(
        "--inspect-only",
        action="store_true",
        help="只识别 App/视频并保存截图，不下载、不删除",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="读取输出目录已有 manifest，跳过已下载并校验成功的文件",
    )
    return parser.parse_args(argv)


def configure_logging(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    logger.addHandler(console)
    file_handler = logging.FileHandler(output_dir / "extraction.log", encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    output_dir = args.output_dir.resolve()
    configure_logging(output_dir)
    manifest_path = output_dir / "manifest.json"
    if args.base_url:
        base_url = args.base_url.rstrip("/")
    elif args.port:
        base_url = f"http://127.0.0.1:{args.port}"
    else:
        base_url = discover_mcp_base_url()
    logging.info("连接 iOS MCP：%s", base_url)
    client = McpClient(base_url)
    records = load_manifest_records(manifest_path) if args.resume else []
    record_index = {
        str(item.get("remote_path") or ""): index
        for index, item in enumerate(records)
        if item.get("remote_path")
    }

    def store_record(record: dict[str, Any]) -> None:
        remote_path = str(record.get("remote_path") or "")
        if remote_path and remote_path in record_index:
            records[record_index[remote_path]] = record
        else:
            records.append(record)
            if remote_path:
                record_index[remote_path] = len(records) - 1
    try:
        client.connect()
        logging.info("iOS MCP %s 已连接", client.server_version or "未知版本")
        screen = PhoneScreen(
            client, output_dir,
            ocr_engine=args.ocr_engine,
            min_confidence=args.min_confidence,
        )
        bundle_id = locate_and_open_app(
            screen, client, args.app_name, args.bundle_id,
            max(1, min(args.max_home_pages, 12)),
        )
        bundle_id = bundle_id or screen.frontmost()[0]
        if not bundle_id:
            raise ExtractionError("已进入应用但没有取得 bundle id")
        logging.info("已识别并打开 %s，bundle id=%s", args.app_name, bundle_id)

        page_state = screen.look(name="app_opened", save_screenshot=True)
        logging.info("应用页面 OCR：%s", " | ".join(hit.text for hit in page_state.texts[:30]))
        roots = get_app_roots(client, bundle_id)
        logging.info("应用数据目录：%s", " | ".join(roots))
        videos = scan_video_files(
            client, roots,
            max_depth=max(1, min(args.max_depth, 30)),
            max_files=max(100, args.max_files),
            min_size=max(0, round(args.min_size_mb * 1024 * 1024)),
        )
        logging.info("识别到 %d 个视频文件", len(videos))
        for item in videos:
            logging.info("视频 %.2f MB %s", item.size / 1024 / 1024, item.path)
        if not videos:
            raise ExtractionError("没有在应用容器中找到视频文件，请查看诊断截图和日志")

        delete_mapping = load_delete_mapping(args.delete_mapping)
        for index, video in enumerate(videos, start=1):
            if not path_is_under_roots(video.path, roots):
                raise ExtractionError(f"拒绝处理应用目录之外的路径：{video.path}")
            logging.info("处理 %d/%d：%s", index, len(videos), video.path)
            previous = (
                records[record_index[video.path]]
                if args.resume and video.path in record_index
                else None
            )
            if previous:
                local_value = str(previous.get("local_path") or "")
                local_path = Path(local_value) if local_value else None
                if (
                    local_path is not None
                    and local_path.is_file()
                    and local_path.stat().st_size == video.size
                    and bool(previous.get("verified"))
                ):
                    record = dict(previous)
                    if (
                        not args.inspect_only
                        and args.delete_mode != "none"
                        and not bool(record.get("deleted"))
                    ):
                        deleted, detail = delete_remote_source(
                            screen,
                            client,
                            bundle_id,
                            video,
                            delete_mapping,
                            args.delete_mode,
                        )
                        record["deleted"] = deleted
                        record["delete_detail"] = detail
                    store_record(record)
                    write_manifest(manifest_path, records)
                    logging.info("断点续跑：已下载且校验通过，跳过重复下载 %s", video.path)
                    continue
            if args.inspect_only:
                store_record({
                    "remote_path": video.path,
                    "size": video.size,
                    "modified": video.modified,
                    "inspected": True,
                })
                write_manifest(manifest_path, records)
                continue
            try:
                record = download_and_verify(client, video, output_dir)
            except Exception as error:
                store_record({
                    "remote_path": video.path,
                    "size": video.size,
                    "verified": False,
                    "error": clean(error, 2000),
                    "downloaded_at": now_text(),
                    "deleted": False,
                })
                write_manifest(manifest_path, records)
                logging.error("下载失败，源文件保留：%s；%s", video.path, clean(error))
                continue

            store_record(record)
            write_manifest(manifest_path, records)
            if not record["verified"]:
                logging.error("大小校验失败，不删除源文件：%s", video.path)
                continue
            if args.delete_mode == "none":
                logging.info("已保留源文件（--delete-mode none）")
                continue

            deleted, detail = delete_remote_source(
                screen,
                client,
                bundle_id,
                video,
                delete_mapping,
                args.delete_mode,
            )
            if not deleted:
                logging.error("源文件未删除，已保留下载文件：%s；%s", video.path, detail)
            record["deleted"] = deleted
            record["delete_detail"] = detail
            write_manifest(manifest_path, records)

        downloaded = [item for item in records if item.get("local_path")]
        deleted_count = sum(1 for item in records if item.get("deleted"))
        delete_requested = not args.inspect_only and args.delete_mode != "none"
        has_errors = any(item.get("error") for item in records)
        deletion_incomplete = delete_requested and any(
            item.get("local_path") and not item.get("deleted") for item in records
        )
        success = not has_errors and not deletion_incomplete
        report = {
            "success": success,
            "delete_requested": delete_requested,
            "mode": "inspect" if args.inspect_only else "extract",
            "app_name": args.app_name,
            "bundle_id": bundle_id,
            "finished_at": now_text(),
            "output_dir": str(output_dir),
            "video_count": len(videos),
            "downloaded_count": len(downloaded),
            "deleted_count": deleted_count,
            "records": records,
        }
        atomic_write_json(output_dir / "report.json", report)
        logging.info(
            "完成：识别 %d，下载 %d，删除 %d，结果=%s；报告 %s",
            len(videos), len(downloaded), deleted_count,
            "成功" if success else "未全部完成",
            output_dir / "report.json",
        )
        return 0 if success else 2
    except KeyboardInterrupt:
        logging.warning("用户中止")
        return 130
    except Exception as error:
        logging.exception("任务失败：%s", clean(error))
        try:
            atomic_write_json(
                output_dir / "failure.json",
                {"finished_at": now_text(), "error": clean(error, 3000)},
            )
        except Exception:
            pass
        return 1
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
