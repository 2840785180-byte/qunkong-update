[CmdletBinding()]
param(
    [switch]$CheckOnly,
    [switch]$SkipLaunchCheck
)

$ErrorActionPreference = "Stop"
try {
    $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $Utf8NoBom
    [Console]::InputEncoding = $Utf8NoBom
    $OutputEncoding = $Utf8NoBom
}
catch {
}
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptRoot
$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"
$Requirements = Join-Path $ProjectRoot "requirements-dev.txt"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Test-PythonCandidate {
    param(
        [string]$Command,
        [string[]]$PrefixArguments
    )

    $probe = "import sys; raise SystemExit(0 if (3, 11) <= sys.version_info[:2] < (3, 13) else 1)"
    & $Command @PrefixArguments -c $probe 2>$null
    return ($LASTEXITCODE -eq 0)
}

function Resolve-BasePython {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($null -ne $py) {
        foreach ($version in @("-3.12", "-3.11")) {
            if (Test-PythonCandidate -Command $py.Source -PrefixArguments @($version)) {
                return [pscustomobject]@{
                    Command = $py.Source
                    PrefixArguments = @($version)
                }
            }
        }
    }

    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($null -ne $python) {
        if (Test-PythonCandidate -Command $python.Source -PrefixArguments @()) {
            return [pscustomobject]@{
                Command = $python.Source
                PrefixArguments = @()
            }
        }
    }

    return $null
}

function Invoke-ProjectPython {
    param([string[]]$Arguments)
    & $VenvPython @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Python command failed with exit code ${LASTEXITCODE}: $($Arguments -join ' ')"
    }
}

function Test-AppleService {
    $service = Get-Service -Name "Apple Mobile Device Service" -ErrorAction SilentlyContinue
    if ($null -eq $service) {
        throw "Apple Mobile Device Service was not found. Install iTunes or Apple Devices first."
    }
    if ($service.Status -ne "Running") {
        Write-Warning "Apple Mobile Device Service is installed but not running. Start it before connecting an iPhone."
    }
    else {
        Write-Host "Apple Mobile Device Service: Running" -ForegroundColor Green
    }
}

function Install-DesktopShortcut {
    $Pythonw = Join-Path $VenvDir "Scripts\pythonw.exe"
    $IconPath = Join-Path $ProjectRoot "resources\ic20.ico"
    if (-not (Test-Path -LiteralPath $Pythonw)) {
        throw "pythonw.exe was not found after installation: $Pythonw"
    }

    $Desktop = [Environment]::GetFolderPath("Desktop")
    if ([string]::IsNullOrWhiteSpace($Desktop)) {
        throw "The Windows desktop folder could not be resolved."
    }

    $ConnectorFolderName = ([string][char]0x8FDE) + [char]0x63A5 + [char]0x5668
    $ConnectorFolder = Join-Path $Desktop $ConnectorFolderName
    New-Item -ItemType Directory -Force -Path $ConnectorFolder | Out-Null
    $ShortcutName = ([string][char]0x542F) + [char]0x52A8 + [char]0x8FDE + [char]0x63A5 + [char]0x5668 + ".lnk"
    $ShortcutPath = Join-Path $ConnectorFolder $ShortcutName
    $Shell = New-Object -ComObject WScript.Shell
    $Shortcut = $Shell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $Pythonw
    $Shortcut.Arguments = "-m iphone_control_center.panel_main"
    $Shortcut.WorkingDirectory = $ProjectRoot
    if (Test-Path -LiteralPath $IconPath) {
        $Shortcut.IconLocation = "$IconPath,0"
    }
    $Shortcut.Description = "iPhone Control Center 20 - three-step setup and live test"
    $Shortcut.WindowStyle = 1
    $Shortcut.Save()
    Write-Host "Desktop connector folder: $ConnectorFolder" -ForegroundColor Green
    Write-Host "Desktop shortcut: $ShortcutPath" -ForegroundColor Green
}

Write-Host "iPhone Control Center 20 - one-click installer" -ForegroundColor Green
Write-Host "Project: $ProjectRoot"

if ($CheckOnly) {
    Write-Step "Checking the existing environment"
    if (-not (Test-Path -LiteralPath $VenvPython)) {
        throw "Project virtual environment is missing: $VenvPython"
    }
    Invoke-ProjectPython -Arguments @(
        "-c",
        "import PySide6, pymobiledevice3, psutil; print('Python dependencies: OK')"
    )
    Test-AppleService
    Write-Host "Environment check completed." -ForegroundColor Green
    exit 0
}

if (-not (Test-Path -LiteralPath $VenvPython)) {
    Write-Step "Creating the Python virtual environment"
    $basePython = Resolve-BasePython
    if ($null -eq $basePython) {
        throw "Python 3.11 or 3.12 was not found. Install Python 3.12 x64 and retry."
    }
    & $basePython.Command @($basePython.PrefixArguments + @("-m", "venv", $VenvDir))
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to create .venv with exit code $LASTEXITCODE."
    }
}

Push-Location $ProjectRoot
try {
    Write-Step "Upgrading pip"
    Invoke-ProjectPython -Arguments @("-m", "pip", "install", "--upgrade", "pip")

    Write-Step "Installing runtime and test dependencies"
    Invoke-ProjectPython -Arguments @("-m", "pip", "install", "-r", $Requirements)

    Write-Step "Installing this project in editable mode"
    Invoke-ProjectPython -Arguments @("-m", "pip", "install", "-e", ".", "--no-deps")

    Write-Step "Creating the desktop shortcut"
    Install-DesktopShortcut

    Write-Step "Compiling Python sources"
    Invoke-ProjectPython -Arguments @("-m", "compileall", "-q", "src", "tests", "scripts")

    Test-AppleService

    if (-not $SkipLaunchCheck) {
        Write-Step "Running a short GUI startup self-check"
        $oldPath = $env:PYTHONPATH
        $oldPlatform = $env:QT_QPA_PLATFORM
        try {
            $env:PYTHONPATH = Join-Path $ProjectRoot "src"
            $env:QT_QPA_PLATFORM = "offscreen"
            $smokeData = Join-Path $ProjectRoot "work\\install_smoke_data"
            Invoke-ProjectPython -Arguments @("-m", "iphone_control_center", "--smoke-test", "2", "--data-dir", $smokeData)
            Invoke-ProjectPython -Arguments @("-m", "iphone_control_center.panel_main", "--smoke-test", "2")
        }
        finally {
            $env:PYTHONPATH = $oldPath
            $env:QT_QPA_PLATFORM = $oldPlatform
        }
    }

    Write-Host ""
    Write-Host "Installation completed successfully." -ForegroundColor Green
    Write-Host "Start the GUI:   scripts\run.bat"
    Write-Host "Run live tests:  scripts\test-live.cmd"
}
finally {
    Pop-Location
}
